	.file	"abla"
	.section	.text.abla_runtime_set_arguments,"ax",@progbits
	.hidden	abla_runtime_set_arguments      # -- Begin function abla_runtime_set_arguments
	.global	abla_runtime_set_arguments
	.p2align	2
	.type	abla_runtime_set_arguments,@function
abla_runtime_set_arguments:             # @abla_runtime_set_arguments
# %bb.0:                                # %entry
	entry	a1, 32
	retw.n
.Lfunc_end0:
	.size	abla_runtime_set_arguments, .Lfunc_end0-abla_runtime_set_arguments
                                        # -- End function
	.section	.text.abla_fn_334943840_569200394_direct,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_334943840_569200394_direct
	.type	abla_fn_334943840_569200394_direct,@function
abla_fn_334943840_569200394_direct:     # @abla_fn_334943840_569200394_direct
# %bb.0:                                # %entry
	entry	a1, 32
	movi	a8, 0
	beq	a4, a8, .LBB1_2
.LBB1_1:                                # %source.label2
                                        # =>This Inner Loop Header: Depth=1
	add	a9, a2, a8
	add	a10, a3, a8
	l8ui	a10, a10, 0
	s8i	a10, a9, 0
	addi	a8, a8, 1
	bne	a4, a8, .LBB1_1
.LBB1_2:                                # %source.label3
	retw.n
.Lfunc_end1:
	.size	abla_fn_334943840_569200394_direct, .Lfunc_end1-abla_fn_334943840_569200394_direct
                                        # -- End function
	.literal_position
	.literal .LCPI2_0, -1074200576
	.literal .LCPI2_1, 327680
	.literal .LCPI2_2, 16843009
	.section	.text.abla_fn_334943840_569200394_direct,"ax",@progbits
	.section	.text.abla_fn_853840267_528021067_direct,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_853840267_528021067_direct
	.type	abla_fn_853840267_528021067_direct,@function
abla_fn_853840267_528021067_direct:     # @abla_fn_853840267_528021067_direct
# %bb.0:                                # %entry
	entry	a1, 32
	l32r	a8, .LCPI2_0
	add	a8, a2, a8
	l32r	a9, .LCPI2_1
	bltu	a8, a9, .LBB2_1
	j	.LBB2_9
.LBB2_1:                                # %source.label10
	slli	a9, a2, 3
	movi	a10, 24
	movi	a11, 255
	movi	a12, -1
	movi	a13, -4
	or	a8, a2, a2
.LBB2_2:                                # %source.label15
                                        # =>This Inner Loop Header: Depth=1
	extui	a14, a8, 0, 2
	beqz.n	a14, .LBB2_4
# %bb.3:                                # %source.label20
                                        #   in Loop: Header=BB2_2 Depth=1
	slli	a14, a8, 3
	and	a14, a14, a10
	ssl	a14
	sll	a15, a11
	xor	a15, a15, a12
	and	a7, a8, a13
	l32i	a6, a7, 0
	and	a15, a6, a15
	ssl	a14
	sll	a14, a3
	or	a14, a15, a14
	memw
	s32i	a14, a7, 0
	addi	a9, a9, 8
	addi	a8, a8, 1
	j	.LBB2_2
.LBB2_4:                                # %source.label26.preheader
	l32r	a10, .LCPI2_2
	mull	a11, a3, a10
	neg	a10, a2
	extui	a10, a10, 0, 2
	sub	a10, a4, a10
	movi	a12, 0
	movi	a13, 3
	bgeu	a13, a10, .LBB2_6
.LBB2_5:                                # %source.label27
                                        # =>This Inner Loop Header: Depth=1
	memw
	s32i	a11, a8, 0
	addi	a12, a12, -32
	addi	a10, a10, -4
	addi	a8, a8, 4
	bltu	a13, a10, .LBB2_5
.LBB2_6:                                # %source.label29.preheader
	sub	a9, a9, a12
	movi	a11, 0
	movi	a12, 24
	movi	a13, 255
	movi	a14, -1
	movi	a15, -4
	beq	a10, a11, .LBB2_8
.LBB2_7:                                # %source.label30
                                        # =>This Inner Loop Header: Depth=1
	add	a7, a8, a11
	and	a6, a9, a12
	ssl	a6
	sll	a5, a13
	xor	a5, a5, a14
	and	a7, a7, a15
	l32i	a4, a7, 0
	and	a5, a4, a5
	ssl	a6
	sll	a6, a3
	or	a6, a5, a6
	memw
	s32i	a6, a7, 0
	addi	a9, a9, 8
	addi	a11, a11, 1
	bne	a10, a11, .LBB2_7
.LBB2_8:                                # %common.ret
	retw.n
.LBB2_9:
	or	a8, a2, a2
	beqz	a4, .LBB2_8
.LBB2_10:                               # %source.label39
                                        # =>This Inner Loop Header: Depth=1
	s8i	a3, a8, 0
	addi	a4, a4, -1
	addi	a8, a8, 1
	beqz	a4, .LBB2_8
	j	.LBB2_10
.Lfunc_end2:
	.size	abla_fn_853840267_528021067_direct, .Lfunc_end2-abla_fn_853840267_528021067_direct
                                        # -- End function
	.section	.text.abla_fn_934637158_713051631_direct,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_934637158_713051631_direct
	.type	abla_fn_934637158_713051631_direct,@function
abla_fn_934637158_713051631_direct:     # @abla_fn_934637158_713051631_direct
# %bb.0:                                # %entry
	entry	a1, 32
.LBB3_1:                                # %source.label
                                        # =>This Inner Loop Header: Depth=1
	l8ui	a9, a3, 0
	l8ui	a8, a2, 0
	bne	a8, a9, .LBB3_4
# %bb.2:                                # %source.label6
                                        #   in Loop: Header=BB3_1 Depth=1
	addi	a2, a2, 1
	addi	a3, a3, 1
	bnez	a8, .LBB3_1
# %bb.3:
	movi	a2, 0
	retw.n
.LBB3_4:                                # %source.label4
	sub	a2, a8, a9
	retw.n
.Lfunc_end3:
	.size	abla_fn_934637158_713051631_direct, .Lfunc_end3-abla_fn_934637158_713051631_direct
                                        # -- End function
	.literal_position
	.literal .LCPI4_0, 1073405972
	.literal .LCPI4_1, 1073405968
	.section	.text.abla_fn_934637158_713051631_direct,"ax",@progbits
	.section	.iram1.0.abla.esp32RomOutputToChannels,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_693273882_801650692_direct
	.type	abla_fn_693273882_801650692_direct,@function
abla_fn_693273882_801650692_direct:     # @abla_fn_693273882_801650692_direct
# %bb.0:                                # %entry
	entry	a1, 32
	l32r	a8, .LCPI4_0
	memw
	l32i	a8, a8, 0
	beqz.n	a8, .LBB4_2
# %bb.1:                                # %source.label
	or	a10, a2, a2
	callx8	a8
.LBB4_2:                                # %source.label5
	l32r	a8, .LCPI4_1
	memw
	l32i	a8, a8, 0
	beqz.n	a8, .LBB4_4
# %bb.3:                                # %source.label7
	or	a10, a2, a2
	callx8	a8
.LBB4_4:                                # %source.label9
	retw.n
.Lfunc_end4:
	.size	abla_fn_693273882_801650692_direct, .Lfunc_end4-abla_fn_693273882_801650692_direct
                                        # -- End function
	.literal_position
	.literal .LCPI5_0, 1073627376
	.literal .LCPI5_1, 1073611232
	.section	.iram1.0.abla.esp32RomOutputToChannels,"ax",@progbits
	.section	.iram1.0.abla.esp32DelayMicroseconds,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_887465115_248809038_direct
	.type	abla_fn_887465115_248809038_direct,@function
abla_fn_887465115_248809038_direct:     # @abla_fn_887465115_248809038_direct
# %bb.0:                                # %entry
	entry	a1, 32
	#APP
	rsr	a8, ccount
	#NO_APP
	l32r	a10, .LCPI5_0
	l32r	a9, .LCPI5_1
	movi	a11, 0
	#APP
	rsr	a12, prid
	extui	a12, a12, 13, 1
	#NO_APP
	beq	a12, a11, .LBB5_2
# %bb.1:                                # %entry
	or	a9, a10, a10
.LBB5_2:                                # %entry
	l32i	a9, a9, 0
	mull	a9, a9, a2
.LBB5_3:                                # %source.label
                                        # =>This Inner Loop Header: Depth=1
	#APP
	rsr	a10, ccount
	#NO_APP
	sub	a10, a10, a8
	bltu	a10, a9, .LBB5_3
# %bb.4:                                # %source.label3
	retw.n
.Lfunc_end5:
	.size	abla_fn_887465115_248809038_direct, .Lfunc_end5-abla_fn_887465115_248809038_direct
                                        # -- End function
	.literal_position
	.literal .LCPI6_0, abla_fn_693273882_801650692_direct
	.section	.iram1.0.abla.esp32DelayMicroseconds,"ax",@progbits
	.section	.text.abla_fn_42609761_802612666_direct,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_42609761_802612666_direct
	.type	abla_fn_42609761_802612666_direct,@function
abla_fn_42609761_802612666_direct:      # @abla_fn_42609761_802612666_direct
# %bb.0:                                # %entry
	entry	a1, 32
	l32r	a7, .LCPI6_0
	beqz.n	a3, .LBB6_2
.LBB6_1:                                # %source.label2
                                        # =>This Inner Loop Header: Depth=1
	or	a10, a2, a2
	callx8	a7
	addi	a3, a3, -1
	bnez	a3, .LBB6_1
.LBB6_2:                                # %source.label3
	retw.n
.Lfunc_end6:
	.size	abla_fn_42609761_802612666_direct, .Lfunc_end6-abla_fn_42609761_802612666_direct
                                        # -- End function
	.literal_position
	.literal .LCPI7_0, 1073405972
	.literal .LCPI7_1, 1073405968
	.literal .LCPI7_2, abla_fn_693273882_801650692_direct
	.literal .LCPI7_3, abla_fn_42609761_802612666_direct
	.literal .LCPI7_4, .Lswitch.table.abla_fn_765949846_578441510_direct
	.literal .LCPI7_5, abla_fn_693273882_801650692_direct
	.literal .LCPI7_6, abla_fn_42609761_802612666_direct
	.literal .LCPI7_7, abla_fn_42609761_802612666_direct
	.literal .LCPI7_8, abla_fn_693273882_801650692_direct
	.literal .LCPI7_9, abla_fn_693273882_801650692_direct
	.literal .LCPI7_10, abla_fn_42609761_802612666_direct
	.literal .LCPI7_11, abla_fn_693273882_801650692_direct
	.literal .LCPI7_12, abla_fn_693273882_801650692_direct
	.literal .LCPI7_13, __udivdi3
	.literal .LCPI7_14, abla_fn_42609761_802612666_direct
	.literal .LCPI7_15, abla_fn_693273882_801650692_direct
	.literal .LCPI7_16, abla_fn_693273882_801650692_direct
	.literal .LCPI7_17, abla_fn_693273882_801650692_direct
	.literal .LCPI7_18, abla_fn_42609761_802612666_direct
	.literal .LCPI7_19, __udivdi3
	.literal .LCPI7_20, __udivdi3
	.literal .LCPI7_21, abla_fn_693273882_801650692_direct
	.literal .LCPI7_22, __udivdi3
	.literal .LCPI7_23, abla_fn_42609761_802612666_direct
	.literal .LCPI7_24, abla_fn_693273882_801650692_direct
	.section	.text.abla_fn_42609761_802612666_direct,"ax",@progbits
	.section	.iram1.0.abla.esp32RomPrintfFormat,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_765949846_578441510_direct
	.type	abla_fn_765949846_578441510_direct,@function
abla_fn_765949846_578441510_direct:     # @abla_fn_765949846_578441510_direct
# %bb.0:                                # %entry
	entry	a1, 96
	s32i	a5, a1, 24                      # 4-byte Folded Spill
	s32i	a3, a1, 0                       # 4-byte Folded Spill
	l32r	a8, .LCPI7_0
	memw
	l32i	a8, a8, 0
	bnez.n	a8, .LBB7_2
# %bb.1:                                # %abla_fn_805177204_210185428_direct.exit
	l32r	a8, .LCPI7_1
	memw
	l32i	a8, a8, 0
	beqz	a8, .LBB7_153
.LBB7_2:                                # %source.label16.preheader
	movi	a5, 37
	movi	a3, 45
	movi	a6, 48
	movi	a7, 0
	s32i	a4, a1, 16                      # 4-byte Folded Spill
.LBB7_3:                                # %source.label16.outer
                                        # =>This Loop Header: Depth=1
                                        #     Child Loop BB7_4 Depth 2
                                        #     Child Loop BB7_8 Depth 2
                                        #       Child Loop BB7_9 Depth 3
                                        #         Child Loop BB7_10 Depth 4
                                        #     Child Loop BB7_16 Depth 2
                                        #     Child Loop BB7_19 Depth 2
                                        #     Child Loop BB7_130 Depth 2
                                        #     Child Loop BB7_144 Depth 2
                                        #     Child Loop BB7_66 Depth 2
                                        #     Child Loop BB7_88 Depth 2
                                        #     Child Loop BB7_104 Depth 2
	addi	a7, a7, 1
.LBB7_4:                                # %source.label16
                                        #   Parent Loop BB7_3 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	l8ui	a10, a2, 0
	beqz	a10, .LBB7_153
# %bb.5:                                # %source.label16
                                        #   in Loop: Header=BB7_4 Depth=2
	beq	a10, a5, .LBB7_7
# %bb.6:                                # %source.label18
                                        #   in Loop: Header=BB7_4 Depth=2
	addi	a7, a7, 1
	l32r	a8, .LCPI7_24
	callx8	a8
	addi	a2, a2, 1
	j	.LBB7_4
.LBB7_7:                                # %source.label23.sink.split.outer.preheader
                                        #   in Loop: Header=BB7_3 Depth=1
	s32i	a7, a1, 44                      # 4-byte Folded Spill
	movi	a7, 0
	movi	a8, 0
.LBB7_8:                                # %source.label23.sink.split
                                        #   Parent Loop BB7_3 Depth=1
                                        # =>  This Loop Header: Depth=2
                                        #       Child Loop BB7_9 Depth 3
                                        #         Child Loop BB7_10 Depth 4
	s32i	a8, a1, 28                      # 4-byte Folded Spill
.LBB7_9:                                # %source.label23.sink.split
                                        #   Parent Loop BB7_3 Depth=1
                                        #     Parent Loop BB7_8 Depth=2
                                        # =>    This Loop Header: Depth=3
                                        #         Child Loop BB7_10 Depth 4
	l8ui	a8, a2, 1
	addi	a2, a2, 1
	movi	a9, 1
.LBB7_10:                               # %source.label23
                                        #   Parent Loop BB7_3 Depth=1
                                        #     Parent Loop BB7_8 Depth=2
                                        #       Parent Loop BB7_9 Depth=3
                                        # =>      This Inner Loop Header: Depth=4
	bbci	a9, 0, .LBB7_15
# %bb.11:                               # %source.label24
                                        #   in Loop: Header=BB7_10 Depth=4
	beq	a8, a3, .LBB7_14
# %bb.12:                               # %source.label24
                                        #   in Loop: Header=BB7_10 Depth=4
	movi	a9, 0
	bne	a8, a6, .LBB7_10
# %bb.13:                               # %source.label23.sink.split.outer.loopexit
                                        #   in Loop: Header=BB7_9 Depth=3
	movi	a7, 1
	j	.LBB7_9
.LBB7_14:                               # %source.label23.sink.split.loopexit
                                        #   in Loop: Header=BB7_8 Depth=2
	movi	a8, 1
	j	.LBB7_8
.LBB7_15:                               # %source.label33.loopexit
                                        #   in Loop: Header=BB7_3 Depth=1
	movi	a14, 0
.LBB7_16:                               # %source.label33
                                        #   Parent Loop BB7_3 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	extui	a11, a8, 0, 8
	addi	a9, a11, -48
	movi	a10, 9
	bltu	a10, a9, .LBB7_18
# %bb.17:                               # %source.label38
                                        #   in Loop: Header=BB7_16 Depth=2
	movi	a8, 10
	mull	a8, a14, a8
	add	a14, a9, a8
	l8ui	a8, a2, 1
	addi	a2, a2, 1
	j	.LBB7_16
.LBB7_18:                               # %source.label39
                                        #   in Loop: Header=BB7_3 Depth=1
	s32i	a11, a1, 36                     # 4-byte Folded Spill
	extui	a8, a8, 0, 8
	movi	a10, 108
	movi	a9, 46
	bne	a8, a9, .LBB7_21
.LBB7_19:                               # %source.label41
                                        #   Parent Loop BB7_3 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	or	a8, a2, a2
	addi	a2, a8, 1
	l8ui	a9, a8, 1
	addi	a8, a9, -48
	extui	a8, a8, 0, 8
	bltui	a8, 10, .LBB7_19
# %bb.20:                               # %source.label49.loopexit
                                        #   in Loop: Header=BB7_3 Depth=1
	s32i	a9, a1, 36                      # 4-byte Folded Spill
	movi	a7, 1
.LBB7_21:                               # %source.label49
                                        #   in Loop: Header=BB7_3 Depth=1
	movi	a9, 0
	l32i	a8, a1, 36                      # 4-byte Folded Reload
	bne	a8, a10, .LBB7_25
# %bb.22:                               # %source.label51
                                        #   in Loop: Header=BB7_3 Depth=1
	l8ui	a8, a2, 1
	s32i	a8, a1, 36                      # 4-byte Folded Spill
	bne	a8, a10, .LBB7_24
# %bb.23:                               # %source.label52
                                        #   in Loop: Header=BB7_3 Depth=1
	l8ui	a8, a2, 2
	s32i	a8, a1, 36                      # 4-byte Folded Spill
	addi	a2, a2, 2
	movi	a9, 1
	j	.LBB7_25
.LBB7_24:                               #   in Loop: Header=BB7_3 Depth=1
	addi	a2, a2, 1
.LBB7_25:                               # %source.label56
                                        #   in Loop: Header=BB7_3 Depth=1
	movi	a8, 1
	movi	a10, 68
	l32i	a11, a1, 36                     # 4-byte Folded Reload
	beq	a11, a10, .LBB7_30
# %bb.26:                               # %source.label56
                                        #   in Loop: Header=BB7_3 Depth=1
	movi	a10, 85
	beq	a11, a10, .LBB7_30
# %bb.27:                               # %source.label56
                                        #   in Loop: Header=BB7_3 Depth=1
	movi	a10, 100
	beq	a11, a10, .LBB7_30
# %bb.28:                               # %source.label56
                                        #   in Loop: Header=BB7_3 Depth=1
	movi	a10, 117
	beq	a11, a10, .LBB7_30
# %bb.29:                               # %source.label64
                                        #   in Loop: Header=BB7_3 Depth=1
	movi	a8, 0
.LBB7_30:                               # %source.label66
                                        #   in Loop: Header=BB7_3 Depth=1
	movi	a10, 88
	l32i	a4, a1, 36                      # 4-byte Folded Reload
	s32i	a14, a1, 32                     # 4-byte Folded Spill
	beq	a4, a10, .LBB7_34
# %bb.31:                               # %source.label66
                                        #   in Loop: Header=BB7_3 Depth=1
	movi	a10, 112
	beq	a4, a10, .LBB7_34
# %bb.32:                               # %source.label66
                                        #   in Loop: Header=BB7_3 Depth=1
	movi	a10, 120
	beq	a4, a10, .LBB7_34
# %bb.33:                               # %source.label72
                                        #   in Loop: Header=BB7_3 Depth=1
	beqz	a8, .LBB7_113
.LBB7_34:                               # %source.label78
                                        #   in Loop: Header=BB7_3 Depth=1
	extui	a11, a9, 0, 1
	movi	a12, 40
	movi	a13, 0
	movi	a10, 0
	s32i	a10, a1, 48                     # 4-byte Folded Spill
	bne	a11, a13, .LBB7_36
# %bb.35:                               # %source.label78
                                        #   in Loop: Header=BB7_3 Depth=1
	movi	a12, 36
.LBB7_36:                               # %source.label78
                                        #   in Loop: Header=BB7_3 Depth=1
	l32i	a15, a1, 24                     # 4-byte Folded Reload
	addi	a13, a15, 7
	movi	a10, -8
	and	a13, a13, a10
	or	a14, a13, a13
	l32i	a6, a1, 16                      # 4-byte Folded Reload
	movi	a5, 0
	bne	a11, a5, .LBB7_38
# %bb.37:                               # %source.label78
                                        #   in Loop: Header=BB7_3 Depth=1
	or	a14, a15, a15
.LBB7_38:                               # %source.label78
                                        #   in Loop: Header=BB7_3 Depth=1
	bne	a11, a5, .LBB7_40
# %bb.39:                               # %source.label78
                                        #   in Loop: Header=BB7_3 Depth=1
	addi	a13, a15, 4
	j	.LBB7_41
.LBB7_40:                               #   in Loop: Header=BB7_3 Depth=1
	addi	a13, a13, 8
.LBB7_41:                               # %source.label78
                                        #   in Loop: Header=BB7_3 Depth=1
	movi	a15, 25
	bltu	a14, a15, .LBB7_43
# %bb.42:                               # %source.label78
                                        #   in Loop: Header=BB7_3 Depth=1
	or	a12, a13, a13
.LBB7_43:                               # %source.label78
                                        #   in Loop: Header=BB7_3 Depth=1
	or	a15, a13, a13
	movi	a14, 24
	bgeu	a14, a13, .LBB7_45
# %bb.44:                               # %source.label78
                                        #   in Loop: Header=BB7_3 Depth=1
	or	a15, a12, a12
.LBB7_45:                               # %source.label78
                                        #   in Loop: Header=BB7_3 Depth=1
	movi	a12, 0
	bne	a11, a12, .LBB7_47
# %bb.46:                               # %source.label78
                                        #   in Loop: Header=BB7_3 Depth=1
	movi	a10, -4
.LBB7_47:                               # %source.label78
                                        #   in Loop: Header=BB7_3 Depth=1
	or	a11, a6, a6
	movi	a12, 24
	bgeu	a12, a13, .LBB7_49
# %bb.48:                               # %source.label78
                                        #   in Loop: Header=BB7_3 Depth=1
	l32i	a11, a1, 0                      # 4-byte Folded Reload
.LBB7_49:                               # %source.label78
                                        #   in Loop: Header=BB7_3 Depth=1
	add	a10, a11, a10
	s32i	a15, a1, 24                     # 4-byte Folded Spill
	add	a10, a10, a15
	l32i	a6, a10, 0
	beqz.n	a9, .LBB7_51
# %bb.50:                               # %source.label87
                                        #   in Loop: Header=BB7_3 Depth=1
	l32i	a10, a10, 4
	s32i	a10, a1, 48                     # 4-byte Folded Spill
.LBB7_51:                               # %source.label89
                                        #   in Loop: Header=BB7_3 Depth=1
	movi	a10, 32
	l32i	a11, a1, 36                     # 4-byte Folded Reload
	or	a10, a11, a10
	movi	a11, 100
	bne	a10, a11, .LBB7_63
# %bb.52:                               # %source.label91
                                        #   in Loop: Header=BB7_3 Depth=1
	movi	a10, 1
	l32i	a11, a1, 48                     # 4-byte Folded Reload
	blt	a11, a5, .LBB7_55
# %bb.53:                               # %source.label91
                                        #   in Loop: Header=BB7_3 Depth=1
	movi	a10, 0
	beq	a9, a5, .LBB7_56
.LBB7_54:                               # %source.label91
                                        #   in Loop: Header=BB7_3 Depth=1
	beqi	a10, 1, .LBB7_57
	j	.LBB7_63
.LBB7_55:                               # %source.label91
                                        #   in Loop: Header=BB7_3 Depth=1
	bne	a9, a5, .LBB7_54
.LBB7_56:                               # %source.label91
                                        #   in Loop: Header=BB7_3 Depth=1
	extui	a10, a6, 31, 1
	bnei	a10, 1, .LBB7_63
.LBB7_57:                               # %source.label96
                                        #   in Loop: Header=BB7_3 Depth=1
	movi	a5, 1
	movi	a10, 0
	movi	a11, 1
	bne	a6, a10, .LBB7_59
# %bb.58:                               # %source.label96
                                        #   in Loop: Header=BB7_3 Depth=1
	movi	a11, 0
.LBB7_59:                               # %source.label96
                                        #   in Loop: Header=BB7_3 Depth=1
	bne	a9, a10, .LBB7_61
# %bb.60:                               # %source.label96
                                        #   in Loop: Header=BB7_3 Depth=1
	movi	a9, 0
	j	.LBB7_62
.LBB7_61:                               #   in Loop: Header=BB7_3 Depth=1
	l32i	a9, a1, 48                      # 4-byte Folded Reload
	add	a9, a9, a11
	neg	a9, a9
.LBB7_62:                               # %source.label96
                                        #   in Loop: Header=BB7_3 Depth=1
	s32i	a9, a1, 48                      # 4-byte Folded Spill
	neg	a6, a6
.LBB7_63:                               # %source.label104
                                        #   in Loop: Header=BB7_3 Depth=1
	movi	a3, 10
	movi	a9, 0
	bne	a8, a9, .LBB7_65
# %bb.64:                               # %source.label104
                                        #   in Loop: Header=BB7_3 Depth=1
	movi	a3, 16
.LBB7_65:                               # %source.label104
                                        #   in Loop: Header=BB7_3 Depth=1
	movi	a4, 1
	or	a10, a6, a6
	l32i	a11, a1, 48                     # 4-byte Folded Reload
.LBB7_66:                               # %source.label.i.i
                                        #   Parent Loop BB7_3 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	movi	a9, 0
	movi	a8, 1
	bltu	a10, a3, .LBB7_69
# %bb.67:                               # %source.label.i.i
                                        #   in Loop: Header=BB7_66 Depth=2
	movi	a8, 0
	bne	a11, a9, .LBB7_70
.LBB7_68:                               # %source.label.i.i
                                        #   in Loop: Header=BB7_66 Depth=2
	beqz.n	a8, .LBB7_71
	j	.LBB7_72
.LBB7_69:                               # %source.label.i.i
                                        #   in Loop: Header=BB7_66 Depth=2
	beq	a11, a9, .LBB7_68
.LBB7_70:                               # %source.label.i.i
                                        #   in Loop: Header=BB7_66 Depth=2
	movi	a8, 0
	bnez.n	a8, .LBB7_72
.LBB7_71:                               # %scalar.divide.checked.i.i
                                        #   in Loop: Header=BB7_66 Depth=2
	or	a12, a3, a3
	movi	a13, 0
	l32r	a8, .LCPI7_13
	callx8	a8
	addi	a4, a4, 1
	j	.LBB7_66
.LBB7_72:                               # %abla_fn_62735852_938966312_direct.exit.i
                                        #   in Loop: Header=BB7_3 Depth=1
	movi	a8, 1
	movi	a9, 112
	l32i	a10, a1, 36                     # 4-byte Folded Reload
	beq	a10, a9, .LBB7_74
# %bb.73:                               # %abla_fn_62735852_938966312_direct.exit.i
                                        #   in Loop: Header=BB7_3 Depth=1
	movi	a8, 0
.LBB7_74:                               # %abla_fn_62735852_938966312_direct.exit.i
                                        #   in Loop: Header=BB7_3 Depth=1
	l32i	a10, a1, 36                     # 4-byte Folded Reload
	l32i	a11, a1, 32                     # 4-byte Folded Reload
	bne	a10, a9, .LBB7_76
# %bb.75:                               #   in Loop: Header=BB7_3 Depth=1
	movi	a9, 10
	maxu	a11, a11, a9
.LBB7_76:                               # %abla_fn_62735852_938966312_direct.exit.i
                                        #   in Loop: Header=BB7_3 Depth=1
	movi	a9, 112
	l32i	a10, a1, 36                     # 4-byte Folded Reload
	beq	a10, a9, .LBB7_78
# %bb.77:                               # %abla_fn_62735852_938966312_direct.exit.i
                                        #   in Loop: Header=BB7_3 Depth=1
	or	a9, a5, a5
	j	.LBB7_79
.LBB7_78:                               #   in Loop: Header=BB7_3 Depth=1
	movi	a9, 2
	or	a9, a5, a9
.LBB7_79:                               # %abla_fn_62735852_938966312_direct.exit.i
                                        #   in Loop: Header=BB7_3 Depth=1
	or	a7, a7, a8
	l32i	a8, a1, 28                      # 4-byte Folded Reload
	or	a8, a8, a7
	s32i	a9, a1, 8                       # 4-byte Folded Spill
	add	a10, a9, a4
	s32i	a11, a1, 32                     # 4-byte Folded Spill
	maxu	a9, a11, a10
	s32i	a10, a1, 4                      # 4-byte Folded Spill
	sub	a9, a9, a10
	s32i	a9, a1, 20                      # 4-byte Folded Spill
	bbsi	a8, 0, .LBB7_81
# %bb.80:                               # %source.label25.i
                                        #   in Loop: Header=BB7_3 Depth=1
	movi	a10, 32
	l32i	a11, a1, 20                     # 4-byte Folded Reload
	l32r	a8, .LCPI7_14
	callx8	a8
.LBB7_81:                               # %source.label27.i
                                        #   in Loop: Header=BB7_3 Depth=1
	beqz.n	a5, .LBB7_83
# %bb.82:                               # %source.label28.i
                                        #   in Loop: Header=BB7_3 Depth=1
	movi	a10, 45
	l32r	a8, .LCPI7_15
	callx8	a8
.LBB7_83:                               # %source.label30.i
                                        #   in Loop: Header=BB7_3 Depth=1
	movi	a8, 112
	l32i	a9, a1, 36                      # 4-byte Folded Reload
	bne	a9, a8, .LBB7_85
# %bb.84:                               # %source.label31.i
                                        #   in Loop: Header=BB7_3 Depth=1
	movi	a10, 48
	l32r	a8, .LCPI7_16
	callx8	a8
	movi	a10, 120
	l32r	a8, .LCPI7_17
	callx8	a8
.LBB7_85:                               # %source.label33.i
                                        #   in Loop: Header=BB7_3 Depth=1
	s32i	a4, a1, 12                      # 4-byte Folded Spill
	movi	a8, -1
	l32i	a9, a1, 28                      # 4-byte Folded Reload
	xor	a8, a9, a8
	and	a8, a7, a8
	bbci	a8, 0, .LBB7_87
# %bb.86:                               # %source.label38.i
                                        #   in Loop: Header=BB7_3 Depth=1
	movi	a10, 48
	l32i	a11, a1, 20                     # 4-byte Folded Reload
	l32r	a8, .LCPI7_18
	callx8	a8
.LBB7_87:                               # %source.label40.i
                                        #   in Loop: Header=BB7_3 Depth=1
	movi	a5, 0
	or	a10, a6, a6
	l32i	a11, a1, 48                     # 4-byte Folded Reload
	or	a12, a3, a3
	movi	a13, 0
	l32r	a8, .LCPI7_19
	callx8	a8
	movi	a4, 1
	l32i	a7, a1, 44                      # 4-byte Folded Reload
.LBB7_88:                               # %source.label.i8.i
                                        #   Parent Loop BB7_3 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	movi	a8, 1
	bgeu	a10, a4, .LBB7_90
# %bb.89:                               # %source.label.i8.i
                                        #   in Loop: Header=BB7_88 Depth=2
	movi	a8, 0
.LBB7_90:                               # %source.label.i8.i
                                        #   in Loop: Header=BB7_88 Depth=2
	movi	a9, 1
	bgeu	a11, a5, .LBB7_93
# %bb.91:                               # %source.label.i8.i
                                        #   in Loop: Header=BB7_88 Depth=2
	movi	a9, 0
	bne	a5, a11, .LBB7_94
.LBB7_92:                               # %source.label.i8.i
                                        #   in Loop: Header=BB7_88 Depth=2
	bnez.n	a8, .LBB7_95
	j	.LBB7_96
.LBB7_93:                               # %source.label.i8.i
                                        #   in Loop: Header=BB7_88 Depth=2
	beq	a5, a11, .LBB7_92
.LBB7_94:                               # %source.label.i8.i
                                        #   in Loop: Header=BB7_88 Depth=2
	or	a8, a9, a9
	beqz.n	a8, .LBB7_96
.LBB7_95:                               # %source.label3.i.i
                                        #   in Loop: Header=BB7_88 Depth=2
	muluh	a8, a4, a3
	mull	a9, a5, a3
	add	a5, a8, a9
	mull	a4, a4, a3
	j	.LBB7_88
.LBB7_96:                               # %source.label6.preheader.i.i
                                        #   in Loop: Header=BB7_3 Depth=1
	movi	a8, 55
	s32i	a8, a1, 40                      # 4-byte Folded Spill
	movi	a8, 88
	l32i	a9, a1, 36                      # 4-byte Folded Reload
	beq	a9, a8, .LBB7_104
# %bb.97:                               # %source.label6.preheader.i.i
                                        #   in Loop: Header=BB7_3 Depth=1
	movi	a8, 87
	s32i	a8, a1, 40                      # 4-byte Folded Spill
	j	.LBB7_104
.LBB7_98:                               # %scalar.divide.checked17.i.i
                                        #   in Loop: Header=BB7_104 Depth=2
	or	a10, a6, a6
	l32i	a11, a1, 48                     # 4-byte Folded Reload
	or	a12, a4, a4
	or	a13, a5, a5
	l32r	a8, .LCPI7_20
	callx8	a8
	or	a7, a10, a10
	movi	a8, 10
	bltu	a7, a8, .LBB7_100
# %bb.99:                               # %scalar.divide.checked17.i.i
                                        #   in Loop: Header=BB7_104 Depth=2
	l32i	a8, a1, 40                      # 4-byte Folded Reload
	add	a8, a8, a7
	j	.LBB7_101
.LBB7_100:                              #   in Loop: Header=BB7_104 Depth=2
	movi	a8, 48
	or	a8, a7, a8
.LBB7_101:                              # %scalar.divide.checked17.i.i
                                        #   in Loop: Header=BB7_104 Depth=2
	extui	a10, a8, 0, 8
	l32r	a8, .LCPI7_21
	callx8	a8
	mull	a8, a7, a4
	movi	a9, 1
	bltu	a6, a8, .LBB7_103
# %bb.102:                              # %scalar.divide.checked17.i.i
                                        #   in Loop: Header=BB7_104 Depth=2
	movi	a9, 0
.LBB7_103:                              # %scalar.divide.checked17.i.i
                                        #   in Loop: Header=BB7_104 Depth=2
	mull	a10, a7, a5
	muluh	a11, a7, a4
	add	a10, a11, a10
	l32i	a11, a1, 48                     # 4-byte Folded Reload
	sub	a10, a11, a10
	sub	a9, a10, a9
	s32i	a9, a1, 48                      # 4-byte Folded Spill
	sub	a6, a6, a8
	or	a10, a4, a4
	or	a11, a5, a5
	or	a12, a3, a3
	movi	a13, 0
	l32r	a8, .LCPI7_22
	callx8	a8
	or	a4, a10, a10
	or	a5, a11, a11
	l32i	a7, a1, 44                      # 4-byte Folded Reload
.LBB7_104:                              # %source.label6.i.i
                                        #   Parent Loop BB7_3 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	or	a8, a4, a5
	bnez	a8, .LBB7_98
# %bb.105:                              # %abla_fn_953273104_42882710_direct.exit.i
                                        #   in Loop: Header=BB7_3 Depth=1
	l32i	a8, a1, 28                      # 4-byte Folded Reload
	bbci	a8, 0, .LBB7_107
# %bb.106:                              # %source.label41.i
                                        #   in Loop: Header=BB7_3 Depth=1
	movi	a10, 32
	l32i	a11, a1, 20                     # 4-byte Folded Reload
	l32r	a8, .LCPI7_23
	callx8	a8
.LBB7_107:                              # %abla_fn_801245804_213691947_direct.exit
                                        #   in Loop: Header=BB7_3 Depth=1
	l32i	a9, a1, 32                      # 4-byte Folded Reload
	l32i	a8, a1, 8                       # 4-byte Folded Reload
	add	a8, a9, a8
	l32i	a10, a1, 4                      # 4-byte Folded Reload
	minu	a9, a9, a10
	sub	a8, a8, a9
	add	a8, a8, a7
	l32i	a9, a1, 12                      # 4-byte Folded Reload
.LBB7_108:                              # %source.label160
                                        #   in Loop: Header=BB7_3 Depth=1
	add	a8, a8, a9
	addi	a7, a8, -1
	movi	a5, 37
	movi	a3, 45
.LBB7_109:                              # %source.label160
                                        #   in Loop: Header=BB7_3 Depth=1
	movi	a6, 48
.LBB7_110:                              # %source.label160
                                        #   in Loop: Header=BB7_3 Depth=1
	movi	a8, 1
	movi	a9, 0
	l32i	a10, a1, 36                     # 4-byte Folded Reload
	bne	a10, a9, .LBB7_112
# %bb.111:                              # %source.label160
                                        #   in Loop: Header=BB7_3 Depth=1
	movi	a8, 0
.LBB7_112:                              # %source.label160
                                        #   in Loop: Header=BB7_3 Depth=1
	add	a2, a2, a8
	j	.LBB7_3
.LBB7_113:                              # %source.label121
                                        #   in Loop: Header=BB7_3 Depth=1
	bne	a4, a5, .LBB7_114
	j	.LBB7_137
.LBB7_114:                              # %source.label121
                                        #   in Loop: Header=BB7_3 Depth=1
	l32i	a8, a1, 24                      # 4-byte Folded Reload
	addi	a9, a8, -21
	extui	a8, a7, 0, 1
	movi	a10, 67
	l32i	a7, a1, 44                      # 4-byte Folded Reload
	beq	a4, a10, .LBB7_118
# %bb.115:                              # %source.label121
                                        #   in Loop: Header=BB7_3 Depth=1
	movi	a10, 83
	beq	a4, a10, .LBB7_124
# %bb.116:                              # %source.label121
                                        #   in Loop: Header=BB7_3 Depth=1
	movi	a10, 115
	beq	a4, a10, .LBB7_124
# %bb.117:                              # %source.label121
                                        #   in Loop: Header=BB7_3 Depth=1
	movi	a10, 99
	beq	a4, a10, .LBB7_118
	j	.LBB7_135
.LBB7_118:                              # %source.label126
                                        #   in Loop: Header=BB7_3 Depth=1
	l32i	a10, a1, 24                     # 4-byte Folded Reload
	addi	a11, a10, 4
	l32i	a4, a1, 16                      # 4-byte Folded Reload
	or	a10, a4, a4
	movi	a12, 24
	bgeu	a12, a11, .LBB7_120
# %bb.119:                              # %source.label126
                                        #   in Loop: Header=BB7_3 Depth=1
	l32i	a10, a1, 0                      # 4-byte Folded Reload
.LBB7_120:                              # %source.label126
                                        #   in Loop: Header=BB7_3 Depth=1
	movi	a12, 36
	movi	a13, 4
	bltu	a9, a13, .LBB7_122
# %bb.121:                              # %source.label126
                                        #   in Loop: Header=BB7_3 Depth=1
	or	a12, a11, a11
.LBB7_122:                              # %source.label126
                                        #   in Loop: Header=BB7_3 Depth=1
	s32i	a12, a1, 24                     # 4-byte Folded Spill
	add	a9, a12, a10
	addi	a9, a9, -4
	l8ui	a7, a9, 0
	movi	a9, 1
	maxu	a9, a14, a9
	addi	a6, a9, -1
	l32i	a9, a1, 28                      # 4-byte Folded Reload
	bbci	a9, 0, .LBB7_131
# %bb.123:                              # %source.label141.critedge
                                        #   in Loop: Header=BB7_3 Depth=1
	or	a10, a7, a7
	l32r	a8, .LCPI7_9
	callx8	a8
	movi	a10, 32
	or	a11, a6, a6
	l32r	a8, .LCPI7_10
	callx8	a8
	j	.LBB7_134
.LBB7_124:                              # %source.label149
                                        #   in Loop: Header=BB7_3 Depth=1
	l32i	a10, a1, 24                     # 4-byte Folded Reload
	addi	a11, a10, 4
	l32i	a3, a1, 16                      # 4-byte Folded Reload
	or	a10, a3, a3
	movi	a12, 24
	bgeu	a12, a11, .LBB7_126
# %bb.125:                              # %source.label149
                                        #   in Loop: Header=BB7_3 Depth=1
	l32i	a10, a1, 0                      # 4-byte Folded Reload
.LBB7_126:                              # %source.label149
                                        #   in Loop: Header=BB7_3 Depth=1
	movi	a12, 36
	movi	a13, 4
	bltu	a9, a13, .LBB7_128
# %bb.127:                              # %source.label149
                                        #   in Loop: Header=BB7_3 Depth=1
	or	a12, a11, a11
.LBB7_128:                              # %source.label149
                                        #   in Loop: Header=BB7_3 Depth=1
	add	a9, a12, a10
	addi	a9, a9, -4
	l32i	a5, a9, 0
	s32i	a12, a1, 24                     # 4-byte Folded Spill
	beqz	a5, .LBB7_138
# %bb.129:                              # %source.label3.i.i172.preheader
                                        #   in Loop: Header=BB7_3 Depth=1
	movi	a7, -1
.LBB7_130:                              # %source.label3.i.i172
                                        #   Parent Loop BB7_3 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	add	a9, a5, a7
	l8ui	a9, a9, 1
	addi	a7, a7, 1
	bnez	a9, .LBB7_130
	j	.LBB7_139
.LBB7_131:                              # %source.label134
                                        #   in Loop: Header=BB7_3 Depth=1
	movi	a10, 48
	movi	a9, 0
	bne	a8, a9, .LBB7_133
# %bb.132:                              # %source.label134
                                        #   in Loop: Header=BB7_3 Depth=1
	movi	a10, 32
.LBB7_133:                              # %source.label134
                                        #   in Loop: Header=BB7_3 Depth=1
	or	a11, a6, a6
	l32r	a8, .LCPI7_7
	callx8	a8
	or	a10, a7, a7
	l32r	a8, .LCPI7_8
	callx8	a8
.LBB7_134:                              # %source.label143
                                        #   in Loop: Header=BB7_3 Depth=1
	l32i	a7, a1, 44                      # 4-byte Folded Reload
	add	a7, a6, a7
	j	.LBB7_109
.LBB7_135:                              # %source.label153
                                        #   in Loop: Header=BB7_3 Depth=1
	movi	a10, 37
	l32r	a8, .LCPI7_11
	callx8	a8
	beqz	a4, .LBB7_110
# %bb.136:                              # %source.label154
                                        #   in Loop: Header=BB7_3 Depth=1
	or	a10, a4, a4
	l32r	a8, .LCPI7_12
	callx8	a8
	addi	a7, a7, 1
	j	.LBB7_110
.LBB7_137:                              # %source.label152
                                        #   in Loop: Header=BB7_3 Depth=1
	movi	a10, 37
	l32r	a8, .LCPI7_2
	callx8	a8
	l32i	a7, a1, 44                      # 4-byte Folded Reload
	j	.LBB7_110
.LBB7_138:                              #   in Loop: Header=BB7_3 Depth=1
	movi	a7, 6
.LBB7_139:                              # %abla_fn_746736921_566718300_direct.exit.i
                                        #   in Loop: Header=BB7_3 Depth=1
	maxu	a9, a14, a7
	sub	a6, a9, a7
	l32i	a9, a1, 28                      # 4-byte Folded Reload
	bbsi	a9, 0, .LBB7_143
# %bb.140:                              # %source.label8.i
                                        #   in Loop: Header=BB7_3 Depth=1
	movi	a10, 48
	movi	a9, 0
	bne	a8, a9, .LBB7_142
# %bb.141:                              # %source.label8.i
                                        #   in Loop: Header=BB7_3 Depth=1
	movi	a10, 32
.LBB7_142:                              # %source.label8.i
                                        #   in Loop: Header=BB7_3 Depth=1
	or	a11, a6, a6
	l32r	a8, .LCPI7_3
	callx8	a8
	l32i	a14, a1, 32                     # 4-byte Folded Reload
.LBB7_143:                              # %source.label16.i.preheader
                                        #   in Loop: Header=BB7_3 Depth=1
	movi	a4, 0
	beq	a7, a4, .LBB7_150
.LBB7_144:                              # %source.label17.i
                                        #   Parent Loop BB7_3 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	beqz.n	a5, .LBB7_146
# %bb.145:                              # %source.label20.i
                                        #   in Loop: Header=BB7_144 Depth=2
	add	a8, a5, a4
	j	.LBB7_148
.LBB7_146:                              # %source.label19.i
                                        #   in Loop: Header=BB7_144 Depth=2
	movi	a8, 41
	bgeui	a4, 5, .LBB7_149
# %bb.147:                              # %switch.lookup
                                        #   in Loop: Header=BB7_144 Depth=2
	l32r	a8, .LCPI7_4
	add	a8, a8, a4
.LBB7_148:                              # %source.label21.i
                                        #   in Loop: Header=BB7_144 Depth=2
	l8ui	a8, a8, 0
.LBB7_149:                              # %source.label21.i
                                        #   in Loop: Header=BB7_144 Depth=2
	extui	a10, a8, 0, 8
	l32r	a8, .LCPI7_5
	callx8	a8
	addi	a4, a4, 1
	l32i	a14, a1, 32                     # 4-byte Folded Reload
	bne	a7, a4, .LBB7_144
.LBB7_150:                              # %source.label22.i
                                        #   in Loop: Header=BB7_3 Depth=1
	l32i	a8, a1, 28                      # 4-byte Folded Reload
	bbci	a8, 0, .LBB7_152
# %bb.151:                              # %source.label23.i
                                        #   in Loop: Header=BB7_3 Depth=1
	movi	a10, 32
	or	a11, a6, a6
	l32r	a8, .LCPI7_6
	callx8	a8
	l32i	a14, a1, 32                     # 4-byte Folded Reload
.LBB7_152:                              # %abla_fn_398257715_940250081_direct.exit
                                        #   in Loop: Header=BB7_3 Depth=1
	minu	a8, a14, a7
	add	a9, a7, a14
	sub	a8, a9, a8
	l32i	a9, a1, 44                      # 4-byte Folded Reload
	j	.LBB7_108
.LBB7_153:                              # %common.ret
	retw.n
.Lfunc_end7:
	.size	abla_fn_765949846_578441510_direct, .Lfunc_end7-abla_fn_765949846_578441510_direct
                                        # -- End function
	.literal_position
	.literal .LCPI8_0, abla_fn_765949846_578441510_direct
	.section	.iram1.0.abla.esp32RomPrintfFormat,"ax",@progbits
	.section	.text.abla_fn_248569758_289064282_direct,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_248569758_289064282_direct
	.type	abla_fn_248569758_289064282_direct,@function
abla_fn_248569758_289064282_direct:     # @abla_fn_248569758_289064282_direct
# %bb.0:                                # %entry
	entry	a1, 112
	or	a10, a2, a2
	l32i	a8, a1, 136
	s32i	a8, a1, 68
	l32i	a8, a1, 132
	s32i	a8, a1, 64
	l32i	a8, a1, 128
	s32i	a8, a1, 60
	l32i	a8, a1, 124
	s32i	a8, a1, 56
	l32i	a8, a1, 120
	s32i	a8, a1, 52
	l32i	a8, a1, 116
	s32i	a8, a1, 48
	l32i	a8, a1, 112
	s32i	a8, a1, 44
	s32i	a7, a1, 40
	s32i	a6, a1, 36
	s32i	a5, a1, 32
	movi	a8, 0
	s32i	a8, a1, 20
	s32i	a8, a1, 16
	s32i	a8, a1, 12
	s32i	a4, a1, 8
	s32i	a3, a1, 4
	addi	a11, a1, 0
	l32r	a8, .LCPI8_0
	or	a12, a11, a11
	movi	a13, 4
	callx8	a8
	retw.n
.Lfunc_end8:
	.size	abla_fn_248569758_289064282_direct, .Lfunc_end8-abla_fn_248569758_289064282_direct
                                        # -- End function
	.literal_position
	.literal .LCPI9_0, abla_fn_765949846_578441510_direct
	.section	.text.abla_fn_248569758_289064282_direct,"ax",@progbits
	.section	.text.abla_fn_996971693_205949621_direct,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_996971693_205949621_direct
	.type	abla_fn_996971693_205949621_direct,@function
abla_fn_996971693_205949621_direct:     # @abla_fn_996971693_205949621_direct
# %bb.0:                                # %entry
	entry	a1, 32
	or	a12, a4, a4
	or	a11, a3, a3
	or	a10, a2, a2
	l32r	a8, .LCPI9_0
	movi	a13, 12
	callx8	a8
	retw.n
.Lfunc_end9:
	.size	abla_fn_996971693_205949621_direct, .Lfunc_end9-abla_fn_996971693_205949621_direct
                                        # -- End function
	.literal_position
	.literal .LCPI10_0, abla_fn_923148460_536466818_direct
	.literal .LCPI10_1, abla_static_abla_fn_627837887_633683867_241.0
	.literal .LCPI10_2, abla_static_abla_fn_627837887_633683867_235
	.literal .LCPI10_3, abla_static_abla_fn_627837887_633683867_247.0
	.literal .LCPI10_4, 536870911
	.literal .LCPI10_5, abla_static_abla_fn_627837887_633683867_260.0
	.literal .LCPI10_6, abla_fn_923148460_536466818_direct
	.literal .LCPI10_7, .Labla_string_abla_fn_627837887_633683867_265.native.bytes
	.literal .LCPI10_8, .Labla_string_abla_fn_627837887_633683867_252.native.bytes
	.section	.text.abla_fn_996971693_205949621_direct,"ax",@progbits
	.section	.text.abla_fn_992771427_703335695_direct,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_992771427_703335695_direct
	.type	abla_fn_992771427_703335695_direct,@function
abla_fn_992771427_703335695_direct:     # @abla_fn_992771427_703335695_direct
# %bb.0:                                # %entry
	entry	a1, 48
	or	a7, a1, a1
	beqz	a2, .LBB10_12
# %bb.1:                                # %source.label5.i.i.i.i.i
	s32i	a6, a7, 12                      # 4-byte Folded Spill
	or	a6, a3, a3
	l32r	a8, .LCPI10_0
	callx8	a8
	l32r	a9, .LCPI10_1
	l32i	a11, a9, 0
	movi	a15, 1
	movi	a10, 0
	l32r	a8, .LCPI10_2
	movi	a13, -8
	movi	a3, 0
.LBB10_2:                               # %source.label.i.i.i.i.i.i
                                        # =>This Inner Loop Header: Depth=1
	slli	a14, a10, 3
	bbci	a15, 0, .LBB10_9
# %bb.3:                                # %source.label21.i.i.i.i.i.i
                                        #   in Loop: Header=BB10_2 Depth=1
	movi	a15, 0
	or	a3, a11, a11
	bgeu	a10, a11, .LBB10_2
# %bb.4:                                # %source.label22.i.i.i.i.i.i
                                        #   in Loop: Header=BB10_2 Depth=1
	beqz.n	a10, .LBB10_6
# %bb.5:                                # %source.label23.i.i.i.i.i.i
                                        #   in Loop: Header=BB10_2 Depth=1
	addi	a15, a8, 4
	addx8	a3, a10, a15
	l32i	a3, a3, 0
	srli	a3, a3, 3
	movi	a12, -4
	addx4	a12, a10, a12
	and	a12, a12, a13
	add	a12, a12, a15
	l32i	a12, a12, 0
	srli	a12, a12, 3
	or	a15, a14, a14
	bltu	a12, a3, .LBB10_6
	j	.LBB10_23
.LBB10_6:                               # %source.label31.i.i.i.i.i.i
                                        #   in Loop: Header=BB10_2 Depth=1
	add	a12, a15, a8
	l32i	a12, a12, 0
	movi	a15, 1
	bne	a12, a2, .LBB10_8
# %bb.7:                                # %source.label31.i.i.i.i.i.i
                                        #   in Loop: Header=BB10_2 Depth=1
	movi	a15, 0
.LBB10_8:                               # %source.label31.i.i.i.i.i.i
                                        #   in Loop: Header=BB10_2 Depth=1
	add	a10, a10, a15
	or	a3, a11, a11
	j	.LBB10_2
.LBB10_9:                               # %source.label37.i.i.i.i.i.i
	bne	a3, a10, .LBB10_13
# %bb.10:                               # %source.label13.i.i.i.i.i
	l32r	a10, .LCPI10_5
	l32i	a12, a10, 0
	addi	a12, a12, 1
	s32i	a12, a10, 0
	l32r	a3, .LCPI10_3
	l32i	a10, a3, 0
	addi	a12, a10, 1
	s32i	a12, a3, 0
	movi	a12, 31
	bltu	a11, a12, .LBB10_15
# %bb.11:                               # %source.label.i27.i.i.i.i.i
	s32i	a2, a8, 0
	slli	a9, a10, 3
	movi	a10, 3
	or	a9, a9, a10
	s32i	a9, a8, 4
	movi	a10, 0
	call8	abla_fn_30454968_345956014_direct
	j	.LBB10_16
.LBB10_12:
	movi	a2, 3
	bnez	a2, .LBB10_21
	j	.LBB10_22
.LBB10_13:                              # %source.label38.i.i.i.i.i.i
	addx8	a9, a10, a8
	l32i	a9, a9, 4
	extui	a2, a9, 0, 3
	movi	a9, 31
	bne	a3, a9, .LBB10_19
# %bb.14:                               # %source.label40.i.i.i.i.i.i
	l32r	a3, .LCPI10_3
	l32i	a9, a3, 0
	addi	a11, a9, 1
	s32i	a11, a3, 0
	add	a8, a8, a14
	l32i	a11, a8, 4
	extui	a11, a11, 0, 3
	slli	a9, a9, 3
	or	a9, a11, a9
	s32i	a9, a8, 4
	call8	abla_fn_30454968_345956014_direct
	l32i	a8, a3, 0
	j	.LBB10_17
.LBB10_15:                              # %source.label23.i24.i.i.i.i.i
	addx8	a8, a11, a8
	s32i	a2, a8, 0
	slli	a10, a10, 3
	movi	a12, 3
	or	a10, a10, a12
	s32i	a10, a8, 4
	addi	a8, a11, 1
	s32i	a8, a9, 0
.LBB10_16:                              # %source.label24.i.i.i.i.i.i
	l32i	a8, a3, 0
	movi	a2, 3
.LBB10_17:                              # %source.label24.i.i.i.i.i.i
	l32r	a9, .LCPI10_4
	or	a3, a6, a6
	bne	a8, a9, .LBB10_20
# %bb.18:                               # %source.label15.i.i.i.i.i.sink.split
	call8	abla_fn_406806377_219124179_direct
	j	.LBB10_20
.LBB10_19:
	or	a3, a6, a6
.LBB10_20:                              # %source.label15.i.i.i.i.i
	l32r	a8, .LCPI10_6
	callx8	a8
	l32i	a6, a7, 12                      # 4-byte Folded Reload
	beqz	a2, .LBB10_22
.LBB10_21:                              # %source.label24
	addi	a8, a1, -128
	movsp	a1, a8
	addi	a11, a1, 32
	s32i	a11, a1, 0
	s32i	a11, a1, 4
	movi	a8, 12
	s32i	a8, a1, 8
	s32i	a11, a1, 12
	movi	a9, 0
	s32i	a9, a1, 100
	s32i	a9, a1, 96
	s32i	a9, a1, 92
	s32i	a9, a1, 88
	s32i	a9, a1, 84
	s32i	a9, a1, 80
	s32i	a9, a1, 76
	s32i	a9, a1, 72
	s32i	a9, a1, 68
	s32i	a9, a1, 64
	s32i	a6, a1, 52
	s32i	a5, a1, 48
	s32i	a4, a1, 44
	s32i	a8, a1, 20
	s32i	a11, a1, 16
	or	a10, a3, a3
	or	a12, a11, a11
	call8	abla_fn_996971693_205949621_direct
.LBB10_22:                              # %common.ret
	retw.n
.LBB10_23:                              # %source.label27.i.i.i.i.i.i
	movi	a8, 131
	l32r	a13, .LCPI10_7
	add	a10, a13, a8
	l32r	a12, .LCPI10_8
	movi	a11, 99
	call8	abla_fn_343754787_547301002_direct
.Lfunc_end10:
	.size	abla_fn_992771427_703335695_direct, .Lfunc_end10-abla_fn_992771427_703335695_direct
                                        # -- End function
	.literal_position
	.literal .LCPI11_0, .Labla_string_abla_fn_627837887_633683867_8.native.bytes
	.section	.text.abla_fn_992771427_703335695_direct,"ax",@progbits
	.section	.text.abla_fn_794705890_555600125_direct,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_794705890_555600125_direct
	.type	abla_fn_794705890_555600125_direct,@function
abla_fn_794705890_555600125_direct:     # @abla_fn_794705890_555600125_direct
# %bb.0:                                # %entry
	entry	a1, 32
	movi	a8, -1
	l32r	a9, .LCPI11_0
.LBB11_1:                               # %source.label15
                                        # =>This Inner Loop Header: Depth=1
	or	a10, a2, a2
	add	a11, a3, a8
	quou	a2, a10, a4
	mull	a12, a2, a4
	sub	a12, a10, a12
	add	a12, a12, a9
	l8ui	a12, a12, 0
	s8i	a12, a11, 1
	addi	a8, a8, 1
	bgeu	a10, a4, .LBB11_1
# %bb.2:                                # %source.label21
	add	a10, a3, a8
	movi	a9, 0
	s8i	a9, a10, 1
	bgeu	a9, a8, .LBB11_4
.LBB11_3:                               # %source.label25
                                        # =>This Inner Loop Header: Depth=1
	add	a10, a3, a9
	l8ui	a11, a10, 0
	add	a12, a3, a8
	l8ui	a13, a12, 0
	s8i	a13, a10, 0
	s8i	a11, a12, 0
	addi	a8, a8, -1
	addi	a9, a9, 1
	bltu	a9, a8, .LBB11_3
.LBB11_4:                               # %common.ret
	or	a2, a3, a3
	retw.n
.Lfunc_end11:
	.size	abla_fn_794705890_555600125_direct, .Lfunc_end11-abla_fn_794705890_555600125_direct
                                        # -- End function
	.section	.text.abla_fn_190887214_489433951_direct,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_190887214_489433951_direct
	.type	abla_fn_190887214_489433951_direct,@function
abla_fn_190887214_489433951_direct:     # @abla_fn_190887214_489433951_direct
# %bb.0:                                # %entry
	entry	a1, 32
	bnei	a4, 10, .LBB12_3
# %bb.1:                                # %entry
	bgez	a2, .LBB12_3
# %bb.2:                                # %source.label11
	movi	a8, 45
	s8i	a8, a3, 0
	neg	a10, a2
	addi	a11, a3, 1
	movi	a12, 10
	j	.LBB12_4
.LBB12_3:                               # %source.label13
	or	a10, a2, a2
	or	a11, a3, a3
	or	a12, a4, a4
.LBB12_4:                               # %common.ret
	call8	abla_fn_794705890_555600125_direct
	or	a2, a3, a3
	retw.n
.Lfunc_end12:
	.size	abla_fn_190887214_489433951_direct, .Lfunc_end12-abla_fn_190887214_489433951_direct
                                        # -- End function
	.literal_position
	.literal .LCPI13_0, port_xSchedulerRunning
	.literal .LCPI13_1, abla_fn_326491309_387073790_direct
	.literal .LCPI13_2, abla_fn_607480688_644791182_direct
	.section	.text.abla_fn_190887214_489433951_direct,"ax",@progbits
	.section	.iram1.1.abla.esp32HeapCapsMalloc,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_724969459_465497474_direct
	.type	abla_fn_724969459_465497474_direct,@function
abla_fn_724969459_465497474_direct:     # @abla_fn_724969459_465497474_direct
# %bb.0:                                # %entry
	entry	a1, 32
	or	a11, a3, a3
	or	a10, a2, a2
	l32r	a8, .LCPI13_0
	#APP
	rsr	a9, prid
	extui	a9, a9, 13, 1
	#NO_APP
	addx4	a8, a9, a8
	l32i	a8, a8, 0
	extui	a9, a11, 0, 1
	or	a8, a8, a9
	bnez.n	a8, .LBB13_2
# %bb.1:                                # %source.label4.i
	l32r	a8, .LCPI13_2
	j	.LBB13_3
.LBB13_2:                               # %source.label5.i
	l32r	a8, .LCPI13_1
.LBB13_3:                               # %abla_fn_998071156_959388080_direct.exit
	callx8	a8
	or	a2, a10, a10
	retw.n
.Lfunc_end13:
	.size	abla_fn_724969459_465497474_direct, .Lfunc_end13-abla_fn_724969459_465497474_direct
                                        # -- End function
	.literal_position
	.literal .LCPI14_0, abla_static_abla_fn_627837887_633683867_4085.0
	.literal .LCPI14_1, port_xSchedulerRunning
	.literal .LCPI14_2, 5120
	.literal .LCPI14_3, abla_fn_326491309_387073790_direct
	.literal .LCPI14_4, abla_fn_607480688_644791182_direct
	.literal .LCPI14_5, 4096
	.literal .LCPI14_6, abla_fn_326491309_387073790_direct
	.literal .LCPI14_7, abla_fn_607480688_644791182_direct
	.literal .LCPI14_8, 6144
	.literal .LCPI14_9, abla_fn_724969459_465497474_direct
	.section	.iram1.1.abla.esp32HeapCapsMalloc,"ax",@progbits
	.section	.iram1.2.abla.esp32HeapCapsMallocDefault,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_500235045_572962334_direct
	.type	abla_fn_500235045_572962334_direct,@function
abla_fn_500235045_572962334_direct:     # @abla_fn_500235045_572962334_direct
# %bb.0:                                # %entry
	entry	a1, 32
	l32r	a8, .LCPI14_0
	l8ui	a8, a8, 0
	beqz.n	a8, .LBB14_3
# %bb.1:                                # %source.label
	l32r	a11, .LCPI14_8
	l32r	a8, .LCPI14_9
.LBB14_2:                               # %common.ret
	or	a10, a2, a2
	callx8	a8
	j	.LBB14_7
.LBB14_3:                               # %source.label2
	l32r	a7, .LCPI14_1
	#APP
	rsr	a8, prid
	extui	a8, a8, 13, 1
	#NO_APP
	addx4	a8, a8, a7
	l32i	a8, a8, 0
	beqz.n	a8, .LBB14_5
# %bb.4:                                # %source.label5.i
	l32r	a11, .LCPI14_2
	l32r	a8, .LCPI14_3
	j	.LBB14_6
.LBB14_5:                               # %source.label4.i
	l32r	a11, .LCPI14_2
	l32r	a8, .LCPI14_4
.LBB14_6:                               # %abla_fn_998071156_959388080_direct.exit
	or	a10, a2, a2
	callx8	a8
	beqz.n	a10, .LBB14_8
.LBB14_7:                               # %common.ret
	or	a2, a10, a10
	retw.n
.LBB14_8:                               # %source.label13
	#APP
	rsr	a8, prid
	extui	a8, a8, 13, 1
	#NO_APP
	addx4	a8, a8, a7
	l32i	a8, a8, 0
	beqz.n	a8, .LBB14_10
# %bb.9:                                # %source.label5.i12
	l32r	a11, .LCPI14_5
	l32r	a8, .LCPI14_6
	j	.LBB14_2
.LBB14_10:                              # %source.label4.i15
	l32r	a11, .LCPI14_5
	l32r	a8, .LCPI14_7
	j	.LBB14_2
.Lfunc_end14:
	.size	abla_fn_500235045_572962334_direct, .Lfunc_end14-abla_fn_500235045_572962334_direct
                                        # -- End function
	.literal_position
	.literal .LCPI15_0, abla_fn_326491309_387073790_direct
	.literal .LCPI15_1, abla_fn_853840267_528021067_direct
	.section	.iram1.2.abla.esp32HeapCapsMallocDefault,"ax",@progbits
	.section	.iram1.8.abla.esp32HeapCapsCallocate,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_652716366_793746133_direct
	.type	abla_fn_652716366_793746133_direct,@function
abla_fn_652716366_793746133_direct:     # @abla_fn_652716366_793746133_direct
# %bb.0:                                # %entry
	entry	a1, 32
	or	a11, a3, a3
	l32r	a8, .LCPI15_0
	or	a10, a2, a2
	callx8	a8
	or	a7, a10, a10
	beqz.n	a7, .LBB15_2
# %bb.1:                                # %abla_fn_246791823_440449191_direct.exit
	l32r	a8, .LCPI15_1
	or	a10, a7, a7
	movi	a11, 0
	or	a12, a2, a2
	callx8	a8
.LBB15_2:                               # %source.label6
	or	a2, a7, a7
	retw.n
.Lfunc_end15:
	.size	abla_fn_652716366_793746133_direct, .Lfunc_end15-abla_fn_652716366_793746133_direct
                                        # -- End function
	.literal_position
	.literal .LCPI16_0, -2147483648
	.section	.iram1.8.abla.esp32HeapCapsCallocate,"ax",@progbits
	.section	.text.abla_fn_946434868_368388687_direct,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_946434868_368388687_direct
	.type	abla_fn_946434868_368388687_direct,@function
abla_fn_946434868_368388687_direct:     # @abla_fn_946434868_368388687_direct
# %bb.0:                                # %entry
	entry	a1, 32
	movi	a8, 0
	beqz	a2, .LBB16_57
# %bb.1:                                # %entry
	beqz	a3, .LBB16_57
# %bb.2:                                # %abla_fn_259878424_650702494_direct.exit.i
	addi	a10, a3, 3
	movi	a9, -4
	and	a12, a10, a9
	l32i	a11, a2, 16
	extui	a13, a11, 8, 6
	ssr	a13
	srl	a9, a12
	movi	a14, 31
	bgeu	a14, a13, .LBB16_3
	j	.LBB16_57
.LBB16_3:                               # %abla_fn_259878424_650702494_direct.exit.i
	bnez	a9, .LBB16_57
# %bb.4:                                # %source.label5.i
	movi	a9, 12
	bltu	a10, a9, .LBB16_6
# %bb.5:                                # %source.label5.i
	or	a9, a12, a12
.LBB16_6:                               # %source.label5.i
	extui	a8, a11, 23, 8
	bltu	a9, a8, .LBB16_11
# %bb.7:                                # %abla_fn_157370637_319623238_direct.exit
	#APP
	nsau	a8, a9
	#NO_APP
	l32i	a11, a2, 16
	extui	a10, a11, 20, 3
	add	a12, a10, a8
	l32r	a8, .LCPI16_0
	ssr	a12
	srl	a10, a8
	movi	a8, 0
	movi	a13, 31
	bgeu	a13, a12, .LBB16_9
# %bb.8:                                # %abla_fn_157370637_319623238_direct.exit
	movi	a10, 0
.LBB16_9:                               # %abla_fn_157370637_319623238_direct.exit
	neg	a12, a10
	add	a9, a9, a10
	addi	a9, a9, -1
	and	a9, a9, a12
	beqz	a9, .LBB16_57
# %bb.10:                               # %abla_fn_157370637_319623238_direct.exit.source.label2.i9_crit_edge
	extui	a8, a11, 23, 8
.LBB16_11:                              # %source.label2.i9
	extui	a10, a11, 23, 9
	bgeu	a9, a8, .LBB16_15
# %bb.12:                               # %source.label.i.i
	extui	a12, a11, 14, 6
	beqz	a12, .LBB16_58
# %bb.13:                               # %scalar.divide.checked.i.i
	bgeu	a8, a12, .LBB16_14
	j	.LBB16_58
.LBB16_14:                              # %scalar.divide.checked13.i.i
	extui	a8, a10, 0, 8
	quou	a8, a8, a12
	extui	a10, a9, 0, 8
	quou	a8, a10, a8
	slli	a12, a8, 8
	j	.LBB16_18
.LBB16_15:                              # %abla_fn_173146590_885096896_direct.exit.i.i
	#APP
	nsau	a8, a9
	#NO_APP
	l32i	a11, a2, 16
	extui	a10, a11, 20, 3
	add	a13, a8, a10
	sub	a12, a14, a13
	ssr	a12
	srl	a12, a9
	bgeu	a14, a13, .LBB16_17
# %bb.16:                               # %abla_fn_173146590_885096896_direct.exit.i.i
	movi	a12, 0
.LBB16_17:                              # %abla_fn_173146590_885096896_direct.exit.i.i
	movi	a13, 1
	ssl	a10
	sll	a10, a13
	xor	a10, a12, a10
	slli	a10, a10, 8
	extui	a12, a11, 5, 3
	add	a8, a8, a12
	movi	a12, 32
	sub	a8, a12, a8
	or	a12, a10, a8
.LBB16_18:                              # %abla_fn_425450285_944651937_direct.exit.i
	extui	a10, a12, 0, 8
	extui	a11, a11, 0, 5
	movi	a8, 0
	bltu	a10, a11, .LBB16_19
	j	.LBB16_57
.LBB16_19:                              # %source.label7.i
	extui	a8, a12, 8, 8
	movi	a11, -1
	ssl	a8
	sll	a11, a11
	movi	a12, 31
	bgeu	a12, a8, .LBB16_21
# %bb.20:                               # %source.label7.i
	movi	a11, 0
.LBB16_21:                              # %source.label7.i
	l32i	a8, a2, 28
	addx4	a12, a10, a8
	l32i	a12, a12, 0
	and	a11, a12, a11
	bnez.n	a11, .LBB16_27
# %bb.22:                               # %source.label14.i
	movi	a11, -2
	ssl	a10
	sll	a10, a11
	l32i	a11, a2, 24
	and	a10, a11, a10
	beqz	a10, .LBB16_44
# %bb.23:                               # %source.label19.i
	neg	a11, a10
	and	a10, a10, a11
	beqz.n	a10, .LBB16_25
# %bb.24:                               # %source.label2.i33.i
	#APP
	nsau	a10, a10
	#NO_APP
	movi	a11, 31
	sub	a10, a11, a10
	j	.LBB16_26
.LBB16_25:
	movi	a10, 32
.LBB16_26:                              # %abla_fn_483389371_503684775_direct.exit37.i
	addx4	a8, a10, a8
	l32i	a11, a8, 0
.LBB16_27:                              # %source.label21.i
	neg	a8, a11
	and	a8, a11, a8
	beqz.n	a8, .LBB16_29
# %bb.28:                               # %source.label2.i.i
	#APP
	nsau	a8, a8
	#NO_APP
	movi	a11, 31
	sub	a11, a11, a8
	j	.LBB16_30
.LBB16_29:
	movi	a11, 32
.LBB16_30:                              # %abla_fn_483389371_503684775_direct.exit.i
	l32i	a8, a2, 16
	extui	a8, a8, 14, 6
	mull	a8, a8, a10
	add	a8, a8, a11
	l32i	a12, a2, 32
	addx4	a8, a8, a12
	l32i	a8, a8, 0
	beqz	a8, .LBB16_44
# %bb.31:                               # %source.label23.i
	l32i	a12, a8, 8
	l32i	a13, a8, 12
	s32i	a13, a12, 12
	s32i	a12, a13, 8
	l32i	a13, a2, 16
	extui	a13, a13, 14, 6
	mull	a13, a13, a10
	add	a14, a13, a11
	l32i	a13, a2, 32
	addx4	a15, a14, a13
	l32i	a15, a15, 0
	bne	a15, a8, .LBB16_39
# %bb.32:                               # %source.label.i62.i
	slli	a14, a14, 2
	add	a13, a14, a13
	s32i	a12, a13, 0
	bne	a12, a2, .LBB16_39
# %bb.33:                               # %source.label14.i.i
	movi	a12, 1
	ssl	a11
	sll	a13, a12
	movi	a12, -1
	movi	a14, 31
	bltu	a14, a11, .LBB16_35
# %bb.34:
	xor	a12, a13, a12
.LBB16_35:                              # %source.label14.i.i
	l32i	a11, a2, 28
	addx4	a11, a10, a11
	l32i	a13, a11, 0
	and	a12, a13, a12
	s32i	a12, a11, 0
	bnez.n	a12, .LBB16_39
# %bb.36:                               # %source.label18.i.i
	movi	a11, 1
	ssl	a10
	sll	a12, a11
	movi	a11, -1
	movi	a13, 31
	bltu	a13, a10, .LBB16_38
# %bb.37:
	xor	a11, a12, a11
.LBB16_38:                              # %source.label18.i.i
	l32i	a10, a2, 24
	and	a10, a10, a11
	s32i	a10, a2, 24
.LBB16_39:                              # %source.label3.i
	l32i	a10, a8, 4
	movi	a12, -4
	and	a13, a10, a12
	addi	a10, a8, 4
	addi	a11, a9, 16
	bgeu	a13, a11, .LBB16_40
	j	.LBB16_56
.LBB16_40:                              # %source.label.i.i40
	add	a11, a8, a9
	sub	a13, a13, a9
	addi	a13, a13, -4
	s32i	a13, a11, 8
	l32i	a13, a8, 4
	extui	a13, a13, 0, 2
	or	a9, a13, a9
	s32i	a9, a8, 4
	l32i	a9, a11, 8
	and	a13, a9, a12
	addi	a9, a11, 4
	add	a13, a13, a9
	s32i	a9, a13, 4
	l32i	a14, a13, 8
	movi	a15, 2
	or	a14, a14, a15
	s32i	a14, a13, 8
	l32i	a13, a11, 8
	movi	a14, 1
	or	a13, a13, a14
	s32i	a13, a11, 8
	l32i	a13, a8, 4
	and	a13, a13, a12
	add	a13, a10, a13
	s32i	a8, a13, 0
	l32i	a13, a11, 8
	or	a14, a13, a15
	s32i	a14, a11, 8
	and	a14, a13, a12
	l32i	a13, a2, 16
	extui	a12, a13, 14, 6
	extui	a15, a13, 23, 8
	bgeu	a14, a15, .LBB16_45
# %bb.41:                               # %source.label.i.i.i.i
	beqz	a12, .LBB16_58
# %bb.42:                               # %scalar.divide.checked.i.i.i.i
	bgeu	a15, a12, .LBB16_43
	j	.LBB16_58
.LBB16_43:                              # %scalar.divide.checked13.i.i.i.i
	extui	a13, a13, 23, 9
	extui	a13, a13, 0, 8
	quou	a13, a13, a12
	extui	a14, a14, 0, 8
	quou	a13, a14, a13
	slli	a14, a13, 8
	j	.LBB16_51
.LBB16_44:
	movi	a8, 0
	j	.LBB16_57
.LBB16_45:                              # %source.label3.i.i.i.i
	beqz.n	a14, .LBB16_47
# %bb.46:                               # %source.label1.i.i.i.i.i
	#APP
	nsau	a12, a14
	#NO_APP
	movi	a13, 31
	sub	a15, a13, a12
	l32i	a13, a2, 16
	extui	a12, a13, 14, 6
	j	.LBB16_48
.LBB16_47:
	movi	a15, -1
.LBB16_48:                              # %abla_fn_173146590_885096896_direct.exit.i.i.i.i
	extui	a7, a13, 20, 3
	sub	a6, a15, a7
	ssr	a6
	srl	a14, a14
	movi	a5, 31
	bgeu	a5, a6, .LBB16_50
# %bb.49:                               # %abla_fn_173146590_885096896_direct.exit.i.i.i.i
	movi	a14, 0
.LBB16_50:                              # %abla_fn_173146590_885096896_direct.exit.i.i.i.i
	movi	a6, 1
	ssl	a7
	sll	a7, a6
	xor	a14, a14, a7
	slli	a14, a14, 8
	extui	a13, a13, 5, 3
	sub	a13, a15, a13
	addi	a13, a13, 1
	or	a14, a14, a13
.LBB16_51:                              # %abla_fn_386852483_179931374_direct.exit.i.i
	extui	a13, a14, 0, 8
	mull	a15, a12, a13
	extui	a12, a14, 8, 8
	add	a14, a15, a12
	l32i	a15, a2, 32
	addx4	a14, a14, a15
	l32i	a15, a14, 0
	s32i	a2, a11, 16
	s32i	a15, a11, 12
	s32i	a9, a15, 12
	s32i	a9, a14, 0
	movi	a9, 1
	ssl	a13
	sll	a14, a9
	movi	a11, 31
	bgeu	a11, a13, .LBB16_53
# %bb.52:                               # %abla_fn_386852483_179931374_direct.exit.i.i
	movi	a14, 0
.LBB16_53:                              # %abla_fn_386852483_179931374_direct.exit.i.i
	l32i	a15, a2, 24
	or	a14, a15, a14
	s32i	a14, a2, 24
	ssl	a12
	sll	a9, a9
	bgeu	a11, a12, .LBB16_55
# %bb.54:                               # %abla_fn_386852483_179931374_direct.exit.i.i
	movi	a9, 0
.LBB16_55:                              # %abla_fn_386852483_179931374_direct.exit.i.i
	l32i	a11, a2, 28
	addx4	a11, a13, a11
	l32i	a12, a11, 0
	or	a9, a12, a9
	s32i	a9, a11, 0
	l32i	a9, a10, 0
	movi	a11, -4
	and	a13, a9, a11
.LBB16_56:                              # %abla_fn_344321167_89439647_direct.exit.i
	addi	a8, a8, 8
	add	a9, a8, a13
	l32i	a11, a9, 0
	movi	a12, -3
	and	a11, a11, a12
	s32i	a11, a9, 0
	l32i	a9, a10, 0
	movi	a11, -2
	and	a9, a9, a11
	s32i	a9, a10, 0
.LBB16_57:                              # %common.ret
	or	a2, a8, a8
	retw.n
.LBB16_58:                              # %scalar.division.by.zero.i.i
	ill.n
.Lfunc_end16:
	.size	abla_fn_946434868_368388687_direct, .Lfunc_end16-abla_fn_946434868_368388687_direct
                                        # -- End function
	.section	.text.abla_fn_297717203_153064921_direct,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_297717203_153064921_direct
	.type	abla_fn_297717203_153064921_direct,@function
abla_fn_297717203_153064921_direct:     # @abla_fn_297717203_153064921_direct
# %bb.0:                                # %entry
	entry	a1, 32
	beqz	a2, .LBB17_59
# %bb.1:                                # %entry
	beqz	a3, .LBB17_59
# %bb.2:                                # %source.label7
	addi	a10, a3, -4
	l32i	a8, a10, 0
	movi	a9, -4
	and	a11, a8, a9
	add	a12, a10, a11
	addi	a8, a3, -8
	s32i	a8, a12, 0
	add	a11, a11, a3
	l32i	a12, a11, 0
	movi	a13, 2
	or	a12, a12, a13
	s32i	a12, a11, 0
	l32i	a12, a10, 0
	movi	a11, 1
	or	a11, a12, a11
	s32i	a11, a10, 0
	bbsi	a12, 1, .LBB17_4
# %bb.3:                                # %source.label7.abla_fn_439871305_227881272_direct.exit_crit_edge
	or	a9, a10, a10
	j	.LBB17_23
.LBB17_4:                               # %source.label.i
	l32i	a8, a8, 0
	l32i	a11, a8, 4
	and	a11, a11, a9
	l32i	a9, a2, 16
	extui	a13, a9, 23, 8
	bgeu	a11, a13, .LBB17_8
# %bb.5:                                # %source.label.i.i.i
	extui	a12, a9, 14, 6
	beqz	a12, .LBB17_60
# %bb.6:                                # %scalar.divide.checked.i.i.i
	bgeu	a13, a12, .LBB17_7
	j	.LBB17_60
.LBB17_7:                               # %scalar.divide.checked13.i.i.i
	extui	a9, a9, 23, 9
	extui	a9, a9, 0, 8
	quou	a9, a9, a12
	extui	a11, a11, 0, 8
	quou	a9, a11, a9
	slli	a12, a9, 8
	j	.LBB17_14
.LBB17_8:                               # %source.label3.i.i.i
	beqz.n	a11, .LBB17_10
# %bb.9:                                # %source.label1.i.i.i.i
	#APP
	nsau	a9, a11
	#NO_APP
	movi	a12, 31
	sub	a12, a12, a9
	l32i	a9, a2, 16
	j	.LBB17_11
.LBB17_10:
	movi	a12, -1
.LBB17_11:                              # %abla_fn_173146590_885096896_direct.exit.i.i.i
	extui	a13, a9, 20, 3
	sub	a14, a12, a13
	ssr	a14
	srl	a11, a11
	movi	a15, 31
	bgeu	a15, a14, .LBB17_13
# %bb.12:                               # %abla_fn_173146590_885096896_direct.exit.i.i.i
	movi	a11, 0
.LBB17_13:                              # %abla_fn_173146590_885096896_direct.exit.i.i.i
	movi	a14, 1
	ssl	a13
	sll	a13, a14
	xor	a11, a11, a13
	slli	a11, a11, 8
	extui	a9, a9, 5, 3
	sub	a9, a12, a9
	addi	a9, a9, 1
	or	a12, a11, a9
.LBB17_14:                              # %abla_fn_425450285_944651937_direct.exit.i.i
	addi	a9, a8, 4
	l32i	a13, a8, 8
	l32i	a11, a8, 12
	s32i	a11, a13, 12
	s32i	a13, a11, 8
	extui	a11, a12, 0, 8
	l32i	a14, a2, 16
	extui	a14, a14, 14, 6
	mull	a14, a14, a11
	extui	a12, a12, 8, 8
	add	a15, a14, a12
	l32i	a14, a2, 32
	addx4	a7, a15, a14
	l32i	a7, a7, 0
	bne	a7, a8, .LBB17_22
# %bb.15:                               # %source.label.i15.i.i
	slli	a15, a15, 2
	add	a14, a15, a14
	s32i	a13, a14, 0
	bne	a13, a2, .LBB17_22
# %bb.16:                               # %source.label14.i.i.i
	movi	a13, 1
	ssl	a12
	sll	a14, a13
	movi	a13, -1
	movi	a15, 31
	bltu	a15, a12, .LBB17_18
# %bb.17:
	xor	a13, a14, a13
.LBB17_18:                              # %source.label14.i.i.i
	l32i	a12, a2, 28
	addx4	a12, a11, a12
	l32i	a14, a12, 0
	and	a13, a14, a13
	s32i	a13, a12, 0
	bnez.n	a13, .LBB17_22
# %bb.19:                               # %source.label18.i.i.i
	movi	a12, 1
	ssl	a11
	sll	a13, a12
	movi	a12, -1
	movi	a14, 31
	bltu	a14, a11, .LBB17_21
# %bb.20:
	xor	a12, a13, a12
.LBB17_21:                              # %source.label18.i.i.i
	l32i	a11, a2, 24
	and	a11, a11, a12
	s32i	a11, a2, 24
.LBB17_22:                              # %abla_fn_128917703_965349236_direct.exit.i
	l32i	a10, a10, 0
	movi	a11, -4
	and	a10, a10, a11
	l32i	a12, a8, 4
	add	a10, a12, a10
	addi	a10, a10, 4
	s32i	a10, a8, 4
	and	a10, a10, a11
	add	a10, a9, a10
	s32i	a8, a10, 0
	l32i	a11, a8, 4
.LBB17_23:                              # %abla_fn_439871305_227881272_direct.exit
	movi	a10, -4
	and	a12, a11, a10
	add	a11, a12, a8
	l32i	a13, a11, 8
	bbci	a13, 0, .LBB17_28
# %bb.24:                               # %source.label.i56
	and	a13, a13, a10
	addi	a10, a2, 16
	l32i	a12, a2, 16
	extui	a15, a12, 23, 8
	bgeu	a13, a15, .LBB17_29
# %bb.25:                               # %source.label.i.i.i175
	extui	a14, a12, 14, 6
	beqz	a14, .LBB17_60
# %bb.26:                               # %scalar.divide.checked.i.i.i177
	bgeu	a15, a14, .LBB17_27
	j	.LBB17_60
.LBB17_27:                              # %scalar.divide.checked13.i.i.i179
	extui	a12, a12, 23, 9
	extui	a12, a12, 0, 8
	quou	a12, a12, a14
	extui	a13, a13, 0, 8
	quou	a12, a13, a12
	slli	a13, a12, 8
	j	.LBB17_35
.LBB17_28:                              # %abla_fn_439871305_227881272_direct.exit.abla_fn_922616927_949514961_direct.exit_crit_edge
	addi	a10, a2, 16
	j	.LBB17_44
.LBB17_29:                              # %source.label3.i.i.i70
	beqz.n	a13, .LBB17_31
# %bb.30:                               # %source.label1.i.i.i.i72
	#APP
	nsau	a12, a13
	#NO_APP
	movi	a14, 31
	sub	a14, a14, a12
	l32i	a12, a10, 0
	j	.LBB17_32
.LBB17_31:
	movi	a14, -1
.LBB17_32:                              # %abla_fn_173146590_885096896_direct.exit.i.i.i74
	extui	a15, a12, 20, 3
	sub	a7, a14, a15
	ssr	a7
	srl	a13, a13
	movi	a6, 31
	bgeu	a6, a7, .LBB17_34
# %bb.33:                               # %abla_fn_173146590_885096896_direct.exit.i.i.i74
	movi	a13, 0
.LBB17_34:                              # %abla_fn_173146590_885096896_direct.exit.i.i.i74
	movi	a7, 1
	ssl	a15
	sll	a15, a7
	xor	a13, a13, a15
	slli	a13, a13, 8
	extui	a12, a12, 5, 3
	sub	a12, a14, a12
	addi	a12, a12, 1
	or	a13, a13, a12
.LBB17_35:                              # %abla_fn_425450285_944651937_direct.exit.i.i98
	addi	a6, a11, 4
	l32i	a14, a11, 12
	l32i	a12, a11, 16
	s32i	a12, a14, 12
	s32i	a14, a12, 8
	extui	a12, a13, 0, 8
	l32i	a15, a2, 16
	extui	a15, a15, 14, 6
	mull	a15, a15, a12
	extui	a13, a13, 8, 8
	add	a7, a15, a13
	l32i	a15, a2, 32
	addx4	a5, a7, a15
	l32i	a5, a5, 0
	bne	a5, a6, .LBB17_43
# %bb.36:                               # %source.label.i15.i.i147
	slli	a7, a7, 2
	add	a15, a7, a15
	s32i	a14, a15, 0
	bne	a14, a2, .LBB17_43
# %bb.37:                               # %source.label14.i.i.i151
	movi	a14, 1
	ssl	a13
	sll	a15, a14
	movi	a14, -1
	movi	a7, 31
	bltu	a7, a13, .LBB17_39
# %bb.38:
	xor	a14, a15, a14
.LBB17_39:                              # %source.label14.i.i.i151
	l32i	a13, a2, 28
	addx4	a13, a12, a13
	l32i	a15, a13, 0
	and	a14, a15, a14
	s32i	a14, a13, 0
	bnez.n	a14, .LBB17_43
# %bb.40:                               # %source.label18.i.i.i167
	movi	a13, 1
	ssl	a12
	sll	a14, a13
	movi	a13, -1
	movi	a15, 31
	bltu	a15, a12, .LBB17_42
# %bb.41:
	xor	a13, a14, a13
.LBB17_42:                              # %source.label18.i.i.i167
	l32i	a12, a2, 24
	and	a12, a12, a13
	s32i	a12, a2, 24
.LBB17_43:                              # %abla_fn_128917703_965349236_direct.exit.i134
	l32i	a11, a11, 8
	movi	a12, -4
	and	a11, a11, a12
	l32i	a13, a9, 0
	add	a11, a13, a11
	addi	a11, a11, 4
	s32i	a11, a9, 0
	and	a11, a11, a12
	add	a11, a9, a11
	s32i	a8, a11, 0
	l32i	a9, a9, 0
	and	a12, a9, a12
.LBB17_44:                              # %abla_fn_922616927_949514961_direct.exit
	l32i	a11, a10, 0
	extui	a9, a11, 14, 6
	extui	a13, a11, 23, 8
	bgeu	a12, a13, .LBB17_48
# %bb.45:                               # %source.label.i.i
	beqz	a9, .LBB17_60
# %bb.46:                               # %scalar.divide.checked.i.i
	bgeu	a13, a9, .LBB17_47
	j	.LBB17_60
.LBB17_47:                              # %scalar.divide.checked13.i.i
	extui	a10, a11, 23, 9
	extui	a10, a10, 0, 8
	quou	a10, a10, a9
	extui	a11, a12, 0, 8
	quou	a10, a11, a10
	slli	a11, a10, 8
	j	.LBB17_54
.LBB17_48:                              # %source.label3.i.i
	beqz.n	a12, .LBB17_50
# %bb.49:                               # %source.label1.i.i.i
	#APP
	nsau	a9, a12
	#NO_APP
	movi	a11, 31
	sub	a13, a11, a9
	l32i	a11, a10, 0
	extui	a9, a11, 14, 6
	j	.LBB17_51
.LBB17_50:
	movi	a13, -1
.LBB17_51:                              # %abla_fn_173146590_885096896_direct.exit.i.i
	extui	a10, a11, 20, 3
	sub	a14, a13, a10
	ssr	a14
	srl	a12, a12
	movi	a15, 31
	bgeu	a15, a14, .LBB17_53
# %bb.52:                               # %abla_fn_173146590_885096896_direct.exit.i.i
	movi	a12, 0
.LBB17_53:                              # %abla_fn_173146590_885096896_direct.exit.i.i
	movi	a14, 1
	ssl	a10
	sll	a10, a14
	xor	a10, a12, a10
	slli	a10, a10, 8
	extui	a11, a11, 5, 3
	sub	a11, a13, a11
	addi	a11, a11, 1
	or	a11, a10, a11
.LBB17_54:                              # %abla_fn_386852483_179931374_direct.exit
	extui	a10, a11, 0, 8
	mull	a12, a9, a10
	extui	a9, a11, 8, 8
	add	a11, a12, a9
	l32i	a12, a2, 32
	addx4	a11, a11, a12
	l32i	a12, a11, 0
	s32i	a2, a8, 12
	s32i	a12, a8, 8
	s32i	a8, a12, 12
	s32i	a8, a11, 0
	movi	a8, 1
	ssl	a10
	sll	a12, a8
	movi	a11, 31
	bgeu	a11, a10, .LBB17_56
# %bb.55:                               # %abla_fn_386852483_179931374_direct.exit
	movi	a12, 0
.LBB17_56:                              # %abla_fn_386852483_179931374_direct.exit
	l32i	a13, a2, 24
	or	a12, a13, a12
	s32i	a12, a2, 24
	ssl	a9
	sll	a8, a8
	bgeu	a11, a9, .LBB17_58
# %bb.57:                               # %abla_fn_386852483_179931374_direct.exit
	movi	a8, 0
.LBB17_58:                              # %abla_fn_386852483_179931374_direct.exit
	l32i	a9, a2, 28
	addx4	a9, a10, a9
	l32i	a10, a9, 0
	or	a8, a10, a8
	s32i	a8, a9, 0
.LBB17_59:                              # %common.ret
	retw.n
.LBB17_60:                              # %scalar.division.by.zero.i.i.i
	ill.n
.Lfunc_end17:
	.size	abla_fn_297717203_153064921_direct, .Lfunc_end17-abla_fn_297717203_153064921_direct
                                        # -- End function
	.literal_position
	.literal .LCPI18_0, abla_fn_186944242_355245718_direct
	.section	.text.abla_fn_297717203_153064921_direct,"ax",@progbits
	.section	.text.abla_fn_524213402_227204421_direct,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_524213402_227204421_direct
	.type	abla_fn_524213402_227204421_direct,@function
abla_fn_524213402_227204421_direct:     # @abla_fn_524213402_227204421_direct
# %bb.0:                                # %entry
	entry	a1, 32
	l32i	a10, a2, 0
	beqz.n	a10, .LBB18_2
# %bb.1:                                # %source.label
	l32r	a8, .LCPI18_0
	callx8	a8
.LBB18_2:                               # %source.label2
	retw.n
.Lfunc_end18:
	.size	abla_fn_524213402_227204421_direct, .Lfunc_end18-abla_fn_524213402_227204421_direct
                                        # -- End function
	.literal_position
	.literal .LCPI19_0, abla_fn_707068177_288599970_direct
	.section	.text.abla_fn_524213402_227204421_direct,"ax",@progbits
	.section	.text.abla_fn_973951929_967810110_direct,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_973951929_967810110_direct
	.type	abla_fn_973951929_967810110_direct,@function
abla_fn_973951929_967810110_direct:     # @abla_fn_973951929_967810110_direct
# %bb.0:                                # %entry
	entry	a1, 32
	l32i	a10, a2, 0
	beqz.n	a10, .LBB19_2
# %bb.1:                                # %source.label
	l32r	a8, .LCPI19_0
	callx8	a8
.LBB19_2:                               # %source.label3
	retw.n
.Lfunc_end19:
	.size	abla_fn_973951929_967810110_direct, .Lfunc_end19-abla_fn_973951929_967810110_direct
                                        # -- End function
	.section	.text.abla_fn_831776377_590574128_direct,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_831776377_590574128_direct
	.type	abla_fn_831776377_590574128_direct,@function
abla_fn_831776377_590574128_direct:     # @abla_fn_831776377_590574128_direct
# %bb.0:                                # %entry
	entry	a1, 32
	movi	a7, 0
	bnez	a7, .LBB20_96
# %bb.1:                                # %entry
	beqz	a3, .LBB20_96
# %bb.2:                                # %entry
	addi	a6, a4, -1
	and	a8, a4, a6
	bnez	a8, .LBB20_96
# %bb.3:                                # %source.label10
	or	a10, a2, a2
	call8	abla_fn_524213402_227204421_direct
	l32i	a8, a2, 16
	beqz	a8, .LBB20_13
# %bb.4:                                # %abla_fn_259878424_650702494_direct.exit.i42.i
	addi	a11, a3, 3
	movi	a9, -4
	and	a10, a11, a9
	movi	a9, 12
	bltu	a11, a9, .LBB20_6
# %bb.5:                                # %abla_fn_259878424_650702494_direct.exit.i42.i
	or	a9, a10, a10
.LBB20_6:                               # %abla_fn_259878424_650702494_direct.exit.i42.i
	l32i	a11, a8, 16
	extui	a12, a11, 8, 6
	ssr	a12
	srl	a10, a10
	movi	a13, 0
	beq	a10, a13, .LBB20_8
# %bb.7:                                # %abla_fn_259878424_650702494_direct.exit.i42.i
	movi	a9, 0
.LBB20_8:                               # %abla_fn_259878424_650702494_direct.exit.i42.i
	movi	a10, 32
	bltu	a12, a10, .LBB20_10
# %bb.9:                                # %abla_fn_259878424_650702494_direct.exit.i42.i
	movi	a9, 0
.LBB20_10:                              # %abla_fn_259878424_650702494_direct.exit.i42.i
	add	a10, a4, a9
	addi	a14, a10, 16
	neg	a10, a4
	beqz.n	a14, .LBB20_17
# %bb.11:                               # %abla_fn_259878424_650702494_direct.exit.i.i
	add	a13, a4, a14
	addi	a13, a13, -1
	and	a13, a13, a10
	ssr	a12
	srl	a14, a13
	movi	a15, 0
	beq	a14, a15, .LBB20_14
# %bb.12:                               # %abla_fn_259878424_650702494_direct.exit.i.i
	movi	a13, 0
	j	.LBB20_15
.LBB20_13:
	movi	a7, 0
	j	.LBB20_95
.LBB20_14:
	movi	a14, 12
	maxu	a13, a13, a14
.LBB20_15:                              # %abla_fn_259878424_650702494_direct.exit.i.i
	movi	a14, 32
	bltu	a12, a14, .LBB20_17
# %bb.16:                               # %abla_fn_259878424_650702494_direct.exit.i.i
	movi	a13, 0
.LBB20_17:                              # %abla_fn_893648206_137591682_direct.exit.i
	movi	a12, 0
	beq	a9, a12, .LBB20_19
# %bb.18:                               # %abla_fn_893648206_137591682_direct.exit.i
	or	a12, a13, a13
.LBB20_19:                              # %abla_fn_893648206_137591682_direct.exit.i
	extui	a13, a11, 23, 8
	bltu	a12, a13, .LBB20_26
# %bb.20:                               # %source.label.i.i
	beqz.n	a12, .LBB20_22
# %bb.21:                               # %source.label1.i.i51.i
	#APP
	nsau	a11, a12
	#NO_APP
	movi	a13, 31
	sub	a13, a13, a11
	l32i	a11, a8, 16
	j	.LBB20_23
.LBB20_22:
	movi	a13, -1
.LBB20_23:                              # %abla_fn_173146590_885096896_direct.exit.i.i
	extui	a14, a11, 20, 3
	sub	a14, a13, a14
	movi	a13, 1
	ssl	a14
	sll	a13, a13
	movi	a15, 31
	bgeu	a15, a14, .LBB20_25
# %bb.24:                               # %abla_fn_173146590_885096896_direct.exit.i.i
	movi	a13, 0
.LBB20_25:                              # %abla_fn_173146590_885096896_direct.exit.i.i
	neg	a14, a13
	add	a12, a12, a13
	addi	a12, a12, -1
	and	a12, a12, a14
.LBB20_26:                              # %abla_fn_157370637_319623238_direct.exit.i
	movi	a7, 0
	beqz	a12, .LBB20_95
# %bb.27:                               # %source.label2.i59.i
	extui	a14, a11, 23, 8
	bgeu	a12, a14, .LBB20_31
# %bb.28:                               # %source.label.i.i.i
	extui	a13, a11, 14, 6
	beqz	a13, .LBB20_97
# %bb.29:                               # %scalar.divide.checked.i.i.i
	bgeu	a14, a13, .LBB20_30
	j	.LBB20_97
.LBB20_30:                              # %scalar.divide.checked13.i.i.i
	extui	a14, a11, 23, 9
	extui	a14, a14, 0, 8
	quou	a13, a14, a13
	extui	a12, a12, 0, 8
	quou	a12, a12, a13
	slli	a12, a12, 8
	j	.LBB20_34
.LBB20_31:                              # %abla_fn_173146590_885096896_direct.exit.i.i.i
	#APP
	nsau	a13, a12
	#NO_APP
	l32i	a11, a8, 16
	extui	a14, a11, 20, 3
	add	a15, a14, a13
	movi	a5, 31
	sub	a3, a5, a15
	ssr	a3
	srl	a12, a12
	bgeu	a5, a15, .LBB20_33
# %bb.32:                               # %abla_fn_173146590_885096896_direct.exit.i.i.i
	movi	a12, 0
.LBB20_33:                              # %abla_fn_173146590_885096896_direct.exit.i.i.i
	movi	a15, 1
	ssl	a14
	sll	a14, a15
	xor	a12, a12, a14
	slli	a12, a12, 8
	extui	a14, a11, 5, 3
	add	a13, a13, a14
	movi	a14, 32
	sub	a13, a14, a13
	or	a12, a12, a13
.LBB20_34:                              # %abla_fn_425450285_944651937_direct.exit.i.i
	extui	a13, a12, 0, 8
	extui	a11, a11, 0, 5
	bltu	a13, a11, .LBB20_35
	j	.LBB20_95
.LBB20_35:                              # %source.label7.i.i
	extui	a11, a12, 8, 8
	movi	a12, -1
	ssl	a11
	sll	a12, a12
	movi	a14, 31
	bgeu	a14, a11, .LBB20_37
# %bb.36:                               # %source.label7.i.i
	movi	a12, 0
.LBB20_37:                              # %source.label7.i.i
	l32i	a11, a8, 28
	addx4	a14, a13, a11
	l32i	a14, a14, 0
	and	a12, a14, a12
	bnez.n	a12, .LBB20_43
# %bb.38:                               # %source.label14.i.i
	movi	a12, -2
	ssl	a13
	sll	a12, a12
	l32i	a13, a8, 24
	and	a12, a13, a12
	beqz	a12, .LBB20_95
# %bb.39:                               # %source.label19.i.i
	neg	a13, a12
	and	a12, a12, a13
	beqz.n	a12, .LBB20_41
# %bb.40:                               # %source.label2.i33.i.i
	#APP
	nsau	a12, a12
	#NO_APP
	movi	a13, 31
	sub	a13, a13, a12
	j	.LBB20_42
.LBB20_41:
	movi	a13, 32
.LBB20_42:                              # %abla_fn_483389371_503684775_direct.exit37.i.i
	addx4	a11, a13, a11
	l32i	a12, a11, 0
.LBB20_43:                              # %source.label21.i.i
	neg	a11, a12
	and	a11, a12, a11
	beqz.n	a11, .LBB20_45
# %bb.44:                               # %source.label2.i.i.i
	#APP
	nsau	a11, a11
	#NO_APP
	movi	a12, 31
	sub	a14, a12, a11
	j	.LBB20_46
.LBB20_45:
	movi	a14, 32
.LBB20_46:                              # %abla_fn_483389371_503684775_direct.exit.i.i
	l32i	a11, a8, 16
	extui	a11, a11, 14, 6
	mull	a11, a11, a13
	add	a11, a11, a14
	l32i	a12, a8, 32
	addx4	a11, a11, a12
	l32i	a12, a11, 0
	beqz	a12, .LBB20_95
# %bb.47:                               # %source.label23.i.i
	l32i	a15, a12, 8
	l32i	a11, a12, 12
	s32i	a11, a15, 12
	s32i	a15, a11, 8
	l32i	a11, a8, 16
	extui	a11, a11, 14, 6
	mull	a11, a11, a13
	add	a5, a11, a14
	l32i	a7, a8, 32
	addx4	a11, a5, a7
	l32i	a3, a11, 0
	addi	a11, a12, 8
	bne	a3, a12, .LBB20_55
# %bb.48:                               # %source.label.i62.i.i
	slli	a5, a5, 2
	add	a7, a5, a7
	s32i	a15, a7, 0
	bne	a15, a8, .LBB20_55
# %bb.49:                               # %source.label14.i.i.i
	movi	a15, 1
	ssl	a14
	sll	a7, a15
	movi	a15, -1
	movi	a5, 31
	bltu	a5, a14, .LBB20_51
# %bb.50:
	xor	a15, a7, a15
.LBB20_51:                              # %source.label14.i.i.i
	l32i	a14, a8, 28
	addx4	a14, a13, a14
	l32i	a7, a14, 0
	and	a15, a7, a15
	s32i	a15, a14, 0
	bnez.n	a15, .LBB20_55
# %bb.52:                               # %source.label18.i.i.i
	movi	a14, 1
	ssl	a13
	sll	a15, a14
	movi	a14, -1
	movi	a7, 31
	bltu	a7, a13, .LBB20_54
# %bb.53:
	xor	a14, a15, a14
.LBB20_54:                              # %source.label18.i.i.i
	l32i	a13, a8, 24
	and	a13, a13, a14
	s32i	a13, a8, 24
.LBB20_55:                              # %source.label24.i
	add	a13, a11, a6
	and	a13, a13, a10
	sub	a14, a13, a11
	addi	a15, a14, -1
	movi	a7, 14
	bltu	a7, a15, .LBB20_57
# %bb.56:                               # %source.label41.i
	add	a13, a13, a6
	movi	a15, 16
	sub	a14, a15, a14
	maxu	a14, a14, a4
	add	a13, a13, a14
	and	a10, a13, a10
	sub	a14, a10, a11
.LBB20_57:                              # %source.label48.i
	addi	a11, a12, 4
	beqz.n	a14, .LBB20_59
# %bb.58:                               # %source.label49.i
	l32i	a10, a11, 0
	movi	a13, -4
	and	a15, a10, a13
	addi	a10, a14, 16
	bgeu	a15, a10, .LBB20_60
.LBB20_59:
	or	a10, a12, a12
	j	.LBB20_75
.LBB20_60:                              # %source.label3.i100.i
	add	a10, a14, a12
	sub	a15, a15, a14
	s32i	a15, a10, 4
	addi	a14, a14, -4
	l32i	a15, a12, 4
	extui	a15, a15, 0, 2
	or	a14, a15, a14
	s32i	a14, a12, 4
	l32i	a14, a10, 4
	and	a14, a14, a13
	add	a14, a14, a10
	s32i	a10, a14, 4
	l32i	a15, a14, 8
	movi	a7, 2
	or	a15, a15, a7
	s32i	a15, a14, 8
	l32i	a14, a10, 4
	movi	a15, 3
	or	a14, a14, a15
	s32i	a14, a10, 4
	l32i	a14, a12, 4
	and	a14, a14, a13
	add	a11, a14, a11
	s32i	a12, a11, 0
	l32i	a11, a12, 4
	and	a14, a11, a13
	l32i	a13, a8, 16
	extui	a11, a13, 14, 6
	extui	a15, a13, 23, 8
	bgeu	a14, a15, .LBB20_64
# %bb.61:                               # %source.label.i.i.i.i
	beqz	a11, .LBB20_97
# %bb.62:                               # %scalar.divide.checked.i.i.i.i
	bgeu	a15, a11, .LBB20_63
	j	.LBB20_97
.LBB20_63:                              # %scalar.divide.checked13.i.i.i.i
	extui	a13, a13, 23, 9
	extui	a13, a13, 0, 8
	quou	a13, a13, a11
	extui	a14, a14, 0, 8
	quou	a13, a14, a13
	slli	a14, a13, 8
	j	.LBB20_70
.LBB20_64:                              # %source.label3.i.i.i.i
	beqz.n	a14, .LBB20_66
# %bb.65:                               # %source.label1.i.i.i.i.i
	#APP
	nsau	a11, a14
	#NO_APP
	movi	a13, 31
	sub	a15, a13, a11
	l32i	a13, a8, 16
	extui	a11, a13, 14, 6
	j	.LBB20_67
.LBB20_66:
	movi	a15, -1
.LBB20_67:                              # %abla_fn_173146590_885096896_direct.exit.i.i.i.i
	extui	a7, a13, 20, 3
	sub	a6, a15, a7
	ssr	a6
	srl	a14, a14
	movi	a5, 31
	bgeu	a5, a6, .LBB20_69
# %bb.68:                               # %abla_fn_173146590_885096896_direct.exit.i.i.i.i
	movi	a14, 0
.LBB20_69:                              # %abla_fn_173146590_885096896_direct.exit.i.i.i.i
	movi	a6, 1
	ssl	a7
	sll	a7, a6
	xor	a14, a14, a7
	slli	a14, a14, 8
	extui	a13, a13, 5, 3
	sub	a13, a15, a13
	addi	a13, a13, 1
	or	a14, a14, a13
.LBB20_70:                              # %source.label51.i
	extui	a13, a14, 0, 8
	mull	a11, a13, a11
	extui	a14, a14, 8, 8
	add	a11, a11, a14
	l32i	a15, a8, 32
	addx4	a11, a11, a15
	l32i	a15, a11, 0
	s32i	a8, a12, 12
	s32i	a15, a12, 8
	s32i	a12, a15, 12
	s32i	a12, a11, 0
	movi	a12, 1
	ssl	a13
	sll	a6, a12
	movi	a7, 0
	movi	a15, 31
	bgeu	a15, a13, .LBB20_72
# %bb.71:                               # %source.label51.i
	movi	a6, 0
.LBB20_72:                              # %source.label51.i
	addi	a11, a10, 4
	l32i	a5, a8, 24
	or	a6, a5, a6
	s32i	a6, a8, 24
	ssl	a14
	sll	a12, a12
	bgeu	a15, a14, .LBB20_74
# %bb.73:                               # %source.label51.i
	movi	a12, 0
.LBB20_74:                              # %source.label51.i
	l32i	a14, a8, 28
	addx4	a13, a13, a14
	l32i	a14, a13, 0
	or	a12, a14, a12
	s32i	a12, a13, 0
	beqz	a10, .LBB20_95
.LBB20_75:                              # %source.label3.i.i
	l32i	a12, a10, 4
	movi	a13, -4
	and	a14, a12, a13
	addi	a12, a9, 16
	bgeu	a14, a12, .LBB20_76
	j	.LBB20_91
.LBB20_76:                              # %source.label.i.i91.i
	add	a12, a10, a9
	sub	a14, a14, a9
	addi	a14, a14, -4
	s32i	a14, a12, 8
	l32i	a14, a11, 0
	extui	a14, a14, 0, 2
	or	a9, a14, a9
	s32i	a9, a11, 0
	l32i	a9, a12, 8
	and	a14, a9, a13
	addi	a9, a12, 4
	add	a14, a14, a9
	s32i	a9, a14, 4
	l32i	a15, a14, 8
	movi	a7, 2
	or	a15, a15, a7
	s32i	a15, a14, 8
	l32i	a14, a12, 8
	movi	a15, 1
	or	a14, a14, a15
	s32i	a14, a12, 8
	l32i	a14, a11, 0
	and	a14, a14, a13
	add	a14, a14, a11
	s32i	a10, a14, 0
	l32i	a14, a12, 8
	or	a15, a14, a7
	s32i	a15, a12, 8
	and	a15, a14, a13
	l32i	a14, a8, 16
	extui	a13, a14, 14, 6
	extui	a7, a14, 23, 8
	bgeu	a15, a7, .LBB20_80
# %bb.77:                               # %source.label.i.i.i.i.i
	beqz	a13, .LBB20_97
# %bb.78:                               # %scalar.divide.checked.i.i.i.i.i
	bgeu	a7, a13, .LBB20_79
	j	.LBB20_97
.LBB20_79:                              # %scalar.divide.checked13.i.i.i.i.i
	extui	a14, a14, 23, 9
	extui	a14, a14, 0, 8
	quou	a14, a14, a13
	extui	a15, a15, 0, 8
	quou	a14, a15, a14
	slli	a15, a14, 8
	j	.LBB20_86
.LBB20_80:                              # %source.label3.i.i.i.i.i
	beqz.n	a15, .LBB20_82
# %bb.81:                               # %source.label1.i.i.i.i.i.i
	#APP
	nsau	a13, a15
	#NO_APP
	movi	a14, 31
	sub	a7, a14, a13
	l32i	a14, a8, 16
	extui	a13, a14, 14, 6
	j	.LBB20_83
.LBB20_82:
	movi	a7, -1
.LBB20_83:                              # %abla_fn_173146590_885096896_direct.exit.i.i.i.i.i
	extui	a6, a14, 20, 3
	sub	a5, a7, a6
	ssr	a5
	srl	a15, a15
	movi	a4, 31
	bgeu	a4, a5, .LBB20_85
# %bb.84:                               # %abla_fn_173146590_885096896_direct.exit.i.i.i.i.i
	movi	a15, 0
.LBB20_85:                              # %abla_fn_173146590_885096896_direct.exit.i.i.i.i.i
	movi	a5, 1
	ssl	a6
	sll	a6, a5
	xor	a15, a15, a6
	slli	a15, a15, 8
	extui	a14, a14, 5, 3
	sub	a14, a7, a14
	addi	a14, a14, 1
	or	a15, a15, a14
.LBB20_86:                              # %abla_fn_386852483_179931374_direct.exit.i.i.i
	extui	a14, a15, 0, 8
	mull	a7, a14, a13
	extui	a13, a15, 8, 8
	add	a15, a7, a13
	l32i	a7, a8, 32
	addx4	a15, a15, a7
	l32i	a7, a15, 0
	s32i	a8, a12, 16
	s32i	a7, a12, 12
	s32i	a9, a7, 12
	s32i	a9, a15, 0
	movi	a9, 1
	ssl	a14
	sll	a15, a9
	movi	a12, 31
	bgeu	a12, a14, .LBB20_88
# %bb.87:                               # %abla_fn_386852483_179931374_direct.exit.i.i.i
	movi	a15, 0
.LBB20_88:                              # %abla_fn_386852483_179931374_direct.exit.i.i.i
	l32i	a7, a8, 24
	or	a15, a7, a15
	s32i	a15, a8, 24
	ssl	a13
	sll	a9, a9
	bgeu	a12, a13, .LBB20_90
# %bb.89:                               # %abla_fn_386852483_179931374_direct.exit.i.i.i
	movi	a9, 0
.LBB20_90:                              # %abla_fn_386852483_179931374_direct.exit.i.i.i
	l32i	a8, a8, 28
	addx4	a8, a14, a8
	l32i	a12, a8, 0
	or	a9, a12, a9
	s32i	a9, a8, 0
	l32i	a8, a11, 0
	movi	a9, -4
	and	a14, a8, a9
.LBB20_91:                              # %abla_fn_533195239_663534289_direct.exit
	addi	a8, a10, 8
	add	a9, a14, a8
	l32i	a12, a9, 0
	movi	a13, -3
	and	a12, a12, a13
	s32i	a12, a9, 0
	l32i	a9, a11, 0
	movi	a12, -2
	and	a9, a9, a12
	s32i	a9, a11, 0
	movi	a7, 0
	beqz.n	a8, .LBB20_95
# %bb.92:                               # %abla_fn_126288948_669618382_direct.exit
	l32i	a9, a10, 4
	movi	a10, -4
	and	a9, a9, a10
	l32i	a10, a2, 4
	sub	a9, a10, a9
	addi	a9, a9, -4
	s32i	a9, a2, 4
	l32i	a10, a2, 8
	bgeu	a9, a10, .LBB20_94
# %bb.93:                               # %source.label14
	s32i	a9, a2, 8
.LBB20_94:                              # %source.label18
	or	a7, a8, a8
.LBB20_95:                              # %source.label18
	or	a10, a2, a2
	call8	abla_fn_973951929_967810110_direct
.LBB20_96:                              # %common.ret
	or	a2, a7, a7
	retw.n
.LBB20_97:                              # %scalar.division.by.zero.i.i.i
	ill.n
.Lfunc_end20:
	.size	abla_fn_831776377_590574128_direct, .Lfunc_end20-abla_fn_831776377_590574128_direct
                                        # -- End function
	.literal_position
	.literal .LCPI21_0, 1966088
	.literal .LCPI21_1, 393216
	.literal .LCPI21_2, -393225
	.literal .LCPI21_3, -524297
	.literal .LCPI21_4, -524289
	.section	.text.abla_fn_831776377_590574128_direct,"ax",@progbits
	.section	.iram1.0.abla.esp32HeapAdjustAlignmentToHardware,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_943683849_603704949_direct
	.type	abla_fn_943683849_603704949_direct,@function
abla_fn_943683849_603704949_direct:     # @abla_fn_943683849_603704949_direct
# %bb.0:                                # %entry
	entry	a1, 32
	l32i	a8, a4, 0
	l32r	a9, .LCPI21_0
	and	a9, a8, a9
	beqz	a9, .LBB21_7
# %bb.1:                                # %source.label6
	srli	a9, a8, 8
	movi	a10, 4
	and	a9, a9, a10
	l32i	a10, a2, 0
	maxu	a9, a9, a10
	l32i	a10, a3, 0
	s32i	a9, a2, 0
	neg	a11, a9
	add	a9, a9, a10
	addi	a9, a9, -1
	and	a9, a9, a11
	s32i	a9, a3, 0
	l32r	a9, .LCPI21_1
	and	a10, a8, a9
	movi	a9, 0
	beq	a10, a9, .LBB21_3
# %bb.2:                                # %source.label6
	l32r	a10, .LCPI21_2
	and	a8, a8, a10
	movi	a10, 8
	or	a8, a8, a10
.LBB21_3:                               # %source.label6
	movi	a10, 1024
	and	a10, a8, a10
	beq	a10, a9, .LBB21_5
# %bb.4:                                # %source.label6
	l32r	a9, .LCPI21_3
	j	.LBB21_6
.LBB21_5:
	l32r	a9, .LCPI21_4
.LBB21_6:                               # %source.label6
	and	a8, a9, a8
	s32i	a8, a4, 0
.LBB21_7:                               # %common.ret
	retw.n
.Lfunc_end21:
	.size	abla_fn_943683849_603704949_direct, .Lfunc_end21-abla_fn_943683849_603704949_direct
                                        # -- End function
	.literal_position
	.literal .LCPI22_0, abla_static_abla_fn_627837887_633683867_4112
	.section	.iram1.0.abla.esp32HeapAdjustAlignmentToHardware,"ax",@progbits
	.section	.text.abla_fn_268325070_984894759_direct,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_268325070_984894759_direct
	.type	abla_fn_268325070_984894759_direct,@function
abla_fn_268325070_984894759_direct:     # @abla_fn_268325070_984894759_direct
# %bb.0:                                # %entry
	entry	a1, 32
	l32r	a8, .LCPI22_0
.LBB22_1:                               # %source.label
                                        # =>This Inner Loop Header: Depth=1
	l32i	a8, a8, 0
	beqz.n	a8, .LBB22_6
# %bb.2:                                # %source.label1
                                        #   in Loop: Header=BB22_1 Depth=1
	l32i	a9, a8, 28
	beqz.n	a9, .LBB22_5
# %bb.3:                                # %source.label3
                                        #   in Loop: Header=BB22_1 Depth=1
	l32i	a9, a8, 12
	bltu	a2, a9, .LBB22_5
# %bb.4:                                # %source.label4
                                        #   in Loop: Header=BB22_1 Depth=1
	l32i	a9, a8, 16
	bltu	a2, a9, .LBB22_6
.LBB22_5:                               # %source.label9
                                        #   in Loop: Header=BB22_1 Depth=1
	addi	a8, a8, 32
	j	.LBB22_1
.LBB22_6:                               # %common.ret
	or	a2, a8, a8
	retw.n
.Lfunc_end22:
	.size	abla_fn_268325070_984894759_direct, .Lfunc_end22-abla_fn_268325070_984894759_direct
                                        # -- End function
	.literal_position
	.literal .LCPI23_0, -1074397184
	.literal .LCPI23_1, 139263
	.literal .LCPI23_2, abla_fn_268325070_984894759_direct
	.literal .LCPI23_3, abla_fn_524213402_227204421_direct
	.literal .LCPI23_4, abla_fn_297717203_153064921_direct
	.literal .LCPI23_5, abla_fn_973951929_967810110_direct
	.section	.text.abla_fn_268325070_984894759_direct,"ax",@progbits
	.section	.iram1.1.abla.esp32HeapCapsFree,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_213944016_953228118_direct
	.type	abla_fn_213944016_953228118_direct,@function
abla_fn_213944016_953228118_direct:     # @abla_fn_213944016_953228118_direct
# %bb.0:                                # %entry
	entry	a1, 32
	beqz	a2, .LBB23_13
# %bb.1:                                # %source.label5
	l32r	a8, .LCPI23_0
	add	a8, a2, a8
	l32r	a9, .LCPI23_1
	bltu	a9, a8, .LBB23_3
# %bb.2:                                # %source.label6
	addi	a8, a2, -4
	l32i	a2, a8, 0
.LBB23_3:                               # %source.label8
	l32r	a8, .LCPI23_2
	or	a10, a2, a2
	callx8	a8
	beqz	a10, .LBB23_14
# %bb.4:                                # %source.label12
	l32i	a7, a10, 28
	beqz	a7, .LBB23_13
# %bb.5:                                # %source.label12
	beqz	a2, .LBB23_13
# %bb.6:                                # %source.label11.i.i
	beqi	a2, 8, .LBB23_14
# %bb.7:                                # %source.label5.i.i.i
	l32i	a8, a7, 16
	beqz.n	a8, .LBB23_9
# %bb.8:                                # %source.label1.i.i.i.i.i
	l32i	a9, a8, 20
	j	.LBB23_10
.LBB23_9:
	movi	a9, 0
.LBB23_10:                              # %abla_fn_896935147_719056048_direct.exit.i.i.i
	add	a8, a9, a8
	bltu	a2, a8, .LBB23_14
# %bb.11:                               # %abla_fn_295721179_363527029_direct.exit.i.i
	l32i	a9, a7, 12
	add	a8, a9, a8
	bgeu	a2, a8, .LBB23_14
# %bb.12:                               # %abla_fn_126288948_669618382_direct.exit.i.i
	l32r	a8, .LCPI23_3
	or	a10, a7, a7
	callx8	a8
	addi	a8, a2, -4
	l32i	a8, a8, 0
	movi	a9, -4
	and	a8, a8, a9
	l32i	a9, a7, 4
	add	a8, a9, a8
	addi	a8, a8, 4
	s32i	a8, a7, 4
	l32i	a10, a7, 16
	l32r	a8, .LCPI23_4
	or	a11, a2, a2
	callx8	a8
	l32r	a8, .LCPI23_5
	or	a10, a7, a7
	callx8	a8
.LBB23_13:                              # %common.ret
	retw.n
.LBB23_14:                              # %source.label10
	ill.n
.Lfunc_end23:
	.size	abla_fn_213944016_953228118_direct, .Lfunc_end23-abla_fn_213944016_953228118_direct
                                        # -- End function
	.literal_position
	.literal .LCPI24_0, abla_fn_943683849_603704949_direct
	.literal .LCPI24_1, -4194305
	.literal .LCPI24_2, 16777212
	.literal .LCPI24_3, abla_static_abla_fn_627837887_633683867_4112
	.literal .LCPI24_4, -8192
	.literal .LCPI24_5, -131072
	.literal .LCPI24_6, 1073610752
	.literal .LCPI24_7, 1073217536
	.literal .LCPI24_8, abla_fn_831776377_590574128_direct
	.literal .LCPI24_9, abla_fn_524213402_227204421_direct
	.literal .LCPI24_10, abla_fn_946434868_368388687_direct
	.literal .LCPI24_11, abla_fn_973951929_967810110_direct
	.literal .LCPI24_12, -2146828288
	.literal .LCPI24_13, -2146828284
	.literal .LCPI24_14, abla_fn_831776377_590574128_direct
	.literal .LCPI24_15, abla_fn_524213402_227204421_direct
	.literal .LCPI24_16, abla_fn_946434868_368388687_direct
	.literal .LCPI24_17, abla_fn_973951929_967810110_direct
	.section	.iram1.1.abla.esp32HeapCapsFree,"ax",@progbits
	.section	.iram1.3.abla.esp32HeapCapsAlignedAllocateBase,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_510554077_859267517_direct
	.type	abla_fn_510554077_859267517_direct,@function
abla_fn_510554077_859267517_direct:     # @abla_fn_510554077_859267517_direct
# %bb.0:                                # %entry
	entry	a1, 80
	s32i	a4, a1, 40
	s32i	a3, a1, 36
	s32i	a2, a1, 32
	movi	a8, 4
	addi	a10, a1, 32
	or	a11, a10, a8
	movi	a8, 8
	or	a12, a10, a8
	l32r	a8, .LCPI24_0
	callx8	a8
	l32r	a8, .LCPI24_1
	l32i	a10, a1, 36
	add	a9, a10, a8
	movi	a2, 0
	bgeu	a8, a9, .LBB24_3
# %bb.1:                                # %source.label14
	l32i	a8, a1, 40
	l32i	a12, a1, 32
	or	a5, a8, a8
	bbci	a8, 0, .LBB24_5
# %bb.2:                                # %source.label16
	movi	a9, 12
	and	a9, a8, a9
	beqz.n	a9, .LBB24_4
.LBB24_3:                               # %common.ret
	retw.n
.LBB24_4:                               # %source.label19
	movi	a9, 2
	or	a5, a8, a9
.LBB24_5:                               # %source.label21
	movi	a9, 2
	and	a9, a5, a9
	movi	a11, 0
	beq	a9, a11, .LBB24_7
# %bb.6:                                # %source.label21
	addi	a9, a10, 3
	l32r	a10, .LCPI24_2
	and	a10, a9, a10
.LBB24_7:                               # %source.label21
	extui	a8, a8, 0, 1
	s32i	a8, a1, 24                      # 4-byte Folded Spill
	s32i	a10, a1, 20                     # 4-byte Folded Spill
	addi	a8, a10, 4
	s32i	a8, a1, 12                      # 4-byte Folded Spill
	s32i	a12, a1, 28                     # 4-byte Folded Spill
	bnei	a11, 3, .LBB24_8
	j	.LBB24_32
.LBB24_8:                               # %source.label29.preheader
                                        # =>This Loop Header: Depth=1
                                        #     Child Loop BB24_9 Depth 2
	s32i	a11, a1, 16                     # 4-byte Folded Spill
	slli	a7, a11, 2
	l32r	a8, .LCPI24_3
.LBB24_9:                               # %source.label29
                                        #   Parent Loop BB24_8 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	l32i	a6, a8, 0
	beqz	a6, .LBB24_31
# %bb.10:                               # %source.label30
                                        #   in Loop: Header=BB24_9 Depth=2
	l32i	a4, a6, 28
	beqz	a4, .LBB24_30
# %bb.11:                               # %source.label33
                                        #   in Loop: Header=BB24_9 Depth=2
	add	a8, a6, a7
	l32i	a8, a8, 0
	and	a8, a8, a5
	beqz	a8, .LBB24_30
# %bb.12:                               # %source.label34
                                        #   in Loop: Header=BB24_9 Depth=2
	l32i	a8, a6, 0
	l32i	a9, a6, 4
	or	a8, a9, a8
	l32i	a9, a6, 8
	or	a8, a8, a9
	and	a8, a8, a5
	beq	a8, a5, .LBB24_13
	j	.LBB24_30
.LBB24_13:                              # %source.label37
                                        #   in Loop: Header=BB24_9 Depth=2
	l32i	a8, a1, 24                      # 4-byte Folded Reload
	beqz.n	a8, .LBB24_16
# %bb.14:                               # %source.label39
                                        #   in Loop: Header=BB24_9 Depth=2
	l32i	a8, a6, 12
	l32r	a9, .LCPI24_5
	and	a9, a8, a9
	l32r	a10, .LCPI24_6
	beq	a9, a10, .LBB24_23
# %bb.15:                               # %source.label39
                                        #   in Loop: Header=BB24_9 Depth=2
	l32r	a9, .LCPI24_4
	and	a8, a8, a9
	l32r	a9, .LCPI24_7
	beq	a8, a9, .LBB24_23
.LBB24_16:                              # %source.label47
                                        #   in Loop: Header=BB24_9 Depth=2
	movi	a8, 4
	bltu	a8, a12, .LBB24_21
# %bb.17:                               # %source.label8.i.i
                                        #   in Loop: Header=BB24_9 Depth=2
	or	a10, a4, a4
	l32r	a8, .LCPI24_15
	callx8	a8
	l32i	a10, a4, 16
	l32i	a11, a1, 20                     # 4-byte Folded Reload
	l32r	a8, .LCPI24_16
	callx8	a8
	or	a2, a10, a10
	beqz.n	a2, .LBB24_20
# %bb.18:                               # %source.label10.i.i
                                        #   in Loop: Header=BB24_9 Depth=2
	addi	a8, a2, -4
	l32i	a8, a8, 0
	movi	a9, -4
	and	a8, a8, a9
	l32i	a9, a4, 4
	sub	a8, a9, a8
	addi	a8, a8, -4
	s32i	a8, a4, 4
	l32i	a9, a4, 8
	bgeu	a8, a9, .LBB24_20
# %bb.19:                               # %source.label12.i.i
                                        #   in Loop: Header=BB24_9 Depth=2
	s32i	a8, a4, 8
.LBB24_20:                              # %source.label16.i.i
                                        #   in Loop: Header=BB24_9 Depth=2
	or	a10, a4, a4
	l32r	a8, .LCPI24_17
	callx8	a8
	j	.LBB24_22
.LBB24_21:                              # %source.label1.i
                                        #   in Loop: Header=BB24_9 Depth=2
	or	a10, a4, a4
	l32i	a11, a1, 20                     # 4-byte Folded Reload
	l32r	a8, .LCPI24_14
	callx8	a8
	or	a2, a10, a10
.LBB24_22:                              # %abla_fn_787789690_813355367_direct.exit
                                        #   in Loop: Header=BB24_9 Depth=2
	l32i	a12, a1, 28                     # 4-byte Folded Reload
	bnez	a2, .LBB24_3
	j	.LBB24_30
.LBB24_23:                              # %source.label42
                                        #   in Loop: Header=BB24_9 Depth=2
	movi	a8, 4
	bltu	a8, a12, .LBB24_28
# %bb.24:                               # %source.label8.i.i72
                                        #   in Loop: Header=BB24_9 Depth=2
	or	a10, a4, a4
	l32r	a8, .LCPI24_9
	callx8	a8
	l32i	a10, a4, 16
	l32i	a11, a1, 12                     # 4-byte Folded Reload
	l32r	a8, .LCPI24_10
	callx8	a8
	or	a3, a10, a10
	beqz.n	a3, .LBB24_27
# %bb.25:                               # %source.label10.i.i79
                                        #   in Loop: Header=BB24_9 Depth=2
	addi	a8, a3, -4
	l32i	a8, a8, 0
	movi	a9, -4
	and	a8, a8, a9
	l32i	a9, a4, 4
	sub	a8, a9, a8
	addi	a8, a8, -4
	s32i	a8, a4, 4
	l32i	a9, a4, 8
	bgeu	a8, a9, .LBB24_27
# %bb.26:                               # %source.label12.i.i101
                                        #   in Loop: Header=BB24_9 Depth=2
	s32i	a8, a4, 8
.LBB24_27:                              # %source.label16.i.i98
                                        #   in Loop: Header=BB24_9 Depth=2
	or	a10, a4, a4
	l32r	a8, .LCPI24_11
	callx8	a8
	j	.LBB24_29
.LBB24_28:                              # %source.label1.i65
                                        #   in Loop: Header=BB24_9 Depth=2
	or	a10, a4, a4
	l32i	a11, a1, 12                     # 4-byte Folded Reload
	l32r	a8, .LCPI24_8
	callx8	a8
	or	a3, a10, a10
.LBB24_29:                              # %abla_fn_787789690_813355367_direct.exit104
                                        #   in Loop: Header=BB24_9 Depth=2
	l32i	a12, a1, 28                     # 4-byte Folded Reload
	bnez.n	a3, .LBB24_33
.LBB24_30:                              # %source.label54
                                        #   in Loop: Header=BB24_9 Depth=2
	addi	a8, a6, 32
	j	.LBB24_9
.LBB24_31:                              # %source.label55
                                        #   in Loop: Header=BB24_8 Depth=1
	l32i	a11, a1, 16                     # 4-byte Folded Reload
	addi	a11, a11, 1
	beqi	a11, 3, .LBB24_32
	j	.LBB24_8
.LBB24_32:
	movi	a2, 0
	retw.n
.LBB24_33:                              # %source.label44
	l32i	a8, a1, 20                      # 4-byte Folded Reload
	or	a8, a3, a8
	extui	a8, a8, 0, 2
	bnez.n	a8, .LBB24_35
# %bb.34:                               # %abla_fn_815233162_947672494_direct.exit
	l32i	a8, a1, 12                      # 4-byte Folded Reload
	add	a8, a3, a8
	l32r	a9, .LCPI24_12
	sub	a9, a9, a8
	s32i	a3, a9, 0
	l32r	a9, .LCPI24_13
	sub	a2, a9, a8
	retw.n
.LBB24_35:                              # %source.label5.i
	ill.n
.Lfunc_end24:
	.size	abla_fn_510554077_859267517_direct, .Lfunc_end24-abla_fn_510554077_859267517_direct
                                        # -- End function
	.literal_position
	.literal .LCPI25_0, abla_static_abla_fn_627837887_633683867_4112
	.section	.iram1.3.abla.esp32HeapCapsAlignedAllocateBase,"ax",@progbits
	.section	.text.abla_fn_607480688_644791182_direct,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_607480688_644791182_direct
	.type	abla_fn_607480688_644791182_direct,@function
abla_fn_607480688_644791182_direct:     # @abla_fn_607480688_644791182_direct
# %bb.0:                                # %entry
	entry	a1, 32
	movi	a10, 0
	beqz	a2, .LBB25_14
# %bb.1:                                # %entry
	bbsi	a3, 0, .LBB25_14
# %bb.2:                                # %source.label8.preheader
	movi	a6, 0
	beqi	a6, 3, .LBB25_11
.LBB25_3:                               # %source.label11.preheader
                                        # =>This Loop Header: Depth=1
                                        #     Child Loop BB25_4 Depth 2
	slli	a4, a6, 2
	l32r	a8, .LCPI25_0
.LBB25_4:                               # %source.label11
                                        #   Parent Loop BB25_3 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	l32i	a7, a8, 0
	beqz.n	a7, .LBB25_10
# %bb.5:                                # %source.label12
                                        #   in Loop: Header=BB25_4 Depth=2
	l32i	a5, a7, 28
	beqz.n	a5, .LBB25_9
# %bb.6:                                # %source.label15
                                        #   in Loop: Header=BB25_4 Depth=2
	add	a8, a7, a4
	l32i	a8, a8, 0
	and	a8, a8, a3
	beqz.n	a8, .LBB25_9
# %bb.7:                                # %source.label16
                                        #   in Loop: Header=BB25_4 Depth=2
	l32i	a8, a7, 0
	l32i	a9, a7, 4
	or	a8, a9, a8
	l32i	a9, a7, 8
	or	a8, a8, a9
	and	a8, a8, a3
	bne	a8, a3, .LBB25_9
# %bb.8:                                # %source.label6.i
                                        #   in Loop: Header=BB25_4 Depth=2
	l32i	a10, a5, 16
	or	a11, a2, a2
	call8	abla_fn_946434868_368388687_direct
	bnez.n	a10, .LBB25_12
.LBB25_9:                               # %source.label25
                                        #   in Loop: Header=BB25_4 Depth=2
	addi	a8, a7, 32
	j	.LBB25_4
.LBB25_10:                              # %source.label26
                                        #   in Loop: Header=BB25_3 Depth=1
	addi	a6, a6, 1
	bnei	a6, 3, .LBB25_3
.LBB25_11:
	movi	a10, 0
	j	.LBB25_14
.LBB25_12:                              # %abla_fn_126288948_669618382_direct.exit.i
	addi	a8, a10, -4
	l32i	a8, a8, 0
	movi	a9, -4
	and	a8, a8, a9
	l32i	a9, a5, 4
	sub	a8, a9, a8
	addi	a8, a8, -4
	s32i	a8, a5, 4
	l32i	a9, a5, 8
	bgeu	a8, a9, .LBB25_14
# %bb.13:                               # %source.label13.i
	s32i	a8, a5, 8
.LBB25_14:                              # %common.ret
	or	a2, a10, a10
	retw.n
.Lfunc_end25:
	.size	abla_fn_607480688_644791182_direct, .Lfunc_end25-abla_fn_607480688_644791182_direct
                                        # -- End function
	.literal_position
	.literal .LCPI26_0, 2052
	.literal .LCPI26_1, abla_fn_510554077_859267517_direct
	.literal .LCPI26_2, -4194305
	.literal .LCPI26_3, -4194304
	.literal .LCPI26_4, abla_static_abla_fn_627837887_633683867_4112
	.literal .LCPI26_5, abla_fn_524213402_227204421_direct
	.literal .LCPI26_6, abla_fn_946434868_368388687_direct
	.literal .LCPI26_7, abla_fn_973951929_967810110_direct
	.literal .LCPI26_8, abla_fn_973951929_967810110_direct
	.section	.text.abla_fn_607480688_644791182_direct,"ax",@progbits
	.section	.iram1.4.abla.esp32HeapCapsMallocBase,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_326491309_387073790_direct
	.type	abla_fn_326491309_387073790_direct,@function
abla_fn_326491309_387073790_direct:     # @abla_fn_326491309_387073790_direct
# %bb.0:                                # %entry
	entry	a1, 32
	l32r	a8, .LCPI26_0
	beq	a3, a8, .LBB26_1
	j	.LBB26_14
.LBB26_1:                               # %source.label
	l32r	a8, .LCPI26_2
	add	a8, a2, a8
	movi	a6, 0
	l32r	a9, .LCPI26_3
	bgeu	a8, a9, .LBB26_2
	j	.LBB26_18
.LBB26_2:                               # %source.label9.preheader
	movi	a5, 0
	beqi	a5, 3, .LBB26_13
.LBB26_3:                               # %source.label12.preheader
                                        # =>This Loop Header: Depth=1
                                        #     Child Loop BB26_4 Depth 2
	slli	a4, a5, 2
	l32r	a8, .LCPI26_4
.LBB26_4:                               # %source.label12
                                        #   Parent Loop BB26_3 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	l32i	a3, a8, 0
	beqz	a3, .LBB26_12
# %bb.5:                                # %source.label13
                                        #   in Loop: Header=BB26_4 Depth=2
	l32i	a7, a3, 28
	beqz	a7, .LBB26_11
# %bb.6:                                # %source.label16
                                        #   in Loop: Header=BB26_4 Depth=2
	add	a8, a3, a4
	l16ui	a8, a8, 0
	l32r	a9, .LCPI26_0
	and	a8, a8, a9
	beqz.n	a8, .LBB26_11
# %bb.7:                                # %source.label17
                                        #   in Loop: Header=BB26_4 Depth=2
	beqz.n	a2, .LBB26_11
# %bb.8:                                # %source.label17
                                        #   in Loop: Header=BB26_4 Depth=2
	l32i	a8, a3, 0
	l32i	a9, a3, 4
	or	a8, a9, a8
	l32i	a9, a3, 8
	or	a8, a8, a9
	l32r	a9, .LCPI26_0
	and	a8, a8, a9
	l32r	a9, .LCPI26_0
	bne	a8, a9, .LBB26_11
# %bb.9:                                # %source.label8.i
                                        #   in Loop: Header=BB26_4 Depth=2
	or	a10, a7, a7
	l32r	a8, .LCPI26_5
	callx8	a8
	l32i	a10, a7, 16
	or	a11, a2, a2
	l32r	a8, .LCPI26_6
	callx8	a8
	or	a6, a10, a10
	bnez.n	a6, .LBB26_15
# %bb.10:                               # %source.label26.critedge
                                        #   in Loop: Header=BB26_4 Depth=2
	or	a10, a7, a7
	l32r	a8, .LCPI26_8
	callx8	a8
.LBB26_11:                              # %source.label26
                                        #   in Loop: Header=BB26_4 Depth=2
	addi	a8, a3, 32
	j	.LBB26_4
.LBB26_12:                              # %source.label27
                                        #   in Loop: Header=BB26_3 Depth=1
	addi	a5, a5, 1
	bnei	a5, 3, .LBB26_3
.LBB26_13:
	movi	a6, 0
	j	.LBB26_18
.LBB26_14:                              # %source.label30
	l32r	a8, .LCPI26_1
	movi	a10, 4
	or	a11, a2, a2
	or	a12, a3, a3
	callx8	a8
	or	a6, a10, a10
	j	.LBB26_18
.LBB26_15:                              # %source.label10.i
	addi	a8, a6, -4
	l32i	a8, a8, 0
	movi	a9, -4
	and	a8, a8, a9
	l32i	a9, a7, 4
	sub	a8, a9, a8
	addi	a8, a8, -4
	s32i	a8, a7, 4
	l32i	a9, a7, 8
	bgeu	a8, a9, .LBB26_17
# %bb.16:                               # %source.label12.i
	s32i	a8, a7, 8
.LBB26_17:                              # %abla_fn_370284784_413628352_direct.exit
	l32r	a8, .LCPI26_7
	or	a10, a7, a7
	callx8	a8
.LBB26_18:                              # %common.ret
	or	a2, a6, a6
	retw.n
.Lfunc_end26:
	.size	abla_fn_326491309_387073790_direct, .Lfunc_end26-abla_fn_326491309_387073790_direct
                                        # -- End function
	.literal_position
	.literal .LCPI27_0, abla_fn_943683849_603704949_direct
	.literal .LCPI27_1, 4194304
	.literal .LCPI27_2, -1074536448
	.literal .LCPI27_3, -139264
	.literal .LCPI27_4, abla_fn_268325070_984894759_direct
	.literal .LCPI27_5, -139265
	.literal .LCPI27_6, abla_fn_524213402_227204421_direct
	.literal .LCPI27_7, 16777212
	.literal .LCPI27_8, abla_fn_946434868_368388687_direct
	.literal .LCPI27_9, abla_fn_297717203_153064921_direct
	.literal .LCPI27_10, abla_fn_973951929_967810110_direct
	.literal .LCPI27_11, abla_fn_510554077_859267517_direct
	.literal .LCPI27_12, abla_fn_334943840_569200394_direct
	.literal .LCPI27_13, abla_fn_213944016_953228118_direct
	.literal .LCPI27_14, abla_fn_213944016_953228118_direct
	.literal .LCPI27_15, abla_fn_510554077_859267517_direct
	.section	.iram1.4.abla.esp32HeapCapsMallocBase,"ax",@progbits
	.section	.iram1.5.abla.esp32HeapCapsReallocateBase,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_627273554_864281065_direct
	.type	abla_fn_627273554_864281065_direct,@function
abla_fn_627273554_864281065_direct:     # @abla_fn_627273554_864281065_direct
# %bb.0:                                # %entry
	entry	a1, 80
	or	a5, a2, a2
	s32i	a4, a1, 40
	s32i	a3, a1, 36
	movi	a8, 8
	addi	a10, a1, 32
	or	a12, a10, a8
	movi	a8, 4
	s32i	a8, a1, 32
	or	a11, a10, a8
	l32r	a8, .LCPI27_0
	callx8	a8
	l32i	a6, a1, 40
	l32i	a7, a1, 36
	l32i	a3, a1, 32
	beqz	a5, .LBB27_13
# %bb.1:                                # %source.label12
	beqz	a7, .LBB27_14
# %bb.2:                                # %source.label15
	movi	a2, 0
	l32r	a8, .LCPI27_1
	bgeu	a8, a7, .LBB27_3
	j	.LBB27_89
.LBB27_3:                               # %source.label18
	l32r	a8, .LCPI27_2
	add	a4, a5, a8
	l32r	a8, .LCPI27_3
	addi	a2, a5, -4
	or	a9, a5, a5
	bltu	a4, a8, .LBB27_5
# %bb.4:                                # %source.label21
	l32i	a9, a2, 0
.LBB27_5:                               # %source.label23
	l32r	a8, .LCPI27_4
	s32i	a9, a1, 28                      # 4-byte Folded Spill
	or	a10, a9, a9
	callx8	a8
	beqz	a10, .LBB27_94
# %bb.6:                                # %source.label28
	l32r	a8, .LCPI27_5
	bgeu	a8, a4, .LBB27_7
	j	.LBB27_90
.LBB27_7:                               # %source.label28
	l32i	a8, a10, 0
	l32i	a9, a10, 4
	or	a8, a9, a8
	l32i	a9, a10, 8
	or	a8, a8, a9
	and	a8, a8, a6
	beq	a8, a6, .LBB27_8
	j	.LBB27_90
.LBB27_8:                               # %source.label28
	movi	a8, 4
	bgeu	a8, a3, .LBB27_9
	j	.LBB27_90
.LBB27_9:                               # %source.label36
	l32i	a4, a10, 28
	beqz	a4, .LBB27_94
# %bb.10:                               # %source.label10.i
	addi	a8, a5, -8
	s32i	a8, a1, 12                      # 4-byte Folded Spill
	beqz	a8, .LBB27_94
# %bb.11:                               # %source.label5.i.i
	l32i	a8, a4, 16
	beqz.n	a8, .LBB27_15
# %bb.12:                               # %source.label1.i.i.i.i
	l32i	a9, a8, 20
	j	.LBB27_16
.LBB27_13:                              # %source.label
	l32r	a8, .LCPI27_15
	or	a10, a3, a3
	or	a11, a7, a7
	or	a12, a6, a6
	callx8	a8
	or	a2, a10, a10
	retw.n
.LBB27_14:                              # %source.label13
	l32r	a8, .LCPI27_14
	or	a10, a5, a5
	callx8	a8
	movi	a2, 0
	retw.n
.LBB27_15:
	movi	a9, 0
.LBB27_16:                              # %abla_fn_896935147_719056048_direct.exit.i.i
	add	a8, a9, a8
	bgeu	a5, a8, .LBB27_17
	j	.LBB27_94
.LBB27_17:                              # %abla_fn_295721179_363527029_direct.exit.i
	l32i	a9, a4, 12
	add	a8, a9, a8
	bltu	a5, a8, .LBB27_18
	j	.LBB27_94
.LBB27_18:                              # %source.label13.i
	s32i	a2, a1, 20                      # 4-byte Folded Spill
	l32r	a8, .LCPI27_6
	or	a10, a4, a4
	callx8	a8
	s32i	a4, a1, 24                      # 4-byte Folded Spill
	l32i	a9, a4, 16
	movi	a2, 0
	beqz	a9, .LBB27_88
# %bb.19:                               # %abla_fn_259878424_650702494_direct.exit.i.i.i
	l32i	a8, a1, 20                      # 4-byte Folded Reload
	l32i	a8, a8, 0
	movi	a11, -4
	and	a4, a8, a11
	add	a8, a4, a5
	s32i	a8, a1, 8                       # 4-byte Folded Spill
	l32i	a12, a8, 0
	addi	a8, a7, 3
	l32r	a10, .LCPI27_7
	and	a13, a8, a10
	s32i	a9, a1, 16                      # 4-byte Folded Spill
	l32i	a9, a9, 16
	extui	a14, a9, 8, 6
	ssr	a14
	srl	a8, a13
	movi	a15, 31
	bgeu	a15, a14, .LBB27_20
	j	.LBB27_88
.LBB27_20:                              # %abla_fn_259878424_650702494_direct.exit.i.i.i
	bnez	a8, .LBB27_88
# %bb.21:                               # %abla_fn_893648206_137591682_direct.exit.i.i
	movi	a8, 12
	movi	a14, 9
	bltu	a7, a14, .LBB27_23
# %bb.22:                               # %abla_fn_893648206_137591682_direct.exit.i.i
	or	a8, a13, a13
.LBB27_23:                              # %abla_fn_893648206_137591682_direct.exit.i.i
	or	a13, a4, a4
	s32i	a4, a1, 4                       # 4-byte Folded Spill
	bltu	a4, a8, .LBB27_24
	j	.LBB27_49
.LBB27_24:                              # %source.label22.i.i
	l32i	a10, a1, 16                     # 4-byte Folded Reload
	bbci	a12, 0, .LBB27_30
# %bb.25:                               # %source.label22.i.i
	and	a11, a12, a11
	add	a12, a4, a11
	addi	a12, a12, 4
	bltu	a12, a8, .LBB27_30
# %bb.26:                               # %source.label.i.i.i
	extui	a13, a9, 23, 8
	bgeu	a11, a13, .LBB27_34
# %bb.27:                               # %source.label.i.i.i.i.i
	extui	a12, a9, 14, 6
	beqz	a12, .LBB27_94
# %bb.28:                               # %scalar.divide.checked.i.i.i.i.i
	bgeu	a13, a12, .LBB27_29
	j	.LBB27_94
.LBB27_29:                              # %scalar.divide.checked13.i.i.i.i.i
	extui	a9, a9, 23, 9
	extui	a9, a9, 0, 8
	quou	a9, a9, a12
	extui	a11, a11, 0, 8
	quou	a9, a11, a9
	slli	a11, a9, 8
	j	.LBB27_40
.LBB27_30:                              # %source.label29.i.i
	l32r	a8, .LCPI27_8
	or	a11, a7, a7
	callx8	a8
	or	a4, a10, a10
	beqz	a4, .LBB27_88
# %bb.31:                               # %source.label31.i.i
	l32i	a8, a1, 4                       # 4-byte Folded Reload
	minu	a8, a8, a7
	movi	a9, 0
	l32i	a2, a1, 24                      # 4-byte Folded Reload
	l32i	a10, a1, 16                     # 4-byte Folded Reload
	beq	a8, a9, .LBB27_33
.LBB27_32:                              # %source.label3.i.i.i
                                        # =>This Inner Loop Header: Depth=1
	add	a12, a4, a9
	add	a11, a5, a9
	l8ui	a11, a11, 0
	s8i	a11, a12, 0
	addi	a9, a9, 1
	bne	a8, a9, .LBB27_32
.LBB27_33:                              # %abla_fn_600583565_472377005_direct.exit.i
	l32r	a8, .LCPI27_9
	or	a11, a5, a5
	callx8	a8
	j	.LBB27_85
.LBB27_34:                              # %source.label3.i.i.i.i.i
	beqz.n	a11, .LBB27_36
# %bb.35:                               # %source.label1.i.i.i.i.i.i
	#APP
	nsau	a9, a11
	#NO_APP
	movi	a12, 31
	sub	a12, a12, a9
	l32i	a9, a10, 16
	j	.LBB27_37
.LBB27_36:
	movi	a12, -1
.LBB27_37:                              # %abla_fn_173146590_885096896_direct.exit.i.i.i.i.i
	extui	a13, a9, 20, 3
	sub	a14, a12, a13
	ssr	a14
	srl	a11, a11
	bgeu	a15, a14, .LBB27_39
# %bb.38:                               # %abla_fn_173146590_885096896_direct.exit.i.i.i.i.i
	movi	a11, 0
.LBB27_39:                              # %abla_fn_173146590_885096896_direct.exit.i.i.i.i.i
	movi	a14, 1
	ssl	a13
	sll	a13, a14
	xor	a11, a11, a13
	slli	a11, a11, 8
	extui	a10, a9, 5, 3
	sub	a10, a12, a10
	addi	a10, a10, 1
	or	a11, a11, a10
	l32i	a10, a1, 16                     # 4-byte Folded Reload
.LBB27_40:                              # %abla_fn_425450285_944651937_direct.exit.i.i.i.i
	l32i	a9, a1, 12                      # 4-byte Folded Reload
	add	a9, a4, a9
	addi	a15, a9, 4
	l32i	a12, a9, 12
	l32i	a9, a9, 16
	s32i	a9, a12, 12
	s32i	a12, a9, 8
	extui	a9, a11, 0, 8
	l32i	a13, a10, 16
	extui	a13, a13, 14, 6
	mull	a13, a13, a9
	extui	a11, a11, 8, 8
	add	a14, a13, a11
	l32i	a13, a10, 32
	addx4	a4, a14, a13
	l32i	a4, a4, 0
	bne	a4, a15, .LBB27_48
# %bb.41:                               # %source.label.i15.i.i.i.i
	slli	a14, a14, 2
	add	a13, a14, a13
	s32i	a12, a13, 0
	l32i	a10, a1, 16                     # 4-byte Folded Reload
	bne	a12, a10, .LBB27_48
# %bb.42:                               # %source.label14.i.i.i.i.i
	movi	a12, 1
	ssl	a11
	sll	a13, a12
	movi	a12, -1
	movi	a14, 31
	bltu	a14, a11, .LBB27_44
# %bb.43:
	xor	a12, a13, a12
.LBB27_44:                              # %source.label14.i.i.i.i.i
	l32i	a10, a1, 16                     # 4-byte Folded Reload
	l32i	a11, a10, 28
	addx4	a11, a9, a11
	l32i	a13, a11, 0
	and	a12, a13, a12
	s32i	a12, a11, 0
	bnez.n	a12, .LBB27_48
# %bb.45:                               # %source.label18.i.i.i.i.i
	movi	a11, 1
	ssl	a9
	sll	a12, a11
	movi	a11, -1
	movi	a13, 31
	bltu	a13, a9, .LBB27_47
# %bb.46:
	xor	a11, a12, a11
.LBB27_47:                              # %source.label18.i.i.i.i.i
	l32i	a9, a1, 16                      # 4-byte Folded Reload
	l32i	a10, a9, 24
	and	a10, a10, a11
	s32i	a10, a9, 24
.LBB27_48:                              # %abla_fn_922616927_949514961_direct.exit.i.i
	l32i	a9, a1, 8                       # 4-byte Folded Reload
	l32i	a9, a9, 0
	movi	a10, -4
	and	a9, a9, a10
	l32i	a13, a1, 20                     # 4-byte Folded Reload
	l32i	a11, a13, 0
	add	a9, a11, a9
	addi	a9, a9, 4
	s32i	a9, a13, 0
	and	a9, a9, a10
	add	a9, a9, a13
	l32i	a11, a1, 12                     # 4-byte Folded Reload
	s32i	a11, a9, 0
	l32i	a9, a13, 0
	and	a9, a9, a10
	add	a9, a9, a5
	l32i	a11, a9, 0
	movi	a12, -3
	and	a11, a11, a12
	s32i	a11, a9, 0
	l32i	a9, a13, 0
	movi	a11, -2
	and	a11, a9, a11
	s32i	a11, a13, 0
	and	a13, a9, a10
.LBB27_49:                              # %source.label42.i.i
	addi	a9, a8, 16
	or	a4, a5, a5
	l32i	a2, a1, 24                      # 4-byte Folded Reload
	bgeu	a13, a9, .LBB27_50
	j	.LBB27_85
.LBB27_50:                              # %source.label.i57.i.i
	add	a10, a8, a5
	sub	a9, a13, a8
	addi	a9, a9, -4
	s32i	a9, a10, 0
	l32i	a11, a1, 20                     # 4-byte Folded Reload
	l32i	a9, a11, 0
	extui	a9, a9, 0, 2
	or	a9, a9, a8
	s32i	a9, a11, 0
	l32i	a9, a10, 0
	movi	a13, -4
	and	a11, a9, a13
	l32i	a9, a1, 12                      # 4-byte Folded Reload
	add	a4, a8, a9
	addi	a8, a4, 4
	add	a11, a11, a8
	s32i	a8, a11, 4
	l32i	a12, a11, 8
	movi	a14, 2
	or	a12, a12, a14
	s32i	a12, a11, 8
	l32i	a11, a10, 0
	and	a12, a11, a13
	movi	a11, 1
	or	a11, a12, a11
	s32i	a11, a10, 0
	add	a11, a12, a8
	l32i	a14, a11, 8
	bbsi	a14, 0, .LBB27_51
	j	.LBB27_70
.LBB27_51:                              # %source.label.i.i.i.i
	and	a13, a14, a13
	l32i	a9, a1, 16                      # 4-byte Folded Reload
	l32i	a12, a9, 16
	extui	a15, a12, 23, 8
	s32i	a4, a1, 20                      # 4-byte Folded Spill
	bgeu	a13, a15, .LBB27_55
# %bb.52:                               # %source.label.i.i.i.i.i.i
	extui	a14, a12, 14, 6
	beqz	a14, .LBB27_94
# %bb.53:                               # %scalar.divide.checked.i.i.i.i.i.i
	bgeu	a15, a14, .LBB27_54
	j	.LBB27_94
.LBB27_54:                              # %scalar.divide.checked13.i.i.i.i.i.i
	extui	a12, a12, 23, 9
	extui	a12, a12, 0, 8
	quou	a12, a12, a14
	extui	a13, a13, 0, 8
	quou	a12, a13, a12
	slli	a13, a12, 8
	j	.LBB27_61
.LBB27_55:                              # %source.label3.i.i.i.i.i.i
	beqz.n	a13, .LBB27_57
# %bb.56:                               # %source.label1.i.i.i.i.i.i.i
	#APP
	nsau	a12, a13
	#NO_APP
	movi	a14, 31
	sub	a14, a14, a12
	l32i	a9, a1, 16                      # 4-byte Folded Reload
	l32i	a12, a9, 16
	j	.LBB27_58
.LBB27_57:
	movi	a14, -1
.LBB27_58:                              # %abla_fn_173146590_885096896_direct.exit.i.i.i.i.i.i
	extui	a15, a12, 20, 3
	sub	a4, a14, a15
	ssr	a4
	srl	a13, a13
	movi	a2, 31
	bgeu	a2, a4, .LBB27_60
# %bb.59:                               # %abla_fn_173146590_885096896_direct.exit.i.i.i.i.i.i
	movi	a13, 0
.LBB27_60:                              # %abla_fn_173146590_885096896_direct.exit.i.i.i.i.i.i
	movi	a4, 1
	ssl	a15
	sll	a15, a4
	xor	a13, a13, a15
	slli	a13, a13, 8
	extui	a12, a12, 5, 3
	sub	a12, a14, a12
	addi	a12, a12, 1
	or	a13, a13, a12
.LBB27_61:                              # %abla_fn_425450285_944651937_direct.exit.i.i.i.i.i
	addi	a2, a11, 4
	l32i	a14, a11, 12
	l32i	a12, a11, 16
	s32i	a12, a14, 12
	s32i	a14, a12, 8
	extui	a12, a13, 0, 8
	l32i	a9, a1, 16                      # 4-byte Folded Reload
	l32i	a15, a9, 16
	extui	a15, a15, 14, 6
	mull	a15, a15, a12
	extui	a13, a13, 8, 8
	add	a4, a15, a13
	l32i	a15, a9, 32
	addx4	a9, a4, a15
	l32i	a9, a9, 0
	bne	a9, a2, .LBB27_69
# %bb.62:                               # %source.label.i15.i.i.i.i.i
	slli	a9, a4, 2
	add	a9, a9, a15
	s32i	a14, a9, 0
	l32i	a9, a1, 16                      # 4-byte Folded Reload
	bne	a14, a9, .LBB27_69
# %bb.63:                               # %source.label14.i.i.i.i.i.i
	movi	a9, 1
	ssl	a13
	sll	a15, a9
	movi	a14, -1
	movi	a9, 31
	bltu	a9, a13, .LBB27_65
# %bb.64:
	xor	a14, a15, a14
.LBB27_65:                              # %source.label14.i.i.i.i.i.i
	l32i	a9, a1, 16                      # 4-byte Folded Reload
	l32i	a9, a9, 28
	addx4	a9, a12, a9
	l32i	a13, a9, 0
	and	a13, a13, a14
	s32i	a13, a9, 0
	bnez.n	a13, .LBB27_69
# %bb.66:                               # %source.label18.i.i.i.i.i.i
	movi	a9, 1
	ssl	a12
	sll	a14, a9
	movi	a13, -1
	movi	a9, 31
	bltu	a9, a12, .LBB27_68
# %bb.67:
	xor	a13, a14, a13
.LBB27_68:                              # %source.label18.i.i.i.i.i.i
	l32i	a12, a1, 16                     # 4-byte Folded Reload
	l32i	a9, a12, 24
	and	a9, a9, a13
	s32i	a9, a12, 24
.LBB27_69:                              # %abla_fn_128917703_965349236_direct.exit.i.i.i.i
	l32i	a9, a11, 8
	movi	a11, -4
	and	a9, a9, a11
	l32i	a12, a10, 0
	add	a9, a12, a9
	addi	a9, a9, 4
	s32i	a9, a10, 0
	and	a9, a9, a11
	add	a9, a9, a10
	s32i	a8, a9, 0
	l32i	a9, a10, 0
	and	a12, a9, a11
	l32i	a2, a1, 24                      # 4-byte Folded Reload
	l32i	a4, a1, 20                      # 4-byte Folded Reload
.LBB27_70:                              # %abla_fn_922616927_949514961_direct.exit.i.i.i
	l32i	a14, a1, 16                     # 4-byte Folded Reload
	l32i	a11, a14, 16
	extui	a10, a11, 14, 6
	extui	a13, a11, 23, 8
	bgeu	a12, a13, .LBB27_74
# %bb.71:                               # %source.label.i.i.i131.i.i
	beqz	a10, .LBB27_94
# %bb.72:                               # %scalar.divide.checked.i.i.i133.i.i
	bgeu	a13, a10, .LBB27_73
	j	.LBB27_94
.LBB27_73:                              # %scalar.divide.checked13.i.i.i135.i.i
	extui	a9, a11, 23, 9
	extui	a9, a9, 0, 8
	quou	a9, a9, a10
	extui	a11, a12, 0, 8
	quou	a9, a11, a9
	slli	a12, a9, 8
	j	.LBB27_80
.LBB27_74:                              # %source.label3.i.i.i84.i.i
	beqz.n	a12, .LBB27_76
# %bb.75:                               # %source.label1.i.i.i.i86.i.i
	#APP
	nsau	a9, a12
	#NO_APP
	movi	a10, 31
	sub	a13, a10, a9
	l32i	a11, a14, 16
	extui	a10, a11, 14, 6
	j	.LBB27_77
.LBB27_76:
	movi	a13, -1
.LBB27_77:                              # %abla_fn_173146590_885096896_direct.exit.i.i.i89.i.i
	extui	a14, a11, 20, 3
	sub	a9, a13, a14
	ssr	a9
	srl	a12, a12
	movi	a15, 31
	bgeu	a15, a9, .LBB27_79
# %bb.78:                               # %abla_fn_173146590_885096896_direct.exit.i.i.i89.i.i
	movi	a12, 0
.LBB27_79:                              # %abla_fn_173146590_885096896_direct.exit.i.i.i89.i.i
	movi	a9, 1
	ssl	a14
	sll	a9, a9
	xor	a9, a12, a9
	slli	a9, a9, 8
	extui	a11, a11, 5, 3
	sub	a11, a13, a11
	addi	a11, a11, 1
	or	a12, a9, a11
	l32i	a14, a1, 16                     # 4-byte Folded Reload
.LBB27_80:                              # %abla_fn_386852483_179931374_direct.exit.i.i.i
	extui	a11, a12, 0, 8
	mull	a9, a11, a10
	extui	a10, a12, 8, 8
	add	a9, a9, a10
	l32i	a12, a14, 32
	addx4	a9, a9, a12
	l32i	a12, a9, 0
	s32i	a14, a4, 16
	s32i	a12, a4, 12
	s32i	a8, a12, 12
	s32i	a8, a9, 0
	movi	a8, 1
	ssl	a11
	sll	a12, a8
	movi	a9, 31
	bgeu	a9, a11, .LBB27_82
# %bb.81:                               # %abla_fn_386852483_179931374_direct.exit.i.i.i
	movi	a12, 0
.LBB27_82:                              # %abla_fn_386852483_179931374_direct.exit.i.i.i
	l32i	a13, a14, 24
	or	a12, a13, a12
	s32i	a12, a14, 24
	ssl	a10
	sll	a8, a8
	bgeu	a9, a10, .LBB27_84
# %bb.83:                               # %abla_fn_386852483_179931374_direct.exit.i.i.i
	movi	a8, 0
.LBB27_84:                              # %abla_fn_386852483_179931374_direct.exit.i.i.i
	l32i	a9, a14, 28
	addx4	a9, a11, a9
	l32i	a10, a9, 0
	or	a8, a10, a8
	s32i	a8, a9, 0
	or	a4, a5, a5
.LBB27_85:                              # %abla_fn_126288948_669618382_direct.exit.i
	l32i	a8, a2, 4
	l32i	a9, a1, 4                       # 4-byte Folded Reload
	add	a8, a8, a9
	addi	a9, a4, -4
	l32i	a9, a9, 0
	movi	a10, -4
	and	a9, a9, a10
	sub	a8, a8, a9
	s32i	a8, a2, 4
	l32i	a9, a2, 8
	bgeu	a8, a9, .LBB27_87
# %bb.86:                               # %source.label17.i
	s32i	a8, a2, 8
.LBB27_87:                              # %abla_fn_601604809_455769573_direct.exit
	or	a2, a4, a4
.LBB27_88:                              # %abla_fn_601604809_455769573_direct.exit
	l32r	a8, .LCPI27_10
	l32i	a10, a1, 24                     # 4-byte Folded Reload
	callx8	a8
	beqz.n	a2, .LBB27_90
.LBB27_89:                              # %common.ret
	retw.n
.LBB27_90:                              # %source.label42
	l32r	a8, .LCPI27_11
	or	a10, a3, a3
	or	a11, a7, a7
	or	a12, a6, a6
	callx8	a8
	or	a6, a10, a10
	movi	a2, 0
	beqz	a6, .LBB27_89
# %bb.91:                               # %source.label46
	l32i	a8, a1, 28                      # 4-byte Folded Reload
	beqz.n	a8, .LBB27_94
# %bb.92:                               # %abla_fn_513987808_618767569_direct.exit
	addi	a8, a8, -4
	l32i	a8, a8, 0
	movi	a9, -4
	and	a8, a8, a9
	beqz.n	a8, .LBB27_94
# %bb.93:                               # %source.label50
	minu	a12, a8, a7
	l32r	a8, .LCPI27_12
	or	a10, a6, a6
	or	a11, a5, a5
	callx8	a8
	l32r	a8, .LCPI27_13
	or	a10, a5, a5
	callx8	a8
	or	a2, a6, a6
	retw.n
.LBB27_94:                              # %source.label26
	ill.n
.Lfunc_end27:
	.size	abla_fn_627273554_864281065_direct, .Lfunc_end27-abla_fn_627273554_864281065_direct
                                        # -- End function
	.section	.text.abla_fn_971341861_636336326_direct,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_971341861_636336326_direct
	.type	abla_fn_971341861_636336326_direct,@function
abla_fn_971341861_636336326_direct:     # @abla_fn_971341861_636336326_direct
# %bb.0:                                # %entry
	entry	a1, 32
	memw
	l32i	a8, a2, 4
	memw
	l32i	a9, a8, 8
	memw
	s32i	a8, a3, 4
	memw
	s32i	a9, a3, 8
	memw
	s32i	a3, a9, 4
	memw
	s32i	a3, a8, 8
	memw
	s32i	a2, a3, 16
	memw
	l32i	a8, a2, 0
	addi	a8, a8, 1
	memw
	s32i	a8, a2, 0
	retw.n
.Lfunc_end28:
	.size	abla_fn_971341861_636336326_direct, .Lfunc_end28-abla_fn_971341861_636336326_direct
                                        # -- End function
	.section	.text.abla_fn_33922886_763007037_direct,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_33922886_763007037_direct
	.type	abla_fn_33922886_763007037_direct,@function
abla_fn_33922886_763007037_direct:      # @abla_fn_33922886_763007037_direct
# %bb.0:                                # %entry
	entry	a1, 32
	memw
	l32i	a9, a3, 0
	beqi	a9, -1, .LBB29_3
# %bb.1:                                # %source.label11
	addi	a10, a2, 12
	addi	a11, a2, 8
.LBB29_2:                               # %source.label13
                                        # =>This Inner Loop Header: Depth=1
	or	a8, a11, a11
	memw
	l32i	a11, a10, 0
	addi	a10, a11, 4
	memw
	l32i	a12, a11, 0
	bgeu	a9, a12, .LBB29_2
	j	.LBB29_4
.LBB29_3:                               # %source.label9.thread
	memw
	l32i	a8, a2, 16
.LBB29_4:                               # %source.label17
	memw
	l32i	a9, a8, 4
	memw
	s32i	a9, a3, 4
	memw
	s32i	a8, a3, 8
	memw
	s32i	a3, a9, 8
	memw
	s32i	a3, a8, 4
	memw
	s32i	a2, a3, 16
	memw
	l32i	a8, a2, 0
	addi	a8, a8, 1
	memw
	s32i	a8, a2, 0
	retw.n
.Lfunc_end29:
	.size	abla_fn_33922886_763007037_direct, .Lfunc_end29-abla_fn_33922886_763007037_direct
                                        # -- End function
	.section	.iram1.abla.freertos.list_remove,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_539458941_750097516_direct
	.type	abla_fn_539458941_750097516_direct,@function
abla_fn_539458941_750097516_direct:     # @abla_fn_539458941_750097516_direct
# %bb.0:                                # %entry
	entry	a1, 32
	memw
	l32i	a8, a2, 16
	memw
	l32i	a10, a2, 4
	memw
	l32i	a9, a2, 8
	memw
	s32i	a10, a9, 4
	memw
	s32i	a9, a10, 8
	memw
	l32i	a10, a8, 4
	bne	a10, a2, .LBB30_2
# %bb.1:                                # %source.label
	memw
	s32i	a9, a8, 4
.LBB30_2:                               # %source.label8
	movi	a9, 0
	memw
	s32i	a9, a2, 16
	memw
	l32i	a9, a8, 0
	addi	a9, a9, -1
	memw
	s32i	a9, a8, 0
	retw.n
.Lfunc_end30:
	.size	abla_fn_539458941_750097516_direct, .Lfunc_end30-abla_fn_539458941_750097516_direct
                                        # -- End function
	.section	.iram1.0.abla.esp32XtensaSetInterruptLevel,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_254507142_821368668_direct
	.type	abla_fn_254507142_821368668_direct,@function
abla_fn_254507142_821368668_direct:     # @abla_fn_254507142_821368668_direct
# %bb.0:                                # %entry
	entry	a1, 32
	#APP
	rsr	a9, ps
	xor	a8, a9, a2
	extui	a8, a8, 0, 4
	xor	a8, a9, a8
	wsr	a8, ps
	rsync

	#NO_APP
	retw.n
.Lfunc_end31:
	.size	abla_fn_254507142_821368668_direct, .Lfunc_end31-abla_fn_254507142_821368668_direct
                                        # -- End function
	.literal_position
	.literal .LCPI32_0, 1072955420
	.literal .LCPI32_1, 1072955392
	.section	.iram1.0.abla.esp32XtensaSetInterruptLevel,"ax",@progbits
	.section	.text.abla_fn_823764238_93670715_direct,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_823764238_93670715_direct
	.type	abla_fn_823764238_93670715_direct,@function
abla_fn_823764238_93670715_direct:      # @abla_fn_823764238_93670715_direct
# %bb.0:                                # %entry
	entry	a1, 32
	beqz.n	a2, .LBB32_4
.LBB32_1:                               # %source.label6
                                        # =>This Loop Header: Depth=1
                                        #     Child Loop BB32_2 Depth 2
	l8ui	a8, a2, 0
	beqz.n	a8, .LBB32_4
.LBB32_2:                               # %source.label.i
                                        #   Parent Loop BB32_1 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	l32r	a9, .LCPI32_0
	memw
	l32i	a9, a9, 0
	bbsi	a9, 23, .LBB32_2
# %bb.3:                                # %abla_fn_486103918_4251942_direct.exit
                                        #   in Loop: Header=BB32_1 Depth=1
	l32r	a9, .LCPI32_1
	memw
	s32i	a8, a9, 0
	memw
	addi	a2, a2, 1
	j	.LBB32_1
.LBB32_4:                               # %common.ret
	retw.n
.Lfunc_end32:
	.size	abla_fn_823764238_93670715_direct, .Lfunc_end32-abla_fn_823764238_93670715_direct
                                        # -- End function
	.literal_position
	.literal .LCPI33_0, 1072955420
	.literal .LCPI33_1, 1072955392
	.literal .LCPI33_2, 100000001
	.section	.text.abla_fn_823764238_93670715_direct,"ax",@progbits
	.section	.text.unlikely.abla_fn_343754787_547301002_direct,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_343754787_547301002_direct
	.type	abla_fn_343754787_547301002_direct,@function
abla_fn_343754787_547301002_direct:     # @abla_fn_343754787_547301002_direct
# %bb.0:                                # %entry
	entry	a1, 32
	or	a10, a5, a5
.LBB33_1:                               # %source.label.i66.i
                                        # =>This Inner Loop Header: Depth=1
	l32r	a8, .LCPI33_0
	memw
	l32i	a8, a8, 0
	bbsi	a8, 23, .LBB33_1
# %bb.2:                                # %abla_fn_486103918_4251942_direct.exit72.i
	l32r	a8, .LCPI33_1
	movi	a9, 97
	memw
	s32i	a9, a8, 0
	memw
.LBB33_3:                               # %source.label.i58.i
                                        # =>This Inner Loop Header: Depth=1
	l32r	a8, .LCPI33_0
	memw
	l32i	a8, a8, 0
	bbsi	a8, 23, .LBB33_3
# %bb.4:                                # %abla_fn_486103918_4251942_direct.exit64.i
	l32r	a8, .LCPI33_1
	movi	a9, 115
	memw
	s32i	a9, a8, 0
	memw
.LBB33_5:                               # %source.label.i50.i
                                        # =>This Inner Loop Header: Depth=1
	l32r	a8, .LCPI33_0
	memw
	l32i	a8, a8, 0
	bbsi	a8, 23, .LBB33_5
# %bb.6:                                # %abla_fn_486103918_4251942_direct.exit56.i
	l32r	a8, .LCPI33_1
	movi	a9, 115
	memw
	s32i	a9, a8, 0
	memw
.LBB33_7:                               # %source.label.i42.i
                                        # =>This Inner Loop Header: Depth=1
	l32r	a8, .LCPI33_0
	memw
	l32i	a8, a8, 0
	bbsi	a8, 23, .LBB33_7
# %bb.8:                                # %abla_fn_486103918_4251942_direct.exit48.i
	l32r	a8, .LCPI33_1
	movi	a9, 101
	memw
	s32i	a9, a8, 0
	memw
.LBB33_9:                               # %source.label.i34.i
                                        # =>This Inner Loop Header: Depth=1
	l32r	a8, .LCPI33_0
	memw
	l32i	a8, a8, 0
	bbsi	a8, 23, .LBB33_9
# %bb.10:                               # %abla_fn_486103918_4251942_direct.exit40.i
	l32r	a8, .LCPI33_1
	movi	a9, 114
	memw
	s32i	a9, a8, 0
	memw
.LBB33_11:                              # %source.label.i26.i
                                        # =>This Inner Loop Header: Depth=1
	l32r	a8, .LCPI33_0
	memw
	l32i	a8, a8, 0
	bbsi	a8, 23, .LBB33_11
# %bb.12:                               # %abla_fn_486103918_4251942_direct.exit32.i
	l32r	a8, .LCPI33_1
	movi	a9, 116
	memw
	s32i	a9, a8, 0
	memw
.LBB33_13:                              # %source.label.i18.i
                                        # =>This Inner Loop Header: Depth=1
	l32r	a8, .LCPI33_0
	memw
	l32i	a8, a8, 0
	bbsi	a8, 23, .LBB33_13
# %bb.14:                               # %abla_fn_486103918_4251942_direct.exit24.i
	l32r	a8, .LCPI33_1
	movi	a9, 105
	memw
	s32i	a9, a8, 0
	memw
.LBB33_15:                              # %source.label.i10.i
                                        # =>This Inner Loop Header: Depth=1
	l32r	a8, .LCPI33_0
	memw
	l32i	a8, a8, 0
	bbsi	a8, 23, .LBB33_15
# %bb.16:                               # %abla_fn_486103918_4251942_direct.exit16.i
	l32r	a8, .LCPI33_1
	movi	a9, 111
	memw
	s32i	a9, a8, 0
	memw
.LBB33_17:                              # %source.label.i2.i
                                        # =>This Inner Loop Header: Depth=1
	l32r	a8, .LCPI33_0
	memw
	l32i	a8, a8, 0
	bbsi	a8, 23, .LBB33_17
# %bb.18:                               # %abla_fn_486103918_4251942_direct.exit8.i
	l32r	a8, .LCPI33_1
	movi	a9, 110
	memw
	s32i	a9, a8, 0
	memw
.LBB33_19:                              # %source.label.i.i
                                        # =>This Inner Loop Header: Depth=1
	l32r	a8, .LCPI33_0
	memw
	l32i	a8, a8, 0
	bbsi	a8, 23, .LBB33_19
# %bb.20:                               # %abla_fn_247640842_482364535_direct.exit
	l32r	a8, .LCPI33_1
	movi	a9, 32
	memw
	s32i	a9, a8, 0
	memw
	call8	abla_fn_823764238_93670715_direct
.LBB33_21:                              # %source.label.i58.i2
                                        # =>This Inner Loop Header: Depth=1
	l32r	a8, .LCPI33_0
	memw
	l32i	a8, a8, 0
	bbsi	a8, 23, .LBB33_21
# %bb.22:                               # %abla_fn_486103918_4251942_direct.exit64.i8
	l32r	a8, .LCPI33_1
	movi	a9, 32
	memw
	s32i	a9, a8, 0
	memw
.LBB33_23:                              # %source.label.i50.i10
                                        # =>This Inner Loop Header: Depth=1
	l32r	a8, .LCPI33_0
	memw
	l32i	a8, a8, 0
	bbsi	a8, 23, .LBB33_23
# %bb.24:                               # %abla_fn_486103918_4251942_direct.exit56.i16
	l32r	a8, .LCPI33_1
	movi	a9, 102
	memw
	s32i	a9, a8, 0
	memw
.LBB33_25:                              # %source.label.i42.i18
                                        # =>This Inner Loop Header: Depth=1
	l32r	a8, .LCPI33_0
	memw
	l32i	a8, a8, 0
	bbsi	a8, 23, .LBB33_25
# %bb.26:                               # %abla_fn_486103918_4251942_direct.exit48.i24
	l32r	a8, .LCPI33_1
	movi	a9, 97
	memw
	s32i	a9, a8, 0
	memw
.LBB33_27:                              # %source.label.i34.i26
                                        # =>This Inner Loop Header: Depth=1
	l32r	a8, .LCPI33_0
	memw
	l32i	a8, a8, 0
	bbsi	a8, 23, .LBB33_27
# %bb.28:                               # %abla_fn_486103918_4251942_direct.exit40.i32
	l32r	a8, .LCPI33_1
	movi	a9, 105
	memw
	s32i	a9, a8, 0
	memw
.LBB33_29:                              # %source.label.i26.i34
                                        # =>This Inner Loop Header: Depth=1
	l32r	a8, .LCPI33_0
	memw
	l32i	a8, a8, 0
	bbsi	a8, 23, .LBB33_29
# %bb.30:                               # %abla_fn_486103918_4251942_direct.exit32.i40
	l32r	a8, .LCPI33_1
	movi	a9, 108
	memw
	s32i	a9, a8, 0
	memw
.LBB33_31:                              # %source.label.i18.i42
                                        # =>This Inner Loop Header: Depth=1
	l32r	a8, .LCPI33_0
	memw
	l32i	a8, a8, 0
	bbsi	a8, 23, .LBB33_31
# %bb.32:                               # %abla_fn_486103918_4251942_direct.exit24.i48
	l32r	a8, .LCPI33_1
	movi	a9, 101
	memw
	s32i	a9, a8, 0
	memw
.LBB33_33:                              # %source.label.i10.i50
                                        # =>This Inner Loop Header: Depth=1
	l32r	a8, .LCPI33_0
	memw
	l32i	a8, a8, 0
	bbsi	a8, 23, .LBB33_33
# %bb.34:                               # %abla_fn_486103918_4251942_direct.exit16.i56
	l32r	a8, .LCPI33_1
	movi	a9, 100
	memw
	s32i	a9, a8, 0
	memw
.LBB33_35:                              # %source.label.i2.i58
                                        # =>This Inner Loop Header: Depth=1
	l32r	a8, .LCPI33_0
	memw
	l32i	a8, a8, 0
	bbsi	a8, 23, .LBB33_35
# %bb.36:                               # %abla_fn_486103918_4251942_direct.exit8.i64
	l32r	a8, .LCPI33_1
	movi	a9, 58
	memw
	s32i	a9, a8, 0
	memw
.LBB33_37:                              # %source.label.i.i66
                                        # =>This Inner Loop Header: Depth=1
	l32r	a8, .LCPI33_0
	memw
	l32i	a8, a8, 0
	bbsi	a8, 23, .LBB33_37
# %bb.38:                               # %abla_fn_536296141_487513777_direct.exit
	l32r	a8, .LCPI33_1
	movi	a9, 32
	memw
	s32i	a9, a8, 0
	memw
	or	a10, a2, a2
	call8	abla_fn_823764238_93670715_direct
.LBB33_39:                              # %source.label.i42.i73
                                        # =>This Inner Loop Header: Depth=1
	l32r	a8, .LCPI33_0
	memw
	l32i	a8, a8, 0
	bbsi	a8, 23, .LBB33_39
# %bb.40:                               # %abla_fn_486103918_4251942_direct.exit48.i79
	l32r	a8, .LCPI33_1
	movi	a9, 58
	memw
	s32i	a9, a8, 0
	memw
.LBB33_41:                              # %source.label.i34.i81
                                        # =>This Inner Loop Header: Depth=1
	l32r	a8, .LCPI33_0
	memw
	l32i	a8, a8, 0
	bbsi	a8, 23, .LBB33_41
# %bb.42:                               # %abla_fn_486103918_4251942_direct.exit40.i87
	l32r	a8, .LCPI33_1
	movi	a9, 32
	memw
	s32i	a9, a8, 0
	memw
.LBB33_43:                              # %source.label.i26.i89
                                        # =>This Inner Loop Header: Depth=1
	l32r	a8, .LCPI33_0
	memw
	l32i	a8, a8, 0
	bbsi	a8, 23, .LBB33_43
# %bb.44:                               # %abla_fn_486103918_4251942_direct.exit32.i95
	l32r	a8, .LCPI33_1
	movi	a9, 108
	memw
	s32i	a9, a8, 0
	memw
.LBB33_45:                              # %source.label.i18.i97
                                        # =>This Inner Loop Header: Depth=1
	l32r	a8, .LCPI33_0
	memw
	l32i	a8, a8, 0
	bbsi	a8, 23, .LBB33_45
# %bb.46:                               # %abla_fn_486103918_4251942_direct.exit24.i103
	l32r	a8, .LCPI33_1
	movi	a9, 105
	memw
	s32i	a9, a8, 0
	memw
.LBB33_47:                              # %source.label.i10.i105
                                        # =>This Inner Loop Header: Depth=1
	l32r	a8, .LCPI33_0
	memw
	l32i	a8, a8, 0
	bbsi	a8, 23, .LBB33_47
# %bb.48:                               # %abla_fn_486103918_4251942_direct.exit16.i111
	l32r	a8, .LCPI33_1
	movi	a9, 110
	memw
	s32i	a9, a8, 0
	memw
.LBB33_49:                              # %source.label.i2.i113
                                        # =>This Inner Loop Header: Depth=1
	l32r	a8, .LCPI33_0
	memw
	l32i	a8, a8, 0
	bbsi	a8, 23, .LBB33_49
# %bb.50:                               # %abla_fn_486103918_4251942_direct.exit8.i119
	l32r	a8, .LCPI33_1
	movi	a9, 101
	memw
	s32i	a9, a8, 0
	memw
.LBB33_51:                              # %source.label.i.i121
                                        # =>This Inner Loop Header: Depth=1
	l32r	a8, .LCPI33_0
	memw
	l32i	a8, a8, 0
	bbsi	a8, 23, .LBB33_51
# %bb.52:                               # %abla_fn_20604247_239136549_direct.exit
	l32r	a8, .LCPI33_1
	movi	a9, 32
	memw
	s32i	a9, a8, 0
	memw
	movi	a8, 1
	l32r	a9, .LCPI33_2
	movi	a10, 9
	movi	a11, 10
	bgeu	a8, a9, .LBB33_57
.LBB33_53:                              # %scalar.divide.checked.i
                                        # =>This Inner Loop Header: Depth=1
	quou	a12, a3, a8
	bgeu	a10, a12, .LBB33_57
# %bb.54:                               # %source.label7.i
                                        #   in Loop: Header=BB33_53 Depth=1
	mull	a8, a8, a11
	bltu	a8, a9, .LBB33_53
	j	.LBB33_57
.LBB33_55:                              # %source.label.i.i207
                                        #   Parent Loop BB33_57 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	l32r	a9, .LCPI33_0
	memw
	l32i	a9, a9, 0
	bbsi	a9, 23, .LBB33_55
# %bb.56:                               # %abla_fn_486103918_4251942_direct.exit.i
                                        #   in Loop: Header=BB33_57 Depth=1
	quou	a9, a3, a8
	movi	a10, 10
	remu	a9, a9, a10
	movi	a11, 48
	or	a9, a9, a11
	l32r	a11, .LCPI33_1
	memw
	s32i	a9, a11, 0
	quou	a8, a8, a10
	memw
.LBB33_57:                              # %source.label9.i
                                        # =>This Loop Header: Depth=1
                                        #     Child Loop BB33_55 Depth 2
	bnez	a8, .LBB33_55
.LBB33_58:                              # %source.label.i74.i
                                        # =>This Inner Loop Header: Depth=1
	l32r	a8, .LCPI33_0
	memw
	l32i	a8, a8, 0
	bbsi	a8, 23, .LBB33_58
# %bb.59:                               # %abla_fn_486103918_4251942_direct.exit80.i
	l32r	a8, .LCPI33_1
	movi	a9, 58
	memw
	s32i	a9, a8, 0
	memw
.LBB33_60:                              # %source.label.i66.i128
                                        # =>This Inner Loop Header: Depth=1
	l32r	a8, .LCPI33_0
	memw
	l32i	a8, a8, 0
	bbsi	a8, 23, .LBB33_60
# %bb.61:                               # %abla_fn_486103918_4251942_direct.exit72.i134
	l32r	a8, .LCPI33_1
	movi	a9, 32
	memw
	s32i	a9, a8, 0
	memw
.LBB33_62:                              # %source.label.i58.i136
                                        # =>This Inner Loop Header: Depth=1
	l32r	a8, .LCPI33_0
	memw
	l32i	a8, a8, 0
	bbsi	a8, 23, .LBB33_62
# %bb.63:                               # %abla_fn_486103918_4251942_direct.exit64.i142
	l32r	a8, .LCPI33_1
	movi	a9, 102
	memw
	s32i	a9, a8, 0
	memw
.LBB33_64:                              # %source.label.i50.i144
                                        # =>This Inner Loop Header: Depth=1
	l32r	a8, .LCPI33_0
	memw
	l32i	a8, a8, 0
	bbsi	a8, 23, .LBB33_64
# %bb.65:                               # %abla_fn_486103918_4251942_direct.exit56.i150
	l32r	a8, .LCPI33_1
	movi	a9, 117
	memw
	s32i	a9, a8, 0
	memw
.LBB33_66:                              # %source.label.i42.i152
                                        # =>This Inner Loop Header: Depth=1
	l32r	a8, .LCPI33_0
	memw
	l32i	a8, a8, 0
	bbsi	a8, 23, .LBB33_66
# %bb.67:                               # %abla_fn_486103918_4251942_direct.exit48.i158
	l32r	a8, .LCPI33_1
	movi	a9, 110
	memw
	s32i	a9, a8, 0
	memw
.LBB33_68:                              # %source.label.i34.i160
                                        # =>This Inner Loop Header: Depth=1
	l32r	a8, .LCPI33_0
	memw
	l32i	a8, a8, 0
	bbsi	a8, 23, .LBB33_68
# %bb.69:                               # %abla_fn_486103918_4251942_direct.exit40.i166
	l32r	a8, .LCPI33_1
	movi	a9, 99
	memw
	s32i	a9, a8, 0
	memw
.LBB33_70:                              # %source.label.i26.i168
                                        # =>This Inner Loop Header: Depth=1
	l32r	a8, .LCPI33_0
	memw
	l32i	a8, a8, 0
	bbsi	a8, 23, .LBB33_70
# %bb.71:                               # %abla_fn_486103918_4251942_direct.exit32.i174
	l32r	a8, .LCPI33_1
	movi	a9, 116
	memw
	s32i	a9, a8, 0
	memw
.LBB33_72:                              # %source.label.i18.i176
                                        # =>This Inner Loop Header: Depth=1
	l32r	a8, .LCPI33_0
	memw
	l32i	a8, a8, 0
	bbsi	a8, 23, .LBB33_72
# %bb.73:                               # %abla_fn_486103918_4251942_direct.exit24.i182
	l32r	a8, .LCPI33_1
	movi	a9, 105
	memw
	s32i	a9, a8, 0
	memw
.LBB33_74:                              # %source.label.i10.i184
                                        # =>This Inner Loop Header: Depth=1
	l32r	a8, .LCPI33_0
	memw
	l32i	a8, a8, 0
	bbsi	a8, 23, .LBB33_74
# %bb.75:                               # %abla_fn_486103918_4251942_direct.exit16.i190
	l32r	a8, .LCPI33_1
	movi	a9, 111
	memw
	s32i	a9, a8, 0
	memw
.LBB33_76:                              # %source.label.i2.i192
                                        # =>This Inner Loop Header: Depth=1
	l32r	a8, .LCPI33_0
	memw
	l32i	a8, a8, 0
	bbsi	a8, 23, .LBB33_76
# %bb.77:                               # %abla_fn_486103918_4251942_direct.exit8.i198
	l32r	a8, .LCPI33_1
	movi	a9, 110
	memw
	s32i	a9, a8, 0
	memw
.LBB33_78:                              # %source.label.i.i200
                                        # =>This Inner Loop Header: Depth=1
	l32r	a8, .LCPI33_0
	memw
	l32i	a8, a8, 0
	bbsi	a8, 23, .LBB33_78
# %bb.79:                               # %abla_fn_497587330_957645610_direct.exit
	l32r	a8, .LCPI33_1
	movi	a9, 32
	memw
	s32i	a9, a8, 0
	memw
	or	a10, a4, a4
	call8	abla_fn_823764238_93670715_direct
.LBB33_80:                              # %source.label.i
                                        # =>This Inner Loop Header: Depth=1
	l32r	a8, .LCPI33_0
	memw
	l32i	a8, a8, 0
	bbsi	a8, 23, .LBB33_80
# %bb.81:                               # %abla_fn_486103918_4251942_direct.exit
	l32r	a8, .LCPI33_1
	movi	a9, 10
	memw
	s32i	a9, a8, 0
	memw
	ill.n
.Lfunc_end33:
	.size	abla_fn_343754787_547301002_direct, .Lfunc_end33-abla_fn_343754787_547301002_direct
                                        # -- End function
	.section	.iram1.2.abla.esp32RecoveredEspIpcIsrStallOtherCpu,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_764337598_298335200_direct
	.type	abla_fn_764337598_298335200_direct,@function
abla_fn_764337598_298335200_direct:     # @abla_fn_764337598_298335200_direct
# %bb.0:                                # %entry
	entry	a1, 32
	memw
	retw.n
.Lfunc_end34:
	.size	abla_fn_764337598_298335200_direct, .Lfunc_end34-abla_fn_764337598_298335200_direct
                                        # -- End function
	.section	.iram1.3.abla.esp32RecoveredEspIpcIsrReleaseOtherCpu,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_180033588_623469740_direct
	.type	abla_fn_180033588_623469740_direct,@function
abla_fn_180033588_623469740_direct:     # @abla_fn_180033588_623469740_direct
# %bb.0:                                # %entry
	entry	a1, 32
	memw
	retw.n
.Lfunc_end35:
	.size	abla_fn_180033588_623469740_direct, .Lfunc_end35-abla_fn_180033588_623469740_direct
                                        # -- End function
	.literal_position
	.literal .LCPI36_0, 1072967760
	.literal .LCPI36_1, 1072693336
	.literal .LCPI36_2, 1072693312
	.section	.iram1.3.abla.esp32RecoveredEspIpcIsrReleaseOtherCpu,"ax",@progbits
	.section	.iram1.0.abla.esp32RomCacheReadEnableValue,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_799638508_495272519_direct
	.type	abla_fn_799638508_495272519_direct,@function
abla_fn_799638508_495272519_direct:     # @abla_fn_799638508_495272519_direct
# %bb.0:                                # %entry
	entry	a1, 32
	l32r	a8, .LCPI36_0
	memw
	l32i	a9, a8, 0
	movi	a10, 1
	or	a9, a9, a10
	memw
	s32i	a9, a8, 0
	movi	a8, 0
	beq	a2, a8, .LBB36_2
# %bb.1:                                # %entry
	l32r	a8, .LCPI36_1
	j	.LBB36_3
.LBB36_2:
	l32r	a8, .LCPI36_2
.LBB36_3:                               # %entry
	memw
	memw
	l32i	a9, a8, 0
	movi	a10, 8
	or	a9, a9, a10
	memw
	s32i	a9, a8, 0
	memw
	retw.n
.Lfunc_end36:
	.size	abla_fn_799638508_495272519_direct, .Lfunc_end36-abla_fn_799638508_495272519_direct
                                        # -- End function
	.literal_position
	.literal .LCPI37_0, 1072693336
	.literal .LCPI37_1, 1072693312
	.literal .LCPI37_2, 1072967928
	.literal .LCPI37_3, 1072967760
	.section	.iram1.0.abla.esp32RomCacheReadEnableValue,"ax",@progbits
	.section	.iram1.0.abla.esp32RomCacheReadDisableValue,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_675579554_510628185_direct
	.type	abla_fn_675579554_510628185_direct,@function
abla_fn_675579554_510628185_direct:     # @abla_fn_675579554_510628185_direct
# %bb.0:                                # %entry
	entry	a1, 32
	l32r	a8, .LCPI37_0
	l32r	a9, .LCPI37_1
	movi	a10, 0
	or	a11, a9, a9
	beq	a2, a10, .LBB37_2
# %bb.1:                                # %entry
	or	a11, a8, a8
.LBB37_2:                               # %entry
	memw
	l32i	a12, a11, 0
	movi	a13, -9
	and	a12, a12, a13
	memw
	s32i	a12, a11, 0
	beq	a2, a10, .LBB37_4
# %bb.3:                                # %entry
	or	a8, a9, a9
.LBB37_4:                               # %entry
	memw
	memw
	l32i	a8, a8, 0
	bbsi	a8, 3, .LBB37_7
.LBB37_5:                               # %source.label9.i
                                        # =>This Inner Loop Header: Depth=1
	l32r	a8, .LCPI37_2
	memw
	l32i	a8, a8, 0
	bnez	a8, .LBB37_5
# %bb.6:                                # %source.label11.i
	l32r	a8, .LCPI37_3
	memw
	l32i	a9, a8, 0
	movi	a10, -2
	and	a9, a9, a10
	memw
	s32i	a9, a8, 0
	memw
.LBB37_7:                               # %abla_fn_437526526_553099855_direct.exit
	retw.n
.Lfunc_end37:
	.size	abla_fn_675579554_510628185_direct, .Lfunc_end37-abla_fn_675579554_510628185_direct
                                        # -- End function
	.literal_position
	.literal .LCPI38_0, 1073611189
	.literal .LCPI38_1, 1072955420
	.literal .LCPI38_2, -65536
	.literal .LCPI38_3, 1072955392
	.section	.iram1.0.abla.esp32RomCacheReadDisableValue,"ax",@progbits
	.section	.iram1.abla.esp32RomOutputPutc,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_96223132_121353370_direct
	.type	abla_fn_96223132_121353370_direct,@function
abla_fn_96223132_121353370_direct:      # @abla_fn_96223132_121353370_direct
# %bb.0:                                # %entry
	entry	a1, 32
	movi	a8, 13
	bne	a2, a8, .LBB38_1
	j	.LBB38_9
.LBB38_1:                               # %entry
	beqi	a2, 10, .LBB38_2
	j	.LBB38_10
.LBB38_2:                               # %source.label
	l32r	a8, .LCPI38_0
	memw
	l8ui	a8, a8, 0
	slli	a8, a8, 16
	l32r	a9, .LCPI38_1
	add	a9, a8, a9
	memw
	l32i	a10, a9, 0
	l32r	a9, .LCPI38_2
	bbci	a10, 23, .LBB38_5
.LBB38_3:                               # %source.label.i30
                                        # =>This Inner Loop Header: Depth=1
	beqz.n	a9, .LBB38_5
# %bb.4:                                # %source.label10.i39
                                        #   in Loop: Header=BB38_3 Depth=1
	l32r	a10, .LCPI38_1
	add	a10, a8, a10
	memw
	l32i	a10, a10, 0
	addi	a9, a9, 1
	bbsi	a10, 23, .LBB38_3
.LBB38_5:                               # %abla_fn_443529141_741897711_direct.exit43
	l32r	a9, .LCPI38_3
	add	a8, a8, a9
	movi	a9, 13
	memw
	s32i	a9, a8, 0
	l32r	a8, .LCPI38_0
	memw
	l8ui	a8, a8, 0
	slli	a8, a8, 16
	l32r	a9, .LCPI38_1
	add	a9, a8, a9
	memw
	l32i	a10, a9, 0
	l32r	a9, .LCPI38_2
	movi	a2, 10
	bbci	a10, 23, .LBB38_8
.LBB38_6:                               # %source.label.i10
                                        # =>This Inner Loop Header: Depth=1
	beqz.n	a9, .LBB38_8
# %bb.7:                                # %source.label10.i19
                                        #   in Loop: Header=BB38_6 Depth=1
	l32r	a10, .LCPI38_1
	add	a10, a8, a10
	memw
	l32i	a10, a10, 0
	addi	a9, a9, 1
	bbsi	a10, 23, .LBB38_6
.LBB38_8:                               # %source.label8.sink.split
	l32r	a9, .LCPI38_3
	add	a8, a8, a9
	memw
	s32i	a2, a8, 0
.LBB38_9:                               # %source.label8
	retw.n
.LBB38_10:                              # %source.label5
	l32r	a8, .LCPI38_0
	memw
	l8ui	a8, a8, 0
	slli	a8, a8, 16
	l32r	a9, .LCPI38_1
	add	a9, a8, a9
	memw
	l32i	a10, a9, 0
	l32r	a9, .LCPI38_2
	bbci	a10, 23, .LBB38_8
.LBB38_11:                              # %source.label.i
                                        # =>This Inner Loop Header: Depth=1
	beqz	a9, .LBB38_8
# %bb.12:                               # %source.label10.i
                                        #   in Loop: Header=BB38_11 Depth=1
	l32r	a10, .LCPI38_1
	add	a10, a8, a10
	memw
	l32i	a10, a10, 0
	addi	a9, a9, 1
	bbsi	a10, 23, .LBB38_11
	j	.LBB38_8
.Lfunc_end38:
	.size	abla_fn_96223132_121353370_direct, .Lfunc_end38-abla_fn_96223132_121353370_direct
                                        # -- End function
	.literal_position
	.literal .LCPI39_0, abla_fn_96223132_121353370_direct
	.section	.iram1.abla.esp32RomOutputPutc,"ax",@progbits
	.section	.text.abla_fn_156983400_573095120_direct,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_156983400_573095120_direct
	.type	abla_fn_156983400_573095120_direct,@function
abla_fn_156983400_573095120_direct:     # @abla_fn_156983400_573095120_direct
# %bb.0:                                # %entry
	entry	a1, 32
	l32r	a7, .LCPI39_0
.LBB39_1:                               # %source.label
                                        # =>This Inner Loop Header: Depth=1
	memw
	l8ui	a10, a2, 0
	beqz.n	a10, .LBB39_3
# %bb.2:                                # %source.label4
                                        #   in Loop: Header=BB39_1 Depth=1
	callx8	a7
	addi	a2, a2, 1
	j	.LBB39_1
.LBB39_3:                               # %source.label5
	retw.n
.Lfunc_end39:
	.size	abla_fn_156983400_573095120_direct, .Lfunc_end39-abla_fn_156983400_573095120_direct
                                        # -- End function
	.literal_position
	.literal .LCPI40_0, pxCurrentTCBs
	.literal .LCPI40_1, abla_fn_254507142_821368668_direct
	.section	.text.abla_fn_156983400_573095120_direct,"ax",@progbits
	.section	.text.abla_fn_570566245_151476961_direct,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_570566245_151476961_direct
	.type	abla_fn_570566245_151476961_direct,@function
abla_fn_570566245_151476961_direct:     # @abla_fn_570566245_151476961_direct
# %bb.0:                                # %entry
	entry	a1, 32
	#APP
	rsil	a10, 3
	#NO_APP
	#APP
	rsr	a8, prid
	#NO_APP
	srli	a8, a8, 11
	movi	a9, 4
	and	a8, a8, a9
	l32r	a9, .LCPI40_0
	or	a8, a8, a9
	memw
	l32i	a2, a8, 0
	l32r	a8, .LCPI40_1
	callx8	a8
	retw.n
.Lfunc_end40:
	.size	abla_fn_570566245_151476961_direct, .Lfunc_end40-abla_fn_570566245_151476961_direct
                                        # -- End function
	.literal_position
	.literal .LCPI41_0, .Labla_string_abla_fn_627837887_633683867_1431.native.mutable.u32s
	.literal .LCPI41_1, abla_fn_186944242_355245718_direct
	.literal .LCPI41_2, pxCurrentTCBs
	.literal .LCPI41_3, abla_fn_539458941_750097516_direct
	.literal .LCPI41_4, abla_static_abla_fn_627837887_633683867_1370
	.literal .LCPI41_5, abla_static_abla_fn_627837887_633683867_1376
	.literal .LCPI41_6, abla_fn_707068177_288599970_direct
	.section	.text.abla_fn_570566245_151476961_direct,"ax",@progbits
	.section	.text.abla_fn_723211900_405790393_direct,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_723211900_405790393_direct
	.type	abla_fn_723211900_405790393_direct,@function
abla_fn_723211900_405790393_direct:     # @abla_fn_723211900_405790393_direct
# %bb.0:                                # %entry
	entry	a1, 32
	memw
	l32i	a5, a2, 56
	memw
	l32i	a7, a2, 64
	beqz.n	a7, .LBB41_4
# %bb.1:                                # %source.label11
	memw
	l32i	a6, a2, 4
	or	a10, a6, a6
	or	a11, a3, a3
	or	a12, a7, a7
	call8	abla_fn_334943840_569200394_direct
	add	a8, a6, a7
	memw
	l32i	a9, a2, 8
	bltu	a8, a9, .LBB41_3
# %bb.2:                                # %source.label17
	memw
	l32i	a8, a2, 0
.LBB41_3:                               # %source.label18
	memw
	s32i	a8, a2, 4
	movi	a7, 0
	j	.LBB41_14
.LBB41_4:                               # %source.label
	memw
	l32i	a8, a2, 0
	movi	a7, 0
	bnez	a8, .LBB41_14
# %bb.5:                                # %source.label7
	memw
	l32i	a4, a2, 8
	l32r	a10, .LCPI41_0
	l32r	a8, .LCPI41_1
	callx8	a8
	movi	a6, 0
	movi	a7, 0
	beqz	a4, .LBB41_13
# %bb.6:                                # %source.label.i
	#APP
	rsr	a8, prid
	#NO_APP
	srli	a8, a8, 11
	movi	a9, 4
	and	a8, a8, a9
	l32r	a9, .LCPI41_2
	or	a8, a8, a9
	memw
	l32i	a8, a8, 0
	beq	a4, a8, .LBB41_7
	j	.LBB41_15
.LBB41_7:                               # %source.label8.i
	memw
	l32i	a8, a4, 80
	beqz	a8, .LBB41_15
# %bb.8:                                # %source.label12.i
	addi	a9, a8, -1
	memw
	s32i	a9, a4, 80
	memw
	l32i	a8, a4, 44
	memw
	l32i	a3, a4, 76
	bnez	a9, .LBB41_13
# %bb.9:                                # %source.label12.i
	bne	a8, a3, .LBB41_10
	j	.LBB41_13
.LBB41_10:                              # %source.label20.i
	addi	a7, a4, 4
	l32r	a8, .LCPI41_3
	or	a10, a7, a7
	callx8	a8
	memw
	s32i	a3, a4, 44
	movi	a8, 25
	sub	a8, a8, a3
	memw
	memw
	s32i	a8, a4, 24
	memw
	l32i	a8, a4, 44
	l32r	a9, .LCPI41_4
	memw
	l32i	a10, a9, 0
	bgeu	a10, a8, .LBB41_12
# %bb.11:                               # %source.label.i.i
	memw
	s32i	a8, a9, 0
.LBB41_12:                              # %abla_fn_424462117_41002680_direct.exit.i
	movi	a9, 20
	mull	a8, a8, a9
	l32r	a9, .LCPI41_5
	add	a8, a8, a9
	memw
	l32i	a9, a8, 4
	memw
	l32i	a10, a9, 8
	memw
	s32i	a9, a4, 8
	memw
	s32i	a10, a4, 12
	memw
	s32i	a7, a10, 4
	memw
	s32i	a7, a9, 8
	memw
	s32i	a8, a4, 20
	memw
	l32i	a9, a8, 0
	addi	a9, a9, 1
	memw
	s32i	a9, a8, 0
	movi	a7, 1
.LBB41_13:                              # %abla_fn_71124296_684186346_direct.exit
	l32r	a10, .LCPI41_0
	l32r	a8, .LCPI41_6
	callx8	a8
	memw
	s32i	a6, a2, 8
.LBB41_14:                              # %source.label35
	memw
	addi	a8, a5, 1
	memw
	s32i	a8, a2, 56
	or	a2, a7, a7
	retw.n
.LBB41_15:                              # %source.label6.i
	ill.n
.Lfunc_end41:
	.size	abla_fn_723211900_405790393_direct, .Lfunc_end41-abla_fn_723211900_405790393_direct
                                        # -- End function
	.literal_position
	.literal .LCPI42_0, abla_fn_186944242_355245718_direct
	.literal .LCPI42_1, abla_fn_985332523_289608079_direct
	.literal .LCPI42_2, abla_fn_707068177_288599970_direct
	.section	.text.abla_fn_723211900_405790393_direct,"ax",@progbits
	.section	.text.abla_fn_905045920_888357933_direct,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_905045920_888357933_direct
	.type	abla_fn_905045920_888357933_direct,@function
abla_fn_905045920_888357933_direct:     # @abla_fn_905045920_888357933_direct
# %bb.0:                                # %entry
	entry	a1, 32
	or	a7, a1, a1
	memw
	l32i	a6, a2, 72
	beqz	a6, .LBB42_6
# %bb.1:                                # %source.label3
	memw
	l32i	a8, a6, 56
	memw
	l32i	a9, a6, 60
	bgeu	a8, a9, .LBB42_6
# %bb.2:                                # %source.label8
	addi	a8, a1, -32
	movsp	a1, a8
	or	a4, a1, a1
	memw
	s32i	a2, a4, 0
	addi	a5, a6, 76
	l32r	a8, .LCPI42_0
	or	a10, a5, a5
	callx8	a8
	memw
	memw
	l32i	a8, a6, 56
	memw
	l32i	a9, a6, 60
	movi	a2, 0
	bgeu	a8, a9, .LBB42_5
# %bb.3:                                # %source.label12
	or	a10, a6, a6
	or	a11, a4, a4
	call8	abla_fn_723211900_405790393_direct
	memw
	l32i	a8, a6, 36
	beqz.n	a8, .LBB42_5
# %bb.4:                                # %source.label13
	addi	a10, a6, 36
	l32r	a8, .LCPI42_1
	callx8	a8
	or	a2, a10, a10
.LBB42_5:                               # %source.label17
	l32r	a8, .LCPI42_2
	or	a10, a5, a5
	callx8	a8
	retw.n
.LBB42_6:                               # %source.label
	ill.n
.Lfunc_end42:
	.size	abla_fn_905045920_888357933_direct, .Lfunc_end42-abla_fn_905045920_888357933_direct
                                        # -- End function
	.literal_position
	.literal .LCPI43_0, abla_fn_923148460_536466818_direct
	.literal .LCPI43_1, abla_fn_186944242_355245718_direct
	.literal .LCPI43_2, abla_static_abla_fn_627837887_633683867_1418
	.literal .LCPI43_3, abla_static_abla_fn_627837887_633683867_1394
	.literal .LCPI43_4, abla_fn_707068177_288599970_direct
	.literal .LCPI43_5, abla_fn_970437484_907475612_direct
	.literal .LCPI43_6, abla_fn_985332523_289608079_direct
	.literal .LCPI43_7, abla_fn_473142447_878684343_direct
	.literal .LCPI43_8, abla_fn_707068177_288599970_direct
	.section	.text.abla_fn_905045920_888357933_direct,"ax",@progbits
	.section	.text.abla_fn_522837838_820976022_direct,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_522837838_820976022_direct
	.type	abla_fn_522837838_820976022_direct,@function
abla_fn_522837838_820976022_direct:     # @abla_fn_522837838_820976022_direct
# %bb.0:                                # %entry
	entry	a1, 48
	or	a7, a1, a1
	beqz	a2, .LBB43_19
# %bb.1:                                # %source.label5
	memw
	l32i	a8, a2, 64
	bnez	a8, .LBB43_19
# %bb.2:                                # %source.label19
	l32r	a8, .LCPI43_0
	callx8	a8
	addi	a8, a1, -64
	movsp	a1, a8
	movi	a5, 0
	memw
	s32i	a5, a1, 16
	movi	a8, 4
	or	a8, a1, a8
	s32i	a8, a7, 8                       # 4-byte Folded Spill
	addi	a8, a2, 16
	s32i	a8, a7, 12                      # 4-byte Folded Spill
	addi	a6, a2, 76
	addi	a4, a1, 16
	or	a3, a1, a1
.LBB43_3:                               # %source.label32
                                        # =>This Inner Loop Header: Depth=1
	or	a10, a6, a6
	l32r	a8, .LCPI43_1
	callx8	a8
	memw
	memw
	l32i	a8, a2, 56
	memw
	l32i	a9, a2, 60
	bltu	a8, a9, .LBB43_9
# %bb.4:                                # %source.label69
                                        #   in Loop: Header=BB43_3 Depth=1
	memw
	l32i	a8, a4, 0
	beqz	a8, .LBB43_18
# %bb.5:                                # %source.label73
                                        #   in Loop: Header=BB43_3 Depth=1
	bbsi	a5, 0, .LBB43_7
# %bb.6:                                # %source.label74
                                        #   in Loop: Header=BB43_3 Depth=1
	memw
	memw
	l32r	a8, .LCPI43_2
	l32i	a8, a8, 0
	memw
	s32i	a8, a3, 0
	memw
	memw
	l32r	a8, .LCPI43_3
	l32i	a8, a8, 0
	memw
	l32i	a9, a7, 8                       # 4-byte Folded Reload
	s32i	a8, a9, 0
.LBB43_7:                               # %source.label76
                                        #   in Loop: Header=BB43_3 Depth=1
	or	a10, a3, a3
	or	a11, a4, a4
	call8	abla_fn_632124653_101754171_direct
	bnez	a10, .LBB43_18
# %bb.8:                                # %source.label80
                                        #   in Loop: Header=BB43_3 Depth=1
	memw
	l32i	a11, a4, 0
	l32i	a10, a7, 12                     # 4-byte Folded Reload
	call8	abla_fn_757481649_25429647_direct
	or	a10, a6, a6
	l32r	a8, .LCPI43_4
	callx8	a8
	l32r	a8, .LCPI43_5
	callx8	a8
	movi	a5, 1
	j	.LBB43_3
.LBB43_9:                               # %source.label40
	or	a10, a2, a2
	movi	a11, 0
	call8	abla_fn_723211900_405790393_direct
	memw
	l32i	a8, a2, 72
	beqz.n	a8, .LBB43_12
# %bb.10:                               # %source.label49
	or	a10, a2, a2
	call8	abla_fn_905045920_888357933_direct
	beqz.n	a10, .LBB43_18
# %bb.11:                               # %source.label51
	#APP
	rsr	a8, prid
	#NO_APP
	j	.LBB43_17
.LBB43_12:                              # %source.label56
	memw
	l32i	a8, a2, 36
	beqz.n	a8, .LBB43_15
# %bb.13:                               # %source.label57
	addi	a10, a2, 36
	l32r	a8, .LCPI43_6
	callx8	a8
	beqz.n	a10, .LBB43_18
# %bb.14:                               # %source.label59
	#APP
	rsr	a8, prid
	#NO_APP
	j	.LBB43_17
.LBB43_15:                              # %source.label62
	beqz.n	a10, .LBB43_18
# %bb.16:                               # %source.label63
	#APP
	rsr	a8, prid
	#NO_APP
.LBB43_17:                              # %source.label67.sink.split
	extui	a10, a8, 13, 1
	l32r	a8, .LCPI43_7
	callx8	a8
.LBB43_18:                              # %common.ret
	l32r	a8, .LCPI43_8
	or	a10, a6, a6
	callx8	a8
	retw.n
.LBB43_19:                              # %source.label
	ill.n
.Lfunc_end43:
	.size	abla_fn_522837838_820976022_direct, .Lfunc_end43-abla_fn_522837838_820976022_direct
                                        # -- End function
	.section	.text.abla_fn_460839413_627444129_direct,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_460839413_627444129_direct
	.type	abla_fn_460839413_627444129_direct,@function
abla_fn_460839413_627444129_direct:     # @abla_fn_460839413_627444129_direct
# %bb.0:                                # %entry
	entry	a1, 32
	beqz.n	a2, .LBB44_5
# %bb.1:                                # %source.label2
	memw
	l32i	a7, a2, 8
	call8	abla_fn_570566245_151476961_direct
	bne	a7, a10, .LBB44_3
# %bb.2:                                # %source.label5
	memw
	l32i	a8, a2, 12
	addi	a8, a8, -1
	memw
	s32i	a8, a2, 12
	beqz.n	a8, .LBB44_4
.LBB44_3:                               # %common.ret
	retw.n
.LBB44_4:                               # %source.label6
	or	a10, a2, a2
	call8	abla_fn_522837838_820976022_direct
	retw.n
.LBB44_5:                               # %source.label
	ill.n
.Lfunc_end44:
	.size	abla_fn_460839413_627444129_direct, .Lfunc_end44-abla_fn_460839413_627444129_direct
                                        # -- End function
	.literal_position
	.literal .LCPI45_0, abla_fn_186944242_355245718_direct
	.literal .LCPI45_1, abla_fn_985332523_289608079_direct
	.literal .LCPI45_2, abla_fn_707068177_288599970_direct
	.section	.text.abla_fn_460839413_627444129_direct,"ax",@progbits
	.section	.text.abla_fn_637939547_606627930_direct,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_637939547_606627930_direct
	.type	abla_fn_637939547_606627930_direct,@function
abla_fn_637939547_606627930_direct:     # @abla_fn_637939547_606627930_direct
# %bb.0:                                # %entry
	entry	a1, 32
	beqz	a2, .LBB45_12
# %bb.1:                                # %source.label5
	memw
	l32i	a8, a2, 64
	bnez	a8, .LBB45_12
# %bb.2:                                # %source.label8
	memw
	l32i	a8, a2, 0
	bnez.n	a8, .LBB45_4
# %bb.3:                                # %source.label9
	memw
	l32i	a8, a2, 8
	bnez	a8, .LBB45_12
.LBB45_4:                               # %source.label14
	addi	a7, a2, 76
	l32r	a8, .LCPI45_0
	or	a10, a7, a7
	callx8	a8
	memw
	memw
	l32i	a8, a2, 56
	memw
	l32i	a9, a2, 60
	bgeu	a8, a9, .LBB45_11
# %bb.5:                                # %source.label20
	memw
	addi	a8, a8, 1
	memw
	s32i	a8, a2, 56
	memw
	l32i	a8, a2, 72
	beqz.n	a8, .LBB45_7
# %bb.6:                                # %source.label22
	or	a10, a2, a2
	call8	abla_fn_905045920_888357933_direct
	bnez.n	a10, .LBB45_9
	j	.LBB45_11
.LBB45_7:                               # %source.label23
	memw
	l32i	a8, a2, 36
	beqz.n	a8, .LBB45_11
# %bb.8:                                # %source.label24
	addi	a10, a2, 36
	l32r	a8, .LCPI45_1
	callx8	a8
	beqz.n	a10, .LBB45_11
.LBB45_9:                               # %source.label27
	beqz.n	a3, .LBB45_11
# %bb.10:                               # %source.label32
	movi	a8, 1
	memw
	s32i	a8, a3, 0
.LBB45_11:                              # %common.ret
	l32r	a8, .LCPI45_2
	or	a10, a7, a7
	callx8	a8
	retw.n
.LBB45_12:                              # %source.label
	ill.n
.Lfunc_end45:
	.size	abla_fn_637939547_606627930_direct, .Lfunc_end45-abla_fn_637939547_606627930_direct
                                        # -- End function
	.literal_position
	.literal .LCPI46_0, abla_fn_923148460_536466818_direct
	.literal .LCPI46_1, abla_fn_186944242_355245718_direct
	.literal .LCPI46_2, .Labla_string_abla_fn_627837887_633683867_1431.native.mutable.u32s
	.literal .LCPI46_3, abla_fn_186944242_355245718_direct
	.literal .LCPI46_4, pxCurrentTCBs
	.literal .LCPI46_5, abla_fn_707068177_288599970_direct
	.literal .LCPI46_6, abla_fn_985332523_289608079_direct
	.literal .LCPI46_7, abla_fn_473142447_878684343_direct
	.literal .LCPI46_8, abla_static_abla_fn_627837887_633683867_1418
	.literal .LCPI46_9, abla_static_abla_fn_627837887_633683867_1394
	.literal .LCPI46_10, abla_fn_186944242_355245718_direct
	.literal .LCPI46_11, abla_static_abla_fn_627837887_633683867_1376
	.literal .LCPI46_12, abla_fn_539458941_750097516_direct
	.literal .LCPI46_13, abla_static_abla_fn_627837887_633683867_1370
	.literal .LCPI46_14, abla_fn_707068177_288599970_direct
	.literal .LCPI46_15, abla_fn_186944242_355245718_direct
	.literal .LCPI46_16, abla_fn_539458941_750097516_direct
	.literal .LCPI46_17, abla_fn_707068177_288599970_direct
	.literal .LCPI46_18, abla_fn_707068177_288599970_direct
	.literal .LCPI46_19, abla_fn_970437484_907475612_direct
	.literal .LCPI46_20, abla_fn_707068177_288599970_direct
	.section	.text.abla_fn_637939547_606627930_direct,"ax",@progbits
	.section	.text.abla_fn_782558894_832411509_direct,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_782558894_832411509_direct
	.type	abla_fn_782558894_832411509_direct,@function
abla_fn_782558894_832411509_direct:     # @abla_fn_782558894_832411509_direct
# %bb.0:                                # %entry
	entry	a1, 48
	or	a7, a1, a1
	or	a5, a2, a2
	memw
	l32i	a8, a5, 64
	bnez	a8, .LBB46_50
# %bb.1:                                # %source.label11
	l32r	a8, .LCPI46_0
	callx8	a8
	addi	a8, a1, -64
	movsp	a1, a8
	movi	a8, -1
	memw
	s32i	a8, a1, 16
	movi	a8, 4
	or	a8, a1, a8
	s32i	a8, a7, 4                       # 4-byte Folded Spill
	addi	a8, a5, 36
	s32i	a8, a7, 8                       # 4-byte Folded Spill
	addi	a3, a5, 76
	addi	a4, a1, 16
	movi	a8, 0
	s32i	a8, a7, 0                       # 4-byte Folded Spill
	s32i	a1, a7, 12                      # 4-byte Folded Spill
	movi	a6, 0
.LBB46_2:                               # %source.label24
                                        # =>This Inner Loop Header: Depth=1
	or	a10, a3, a3
	l32r	a8, .LCPI46_1
	callx8	a8
	memw
	memw
	l32i	a8, a5, 56
	bnez	a8, .LBB46_25
# %bb.3:                                # %source.label40
                                        #   in Loop: Header=BB46_2 Depth=1
	memw
	l32i	a8, a4, 0
	movi	a2, 0
	beqz	a8, .LBB46_49
# %bb.4:                                # %source.label43
                                        #   in Loop: Header=BB46_2 Depth=1
	bbsi	a6, 0, .LBB46_6
# %bb.5:                                # %source.label44
                                        #   in Loop: Header=BB46_2 Depth=1
	memw
	memw
	l32r	a8, .LCPI46_8
	l32i	a8, a8, 0
	memw
	l32i	a9, a7, 12                      # 4-byte Folded Reload
	s32i	a8, a9, 0
	memw
	memw
	l32r	a8, .LCPI46_9
	l32i	a8, a8, 0
	memw
	l32i	a9, a7, 4                       # 4-byte Folded Reload
	s32i	a8, a9, 0
.LBB46_6:                               # %source.label46
                                        #   in Loop: Header=BB46_2 Depth=1
	l32i	a10, a7, 12                     # 4-byte Folded Reload
	or	a11, a4, a4
	call8	abla_fn_632124653_101754171_direct
	bnez	a10, .LBB46_32
# %bb.7:                                # %source.label54
                                        #   in Loop: Header=BB46_2 Depth=1
	memw
	l32i	a8, a5, 0
	bnez	a8, .LBB46_24
# %bb.8:                                # %source.label55
                                        #   in Loop: Header=BB46_2 Depth=1
	memw
	l32i	a2, a5, 8
	l32r	a10, .LCPI46_2
	l32r	a8, .LCPI46_15
	callx8	a8
	beqz	a2, .LBB46_16
# %bb.9:                                # %source.label.i50
                                        #   in Loop: Header=BB46_2 Depth=1
	#APP
	rsr	a8, prid
	#NO_APP
	srli	a8, a8, 11
	movi	a9, 4
	and	a8, a8, a9
	l32r	a9, .LCPI46_4
	or	a8, a8, a9
	memw
	l32i	a8, a8, 0
	memw
	l32i	a6, a8, 44
	memw
	l32i	a8, a2, 44
	bltu	a8, a6, .LBB46_10
	j	.LBB46_17
.LBB46_10:                              # %source.label8.i
                                        #   in Loop: Header=BB46_2 Depth=1
	memw
	memw
	l32i	a9, a2, 24
	bltz	a9, .LBB46_12
# %bb.11:                               # %source.label10.i
                                        #   in Loop: Header=BB46_2 Depth=1
	movi	a9, 25
	sub	a9, a9, a6
	memw
	s32i	a9, a2, 24
.LBB46_12:                              # %source.label12.i
                                        #   in Loop: Header=BB46_2 Depth=1
	movi	a9, 20
	mull	a8, a8, a9
	l32r	a9, .LCPI46_11
	add	a8, a8, a9
	memw
	l32i	a9, a2, 20
	beq	a9, a8, .LBB46_13
	j	.LBB46_20
.LBB46_13:                              # %source.label14.i
                                        #   in Loop: Header=BB46_2 Depth=1
	addi	a10, a2, 4
	s32i	a10, a7, 0                      # 4-byte Folded Spill
	l32r	a8, .LCPI46_16
	callx8	a8
	memw
	s32i	a6, a2, 44
	memw
	l32i	a8, a2, 44
	memw
	l32r	a10, .LCPI46_13
	l32i	a9, a10, 0
	bgeu	a9, a8, .LBB46_15
# %bb.14:                               # %source.label.i.i82
                                        #   in Loop: Header=BB46_2 Depth=1
	memw
	s32i	a8, a10, 0
.LBB46_15:                              # %abla_fn_424462117_41002680_direct.exit.i64
                                        #   in Loop: Header=BB46_2 Depth=1
	movi	a9, 20
	mull	a8, a8, a9
	l32r	a9, .LCPI46_11
	add	a8, a8, a9
	memw
	l32i	a9, a8, 4
	memw
	l32i	a10, a9, 8
	memw
	s32i	a9, a2, 8
	memw
	s32i	a10, a2, 12
	memw
	l32i	a11, a7, 0                      # 4-byte Folded Reload
	s32i	a11, a10, 4
	memw
	s32i	a11, a9, 8
	memw
	s32i	a8, a2, 20
	memw
	l32i	a9, a8, 0
	addi	a9, a9, 1
	memw
	s32i	a9, a8, 0
	j	.LBB46_21
.LBB46_16:                              #   in Loop: Header=BB46_2 Depth=1
	movi	a8, 0
	j	.LBB46_22
.LBB46_17:                              # %source.label17.i
                                        #   in Loop: Header=BB46_2 Depth=1
	memw
	l32i	a8, a2, 76
	movi	a9, 1
	bltu	a8, a6, .LBB46_19
# %bb.18:                               # %source.label17.i
                                        #   in Loop: Header=BB46_2 Depth=1
	movi	a9, 0
.LBB46_19:                              # %source.label17.i
                                        #   in Loop: Header=BB46_2 Depth=1
	s32i	a9, a7, 0                       # 4-byte Folded Spill
	j	.LBB46_23
.LBB46_20:                              # %source.label15.i
                                        #   in Loop: Header=BB46_2 Depth=1
	memw
	s32i	a6, a2, 44
.LBB46_21:                              # %abla_fn_97688734_993610124_direct.exit
                                        #   in Loop: Header=BB46_2 Depth=1
	movi	a8, 1
.LBB46_22:                              # %abla_fn_97688734_993610124_direct.exit
                                        #   in Loop: Header=BB46_2 Depth=1
	s32i	a8, a7, 0                       # 4-byte Folded Spill
.LBB46_23:                              # %abla_fn_97688734_993610124_direct.exit
                                        #   in Loop: Header=BB46_2 Depth=1
	l32r	a10, .LCPI46_2
	l32r	a8, .LCPI46_17
	callx8	a8
.LBB46_24:                              # %source.label57
                                        #   in Loop: Header=BB46_2 Depth=1
	memw
	l32i	a11, a4, 0
	l32i	a10, a7, 8                      # 4-byte Folded Reload
	call8	abla_fn_757481649_25429647_direct
	or	a10, a3, a3
	l32r	a8, .LCPI46_18
	callx8	a8
	l32r	a8, .LCPI46_19
	callx8	a8
	movi	a6, 1
	j	.LBB46_2
.LBB46_25:                              # %source.label27
	memw
	addi	a8, a8, -1
	memw
	s32i	a8, a5, 56
	memw
	l32i	a8, a5, 0
	bnez	a8, .LBB46_29
# %bb.26:                               # %source.label28
	l32r	a10, .LCPI46_2
	l32r	a8, .LCPI46_3
	callx8	a8
	#APP
	rsr	a8, prid
	#NO_APP
	srli	a8, a8, 11
	movi	a9, 4
	and	a8, a8, a9
	l32r	a9, .LCPI46_4
	or	a8, a8, a9
	memw
	l32i	a6, a8, 0
	beqz.n	a6, .LBB46_28
# %bb.27:                               # %source.label.i
	memw
	l32i	a8, a6, 80
	addi	a8, a8, 1
	memw
	s32i	a8, a6, 80
.LBB46_28:                              # %abla_fn_869482095_397094874_direct.exit
	l32r	a10, .LCPI46_2
	l32r	a8, .LCPI46_5
	callx8	a8
	memw
	s32i	a6, a5, 8
.LBB46_29:                              # %source.label31
	memw
	l32i	a8, a5, 16
	movi	a2, 1
	beqz	a8, .LBB46_49
# %bb.30:                               # %source.label32
	addi	a10, a5, 16
	l32r	a8, .LCPI46_6
	callx8	a8
	beqz	a10, .LBB46_49
# %bb.31:                               # %source.label34
	#APP
	rsr	a8, prid
	#NO_APP
	extui	a10, a8, 13, 1
	l32r	a8, .LCPI46_7
	j	.LBB46_48
.LBB46_32:                              # %source.label48
	l32i	a8, a7, 0                       # 4-byte Folded Reload
	bbsi	a8, 0, .LBB46_33
	j	.LBB46_49
.LBB46_33:                              # %source.label49
	memw
	memw
	l32i	a8, a7, 8                       # 4-byte Folded Reload
	l32i	a8, a8, 0
	beqz.n	a8, .LBB46_35
# %bb.34:                               # %source.label4.i
	memw
	memw
	l32i	a8, a5, 48
	memw
	memw
	l32i	a8, a8, 0
	movi	a9, 25
	sub	a6, a9, a8
	j	.LBB46_36
.LBB46_35:
	movi	a6, 0
.LBB46_36:                              # %abla_fn_837719261_855074337_direct.exit
	memw
	l32i	a4, a5, 8
	l32r	a10, .LCPI46_2
	l32r	a8, .LCPI46_10
	callx8	a8
	beqz	a4, .LBB46_47
# %bb.37:                               # %source.label.i38
	memw
	l32i	a9, a4, 80
	beqz	a9, .LBB46_50
# %bb.38:                               # %source.label7.i
	memw
	l32i	a10, a4, 76
	memw
	l32i	a8, a4, 44
	beqi	a9, 1, .LBB46_39
	j	.LBB46_47
.LBB46_39:                              # %source.label7.i
	maxu	a9, a10, a6
	bne	a8, a9, .LBB46_40
	j	.LBB46_47
.LBB46_40:                              # %source.label19.i
	#APP
	rsr	a10, prid
	#NO_APP
	srli	a10, a10, 11
	movi	a11, 4
	and	a10, a10, a11
	l32r	a11, .LCPI46_4
	or	a10, a10, a11
	memw
	l32i	a10, a10, 0
	bne	a4, a10, .LBB46_41
	j	.LBB46_50
.LBB46_41:                              # %source.label22.i
	memw
	s32i	a9, a4, 44
	memw
	memw
	l32i	a10, a4, 24
	bltz	a10, .LBB46_43
# %bb.42:                               # %source.label24.i
	movi	a10, 25
	sub	a9, a10, a9
	memw
	s32i	a9, a4, 24
.LBB46_43:                              # %source.label26.i
	movi	a9, 20
	mull	a8, a8, a9
	l32r	a9, .LCPI46_11
	add	a8, a8, a9
	memw
	l32i	a9, a4, 20
	bne	a9, a8, .LBB46_47
# %bb.44:                               # %source.label27.i
	addi	a5, a4, 4
	l32r	a8, .LCPI46_12
	or	a10, a5, a5
	callx8	a8
	memw
	l32i	a8, a4, 44
	memw
	l32r	a10, .LCPI46_13
	l32i	a9, a10, 0
	bgeu	a9, a8, .LBB46_46
# %bb.45:                               # %source.label.i.i
	memw
	s32i	a8, a10, 0
.LBB46_46:                              # %abla_fn_424462117_41002680_direct.exit.i
	movi	a9, 20
	mull	a8, a8, a9
	l32r	a9, .LCPI46_11
	add	a8, a8, a9
	memw
	l32i	a9, a8, 4
	memw
	l32i	a10, a9, 8
	memw
	s32i	a9, a4, 8
	memw
	s32i	a10, a4, 12
	memw
	s32i	a5, a10, 4
	memw
	s32i	a5, a9, 8
	memw
	s32i	a8, a4, 20
	memw
	l32i	a9, a8, 0
	addi	a9, a9, 1
	memw
	s32i	a9, a8, 0
.LBB46_47:                              # %abla_fn_255117324_889145307_direct.exit
	l32r	a10, .LCPI46_2
	l32r	a8, .LCPI46_14
.LBB46_48:                              # %common.ret
	callx8	a8
.LBB46_49:                              # %common.ret
	l32r	a8, .LCPI46_20
	or	a10, a3, a3
	callx8	a8
	retw.n
.LBB46_50:                              # %source.label9
	ill.n
.Lfunc_end46:
	.size	abla_fn_782558894_832411509_direct, .Lfunc_end46-abla_fn_782558894_832411509_direct
                                        # -- End function
	.section	.text.abla_fn_324453604_236267316_direct,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_324453604_236267316_direct
	.type	abla_fn_324453604_236267316_direct,@function
abla_fn_324453604_236267316_direct:     # @abla_fn_324453604_236267316_direct
# %bb.0:                                # %entry
	entry	a1, 32
	beqz.n	a2, .LBB47_5
# %bb.1:                                # %source.label3
	memw
	l32i	a7, a2, 8
	call8	abla_fn_570566245_151476961_direct
	beq	a7, a10, .LBB47_3
# %bb.2:                                # %source.label6
	or	a10, a2, a2
	call8	abla_fn_782558894_832411509_direct
	beqz.n	a10, .LBB47_4
.LBB47_3:                               # %common.ret.sink.split
	memw
	l32i	a8, a2, 12
	addi	a8, a8, 1
	memw
	s32i	a8, a2, 12
.LBB47_4:                               # %common.ret
	retw.n
.LBB47_5:                               # %source.label
	ill.n
.Lfunc_end47:
	.size	abla_fn_324453604_236267316_direct, .Lfunc_end47-abla_fn_324453604_236267316_direct
                                        # -- End function
	.literal_position
	.literal .LCPI48_0, 1072955512
	.literal .LCPI48_1, 1072693316
	.literal .LCPI48_2, abla_global_462423855_903385096
	.literal .LCPI48_3, 1072694256
	.literal .LCPI48_4, 524160
	.literal .LCPI48_5, 1072693312
	.literal .LCPI48_6, 1072693340
	.literal .LCPI48_7, abla_global_186399490_945206650
	.literal .LCPI48_8, 1072694296
	.literal .LCPI48_9, 1072693336
	.section	.text.abla_fn_324453604_236267316_direct,"ax",@progbits
	.section	.iram1.abla.esp32RecoveredSpiFlashDisableCache,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_268604840_948715812_direct
	.type	abla_fn_268604840_948715812_direct,@function
abla_fn_268604840_948715812_direct:     # @abla_fn_268604840_948715812_direct
# %bb.0:                                # %entry
	entry	a1, 32
	#APP
	rsil	a8, 5
	#NO_APP
	l32r	a9, .LCPI48_0
	memw
	l32i	a9, a9, 0
	l32r	a9, .LCPI48_1
	memw
	l32i	a9, a9, 0
	#APP
	wsr	a8, ps
	rsync

	#NO_APP
	movi	a8, -1
	xor	a8, a9, a8
	srli	a9, a8, 1
	movi	a10, 8
	and	a9, a9, a10
	extui	a10, a8, 0, 3
	or	a9, a9, a10
	slli	a8, a8, 1
	movi	a10, 16
	and	a8, a8, a10
	or	a8, a9, a8
	l32r	a9, .LCPI48_2
	s32i	a8, a9, 0
.LBB48_1:                               # %source.label.i.i.i
                                        # =>This Inner Loop Header: Depth=1
	#APP
	rsil	a8, 5
	#NO_APP
	l32r	a9, .LCPI48_0
	memw
	l32i	a9, a9, 0
	l32r	a9, .LCPI48_3
	memw
	l32i	a9, a9, 0
	#APP
	wsr	a8, ps
	rsync

	#NO_APP
	l32r	a8, .LCPI48_4
	and	a8, a9, a8
	bnei	a8, 128, .LBB48_1
# %bb.2:                                # %source.label8.i.i.i
	#APP
	rsil	a8, 5
	#NO_APP
	l32r	a9, .LCPI48_0
	memw
	l32i	a10, a9, 0
	l32r	a10, .LCPI48_5
	memw
	l32i	a11, a10, 0
	#APP
	wsr	a8, ps
	rsync

	#NO_APP
	movi	a8, -9
	and	a8, a11, a8
	memw
	s32i	a8, a10, 0
	memw
	#APP
	rsil	a8, 5
	#NO_APP
	memw
	l32i	a9, a9, 0
	l32r	a9, .LCPI48_6
	memw
	l32i	a9, a9, 0
	#APP
	wsr	a8, ps
	rsync

	#NO_APP
	movi	a8, -1
	xor	a8, a9, a8
	srli	a9, a8, 1
	movi	a10, 8
	and	a9, a9, a10
	extui	a10, a8, 0, 3
	or	a9, a9, a10
	slli	a8, a8, 1
	movi	a10, 16
	and	a8, a8, a10
	or	a8, a9, a8
	l32r	a9, .LCPI48_7
	s32i	a8, a9, 0
.LBB48_3:                               # %source.label9.i.i.i
                                        # =>This Inner Loop Header: Depth=1
	#APP
	rsil	a8, 5
	#NO_APP
	l32r	a9, .LCPI48_0
	memw
	l32i	a9, a9, 0
	l32r	a9, .LCPI48_8
	memw
	l32i	a9, a9, 0
	#APP
	wsr	a8, ps
	rsync

	#NO_APP
	l32r	a8, .LCPI48_4
	and	a8, a9, a8
	bnei	a8, 128, .LBB48_3
# %bb.4:                                # %abla_fn_780831991_734722351_direct.exit
	#APP
	rsil	a8, 5
	#NO_APP
	l32r	a9, .LCPI48_0
	memw
	l32i	a9, a9, 0
	l32r	a9, .LCPI48_9
	memw
	l32i	a10, a9, 0
	#APP
	wsr	a8, ps
	rsync

	#NO_APP
	movi	a8, -9
	and	a8, a10, a8
	memw
	s32i	a8, a9, 0
	memw
	retw.n
.Lfunc_end48:
	.size	abla_fn_268604840_948715812_direct, .Lfunc_end48-abla_fn_268604840_948715812_direct
                                        # -- End function
	.literal_position
	.literal .LCPI49_0, -1073741824
	.literal .LCPI49_1, -335873
	.literal .LCPI49_2, abla_static_abla_fn_627837887_633683867_118.0
	.literal .LCPI49_3, abla_static_abla_fn_627837887_633683867_124
	.literal .LCPI49_4, abla_fn_324453604_236267316_direct
	.literal .LCPI49_5, abla_string_abla_fn_627837887_633683867_173.native.mutable.u32s.0
	.literal .LCPI49_6, .Labla_string_abla_fn_627837887_633683867_158.native.bytes
	.literal .LCPI49_7, .Labla_string_abla_fn_627837887_633683867_126.native.bytes
	.literal .LCPI49_8, .Labla_string_abla_fn_627837887_633683867_165.native.bytes
	.literal .LCPI49_9, abla_fn_343754787_547301002_direct
	.literal .LCPI49_10, abla_fn_923148460_536466818_direct
	.literal .LCPI49_11, abla_fn_43435178_164432985_direct
	.literal .LCPI49_12, abla_fn_268604840_948715812_direct
	.literal .LCPI49_13, abla_fn_268604840_948715812_direct
	.literal .LCPI49_14, abla_fn_343754787_547301002_direct
	.literal .LCPI49_15, abla_fn_343754787_547301002_direct
	.section	.iram1.abla.esp32RecoveredSpiFlashDisableCache,"ax",@progbits
	.section	.iram1.abla.esp32RecoveredSpiFlashDisableInterruptsCachesAndOtherCpu,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_321888515_252845378_direct
	.type	abla_fn_321888515_252845378_direct,@function
abla_fn_321888515_252845378_direct:     # @abla_fn_321888515_252845378_direct
# %bb.0:                                # %entry
	entry	a1, 64
	l32r	a8, .LCPI49_0
	addi	a9, a1, 0
	add	a8, a9, a8
	l32r	a9, .LCPI49_1
	bgeu	a9, a8, .LBB49_6
# %bb.1:                                # %source.label37
	l32r	a8, .LCPI49_2
	l8ui	a8, a8, 0
	movi	a10, 0
	beq	a8, a10, .LBB49_3
# %bb.2:
	l32r	a10, .LCPI49_3
.LBB49_3:                               # %source.label37
	l32r	a8, .LCPI49_4
	callx8	a8
	#APP
	rsr	a8, prid
	#NO_APP
	memw
	extui	a8, a8, 13, 1
	#APP
	nsau	a7, a8
	#NO_APP
	l32r	a9, .LCPI49_5
	l32i	a10, a9, 0
	bnei	a10, -1, .LBB49_7
# %bb.4:                                # %source.label40
	memw
	s32i	a8, a9, 0
	l32r	a8, .LCPI49_10
	callx8	a8
	movi	a8, 31
	bgeu	a8, a7, .LBB49_8
# %bb.5:                                # %source.label80
	l32r	a8, .LCPI49_11
	callx8	a8
	l32r	a8, .LCPI49_12
	callx8	a8
	l32r	a8, .LCPI49_13
	callx8	a8
	retw.n
.LBB49_6:                               # %source.label35
	l32r	a8, .LCPI49_6
	addi	a10, a8, 55
	l32r	a12, .LCPI49_7
	l32r	a13, .LCPI49_8
	l32r	a8, .LCPI49_15
	movi	a11, 126
	callx8	a8
.LBB49_7:                               # %source.label38
	l32r	a8, .LCPI49_6
	addi	a10, a8, 55
	l32r	a12, .LCPI49_7
	l32r	a13, .LCPI49_8
	l32r	a8, .LCPI49_9
	movi	a11, 134
	callx8	a8
.LBB49_8:                               # %source.label60
	l32r	a8, .LCPI49_6
	addi	a10, a8, 55
	l32r	a12, .LCPI49_7
	l32r	a13, .LCPI49_8
	l32r	a8, .LCPI49_14
	movi	a11, 144
	callx8	a8
.Lfunc_end49:
	.size	abla_fn_321888515_252845378_direct, .Lfunc_end49-abla_fn_321888515_252845378_direct
                                        # -- End function
	.literal_position
	.literal .LCPI50_0, 1072955512
	.literal .LCPI50_1, 1072693312
	.literal .LCPI50_2, abla_global_462423855_903385096
	.literal .LCPI50_3, 1072693316
	.literal .LCPI50_4, 1072693336
	.literal .LCPI50_5, abla_global_186399490_945206650
	.literal .LCPI50_6, 1072693340
	.section	.iram1.abla.esp32RecoveredSpiFlashDisableInterruptsCachesAndOtherCpu,"ax",@progbits
	.section	.iram1.abla.esp32RecoveredSpiFlashRestoreCache,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_207252462_325679729_direct
	.type	abla_fn_207252462_325679729_direct,@function
abla_fn_207252462_325679729_direct:     # @abla_fn_207252462_325679729_direct
# %bb.0:                                # %entry
	entry	a1, 32
	#APP
	rsil	a9, 5
	#NO_APP
	l32r	a8, .LCPI50_0
	memw
	l32i	a10, a8, 0
	l32r	a10, .LCPI50_1
	memw
	l32i	a11, a10, 0
	#APP
	wsr	a9, ps
	rsync

	#NO_APP
	movi	a9, 8
	or	a11, a11, a9
	memw
	s32i	a11, a10, 0
	memw
	l32r	a10, .LCPI50_2
	l32i	a11, a10, 0
	#APP
	rsil	a10, 5
	#NO_APP
	memw
	l32i	a12, a8, 0
	l32r	a12, .LCPI50_3
	memw
	l32i	a13, a12, 0
	#APP
	wsr	a10, ps
	rsync

	#NO_APP
	srli	a10, a11, 1
	and	a14, a10, a9
	slli	a15, a11, 1
	movi	a10, 16
	and	a15, a15, a10
	extui	a11, a11, 0, 3
	or	a11, a15, a11
	or	a14, a11, a14
	movi	a11, -1
	xor	a14, a14, a11
	and	a13, a13, a14
	memw
	s32i	a13, a12, 0
	memw
	#APP
	rsil	a12, 5
	#NO_APP
	memw
	l32i	a13, a8, 0
	l32r	a13, .LCPI50_4
	memw
	l32i	a14, a13, 0
	#APP
	wsr	a12, ps
	rsync

	#NO_APP
	or	a12, a14, a9
	memw
	s32i	a12, a13, 0
	memw
	l32r	a12, .LCPI50_5
	l32i	a12, a12, 0
	#APP
	rsil	a13, 5
	#NO_APP
	memw
	l32i	a8, a8, 0
	l32r	a8, .LCPI50_6
	memw
	l32i	a14, a8, 0
	#APP
	wsr	a13, ps
	rsync

	#NO_APP
	srli	a13, a12, 1
	and	a9, a13, a9
	slli	a13, a12, 1
	and	a10, a13, a10
	extui	a12, a12, 0, 3
	or	a10, a10, a12
	or	a9, a10, a9
	xor	a9, a9, a11
	and	a9, a14, a9
	memw
	s32i	a9, a8, 0
	memw
	retw.n
.Lfunc_end50:
	.size	abla_fn_207252462_325679729_direct, .Lfunc_end50-abla_fn_207252462_325679729_direct
                                        # -- End function
	.literal_position
	.literal .LCPI51_0, abla_string_abla_fn_627837887_633683867_173.native.mutable.u32s.0
	.literal .LCPI51_1, .Labla_string_abla_fn_627837887_633683867_158.native.bytes
	.literal .LCPI51_2, .Labla_string_abla_fn_627837887_633683867_151.native.bytes
	.literal .LCPI51_3, .Labla_string_abla_fn_627837887_633683867_165.native.bytes
	.literal .LCPI51_4, abla_fn_343754787_547301002_direct
	.literal .LCPI51_5, abla_fn_923148460_536466818_direct
	.literal .LCPI51_6, abla_fn_343754787_547301002_direct
	.literal .LCPI51_7, abla_fn_207252462_325679729_direct
	.literal .LCPI51_8, abla_fn_207252462_325679729_direct
	.literal .LCPI51_9, abla_fn_923148460_536466818_direct
	.literal .LCPI51_10, abla_fn_262508538_723171161_direct
	.literal .LCPI51_11, abla_fn_923148460_536466818_direct
	.literal .LCPI51_12, abla_static_abla_fn_627837887_633683867_118.0
	.literal .LCPI51_13, abla_static_abla_fn_627837887_633683867_124
	.literal .LCPI51_14, abla_fn_460839413_627444129_direct
	.section	.iram1.abla.esp32RecoveredSpiFlashRestoreCache,"ax",@progbits
	.section	.iram1.abla.esp32RecoveredSpiFlashEnableInterruptsCachesAndOtherCpu,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_795904359_267395915_direct
	.type	abla_fn_795904359_267395915_direct,@function
abla_fn_795904359_267395915_direct:     # @abla_fn_795904359_267395915_direct
# %bb.0:                                # %entry
	entry	a1, 32
	#APP
	rsr	a8, prid
	#NO_APP
	memw
	extui	a6, a8, 13, 1
	l32r	a7, .LCPI51_0
	l32i	a8, a7, 0
	bne	a8, a6, .LBB51_6
# %bb.1:                                # %source.label21
	l32r	a8, .LCPI51_5
	callx8	a8
	beqz.n	a6, .LBB51_3
# %bb.2:                                # %source.label21
	movi	a8, 0
	beqz	a8, .LBB51_7
.LBB51_3:                               # %source.label27
	memw
	movi	a8, -1
	s32i	a8, a7, 0
	l32r	a8, .LCPI51_7
	callx8	a8
	l32r	a8, .LCPI51_8
	callx8	a8
	l32r	a8, .LCPI51_9
	callx8	a8
	l32r	a8, .LCPI51_10
	callx8	a8
	l32r	a8, .LCPI51_11
	callx8	a8
	l32r	a8, .LCPI51_12
	l8ui	a8, a8, 0
	movi	a10, 0
	beq	a8, a10, .LBB51_5
# %bb.4:
	l32r	a10, .LCPI51_13
.LBB51_5:                               # %source.label33
	l32r	a8, .LCPI51_14
	callx8	a8
	retw.n
.LBB51_6:                               # %source.label
	l32r	a8, .LCPI51_1
	addi	a10, a8, 55
	l32r	a12, .LCPI51_2
	l32r	a13, .LCPI51_3
	l32r	a8, .LCPI51_4
	movi	a11, 200
	callx8	a8
.LBB51_7:                               # %source.label23
	l32r	a8, .LCPI51_1
	addi	a10, a8, 55
	l32r	a12, .LCPI51_2
	l32r	a13, .LCPI51_3
	l32r	a8, .LCPI51_6
	movi	a11, 202
	callx8	a8
.Lfunc_end51:
	.size	abla_fn_795904359_267395915_direct, .Lfunc_end51-abla_fn_795904359_267395915_direct
                                        # -- End function
	.literal_position
	.literal .LCPI52_0, 1072955512
	.literal .LCPI52_1, 1072693312
	.literal .LCPI52_2, 1072693336
	.section	.iram1.abla.esp32RecoveredSpiFlashEnableInterruptsCachesAndOtherCpu,"ax",@progbits
	.section	.iram1.14.abla.esp32RecoveredSpiFlashCacheEnabled,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_567470497_190987667_direct
	.type	abla_fn_567470497_190987667_direct,@function
abla_fn_567470497_190987667_direct:     # @abla_fn_567470497_190987667_direct
# %bb.0:                                # %entry
	entry	a1, 32
	#APP
	rsil	a8, 5
	#NO_APP
	l32r	a9, .LCPI52_0
	memw
	l32i	a9, a9, 0
	l32r	a9, .LCPI52_1
	memw
	l32i	a9, a9, 0
	#APP
	wsr	a8, ps
	rsync

	#NO_APP
	movi	a2, 0
	bbci	a9, 3, .LBB52_2
# %bb.1:                                # %source.label3.i
	#APP
	rsil	a8, 5
	#NO_APP
	l32r	a9, .LCPI52_0
	memw
	l32i	a9, a9, 0
	l32r	a9, .LCPI52_2
	memw
	l32i	a9, a9, 0
	#APP
	wsr	a8, ps
	rsync

	#NO_APP
	extui	a2, a9, 3, 1
.LBB52_2:                               # %abla_fn_794383199_760267166_direct.exit
	retw.n
.Lfunc_end52:
	.size	abla_fn_567470497_190987667_direct, .Lfunc_end52-abla_fn_567470497_190987667_direct
                                        # -- End function
	.literal_position
	.literal .LCPI53_0, abla_static_abla_fn_627837887_633683867_241.0
	.literal .LCPI53_1, abla_static_abla_fn_627837887_633683867_247.0
	.literal .LCPI53_2, abla_static_abla_fn_627837887_633683867_235
	.section	.iram1.14.abla.esp32RecoveredSpiFlashCacheEnabled,"ax",@progbits
	.section	.text.abla_fn_406806377_219124179_direct,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_406806377_219124179_direct
	.type	abla_fn_406806377_219124179_direct,@function
abla_fn_406806377_219124179_direct:     # @abla_fn_406806377_219124179_direct
# %bb.0:                                # %entry
	entry	a1, 32
	movi	a11, 0
	l32r	a8, .LCPI53_0
	l32r	a9, .LCPI53_2
	movi	a10, 0
.LBB53_1:                               # %source.label.outer
                                        # =>This Loop Header: Depth=1
                                        #     Child Loop BB53_2 Depth 2
	l32i	a12, a8, 0
	movi	a13, 1
.LBB53_2:                               # %source.label
                                        #   Parent Loop BB53_1 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	bbci	a13, 0, .LBB53_5
# %bb.3:                                # %source.label19
                                        #   in Loop: Header=BB53_2 Depth=2
	movi	a13, 0
	or	a11, a12, a12
	bgeu	a10, a12, .LBB53_2
# %bb.4:                                # %source.label20
                                        #   in Loop: Header=BB53_1 Depth=1
	addx8	a12, a10, a9
	l32i	a11, a12, 4
	extui	a11, a11, 0, 3
	slli	a13, a10, 3
	or	a11, a11, a13
	s32i	a11, a12, 4
	addi	a10, a10, 1
	j	.LBB53_1
.LBB53_5:                               # %source.label23
	l32r	a8, .LCPI53_1
	s32i	a11, a8, 0
	retw.n
.Lfunc_end53:
	.size	abla_fn_406806377_219124179_direct, .Lfunc_end53-abla_fn_406806377_219124179_direct
                                        # -- End function
	.literal_position
	.literal .LCPI54_0, abla_static_abla_fn_627837887_633683867_235
	.section	.text.abla_fn_406806377_219124179_direct,"ax",@progbits
	.section	.text.abla_fn_30454968_345956014_direct,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_30454968_345956014_direct
	.type	abla_fn_30454968_345956014_direct,@function
abla_fn_30454968_345956014_direct:      # @abla_fn_30454968_345956014_direct
# %bb.0:                                # %entry
	entry	a1, 80
	movi	a8, 4
	addi	a9, a1, 0
	or	a8, a9, a8
	movi	a9, 14
	movi	a10, 1
	l32r	a11, .LCPI54_0
	addi	a12, a11, 4
.LBB54_1:                               # %source.label.outer
                                        # =>This Loop Header: Depth=1
                                        #     Child Loop BB54_2 Depth 2
	movi	a13, 1
.LBB54_2:                               # %source.label
                                        #   Parent Loop BB54_1 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	bbci	a13, 0, .LBB54_7
# %bb.3:                                # %source.label17
                                        #   in Loop: Header=BB54_2 Depth=2
	movi	a13, 0
	blt	a9, a2, .LBB54_2
# %bb.4:                                # %source.label18
                                        #   in Loop: Header=BB54_1 Depth=1
	slli	a13, a2, 1
	or	a13, a13, a10
	addx8	a14, a13, a12
	l32i	a4, a14, 0
	addi	a5, a2, 1
	slli	a14, a5, 4
	add	a14, a14, a12
	l32i	a3, a14, 0
	addx8	a15, a2, a12
	l32i	a14, a15, 0
	addx8	a6, a2, a11
	l32i	a7, a6, 0
	s32i	a7, a1, 0
	s32i	a14, a8, 0
	srli	a3, a3, 3
	srli	a4, a4, 3
	bltu	a4, a3, .LBB54_6
# %bb.5:                                # %source.label18
                                        #   in Loop: Header=BB54_1 Depth=1
	slli	a13, a5, 1
.LBB54_6:                               # %source.label18
                                        #   in Loop: Header=BB54_1 Depth=1
	addx8	a5, a13, a11
	l32i	a4, a5, 0
	addx8	a3, a13, a12
	l32i	a2, a3, 0
	s32i	a2, a15, 0
	s32i	a4, a6, 0
	s32i	a14, a3, 0
	s32i	a7, a5, 0
	or	a2, a13, a13
	j	.LBB54_1
.LBB54_7:                               # %source.label24
	retw.n
.Lfunc_end54:
	.size	abla_fn_30454968_345956014_direct, .Lfunc_end54-abla_fn_30454968_345956014_direct
                                        # -- End function
	.section	.iram1.abla.freertos.yield,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_970437484_907475612_direct
	.type	abla_fn_970437484_907475612_direct,@function
abla_fn_970437484_907475612_direct:     # @abla_fn_970437484_907475612_direct
# %bb.0:                                # %entry
	#APP
	entry	a1, 32
	rsr	a2, ps
	.short	4361
	.short	8489
	rur	a2, threadptr
	.short	12585
	.literal .Ltmp0, -262160
	l32r	a6, .Ltmp0
	and	a2, a2, a6
	.short	8763
	wsr	a2, ps
	rsync

	.literal .Ltmp1, xthal_window_spill_nw
	l32r	a0, .Ltmp1
	callx0	a0
	l32i.n	a2, a1, 8
	wsr	a2, ps
	rsil	a2, 3
	.literal .Ltmp2, _xt_coproc_savecs
	l32r	a0, .Ltmp2
	callx0	a0
	.literal .Ltmp3, pxCurrentTCBs
	l32r	a2, .Ltmp3
	rsr	a3, prid
	extui	a3, a3, 13, 1
	addx4	a2, a3, a2
	l32i.n	a2, a2, 0
	movi.n	a4, 0
	s32i.n	a4, a1, 0
	s32i.n	a1, a2, 0
	movi	a3, 72
	add.n	a2, a2, a3
	l32i.n	a2, a2, 0
	movi	a3, 96
	sub	a2, a2, a3
	movi	a3, -16
	and	a2, a2, a3
	wsr	a4, cpenable
	beqz.n	a2, .Labla_xtensa_context_yield_dispatch_0
	s16i	a4, a2, 0
.Labla_xtensa_context_yield_dispatch_0:
	call0	_frxt_dispatch
	#NO_APP
.Lfunc_end55:
	.size	abla_fn_970437484_907475612_direct, .Lfunc_end55-abla_fn_970437484_907475612_direct
                                        # -- End function
	.section	.iram1.abla.freertos.coproc_exc_hook,"axR",@progbits,unique,1
	.p2align	2                               # -- Begin function abla_fn_813260330_283597400_direct
	.type	abla_fn_813260330_283597400_direct,@function
abla_fn_813260330_283597400_direct:     # @abla_fn_813260330_283597400_direct
# %bb.0:                                # %entry
	#APP
	rsr	a2, prid
	extui	a2, a2, 13, 1
	.literal .Ltmp4, port_xSchedulerRunning
	l32r	a3, .Ltmp4
	addx4	a3, a2, a3
	l32i	a3, a3, 0
	beqz	a3, .Ltmp5
	.literal .Ltmp6, port_interruptNesting
	l32r	a3, .Ltmp6
	addx4	a3, a2, a3
	l32i	a3, a3, 0
	bnez	a3, .Ltmp5
	.literal .Ltmp7, pxCurrentTCBs
	l32r	a3, .Ltmp7
	addx4	a3, a2, a3
	l32i	a3, a3, 0
	s32i	a2, a3, 68
.Ltmp5:
	ret

	#NO_APP
.Lfunc_end56:
	.size	abla_fn_813260330_283597400_direct, .Lfunc_end56-abla_fn_813260330_283597400_direct
                                        # -- End function
	.literal_position
	.literal .LCPI57_0, abla_fn_923148460_536466818_direct
	.section	.iram1.abla.freertos.coproc_exc_hook,"axR",@progbits,unique,1
	.section	.text.abla_fn_673801472_872810247_direct,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_673801472_872810247_direct
	.type	abla_fn_673801472_872810247_direct,@function
abla_fn_673801472_872810247_direct:     # @abla_fn_673801472_872810247_direct
# %bb.0:                                # %entry
	entry	a1, 32
	l32r	a8, .LCPI57_0
	callx8	a8
	retw.n
.Lfunc_end57:
	.size	abla_fn_673801472_872810247_direct, .Lfunc_end57-abla_fn_673801472_872810247_direct
                                        # -- End function
	.literal_position
	.literal .LCPI58_0, abla_fn_923148460_536466818_direct
	.section	.text.abla_fn_673801472_872810247_direct,"ax",@progbits
	.section	.text.abla_fn_462535929_882602012_direct,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_462535929_882602012_direct
	.type	abla_fn_462535929_882602012_direct,@function
abla_fn_462535929_882602012_direct:     # @abla_fn_462535929_882602012_direct
# %bb.0:                                # %entry
	entry	a1, 32
	beqz.n	a2, .LBB58_4
# %bb.1:                                # %source.label3
	l32i	a8, a2, 0
	beqz.n	a8, .LBB58_3
# %bb.2:                                # %source.label9
	call8	abla_fn_673801472_872810247_direct
	retw.n
.LBB58_3:                               # %source.label4
	l32r	a8, .LCPI58_0
	callx8	a8
	retw.n
.LBB58_4:                               # %source.label
	ill.n
.Lfunc_end58:
	.size	abla_fn_462535929_882602012_direct, .Lfunc_end58-abla_fn_462535929_882602012_direct
                                        # -- End function
	.literal_position
	.literal .LCPI59_0, abla_fn_923148460_536466818_direct
	.section	.text.abla_fn_462535929_882602012_direct,"ax",@progbits
	.section	.text.abla_fn_348785380_841043292_direct,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_348785380_841043292_direct
	.type	abla_fn_348785380_841043292_direct,@function
abla_fn_348785380_841043292_direct:     # @abla_fn_348785380_841043292_direct
# %bb.0:                                # %entry
	entry	a1, 32
	l32r	a8, .LCPI59_0
	callx8	a8
	retw.n
.Lfunc_end59:
	.size	abla_fn_348785380_841043292_direct, .Lfunc_end59-abla_fn_348785380_841043292_direct
                                        # -- End function
	.section	.text.abla_fn_412776580_912333539_direct,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_412776580_912333539_direct
	.type	abla_fn_412776580_912333539_direct,@function
abla_fn_412776580_912333539_direct:     # @abla_fn_412776580_912333539_direct
# %bb.0:                                # %entry
	entry	a1, 32
	beqz.n	a2, .LBB60_2
# %bb.1:                                # %source.label3
	call8	abla_fn_348785380_841043292_direct
	retw.n
.LBB60_2:                               # %source.label
	ill.n
.Lfunc_end60:
	.size	abla_fn_412776580_912333539_direct, .Lfunc_end60-abla_fn_412776580_912333539_direct
                                        # -- End function
	.section	.text.abla_fn_396055959_456822569_direct,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_396055959_456822569_direct
	.type	abla_fn_396055959_456822569_direct,@function
abla_fn_396055959_456822569_direct:     # @abla_fn_396055959_456822569_direct
# %bb.0:                                # %entry
	entry	a1, 32
	or	a10, a2, a2
	call8	abla_fn_462535929_882602012_direct
	retw.n
.Lfunc_end61:
	.size	abla_fn_396055959_456822569_direct, .Lfunc_end61-abla_fn_396055959_456822569_direct
                                        # -- End function
	.section	.text.abla_fn_954702414_417902696_direct,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_954702414_417902696_direct
	.type	abla_fn_954702414_417902696_direct,@function
abla_fn_954702414_417902696_direct:     # @abla_fn_954702414_417902696_direct
# %bb.0:                                # %entry
	entry	a1, 32
	or	a10, a2, a2
	call8	abla_fn_412776580_912333539_direct
	retw.n
.Lfunc_end62:
	.size	abla_fn_954702414_417902696_direct, .Lfunc_end62-abla_fn_954702414_417902696_direct
                                        # -- End function
	.literal_position
	.literal .LCPI63_0, abla_static_abla_fn_627837887_633683867_324
	.literal .LCPI63_1, esp_app_desc
	.section	.text.abla_fn_954702414_417902696_direct,"ax",@progbits
	.section	.text.abla_fn_10241045_782498044_direct,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_10241045_782498044_direct
	.type	abla_fn_10241045_782498044_direct,@function
abla_fn_10241045_782498044_direct:      # @abla_fn_10241045_782498044_direct
# %bb.0:                                # %entry
	entry	a1, 32
	l32r	a8, .LCPI63_0
	l8ui	a9, a8, 0
	beqz.n	a9, .LBB63_2
# %bb.1:                                # %common.ret
	retw.n
.LBB63_2:                               # %source.label7.preheader
	movi	a9, 0
	l32r	a10, .LCPI63_1
	movi	a11, 48
	movi	a12, 10
	movi	a13, 160
	beqi	a9, 5, .LBB63_10
.LBB63_3:                               # %source.label8
                                        # =>This Inner Loop Header: Depth=1
	add	a14, a10, a9
	l8ui	a14, a14, 144
	extui	a15, a14, 0, 4
	bltu	a15, a12, .LBB63_5
# %bb.4:                                # %source.label8
                                        #   in Loop: Header=BB63_3 Depth=1
	addi	a15, a15, 87
	j	.LBB63_6
.LBB63_5:                               #   in Loop: Header=BB63_3 Depth=1
	or	a15, a15, a11
.LBB63_6:                               # %source.label8
                                        #   in Loop: Header=BB63_3 Depth=1
	s8i	a15, a8, 1
	srli	a15, a14, 4
	bltu	a14, a13, .LBB63_8
# %bb.7:                                # %source.label8
                                        #   in Loop: Header=BB63_3 Depth=1
	addi	a14, a15, 87
	j	.LBB63_9
.LBB63_8:                               #   in Loop: Header=BB63_3 Depth=1
	or	a14, a15, a11
.LBB63_9:                               # %source.label8
                                        #   in Loop: Header=BB63_3 Depth=1
	s8i	a14, a8, 0
	addi	a8, a8, 2
	addi	a9, a9, 1
	bnei	a9, 5, .LBB63_3
.LBB63_10:                              # %source.label20
	l32r	a8, .LCPI63_0
	movi	a9, 0
	s8i	a9, a8, 9
	retw.n
.Lfunc_end63:
	.size	abla_fn_10241045_782498044_direct, .Lfunc_end63-abla_fn_10241045_782498044_direct
                                        # -- End function
	.literal_position
	.literal .LCPI64_0, .Labla_string_abla_fn_627837887_633683867_329.native.bytes
	.literal .LCPI64_1, .Labla_string_abla_fn_627837887_633683867_332.native.bytes
	.literal .LCPI64_2, esp_app_desc
	.literal .LCPI64_3, abla_fn_96223132_121353370_direct
	.literal .LCPI64_4, .Labla_string_abla_fn_627837887_633683867_335.native.bytes
	.literal .LCPI64_5, abla_fn_96223132_121353370_direct
	.literal .LCPI64_6, .Labla_string_abla_fn_627837887_633683867_338.native.bytes
	.literal .LCPI64_7, abla_fn_96223132_121353370_direct
	.literal .LCPI64_8, abla_fn_96223132_121353370_direct
	.literal .LCPI64_9, abla_static_abla_fn_627837887_633683867_324
	.literal .LCPI64_10, .Labla_string_abla_fn_627837887_633683867_341.native.bytes
	.literal .LCPI64_11, .Labla_string_abla_fn_627837887_633683867_347.native.bytes
	.literal .LCPI64_12, .Labla_string_abla_fn_627837887_633683867_344.native.bytes
	.literal .LCPI64_13, abla_fn_96223132_121353370_direct
	.section	.text.abla_fn_10241045_782498044_direct,"ax",@progbits
	.section	.text.abla_fn_350989413_350671624_direct,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_350989413_350671624_direct
	.type	abla_fn_350989413_350671624_direct,@function
abla_fn_350989413_350671624_direct:     # @abla_fn_350989413_350671624_direct
# %bb.0:                                # %entry
	entry	a1, 64
	call8	abla_fn_10241045_782498044_direct
	l32r	a10, .LCPI64_0
	call8	abla_fn_156983400_573095120_direct
	l32r	a10, .LCPI64_1
	call8	abla_fn_156983400_573095120_direct
	l32r	a6, .LCPI64_2
	addi	a10, a6, 48
	call8	abla_fn_156983400_573095120_direct
	l32r	a8, .LCPI64_3
	movi	a10, 10
	callx8	a8
	l32r	a10, .LCPI64_4
	call8	abla_fn_156983400_573095120_direct
	addi	a10, a6, 16
	call8	abla_fn_156983400_573095120_direct
	l32r	a8, .LCPI64_5
	movi	a10, 10
	callx8	a8
	l32r	a10, .LCPI64_6
	call8	abla_fn_156983400_573095120_direct
	addi	a10, a6, 96
	call8	abla_fn_156983400_573095120_direct
	l32r	a8, .LCPI64_7
	movi	a10, 32
	callx8	a8
	addi	a10, a6, 80
	call8	abla_fn_156983400_573095120_direct
	l32r	a8, .LCPI64_8
	movi	a10, 10
	callx8	a8
	call8	abla_fn_10241045_782498044_direct
	addi	a7, a1, 0
	l32r	a11, .LCPI64_9
	or	a10, a7, a7
	movi	a12, 10
	call8	abla_fn_334943840_569200394_direct
	movi	a8, 0
	s8i	a8, a1, 9
	l32r	a10, .LCPI64_10
	call8	abla_fn_156983400_573095120_direct
	or	a10, a7, a7
	call8	abla_fn_156983400_573095120_direct
	l32r	a10, .LCPI64_11
	call8	abla_fn_156983400_573095120_direct
	l32r	a10, .LCPI64_12
	call8	abla_fn_156983400_573095120_direct
	addi	a10, a6, 112
	call8	abla_fn_156983400_573095120_direct
	l32r	a8, .LCPI64_13
	movi	a10, 10
	callx8	a8
	movi	a2, 0
	retw.n
.Lfunc_end64:
	.size	abla_fn_350989413_350671624_direct, .Lfunc_end64-abla_fn_350989413_350671624_direct
                                        # -- End function
	.section	.text.abla_fn_86848695_245733703_direct,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_86848695_245733703_direct
	.type	abla_fn_86848695_245733703_direct,@function
abla_fn_86848695_245733703_direct:      # @abla_fn_86848695_245733703_direct
# %bb.0:                                # %entry
	entry	a1, 32
	or	a8, a2, a2
	movi	a2, -1
.LBB65_1:                               # %source.label3
                                        # =>This Inner Loop Header: Depth=1
	add	a9, a8, a2
	l8ui	a9, a9, 1
	addi	a2, a2, 1
	bnez	a9, .LBB65_1
# %bb.2:                                # %common.ret
	retw.n
.Lfunc_end65:
	.size	abla_fn_86848695_245733703_direct, .Lfunc_end65-abla_fn_86848695_245733703_direct
                                        # -- End function
	.literal_position
	.literal .LCPI66_0, abla_static_abla_fn_627837887_633683867_431
	.section	.text.abla_fn_86848695_245733703_direct,"ax",@progbits
	.section	.text.abla_fn_816159239_883263028_direct,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_816159239_883263028_direct
	.type	abla_fn_816159239_883263028_direct,@function
abla_fn_816159239_883263028_direct:     # @abla_fn_816159239_883263028_direct
# %bb.0:                                # %entry
	entry	a1, 32
	l32r	a10, .LCPI66_0
	call8	abla_fn_462535929_882602012_direct
	retw.n
.Lfunc_end66:
	.size	abla_fn_816159239_883263028_direct, .Lfunc_end66-abla_fn_816159239_883263028_direct
                                        # -- End function
	.literal_position
	.literal .LCPI67_0, abla_static_abla_fn_627837887_633683867_431
	.section	.text.abla_fn_816159239_883263028_direct,"ax",@progbits
	.section	.text.abla_fn_579039599_215173597_direct,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_579039599_215173597_direct
	.type	abla_fn_579039599_215173597_direct,@function
abla_fn_579039599_215173597_direct:     # @abla_fn_579039599_215173597_direct
# %bb.0:                                # %entry
	entry	a1, 32
	l32r	a10, .LCPI67_0
	call8	abla_fn_412776580_912333539_direct
	retw.n
.Lfunc_end67:
	.size	abla_fn_579039599_215173597_direct, .Lfunc_end67-abla_fn_579039599_215173597_direct
                                        # -- End function
	.literal_position
	.literal .LCPI68_0, abla_static_abla_fn_627837887_633683867_425.0
	.literal .LCPI68_1, abla_static_abla_fn_627837887_633683867_419
	.section	.text.abla_fn_579039599_215173597_direct,"ax",@progbits
	.section	.text.abla_fn_391416991_223417075_direct,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_391416991_223417075_direct
	.type	abla_fn_391416991_223417075_direct,@function
abla_fn_391416991_223417075_direct:     # @abla_fn_391416991_223417075_direct
# %bb.0:                                # %entry
	entry	a1, 32
	or	a8, a2, a2
	movi	a2, 0
	bltz	a8, .LBB68_3
# %bb.1:                                # %entry
	l32r	a9, .LCPI68_0
	l32i	a9, a9, 0
	bgeu	a8, a9, .LBB68_3
# %bb.2:                                # %source.label5
	l32r	a9, .LCPI68_1
	addx4	a8, a8, a9
	l32i	a2, a8, 0
.LBB68_3:                               # %common.ret
	retw.n
.Lfunc_end68:
	.size	abla_fn_391416991_223417075_direct, .Lfunc_end68-abla_fn_391416991_223417075_direct
                                        # -- End function
	.literal_position
	.literal .LCPI69_0, .Labla_string_abla_fn_627837887_633683867_484.native.mutable.u32s
	.section	.text.abla_fn_391416991_223417075_direct,"ax",@progbits
	.section	.text.abla_fn_478584785_547940653_direct,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_478584785_547940653_direct
	.type	abla_fn_478584785_547940653_direct,@function
abla_fn_478584785_547940653_direct:     # @abla_fn_478584785_547940653_direct
# %bb.0:                                # %entry
	entry	a1, 32
	or	a8, a2, a2
	movi	a2, 0
	bgeui	a8, 64, .LBB69_4
# %bb.1:                                # %source.label5
	movi	a9, 3
	mull	a8, a8, a9
	l32r	a9, .LCPI69_0
	add	a8, a9, a8
	l8ui	a10, a8, 1
	sext	a8, a10, 7
	movi	a9, 0
	bge	a8, a9, .LBB69_3
# %bb.2:
	movi	a8, -256
	or	a10, a10, a8
.LBB69_3:                               # %source.label5
	call8	abla_fn_391416991_223417075_direct
	or	a2, a10, a10
.LBB69_4:                               # %common.ret
	retw.n
.Lfunc_end69:
	.size	abla_fn_478584785_547940653_direct, .Lfunc_end69-abla_fn_478584785_547940653_direct
                                        # -- End function
	.literal_position
	.literal .LCPI70_0, .Labla_string_abla_fn_627837887_633683867_2776.native.mutable.bytes
	.literal .LCPI70_1, .Labla_string_abla_fn_627837887_633683867_489.native.bytes
	.section	.text.abla_fn_478584785_547940653_direct,"ax",@progbits
	.section	.text.abla_fn_296193149_144011569_direct,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_296193149_144011569_direct
	.type	abla_fn_296193149_144011569_direct,@function
abla_fn_296193149_144011569_direct:     # @abla_fn_296193149_144011569_direct
# %bb.0:                                # %entry
	entry	a1, 32
	l32r	a8, .LCPI70_0
	beqz.n	a8, .LBB70_3
# %bb.1:                                # %source.label5
	l32i	a6, a2, 16
	l32r	a7, .LCPI70_0
	or	a10, a7, a7
	call8	abla_fn_86848695_245733703_direct
	bne	a10, a6, .LBB70_4
# %bb.2:
	l32r	a2, .LCPI70_1
	retw.n
.LBB70_3:
	movi	a2, 0
	retw.n
.LBB70_4:                               # %source.label9
	add	a2, a6, a7
	retw.n
.Lfunc_end70:
	.size	abla_fn_296193149_144011569_direct, .Lfunc_end70-abla_fn_296193149_144011569_direct
                                        # -- End function
	.literal_position
	.literal .LCPI71_0, .Labla_string_abla_fn_627837887_633683867_2776.native.mutable.bytes
	.literal .LCPI71_1, abla_static_abla_fn_627837887_633683867_425.0
	.literal .LCPI71_2, abla_static_abla_fn_627837887_633683867_419
	.section	.text.abla_fn_296193149_144011569_direct,"ax",@progbits
	.section	.text.abla_fn_758233383_766816536_direct,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_758233383_766816536_direct
	.type	abla_fn_758233383_766816536_direct,@function
abla_fn_758233383_766816536_direct:     # @abla_fn_758233383_766816536_direct
# %bb.0:                                # %entry
	entry	a1, 32
	l32r	a7, .LCPI71_0
	beqz	a7, .LBB71_25
# %bb.1:                                # %source.label2
	or	a10, a7, a7
	call8	abla_fn_86848695_245733703_direct
	l32r	a8, .LCPI71_1
	l32i	a8, a8, 0
	movi	a9, -1
	movi	a2, 0
	l32r	a11, .LCPI71_2
	movi	a12, 47
	movi	a13, 0
	movi	a14, -1
	beq	a13, a8, .LBB71_24
.LBB71_2:                               # %source.label7
                                        # =>This Loop Header: Depth=1
                                        #     Child Loop BB71_6 Depth 2
	addx4	a15, a13, a11
	l32i	a15, a15, 0
	beqz	a15, .LBB71_23
# %bb.3:                                # %source.label9
                                        #   in Loop: Header=BB71_2 Depth=1
	l32i	a6, a15, 16
	beqi	a6, -1, .LBB71_23
# %bb.4:                                # %source.label9
                                        #   in Loop: Header=BB71_2 Depth=1
	bltu	a10, a6, .LBB71_23
# %bb.5:                                # %source.label13
                                        #   in Loop: Header=BB71_2 Depth=1
	movi	a5, 0
.LBB71_6:                               # %source.label.i
                                        #   Parent Loop BB71_2 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	beq	a6, a5, .LBB71_9
# %bb.7:                                # %source.label1.i
                                        #   in Loop: Header=BB71_6 Depth=2
	add	a4, a15, a5
	l8ui	a4, a4, 20
	add	a3, a5, a7
	l8ui	a3, a3, 0
	addi	a5, a5, 1
	beq	a3, a4, .LBB71_6
# %bb.8:                                # %abla_fn_296351335_320719062_direct.exit
                                        #   in Loop: Header=BB71_2 Depth=1
	addi	a5, a5, -1
	bltu	a5, a6, .LBB71_23
.LBB71_9:                               # %source.label16
                                        #   in Loop: Header=BB71_2 Depth=1
	or	a5, a6, a2
	bnez.n	a5, .LBB71_11
# %bb.10:                               #   in Loop: Header=BB71_2 Depth=1
	movi	a14, 0
	j	.LBB71_22
.LBB71_11:                              # %source.label22
                                        #   in Loop: Header=BB71_2 Depth=1
	beq	a10, a6, .LBB71_13
# %bb.12:                               # %source.label25
                                        #   in Loop: Header=BB71_2 Depth=1
	add	a5, a6, a7
	l8ui	a5, a5, 0
	bne	a5, a12, .LBB71_23
.LBB71_13:                              # %source.label34
                                        #   in Loop: Header=BB71_2 Depth=1
	movi	a5, 0
	movi	a4, 1
	movi	a3, 1
	bltu	a14, a6, .LBB71_15
# %bb.14:                               # %source.label34
                                        #   in Loop: Header=BB71_2 Depth=1
	movi	a3, 0
.LBB71_15:                              # %source.label34
                                        #   in Loop: Header=BB71_2 Depth=1
	beq	a14, a9, .LBB71_17
# %bb.16:                               # %source.label34
                                        #   in Loop: Header=BB71_2 Depth=1
	movi	a4, 0
.LBB71_17:                              # %source.label34
                                        #   in Loop: Header=BB71_2 Depth=1
	or	a4, a4, a3
	bne	a4, a5, .LBB71_19
# %bb.18:                               # %source.label34
                                        #   in Loop: Header=BB71_2 Depth=1
	or	a15, a2, a2
.LBB71_19:                              # %source.label34
                                        #   in Loop: Header=BB71_2 Depth=1
	bne	a4, a5, .LBB71_21
# %bb.20:                               # %source.label34
                                        #   in Loop: Header=BB71_2 Depth=1
	or	a6, a14, a14
.LBB71_21:                              # %source.label34
                                        #   in Loop: Header=BB71_2 Depth=1
	or	a14, a6, a6
.LBB71_22:                              # %source.label42
                                        #   in Loop: Header=BB71_2 Depth=1
	or	a2, a15, a15
.LBB71_23:                              # %source.label42
                                        #   in Loop: Header=BB71_2 Depth=1
	addi	a13, a13, 1
	bne	a13, a8, .LBB71_2
.LBB71_24:                              # %common.ret
	retw.n
.LBB71_25:
	movi	a2, 0
	retw.n
.Lfunc_end71:
	.size	abla_fn_758233383_766816536_direct, .Lfunc_end71-abla_fn_758233383_766816536_direct
                                        # -- End function
	.section	.text.abla_fn_76595254_971146377_direct,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_76595254_971146377_direct
	.type	abla_fn_76595254_971146377_direct,@function
abla_fn_76595254_971146377_direct:      # @abla_fn_76595254_971146377_direct
# %bb.0:                                # %entry
	entry	a1, 32
	beqz.n	a4, .LBB72_2
.LBB72_1:                               # %source.label2
                                        # =>This Inner Loop Header: Depth=1
	l8ui	a8, a3, 0
	s8i	a8, a2, 0
	addi	a4, a4, -1
	addi	a3, a3, 1
	addi	a2, a2, 1
	bnez	a4, .LBB72_1
.LBB72_2:                               # %source.label3
	retw.n
.Lfunc_end72:
	.size	abla_fn_76595254_971146377_direct, .Lfunc_end72-abla_fn_76595254_971146377_direct
                                        # -- End function
	.section	.text.abla_fn_210504413_369462158_direct,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_210504413_369462158_direct
	.type	abla_fn_210504413_369462158_direct,@function
abla_fn_210504413_369462158_direct:     # @abla_fn_210504413_369462158_direct
# %bb.0:                                # %entry
	entry	a1, 32
	movi	a8, 0
	beqz.n	a3, .LBB73_2
.LBB73_1:                               # %source.label2
                                        # =>This Inner Loop Header: Depth=1
	s8i	a8, a2, 0
	addi	a3, a3, -1
	addi	a2, a2, 1
	bnez	a3, .LBB73_1
.LBB73_2:                               # %source.label3
	retw.n
.Lfunc_end73:
	.size	abla_fn_210504413_369462158_direct, .Lfunc_end73-abla_fn_210504413_369462158_direct
                                        # -- End function
	.literal_position
	.literal .LCPI74_0, .Labla_string_abla_fn_627837887_633683867_686.native.u32s
	.literal .LCPI74_1, .Labla_string_abla_fn_627837887_633683867_704.native.u32s
	.section	.text.abla_fn_210504413_369462158_direct,"ax",@progbits
	.section	.text.abla_fn_606531235_302569135_direct,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_606531235_302569135_direct
	.type	abla_fn_606531235_302569135_direct,@function
abla_fn_606531235_302569135_direct:     # @abla_fn_606531235_302569135_direct
# %bb.0:                                # %entry
	entry	a1, 64
	addi	a12, a2, 24
	l32i	a13, a2, 12
	l32i	a7, a2, 8
	l32i	a11, a2, 4
	s32i	a2, a1, 16                      # 4-byte Folded Spill
	l32i	a6, a2, 0
	movi	a5, 0
	movi	a14, 1
	movi	a15, 5
	movi	a3, 31
	movi	a10, 0
	movi	a9, 0
	s32i	a13, a1, 0                      # 4-byte Folded Spill
	s32i	a7, a1, 4                       # 4-byte Folded Spill
	s32i	a11, a1, 8                      # 4-byte Folded Spill
	s32i	a6, a1, 12                      # 4-byte Folded Spill
.LBB74_1:                               # %source.label
                                        # =>This Inner Loop Header: Depth=1
	or	a2, a13, a13
	bnei	a5, 64, .LBB74_2
	j	.LBB74_14
.LBB74_2:                               # %source.label13
                                        #   in Loop: Header=BB74_1 Depth=1
	srli	a4, a5, 4
	xor	a13, a7, a2
	beqi	a4, 2, .LBB74_7
# %bb.3:                                # %source.label13
                                        #   in Loop: Header=BB74_1 Depth=1
	beqi	a4, 1, .LBB74_6
# %bb.4:                                # %source.label13
                                        #   in Loop: Header=BB74_1 Depth=1
	bnez.n	a4, .LBB74_8
# %bb.5:                                # %source.label17
                                        #   in Loop: Header=BB74_1 Depth=1
	and	a13, a11, a13
	xor	a4, a13, a2
	or	a13, a5, a5
	j	.LBB74_9
.LBB74_6:                               # %source.label19
                                        #   in Loop: Header=BB74_1 Depth=1
	xor	a13, a11, a7
	and	a13, a13, a2
	xor	a4, a13, a7
	extui	a13, a14, 0, 4
	j	.LBB74_9
.LBB74_7:                               # %source.label21
                                        #   in Loop: Header=BB74_1 Depth=1
	xor	a4, a13, a11
	extui	a13, a15, 0, 4
	j	.LBB74_9
.LBB74_8:                               # %source.label22
                                        #   in Loop: Header=BB74_1 Depth=1
	movi	a8, -1
	xor	a13, a2, a8
	or	a13, a11, a13
	xor	a4, a13, a7
	extui	a13, a9, 0, 4
.LBB74_9:                               # %source.label25
                                        #   in Loop: Header=BB74_1 Depth=1
	add	a6, a4, a6
	l32r	a4, .LCPI74_0
	add	a4, a10, a4
	l32i	a4, a4, 0
	add	a6, a6, a4
	addx4	a13, a13, a12
	l32i	a13, a13, 0
	add	a13, a6, a13
	movi	a6, 12
	and	a6, a10, a6
	movi	a4, 48
	and	a4, a5, a4
	l32r	a8, .LCPI74_1
	add	a4, a4, a8
	add	a6, a4, a6
	l32i	a4, a6, 0
	ssl	a4
	sll	a6, a13
	bgeu	a3, a4, .LBB74_11
# %bb.10:                               # %source.label25
                                        #   in Loop: Header=BB74_1 Depth=1
	movi	a6, 0
.LBB74_11:                              # %source.label25
                                        #   in Loop: Header=BB74_1 Depth=1
	movi	a8, 32
	sub	a4, a8, a4
	ssr	a4
	srl	a13, a13
	bgeu	a3, a4, .LBB74_13
# %bb.12:                               # %source.label25
                                        #   in Loop: Header=BB74_1 Depth=1
	movi	a13, 0
.LBB74_13:                              # %source.label25
                                        #   in Loop: Header=BB74_1 Depth=1
	or	a13, a6, a13
	add	a6, a13, a11
	addi	a15, a15, 3
	addi	a14, a14, 5
	addi	a10, a10, 4
	addi	a9, a9, 7
	addi	a5, a5, 1
	or	a13, a7, a7
	or	a7, a11, a11
	or	a11, a6, a6
	or	a6, a2, a2
	j	.LBB74_1
.LBB74_14:                              # %source.label31
	l32i	a8, a1, 0                       # 4-byte Folded Reload
	add	a8, a2, a8
	l32i	a9, a1, 16                      # 4-byte Folded Reload
	s32i	a8, a9, 12
	l32i	a8, a1, 4                       # 4-byte Folded Reload
	add	a8, a7, a8
	s32i	a8, a9, 8
	l32i	a8, a1, 8                       # 4-byte Folded Reload
	add	a8, a11, a8
	s32i	a8, a9, 4
	l32i	a8, a1, 12                      # 4-byte Folded Reload
	add	a8, a6, a8
	s32i	a8, a9, 0
	retw.n
.Lfunc_end74:
	.size	abla_fn_606531235_302569135_direct, .Lfunc_end74-abla_fn_606531235_302569135_direct
                                        # -- End function
	.literal_position
	.literal .LCPI75_0, .Labla_string_abla_fn_627837887_633683867_1332.native.mutable.u32s
	.literal .LCPI75_1, abla_fn_186944242_355245718_direct
	.literal .LCPI75_2, abla_static_abla_fn_627837887_633683867_1325
	.literal .LCPI75_3, abla_fn_707068177_288599970_direct
	.literal .LCPI75_4, 1072693472
	.literal .LCPI75_5, 1072693468
	.section	.text.abla_fn_606531235_302569135_direct,"ax",@progbits
	.section	.iram1.3.abla.esp32RecoveredEspCrosscoreIntSendYield,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_473142447_878684343_direct
	.type	abla_fn_473142447_878684343_direct,@function
abla_fn_473142447_878684343_direct:     # @abla_fn_473142447_878684343_direct
# %bb.0:                                # %entry
	entry	a1, 32
	l32r	a7, .LCPI75_0
	l32r	a8, .LCPI75_1
	or	a10, a7, a7
	callx8	a8
	slli	a8, a2, 2
	l32r	a9, .LCPI75_2
	or	a8, a8, a9
	memw
	l32i	a9, a8, 0
	movi	a6, 1
	or	a9, a9, a6
	s32i	a9, a8, 0
	l32r	a8, .LCPI75_3
	or	a10, a7, a7
	callx8	a8
	movi	a8, 0
	beq	a2, a8, .LBB75_2
# %bb.1:                                # %entry
	l32r	a8, .LCPI75_4
	j	.LBB75_3
.LBB75_2:
	l32r	a8, .LCPI75_5
.LBB75_3:                               # %entry
	memw
	s32i	a6, a8, 0
	retw.n
.Lfunc_end75:
	.size	abla_fn_473142447_878684343_direct, .Lfunc_end75-abla_fn_473142447_878684343_direct
                                        # -- End function
	.literal_position
	.literal .LCPI76_0, 2147483647
	.literal .LCPI76_1, abla_static_abla_fn_627837887_633683867_1340
	.section	.iram1.3.abla.esp32RecoveredEspCrosscoreIntSendYield,"ax",@progbits
	.section	.text.abla_fn_562894442_822187393_direct,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_562894442_822187393_direct
	.type	abla_fn_562894442_822187393_direct,@function
abla_fn_562894442_822187393_direct:     # @abla_fn_562894442_822187393_direct
# %bb.0:                                # %entry
	entry	a1, 32
	memw
	l32i	a8, a2, 68
	memw
	l32r	a9, .LCPI76_0
	bne	a8, a9, .LBB76_4
# %bb.1:                                # %source.label
	l32r	a8, .LCPI76_1
	memw
	l32i	a9, a8, 0
	beqz.n	a9, .LBB76_6
# %bb.2:                                # %source.label7
	memw
	l32i	a8, a8, 4
	movi	a2, 0
	beqz.n	a8, .LBB76_6
.LBB76_3:                               # %common.ret
	retw.n
.LBB76_4:                               # %source.label12
	l32r	a9, .LCPI76_1
	addx4	a8, a8, a9
	memw
	l32i	a8, a8, 0
	movi	a2, 1
	movi	a9, 0
	beq	a8, a9, .LBB76_3
# %bb.5:                                # %source.label12
	movi	a2, 0
	retw.n
.LBB76_6:                               # %source.label7.thread
	movi	a2, 1
	retw.n
.Lfunc_end76:
	.size	abla_fn_562894442_822187393_direct, .Lfunc_end76-abla_fn_562894442_822187393_direct
                                        # -- End function
	.literal_position
	.literal .LCPI77_0, pxCurrentTCBs
	.literal .LCPI77_1, 2147483647
	.literal .LCPI77_2, abla_static_abla_fn_627837887_633683867_1340
	.literal .LCPI77_3, abla_fn_473142447_878684343_direct
	.section	.text.abla_fn_562894442_822187393_direct,"ax",@progbits
	.section	.text.abla_fn_785158669_973105815_direct,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_785158669_973105815_direct
	.type	abla_fn_785158669_973105815_direct,@function
abla_fn_785158669_973105815_direct:     # @abla_fn_785158669_973105815_direct
# %bb.0:                                # %entry
	entry	a1, 32
	movi	a8, 25
	bltu	a3, a8, .LBB77_1
	j	.LBB77_12
.LBB77_1:                               # %source.label2
	#APP
	rsr	a8, prid
	#NO_APP
	extui	a9, a8, 13, 1
	slli	a10, a9, 2
	l32r	a11, .LCPI77_0
	or	a12, a10, a11
	memw
	l32i	a8, a2, 68
	memw
	l32i	a12, a12, 0
	l32r	a13, .LCPI77_1
	beq	a8, a13, .LBB77_3
# %bb.2:                                # %source.label2
	bne	a8, a9, .LBB77_5
.LBB77_3:                               # %source.label23
	memw
	l32i	a12, a12, 44
	bgeu	a12, a3, .LBB77_5
# %bb.4:                                # %source.label24
	l32r	a12, .LCPI77_2
	or	a10, a10, a12
	memw
	l32i	a10, a10, 0
	beqz.n	a10, .LBB77_11
.LBB77_5:                               # %source.label29
	movi	a10, 1
	xor	a10, a9, a10
	slli	a9, a10, 2
	or	a11, a9, a11
	memw
	l32i	a11, a11, 0
	movi	a2, 0
	l32r	a12, .LCPI77_1
	beq	a8, a12, .LBB77_8
# %bb.6:                                # %source.label29
	beq	a8, a10, .LBB77_8
.LBB77_7:                               # %common.ret
	retw.n
.LBB77_8:                               # %source.label37
	memw
	l32i	a8, a11, 44
	bgeu	a8, a3, .LBB77_7
# %bb.9:                                # %source.label38
	l32r	a8, .LCPI77_2
	or	a8, a9, a8
	memw
	l32i	a8, a8, 0
	bnez	a8, .LBB77_7
# %bb.10:                               # %source.label41
	l32r	a8, .LCPI77_3
	callx8	a8
	retw.n
.LBB77_11:
	movi	a2, 1
	retw.n
.LBB77_12:                              # %source.label
	ill.n
.Lfunc_end77:
	.size	abla_fn_785158669_973105815_direct, .Lfunc_end77-abla_fn_785158669_973105815_direct
                                        # -- End function
	.literal_position
	.literal .LCPI78_0, abla_static_abla_fn_627837887_633683867_1394
	.literal .LCPI78_1, pxCurrentTCBs
	.literal .LCPI78_2, abla_static_abla_fn_627837887_633683867_1382
	.literal .LCPI78_3, abla_fn_539458941_750097516_direct
	.literal .LCPI78_4, abla_static_abla_fn_627837887_633683867_1346
	.literal .LCPI78_5, abla_static_abla_fn_627837887_633683867_1400
	.literal .LCPI78_6, abla_static_abla_fn_627837887_633683867_1352
	.literal .LCPI78_7, abla_static_abla_fn_627837887_633683867_1358
	.section	.text.abla_fn_785158669_973105815_direct,"ax",@progbits
	.section	.text.abla_fn_162547092_139541687_direct,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_162547092_139541687_direct
	.type	abla_fn_162547092_139541687_direct,@function
abla_fn_162547092_139541687_direct:     # @abla_fn_162547092_139541687_direct
# %bb.0:                                # %entry
	entry	a1, 32
	l32r	a8, .LCPI78_0
	memw
	l32i	a5, a8, 0
	#APP
	rsr	a8, prid
	#NO_APP
	srli	a8, a8, 11
	movi	a9, 4
	and	a8, a8, a9
	l32r	a9, .LCPI78_1
	or	a8, a8, a9
	memw
	l32i	a8, a8, 0
	memw
	l32i	a9, a8, 20
	l32r	a10, .LCPI78_2
	bne	a9, a10, .LBB78_2
.LBB78_1:                               # %common.ret
	retw.n
.LBB78_2:                               # %source.label5
	movi	a4, 0
	s8i	a4, a8, 98
	addi	a7, a8, 4
	l32r	a8, .LCPI78_3
	or	a10, a7, a7
	callx8	a8
	bnei	a2, -1, .LBB78_5
# %bb.3:                                # %source.label5
	beqz.n	a3, .LBB78_5
# %bb.4:                                # %source.label10
	l32r	a10, .LCPI78_7
	or	a11, a7, a7
	call8	abla_fn_971341861_636336326_direct
	retw.n
.LBB78_5:                               # %source.label12
	add	a6, a5, a2
	memw
	s32i	a6, a7, 0
	movi	a3, 1
	bltu	a6, a5, .LBB78_7
# %bb.6:                                # %source.label12
	movi	a3, 0
.LBB78_7:                               # %source.label12
	bne	a3, a4, .LBB78_9
# %bb.8:                                # %source.label12
	l32r	a8, .LCPI78_4
	j	.LBB78_10
.LBB78_9:
	l32r	a8, .LCPI78_5
.LBB78_10:                              # %source.label12
	memw
	l32i	a10, a8, 0
	or	a11, a7, a7
	call8	abla_fn_33922886_763007037_direct
	bnez	a3, .LBB78_1
# %bb.11:                               # %source.label19
	l32r	a8, .LCPI78_6
	memw
	l32i	a9, a8, 0
	bgeu	a6, a9, .LBB78_1
# %bb.12:                               # %source.label21
	memw
	s32i	a6, a8, 0
	retw.n
.Lfunc_end78:
	.size	abla_fn_162547092_139541687_direct, .Lfunc_end78-abla_fn_162547092_139541687_direct
                                        # -- End function
	.literal_position
	.literal .LCPI79_0, .Labla_string_abla_fn_627837887_633683867_1431.native.mutable.u32s
	.literal .LCPI79_1, abla_fn_186944242_355245718_direct
	.literal .LCPI79_2, pxCurrentTCBs
	.literal .LCPI79_3, abla_fn_707068177_288599970_direct
	.section	.text.abla_fn_162547092_139541687_direct,"ax",@progbits
	.section	.text.abla_fn_757481649_25429647_direct,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_757481649_25429647_direct
	.type	abla_fn_757481649_25429647_direct,@function
abla_fn_757481649_25429647_direct:      # @abla_fn_757481649_25429647_direct
# %bb.0:                                # %entry
	entry	a1, 32
	beqz	a2, .LBB79_2
# %bb.1:                                # %source.label2
	l32r	a7, .LCPI79_0
	l32r	a8, .LCPI79_1
	or	a10, a7, a7
	callx8	a8
	#APP
	rsr	a8, prid
	#NO_APP
	srli	a8, a8, 11
	movi	a9, 4
	and	a8, a8, a9
	l32r	a9, .LCPI79_2
	or	a8, a8, a9
	memw
	l32i	a8, a8, 0
	addi	a11, a8, 24
	or	a10, a2, a2
	call8	abla_fn_33922886_763007037_direct
	or	a10, a3, a3
	movi	a11, 1
	call8	abla_fn_162547092_139541687_direct
	l32r	a8, .LCPI79_3
	or	a10, a7, a7
	callx8	a8
	retw.n
.LBB79_2:                               # %source.label
	ill.n
.Lfunc_end79:
	.size	abla_fn_757481649_25429647_direct, .Lfunc_end79-abla_fn_757481649_25429647_direct
                                        # -- End function
	.literal_position
	.literal .LCPI80_0, .Labla_string_abla_fn_627837887_633683867_1431.native.mutable.u32s
	.literal .LCPI80_1, abla_fn_186944242_355245718_direct
	.literal .LCPI80_2, abla_fn_539458941_750097516_direct
	.literal .LCPI80_3, abla_fn_562894442_822187393_direct
	.literal .LCPI80_4, abla_fn_539458941_750097516_direct
	.literal .LCPI80_5, abla_static_abla_fn_627837887_633683867_1370
	.literal .LCPI80_6, abla_static_abla_fn_627837887_633683867_1376
	.literal .LCPI80_7, abla_fn_971341861_636336326_direct
	.literal .LCPI80_8, 2147483647
	.literal .LCPI80_9, abla_static_abla_fn_627837887_633683867_1340
	.literal .LCPI80_10, abla_static_abla_fn_627837887_633683867_1364
	.literal .LCPI80_11, abla_fn_971341861_636336326_direct
	.literal .LCPI80_12, abla_fn_785158669_973105815_direct
	.literal .LCPI80_13, abla_static_abla_fn_627837887_633683867_1412
	.literal .LCPI80_14, abla_fn_707068177_288599970_direct
	.section	.text.abla_fn_757481649_25429647_direct,"ax",@progbits
	.section	.iram1.abla.freertos.task_remove_from_event_list,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_985332523_289608079_direct
	.type	abla_fn_985332523_289608079_direct,@function
abla_fn_985332523_289608079_direct:     # @abla_fn_985332523_289608079_direct
# %bb.0:                                # %entry
	entry	a1, 32
	or	a7, a2, a2
	l32r	a10, .LCPI80_0
	l32r	a8, .LCPI80_1
	callx8	a8
	memw
	memw
	l32i	a8, a7, 0
	movi	a2, 0
	beqz	a8, .LBB80_12
# %bb.1:                                # %source.label4
	#APP
	rsr	a8, prid
	#NO_APP
	memw
	l32i	a9, a7, 12
	memw
	l32i	a7, a9, 12
	beqz	a7, .LBB80_13
# %bb.2:                                # %source.label10
	extui	a5, a8, 13, 1
	addi	a6, a7, 24
	l32r	a8, .LCPI80_2
	or	a10, a6, a6
	callx8	a8
	l32r	a8, .LCPI80_3
	or	a10, a7, a7
	callx8	a8
	beqz.n	a10, .LBB80_6
# %bb.3:                                # %source.label12
	addi	a6, a7, 4
	l32r	a8, .LCPI80_4
	or	a10, a6, a6
	callx8	a8
	memw
	l32i	a8, a7, 44
	l32r	a9, .LCPI80_5
	memw
	l32i	a10, a9, 0
	bgeu	a10, a8, .LBB80_5
# %bb.4:                                # %source.label15
	memw
	s32i	a8, a9, 0
.LBB80_5:                               # %source.label17
	movi	a9, 20
	mull	a8, a8, a9
	l32r	a9, .LCPI80_6
	add	a10, a8, a9
	l32r	a8, .LCPI80_7
	j	.LBB80_10
.LBB80_6:                               # %source.label19
	memw
	l32i	a9, a7, 68
	l32r	a10, .LCPI80_8
	or	a8, a5, a5
	beq	a9, a10, .LBB80_8
# %bb.7:                                # %source.label19
	or	a8, a9, a9
.LBB80_8:                               # %source.label19
	l32r	a9, .LCPI80_9
	addx4	a9, a8, a9
	memw
	l32i	a9, a9, 0
	beqz	a9, .LBB80_13
# %bb.9:                                # %source.label29
	movi	a9, 20
	mull	a8, a8, a9
	l32r	a9, .LCPI80_10
	add	a10, a8, a9
	l32r	a8, .LCPI80_11
.LBB80_10:                              # %source.label31
	or	a11, a6, a6
	callx8	a8
	memw
	l32i	a11, a7, 44
	l32r	a8, .LCPI80_12
	or	a10, a7, a7
	callx8	a8
	beqz.n	a10, .LBB80_12
# %bb.11:                               # %source.label33
	slli	a8, a5, 2
	l32r	a9, .LCPI80_13
	or	a8, a8, a9
	movi	a9, 1
	memw
	s32i	a9, a8, 0
	or	a2, a10, a10
.LBB80_12:                              # %common.ret
	l32r	a10, .LCPI80_0
	l32r	a8, .LCPI80_14
	callx8	a8
	retw.n
.LBB80_13:                              # %source.label8
	ill.n
.Lfunc_end80:
	.size	abla_fn_985332523_289608079_direct, .Lfunc_end80-abla_fn_985332523_289608079_direct
                                        # -- End function
	.literal_position
	.literal .LCPI81_0, .Labla_string_abla_fn_627837887_633683867_1431.native.mutable.u32s
	.literal .LCPI81_1, abla_fn_186944242_355245718_direct
	.literal .LCPI81_2, abla_static_abla_fn_627837887_633683867_1394
	.literal .LCPI81_3, pxCurrentTCBs
	.literal .LCPI81_4, abla_static_abla_fn_627837887_633683867_1418
	.literal .LCPI81_5, abla_fn_707068177_288599970_direct
	.section	.iram1.abla.freertos.task_remove_from_event_list,"ax",@progbits
	.section	.text.abla_fn_632124653_101754171_direct,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_632124653_101754171_direct
	.type	abla_fn_632124653_101754171_direct,@function
abla_fn_632124653_101754171_direct:     # @abla_fn_632124653_101754171_direct
# %bb.0:                                # %entry
	entry	a1, 32
	beqz	a2, .LBB81_12
# %bb.1:                                # %entry
	beqz	a3, .LBB81_12
# %bb.2:                                # %source.label8
	l32r	a10, .LCPI81_0
	l32r	a8, .LCPI81_1
	callx8	a8
	l32r	a8, .LCPI81_2
	memw
	l32i	a9, a8, 0
	memw
	l32i	a10, a2, 4
	#APP
	rsr	a11, prid
	#NO_APP
	srli	a11, a11, 11
	movi	a12, 4
	and	a11, a11, a12
	l32r	a12, .LCPI81_3
	or	a11, a11, a12
	memw
	l32i	a11, a11, 0
	l8ui	a12, a11, 98
	beqz.n	a12, .LBB81_4
# %bb.3:                                # %source.label14
	movi	a8, 0
	s8i	a8, a11, 98
	j	.LBB81_10
.LBB81_4:                               # %source.label16
	memw
	l32i	a11, a3, 0
	movi	a7, 0
	beqi	a11, -1, .LBB81_11
# %bb.5:                                # %source.label20
	memw
	l32i	a13, a2, 0
	l32r	a12, .LCPI81_4
	memw
	l32i	a14, a12, 0
	beq	a14, a13, .LBB81_7
# %bb.6:                                # %source.label20
	bgeu	a9, a10, .LBB81_9
.LBB81_7:                               # %source.label29
	sub	a9, a9, a10
	bgeu	a9, a11, .LBB81_9
# %bb.8:                                # %source.label30
	sub	a9, a11, a9
	memw
	s32i	a9, a3, 0
	memw
	memw
	l32i	a9, a12, 0
	memw
	s32i	a9, a2, 0
	memw
	memw
	l32i	a8, a8, 0
	memw
	s32i	a8, a2, 4
	j	.LBB81_11
.LBB81_9:                               # %source.label27
	movi	a8, 0
	memw
	s32i	a8, a3, 0
.LBB81_10:                              # %common.ret
	movi	a7, 1
.LBB81_11:                              # %common.ret
	l32r	a10, .LCPI81_0
	l32r	a8, .LCPI81_5
	callx8	a8
	or	a2, a7, a7
	retw.n
.LBB81_12:                              # %source.label6
	ill.n
.Lfunc_end81:
	.size	abla_fn_632124653_101754171_direct, .Lfunc_end81-abla_fn_632124653_101754171_direct
                                        # -- End function
	.literal_position
	.literal .LCPI82_0, abla_fn_254507142_821368668_direct
	.section	.text.abla_fn_632124653_101754171_direct,"ax",@progbits
	.section	.iram1.abla.freertos.task_get_scheduler_state,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_923148460_536466818_direct
	.type	abla_fn_923148460_536466818_direct,@function
abla_fn_923148460_536466818_direct:     # @abla_fn_923148460_536466818_direct
# %bb.0:                                # %entry
	entry	a1, 32
	#APP
	rsil	a10, 3
	#NO_APP
	memw
	l32r	a8, .LCPI82_0
	callx8	a8
	retw.n
.Lfunc_end82:
	.size	abla_fn_923148460_536466818_direct, .Lfunc_end82-abla_fn_923148460_536466818_direct
                                        # -- End function
	.literal_position
	.literal .LCPI83_0, abla_fn_923148460_536466818_direct
	.literal .LCPI83_1, .Labla_string_abla_fn_627837887_633683867_1431.native.mutable.u32s
	.literal .LCPI83_2, abla_fn_186944242_355245718_direct
	.literal .LCPI83_3, abla_fn_707068177_288599970_direct
	.literal .LCPI83_4, abla_fn_970437484_907475612_direct
	.section	.iram1.abla.freertos.task_get_scheduler_state,"ax",@progbits
	.section	.text.abla_fn_381068499_488660261_direct,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_381068499_488660261_direct
	.type	abla_fn_381068499_488660261_direct,@function
abla_fn_381068499_488660261_direct:     # @abla_fn_381068499_488660261_direct
# %bb.0:                                # %entry
	entry	a1, 32
	l32r	a8, .LCPI83_0
	callx8	a8
	l32r	a7, .LCPI83_1
	l32r	a8, .LCPI83_2
	or	a10, a7, a7
	callx8	a8
	movi	a10, 1
	movi	a11, 0
	call8	abla_fn_162547092_139541687_direct
	l32r	a8, .LCPI83_3
	or	a10, a7, a7
	callx8	a8
	l32r	a8, .LCPI83_4
	callx8	a8
	retw.n
.Lfunc_end83:
	.size	abla_fn_381068499_488660261_direct, .Lfunc_end83-abla_fn_381068499_488660261_direct
                                        # -- End function
	.literal_position
	.literal .LCPI84_0, 1073611232
	.section	.text.abla_fn_381068499_488660261_direct,"ax",@progbits
	.section	.text.abla_fn_465821094_160513335_direct,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_465821094_160513335_direct
	.type	abla_fn_465821094_160513335_direct,@function
abla_fn_465821094_160513335_direct:     # @abla_fn_465821094_160513335_direct
# %bb.0:                                # %entry
	entry	a1, 32
	l32r	a8, .LCPI84_0
	l32i	a8, a8, 0
	beqz.n	a8, .LBB84_3
# %bb.1:                                # %source.label2
	movi	a9, 1000
	mull	a8, a8, a9
	#APP
	rsr	a9, ccount
	#NO_APP
	beqz.n	a8, .LBB84_4
# %bb.2:                                # %scalar.divide.checked
	quou	a2, a9, a8
	retw.n
.LBB84_3:
	movi	a2, 0
	retw.n
.LBB84_4:                               # %scalar.division.by.zero
	ill.n
.Lfunc_end84:
	.size	abla_fn_465821094_160513335_direct, .Lfunc_end84-abla_fn_465821094_160513335_direct
                                        # -- End function
	.literal_position
	.literal .LCPI85_0, abla_fn_923148460_536466818_direct
	.section	.text.abla_fn_465821094_160513335_direct,"ax",@progbits
	.section	.text.abla_fn_11786425_863113934_direct,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_11786425_863113934_direct
	.type	abla_fn_11786425_863113934_direct,@function
abla_fn_11786425_863113934_direct:      # @abla_fn_11786425_863113934_direct
# %bb.0:                                # %entry
	entry	a1, 32
	l32r	a8, .LCPI85_0
	callx8	a8
	call8	abla_fn_465821094_160513335_direct
	or	a2, a10, a10
	retw.n
.Lfunc_end85:
	.size	abla_fn_11786425_863113934_direct, .Lfunc_end85-abla_fn_11786425_863113934_direct
                                        # -- End function
	.literal_position
	.literal .LCPI86_0, -1073741824
	.literal .LCPI86_1, abla_fn_471423001_389922946_direct
	.literal .LCPI86_2, 1073741823
	.section	.text.abla_fn_11786425_863113934_direct,"ax",@progbits
	.section	.text.abla_fn_471423001_389922946_direct,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_471423001_389922946_direct
	.type	abla_fn_471423001_389922946_direct,@function
abla_fn_471423001_389922946_direct:     # @abla_fn_471423001_389922946_direct
# %bb.0:                                # %entry
	entry	a1, 32
	movi	a8, 120
	s8i	a8, a2, 1
	movi	a8, 48
	s8i	a8, a2, 0
	l32r	a8, .LCPI86_0
	l32r	a9, .LCPI86_1
	and	a8, a9, a8
	l32r	a9, .LCPI86_2
	#APP
	or	a10, a0, a0
	#NO_APP
	and	a9, a10, a9
	or	a8, a8, a9
	addi	a10, a8, -3
	addi	a11, a2, 2
	movi	a12, 16
	call8	abla_fn_190887214_489433951_direct
	retw.n
.Lfunc_end86:
	.size	abla_fn_471423001_389922946_direct, .Lfunc_end86-abla_fn_471423001_389922946_direct
                                        # -- End function
	.section	.text.abla_fn_659567656_716613326_direct,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_659567656_716613326_direct
	.type	abla_fn_659567656_716613326_direct,@function
abla_fn_659567656_716613326_direct:     # @abla_fn_659567656_716613326_direct
# %bb.0:                                # %entry
	entry	a1, 32
	movi	a8, 198
	bltu	a8, a3, .LBB87_4
# %bb.1:                                # %source.label.i.preheader
	movi	a8, -1
.LBB87_2:                               # %source.label.i
                                        # =>This Inner Loop Header: Depth=1
	add	a9, a4, a8
	l8ui	a9, a9, 1
	addi	a8, a8, 1
	bnez	a9, .LBB87_2
# %bb.3:                                # %abla_fn_561674287_205248474_direct.exit
	add	a10, a3, a2
	movi	a9, 199
	sub	a9, a9, a3
	minu	a7, a8, a9
	or	a11, a4, a4
	or	a12, a7, a7
	call8	abla_fn_334943840_569200394_direct
	add	a3, a7, a3
.LBB87_4:                               # %common.ret
	or	a2, a3, a3
	retw.n
.Lfunc_end87:
	.size	abla_fn_659567656_716613326_direct, .Lfunc_end87-abla_fn_659567656_716613326_direct
                                        # -- End function
	.literal_position
	.literal .LCPI88_0, abla_fn_567470497_190987667_direct
	.literal .LCPI88_1, -4194304
	.literal .LCPI88_2, .Labla_string_abla_fn_627837887_633683867_1441.native.bytes
	.literal .LCPI88_3, 1061158912
	.literal .LCPI88_4, .Labla_string_abla_fn_627837887_633683867_1444.native.bytes
	.literal .LCPI88_5, .Labla_string_abla_fn_627837887_633683867_1447.native.bytes
	.literal .LCPI88_6, .Labla_string_abla_fn_627837887_633683867_1450.native.bytes
	.literal .LCPI88_7, .Labla_string_abla_fn_627837887_633683867_1453.native.bytes
	.literal .LCPI88_8, .Labla_string_abla_fn_627837887_633683867_1456.native.bytes
	.literal .LCPI88_9, .Labla_string_abla_fn_627837887_633683867_1459.native.bytes
	.section	.text.abla_fn_659567656_716613326_direct,"ax",@progbits
	.section	.text.abla_fn_900958054_339523954_direct,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_900958054_339523954_direct
	.type	abla_fn_900958054_339523954_direct,@function
abla_fn_900958054_339523954_direct:     # @abla_fn_900958054_339523954_direct
# %bb.0:                                # %entry
	entry	a1, 64
	or	a7, a1, a1
	addi	a10, a7, 16
	movi	a11, 0
	movi	a12, 11
	call8	abla_fn_853840267_528021067_direct
	addi	a11, a7, 0
	or	a10, a3, a3
	movi	a12, 10
	call8	abla_fn_190887214_489433951_direct
	l32r	a8, .LCPI88_0
	callx8	a8
	bnez.n	a10, .LBB88_7
# %bb.1:                                # %source.label
	l32r	a8, .LCPI88_1
	and	a10, a2, a8
	l32r	a9, .LCPI88_3
	bne	a10, a9, .LBB88_3
# %bb.2:
	l32r	a2, .LCPI88_2
.LBB88_3:                               # %source.label
	movi	a3, 0
	and	a8, a4, a8
	bne	a8, a9, .LBB88_5
# %bb.4:                                # %source.label10
	addi	a4, a7, 16
	or	a10, a4, a4
	call8	abla_fn_471423001_389922946_direct
.LBB88_5:                               # %source.label12
	l32r	a8, .LCPI88_1
	and	a8, a5, a8
	l32r	a9, .LCPI88_3
	bne	a8, a9, .LBB88_8
# %bb.6:
	l32r	a5, .LCPI88_2
	j	.LBB88_8
.LBB88_7:
	movi	a3, 0
.LBB88_8:                               # %source.label17
	movi	a8, -224
	add	a8, a1, a8
	movsp	a1, a8
	or	a6, a1, a1
	l32r	a12, .LCPI88_4
	or	a10, a6, a6
	movi	a11, 0
	call8	abla_fn_659567656_716613326_direct
	or	a11, a10, a10
	bne	a4, a3, .LBB88_10
# %bb.9:
	l32r	a4, .LCPI88_5
.LBB88_10:                              # %source.label17
	or	a10, a6, a6
	or	a12, a4, a4
	call8	abla_fn_659567656_716613326_direct
	or	a11, a10, a10
	l32r	a12, .LCPI88_6
	or	a10, a6, a6
	call8	abla_fn_659567656_716613326_direct
	or	a11, a10, a10
	or	a10, a6, a6
	or	a12, a2, a2
	call8	abla_fn_659567656_716613326_direct
	or	a11, a10, a10
	l32r	a12, .LCPI88_7
	or	a10, a6, a6
	call8	abla_fn_659567656_716613326_direct
	or	a11, a10, a10
	addi	a12, a7, 0
	or	a10, a6, a6
	call8	abla_fn_659567656_716613326_direct
	or	a11, a10, a10
	l32r	a12, .LCPI88_8
	or	a10, a6, a6
	call8	abla_fn_659567656_716613326_direct
	or	a11, a10, a10
	or	a10, a6, a6
	or	a12, a5, a5
	call8	abla_fn_659567656_716613326_direct
	or	a11, a10, a10
	l32r	a12, .LCPI88_9
	or	a10, a6, a6
	call8	abla_fn_659567656_716613326_direct
	add	a8, a10, a6
	s8i	a3, a8, 0
	ill.n
.Lfunc_end88:
	.size	abla_fn_900958054_339523954_direct, .Lfunc_end88-abla_fn_900958054_339523954_direct
                                        # -- End function
	.section	.iram1.abla.freertos.port_in_isr_context,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_952490526_932962922_direct
	.type	abla_fn_952490526_932962922_direct,@function
abla_fn_952490526_932962922_direct:     # @abla_fn_952490526_932962922_direct
# %bb.0:                                # %entry
	entry	a1, 32
	#APP
	rsil	a8, 3
	#NO_APP
	#APP
	rsr	a9, prid
	extui	a9, a9, 13, 1
	#NO_APP
	#APP
	wsr	a8, ps
	rsync

	#NO_APP
	retw.n
.Lfunc_end89:
	.size	abla_fn_952490526_932962922_direct, .Lfunc_end89-abla_fn_952490526_932962922_direct
                                        # -- End function
	.section	.text.unlikely.abla_fn_860733264_35721948_direct,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_860733264_35721948_direct
	.type	abla_fn_860733264_35721948_direct,@function
abla_fn_860733264_35721948_direct:      # @abla_fn_860733264_35721948_direct
# %bb.0:                                # %entry
	entry	a1, 32
	or	a10, a5, a5
	or	a13, a4, a4
	or	a12, a3, a3
	or	a11, a2, a2
	call8	abla_fn_900958054_339523954_direct
.Lfunc_end90:
	.size	abla_fn_860733264_35721948_direct, .Lfunc_end90-abla_fn_860733264_35721948_direct
                                        # -- End function
	.literal_position
	.literal .LCPI91_0, -1287651329
	.literal .LCPI91_1, .Labla_string_abla_fn_627837887_633683867_1541.native.bytes
	.literal .LCPI91_2, .Labla_string_abla_fn_627837887_633683867_1506.native.bytes
	.literal .LCPI91_3, abla_fn_860733264_35721948_direct
	.literal .LCPI91_4, abla_fn_860733264_35721948_direct
	.literal .LCPI91_5, abla_fn_860733264_35721948_direct
	.literal .LCPI91_6, abla_static_abla_fn_627837887_633683867_1495
	.literal .LCPI91_7, abla_static_abla_fn_627837887_633683867_1501
	.literal .LCPI91_8, abla_fn_860733264_35721948_direct
	.section	.text.unlikely.abla_fn_860733264_35721948_direct,"ax",@progbits
	.section	.iram1.abla.freertos.port_enter_critical_timeout,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_186944242_355245718_direct
	.type	abla_fn_186944242_355245718_direct,@function
abla_fn_186944242_355245718_direct:     # @abla_fn_186944242_355245718_direct
# %bb.0:                                # %entry
	entry	a1, 32
	#APP
	rsil	a8, 3
	#NO_APP
	beqz	a2, .LBB91_17
# %bb.1:                                # %abla_fn_401149032_139545174_direct.exit39.i
	#APP
	rsil	a9, 3
	#NO_APP
	#APP
	rsr	a10, prid
	#NO_APP
	memw
	l32i	a11, a2, 0
	bne	a11, a10, .LBB91_4
# %bb.2:                                # %source.label.i
	memw
	l32i	a10, a2, 4
	addi	a11, a10, -1
	movi	a12, 254
	bltu	a11, a12, .LBB91_3
	j	.LBB91_18
.LBB91_3:                               # %abla_fn_401149032_139545174_direct.exit37.i
	addi	a10, a10, 1
	memw
	s32i	a10, a2, 4
	#APP
	wsr	a9, ps
	rsync

	#NO_APP
	j	.LBB91_14
.LBB91_4:                               # %source.label21.i
	l32r	a12, .LCPI91_0
	wsr	a12, scompare1
	or	a13, a10, a10
	s32c1i	a13, a2, 0
	movi	a11, 1
	beq	a13, a12, .LBB91_6
# %bb.5:                                # %source.label21.i
	movi	a11, 0
.LBB91_6:                               # %source.label21.i
	bnez.n	a11, .LBB91_11
# %bb.7:                                # %source.label27.i
	#APP
	rsr	a11, ccount
	#NO_APP
.LBB91_8:                               # %source.label29.i
                                        # =>This Inner Loop Header: Depth=1
	l32r	a12, .LCPI91_0
	wsr	a12, scompare1
	or	a13, a10, a10
	s32c1i	a13, a2, 0
	movi	a11, 1
	beq	a13, a12, .LBB91_10
# %bb.9:                                # %source.label29.i
                                        #   in Loop: Header=BB91_8 Depth=1
	movi	a11, 0
.LBB91_10:                              # %source.label29.i
                                        #   in Loop: Header=BB91_8 Depth=1
	bnei	a11, 1, .LBB91_8
.LBB91_11:                              # %source.label42.i
	memw
	l32i	a11, a2, 0
	bne	a11, a10, .LBB91_19
# %bb.12:                               # %abla_fn_401149032_139545174_direct.exit35.i
	memw
	l32i	a10, a2, 4
	bnez	a10, .LBB91_20
# %bb.13:                               # %abla_fn_401149032_139545174_direct.exit.i
	movi	a10, 1
	memw
	s32i	a10, a2, 4
	#APP
	wsr	a9, ps
	rsync

	#NO_APP
.LBB91_14:                              # %source.label4
	l32r	a10, .LCPI91_6
	#APP
	rsr	a9, prid
	extui	a9, a9, 13, 1
	#NO_APP
	addx4	a10, a9, a10
	memw
	l32i	a11, a10, 0
	addi	a12, a11, 1
	memw
	s32i	a12, a10, 0
	beqz.n	a11, .LBB91_16
# %bb.15:                               # %common.ret
	retw.n
.LBB91_16:                              # %source.label9
	slli	a9, a9, 2
	l32r	a10, .LCPI91_7
	add	a9, a9, a10
	memw
	s32i	a8, a9, 0
	retw.n
.LBB91_17:                              # %source.label.i.i38.i
	l32r	a12, .LCPI91_1
	addi	a13, a12, 48
	l32r	a11, .LCPI91_2
	l32r	a8, .LCPI91_8
	movi	a10, 84
	callx8	a8
.LBB91_18:                              # %source.label.i.i36.i
	l32r	a12, .LCPI91_1
	addi	a13, a12, 48
	l32r	a11, .LCPI91_2
	l32r	a8, .LCPI91_5
	movi	a10, 106
	callx8	a8
.LBB91_19:                              # %source.label.i.i34.i
	l32r	a12, .LCPI91_1
	addi	a13, a12, 48
	l32r	a11, .LCPI91_2
	l32r	a8, .LCPI91_3
	movi	a10, 141
	callx8	a8
.LBB91_20:                              # %source.label.i.i.i
	l32r	a12, .LCPI91_1
	addi	a13, a12, 48
	l32r	a11, .LCPI91_2
	l32r	a8, .LCPI91_4
	movi	a10, 142
	callx8	a8
.Lfunc_end91:
	.size	abla_fn_186944242_355245718_direct, .Lfunc_end91-abla_fn_186944242_355245718_direct
                                        # -- End function
	.literal_position
	.literal .LCPI92_0, .Labla_string_abla_fn_627837887_633683867_1541.native.bytes
	.literal .LCPI92_1, .Labla_string_abla_fn_627837887_633683867_1513.native.bytes
	.literal .LCPI92_2, .Labla_string_abla_fn_627837887_633683867_1534.native.bytes
	.literal .LCPI92_3, abla_fn_860733264_35721948_direct
	.literal .LCPI92_4, abla_fn_860733264_35721948_direct
	.literal .LCPI92_5, -1287651329
	.literal .LCPI92_6, abla_static_abla_fn_627837887_633683867_1495
	.literal .LCPI92_7, port_xSchedulerRunning
	.literal .LCPI92_8, abla_static_abla_fn_627837887_633683867_1501
	.literal .LCPI92_9, .Labla_string_abla_fn_627837887_633683867_1527.native.bytes
	.literal .LCPI92_10, .Labla_string_abla_fn_627837887_633683867_1520.native.bytes
	.literal .LCPI92_11, abla_fn_860733264_35721948_direct
	.literal .LCPI92_12, abla_fn_860733264_35721948_direct
	.section	.iram1.abla.freertos.port_enter_critical_timeout,"ax",@progbits
	.section	.iram1.abla.freertos.port_exit_critical,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_707068177_288599970_direct
	.type	abla_fn_707068177_288599970_direct,@function
abla_fn_707068177_288599970_direct:     # @abla_fn_707068177_288599970_direct
# %bb.0:                                # %entry
	entry	a1, 32
	beqz	a2, .LBB92_11
# %bb.1:                                # %abla_fn_401149032_139545174_direct.exit13.i
	#APP
	rsil	a8, 3
	#NO_APP
	#APP
	rsr	a9, prid
	#NO_APP
	memw
	l32i	a10, a2, 0
	beq	a10, a9, .LBB92_2
	j	.LBB92_12
.LBB92_2:                               # %abla_fn_401149032_139545174_direct.exit11.i
	memw
	l32i	a9, a2, 4
	addi	a9, a9, -1
	memw
	s32i	a9, a2, 4
	beqz.n	a9, .LBB92_5
# %bb.3:                                # %source.label11.i
	bltui	a9, 256, .LBB92_6
# %bb.4:                                # %source.label.i.i.i
	l32r	a8, .LCPI92_0
	addi	a13, a8, 48
	l32r	a11, .LCPI92_1
	l32r	a12, .LCPI92_2
	l32r	a8, .LCPI92_4
	movi	a10, 196
	callx8	a8
.LBB92_5:                               # %source.label.i30
	l32r	a9, .LCPI92_5
	memw
	s32i	a9, a2, 0
.LBB92_6:                               # %abla_fn_204458652_636920995_direct.exit
	#APP
	wsr	a8, ps
	rsync

	#NO_APP
	l32r	a9, .LCPI92_6
	#APP
	rsr	a8, prid
	extui	a8, a8, 13, 1
	#NO_APP
	addx4	a10, a8, a9
	memw
	l32i	a10, a10, 0
	beqz	a10, .LBB92_13
# %bb.7:                                # %abla_fn_962260640_727568821_direct.exit
	slli	a8, a8, 2
	add	a9, a9, a8
	addi	a10, a10, -1
	memw
	s32i	a10, a9, 0
	beqz.n	a10, .LBB92_9
.LBB92_8:                               # %common.ret
	retw.n
.LBB92_9:                               # %source.label
	l32r	a9, .LCPI92_7
	add	a9, a8, a9
	memw
	l32i	a9, a9, 0
	beqz	a9, .LBB92_8
# %bb.10:                               # %source.label14
	l32r	a9, .LCPI92_8
	add	a8, a8, a9
	memw
	l32i	a9, a8, 0
	#APP
	rsr	a10, ps
	xor	a8, a10, a9
	extui	a8, a8, 0, 4
	xor	a8, a10, a8
	wsr	a8, ps
	rsync

	#NO_APP
	retw.n
.LBB92_11:                              # %source.label.i.i12.i
	l32r	a12, .LCPI92_0
	addi	a13, a12, 48
	l32r	a11, .LCPI92_1
	l32r	a8, .LCPI92_12
	movi	a10, 181
	callx8	a8
.LBB92_12:                              # %source.label.i.i10.i
	l32r	a8, .LCPI92_0
	addi	a13, a8, 48
	l32r	a11, .LCPI92_1
	l32r	a12, .LCPI92_2
	l32r	a8, .LCPI92_3
	movi	a10, 190
	callx8	a8
.LBB92_13:                              # %source.label.i
	l32r	a8, .LCPI92_9
	addi	a13, a8, 94
	l32r	a11, .LCPI92_10
	l32r	a12, .LCPI92_2
	l32r	a8, .LCPI92_11
	movi	a10, 520
	callx8	a8
.Lfunc_end92:
	.size	abla_fn_707068177_288599970_direct, .Lfunc_end92-abla_fn_707068177_288599970_direct
                                        # -- End function
	.literal_position
	.literal .LCPI93_0, 1072955512
	.literal .LCPI93_1, 1072693448
	.section	.iram1.abla.freertos.port_exit_critical,"ax",@progbits
	.section	.text.abla_fn_954586519_862037725_direct,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_954586519_862037725_direct
	.type	abla_fn_954586519_862037725_direct,@function
abla_fn_954586519_862037725_direct:     # @abla_fn_954586519_862037725_direct
# %bb.0:                                # %entry
	entry	a1, 32
	#APP
	rsil	a8, 5
	#NO_APP
	l32r	a9, .LCPI93_0
	memw
	l32i	a9, a9, 0
	l32r	a9, .LCPI93_1
	memw
	l32i	a10, a9, 0
	#APP
	wsr	a8, ps
	rsync

	#NO_APP
	movi	a8, 257
	or	a8, a10, a8
	memw
	s32i	a8, a9, 0
	memw
	retw.n
.Lfunc_end93:
	.size	abla_fn_954586519_862037725_direct, .Lfunc_end93-abla_fn_954586519_862037725_direct
                                        # -- End function
	.literal_position
	.literal .LCPI94_0, 1072955512
	.literal .LCPI94_1, 1072693448
	.section	.text.abla_fn_954586519_862037725_direct,"ax",@progbits
	.section	.text.abla_fn_471788702_517623392_direct,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_471788702_517623392_direct
	.type	abla_fn_471788702_517623392_direct,@function
abla_fn_471788702_517623392_direct:     # @abla_fn_471788702_517623392_direct
# %bb.0:                                # %entry
	entry	a1, 32
	#APP
	rsil	a8, 5
	#NO_APP
	l32r	a9, .LCPI94_0
	memw
	l32i	a9, a9, 0
	l32r	a9, .LCPI94_1
	memw
	l32i	a10, a9, 0
	#APP
	wsr	a8, ps
	rsync

	#NO_APP
	movi	a8, -258
	and	a8, a10, a8
	memw
	s32i	a8, a9, 0
	memw
	retw.n
.Lfunc_end94:
	.size	abla_fn_471788702_517623392_direct, .Lfunc_end94-abla_fn_471788702_517623392_direct
                                        # -- End function
	.literal_position
	.literal .LCPI95_0, 1073066020
	.literal .LCPI95_1, 1073065984
	.literal .LCPI95_2, 1073066016
	.section	.text.abla_fn_471788702_517623392_direct,"ax",@progbits
	.section	.text.abla_fn_16377822_540100096_direct,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_16377822_540100096_direct
	.type	abla_fn_16377822_540100096_direct,@function
abla_fn_16377822_540100096_direct:      # @abla_fn_16377822_540100096_direct
# %bb.0:                                # %entry
	entry	a1, 32
	memw
	l32r	a8, .LCPI95_0
	s32i	a2, a8, 0
	memw
	movi	a8, 0
	beqi	a8, 32, .LBB95_2
.LBB95_1:                               # %source.label2.i
                                        # =>This Inner Loop Header: Depth=1
	l32r	a9, .LCPI95_1
	add	a9, a8, a9
	add	a10, a3, a8
	l32i	a10, a10, 0
	memw
	s32i	a10, a9, 0
	memw
	addi	a8, a8, 4
	bnei	a8, 32, .LBB95_1
.LBB95_2:                               # %abla_fn_278644865_859580814_direct.exit
	memw
	l32r	a8, .LCPI95_2
	movi	a9, 1
	s32i	a9, a8, 0
	memw
	retw.n
.Lfunc_end95:
	.size	abla_fn_16377822_540100096_direct, .Lfunc_end95-abla_fn_16377822_540100096_direct
                                        # -- End function
	.literal_position
	.literal .LCPI96_0, 1073066024
	.section	.text.abla_fn_16377822_540100096_direct,"ax",@progbits
	.section	.text.abla_fn_931545567_835396853_direct,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_931545567_835396853_direct
	.type	abla_fn_931545567_835396853_direct,@function
abla_fn_931545567_835396853_direct:     # @abla_fn_931545567_835396853_direct
# %bb.0:                                # %entry
	entry	a1, 32
	l32r	a8, .LCPI96_0
	l8ui	a8, a8, 0
	bbsi	a8, 0, .LBB96_2
.LBB96_1:                               # %source.label
                                        # =>This Inner Loop Header: Depth=1
	j	.LBB96_1
.LBB96_2:                               # %source.label2
	retw.n
.Lfunc_end96:
	.size	abla_fn_931545567_835396853_direct, .Lfunc_end96-abla_fn_931545567_835396853_direct
                                        # -- End function
	.section	.text.abla_fn_103051375_4624815_direct,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_103051375_4624815_direct
	.type	abla_fn_103051375_4624815_direct,@function
abla_fn_103051375_4624815_direct:       # @abla_fn_103051375_4624815_direct
# %bb.0:                                # %entry
	entry	a1, 32
	retw.n
.Lfunc_end97:
	.size	abla_fn_103051375_4624815_direct, .Lfunc_end97-abla_fn_103051375_4624815_direct
                                        # -- End function
	.section	.text.abla_fn_15173205_827940961_direct,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_15173205_827940961_direct
	.type	abla_fn_15173205_827940961_direct,@function
abla_fn_15173205_827940961_direct:      # @abla_fn_15173205_827940961_direct
# %bb.0:                                # %entry
	entry	a1, 32
	extui	a8, a2, 0, 4
	movi	a2, 1
	movi	a9, 0
	beq	a8, a9, .LBB98_2
# %bb.1:                                # %entry
	movi	a2, 0
.LBB98_2:                               # %entry
	retw.n
.Lfunc_end98:
	.size	abla_fn_15173205_827940961_direct, .Lfunc_end98-abla_fn_15173205_827940961_direct
                                        # -- End function
	.literal_position
	.literal .LCPI99_0, 1072963584
	.section	.text.abla_fn_15173205_827940961_direct,"ax",@progbits
	.section	.text.abla_fn_844637847_768207836_direct,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_844637847_768207836_direct
	.type	abla_fn_844637847_768207836_direct,@function
abla_fn_844637847_768207836_direct:     # @abla_fn_844637847_768207836_direct
# %bb.0:                                # %entry
	entry	a1, 32
	l32i	a8, a2, 4
	movi	a2, 1
	l32r	a9, .LCPI99_0
	bne	a8, a9, .LBB99_2
# %bb.1:                                # %entry
	movi	a2, 0
.LBB99_2:                               # %entry
	retw.n
.Lfunc_end99:
	.size	abla_fn_844637847_768207836_direct, .Lfunc_end99-abla_fn_844637847_768207836_direct
                                        # -- End function
	.literal_position
	.literal .LCPI100_0, 1072963584
	.section	.text.abla_fn_844637847_768207836_direct,"ax",@progbits
	.section	.text.abla_fn_215460651_430198619_direct,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_215460651_430198619_direct
	.type	abla_fn_215460651_430198619_direct,@function
abla_fn_215460651_430198619_direct:     # @abla_fn_215460651_430198619_direct
# %bb.0:                                # %entry
	entry	a1, 32
	l32i	a8, a2, 4
	movi	a2, 1
	l32r	a9, .LCPI100_0
	bne	a8, a9, .LBB100_2
# %bb.1:                                # %entry
	movi	a2, 0
.LBB100_2:                              # %entry
	retw.n
.Lfunc_end100:
	.size	abla_fn_215460651_430198619_direct, .Lfunc_end100-abla_fn_215460651_430198619_direct
                                        # -- End function
	.section	.text.abla_fn_204109230_234273409_direct,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_204109230_234273409_direct
	.type	abla_fn_204109230_234273409_direct,@function
abla_fn_204109230_234273409_direct:     # @abla_fn_204109230_234273409_direct
# %bb.0:                                # %entry
	entry	a1, 32
.LBB101_1:                              # %source.label18
                                        # =>This Inner Loop Header: Depth=1
	l32i	a8, a2, 4
	memw
	l32i	a8, a8, 0
	bnez	a8, .LBB101_1
# %bb.2:                                # %source.label22
	retw.n
.Lfunc_end101:
	.size	abla_fn_204109230_234273409_direct, .Lfunc_end101-abla_fn_204109230_234273409_direct
                                        # -- End function
	.section	.text.abla_fn_356122711_422489762_direct,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_356122711_422489762_direct
	.type	abla_fn_356122711_422489762_direct,@function
abla_fn_356122711_422489762_direct:     # @abla_fn_356122711_422489762_direct
# %bb.0:                                # %entry
	entry	a1, 32
	l32i	a8, a2, 4
	memw
	movi	a9, 0
	s32i	a9, a8, 28
	memw
	s32i	a9, a8, 8
	l32i	a10, a2, 8
	movi	a11, 1
	movi	a12, 1
	bne	a10, a9, .LBB102_2
# %bb.1:                                # %entry
	movi	a12, 0
.LBB102_2:                              # %entry
	memw
	l32i	a13, a8, 52
	movi	a14, -2
	and	a13, a13, a14
	or	a12, a13, a12
	memw
	s32i	a12, a8, 52
	movi	a12, 2
	movi	a13, 0
	beq	a10, a11, .LBB102_4
# %bb.3:                                # %entry
	movi	a13, 2
.LBB102_4:                              # %entry
	memw
	l32i	a11, a8, 52
	movi	a14, -3
	and	a11, a11, a14
	or	a11, a11, a13
	memw
	s32i	a11, a8, 52
	movi	a11, 0
	beq	a10, a12, .LBB102_6
# %bb.5:                                # %entry
	movi	a11, 4
.LBB102_6:                              # %entry
	memw
	l32i	a10, a8, 52
	movi	a12, -5
	and	a10, a10, a12
	or	a10, a10, a11
	memw
	s32i	a10, a8, 52
	memw
	l32i	a10, a2, 16
	memw
	s32i	a10, a8, 24
	l8ui	a11, a2, 15
	slli	a10, a11, 4
	movi	a12, 240
	and	a10, a10, a12
	memw
	l32i	a12, a8, 20
	movi	a13, -241
	and	a12, a12, a13
	or	a10, a12, a10
	memw
	s32i	a10, a8, 20
	movi	a10, 0
	beq	a11, a9, .LBB102_8
# %bb.7:                                # %entry
	movi	a10, 16
.LBB102_8:                              # %entry
	memw
	l32i	a11, a8, 28
	movi	a12, -17
	and	a11, a11, a12
	or	a10, a11, a10
	memw
	s32i	a10, a8, 28
	l8ui	a10, a2, 14
	movi	a11, 0
	beq	a10, a9, .LBB102_10
# %bb.9:                                # %entry
	movi	a11, 32
.LBB102_10:                             # %entry
	memw
	l32i	a9, a8, 28
	movi	a12, -33
	and	a9, a9, a12
	or	a9, a9, a11
	memw
	s32i	a9, a8, 28
	memw
	l32i	a9, a8, 20
	movi	a11, -16
	and	a9, a9, a11
	addi	a10, a10, -1
	extui	a10, a10, 0, 4
	or	a9, a9, a10
	memw
	s32i	a9, a8, 20
	movi	a2, 0
	retw.n
.Lfunc_end102:
	.size	abla_fn_356122711_422489762_direct, .Lfunc_end102-abla_fn_356122711_422489762_direct
                                        # -- End function
	.literal_position
	.literal .LCPI103_0, -2147483648
	.literal .LCPI103_1, -268369921
	.literal .LCPI103_2, -268435456
	.literal .LCPI103_3, 268435455
	.literal .LCPI103_4, 1879048192
	.literal .LCPI103_5, -67108864
	.literal .LCPI103_6, 1073741824
	.literal .LCPI103_7, -1073741825
	.literal .LCPI103_8, 536870912
	.literal .LCPI103_9, -536870913
	.literal .LCPI103_10, -268435457
	.literal .LCPI103_11, -134217729
	.literal .LCPI103_12, -26238977
	.literal .LCPI103_13, 8192
	.literal .LCPI103_14, 8396800
	.literal .LCPI103_15, 24576
	.literal .LCPI103_16, 1056768
	.literal .LCPI103_17, 16785408
	.section	.text.abla_fn_356122711_422489762_direct,"ax",@progbits
	.section	.text.abla_fn_797348383_613908390_direct,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_797348383_613908390_direct
	.type	abla_fn_797348383_613908390_direct,@function
abla_fn_797348383_613908390_direct:     # @abla_fn_797348383_613908390_direct
# %bb.0:                                # %entry
	entry	a1, 80
	l32i	a8, a2, 4
	memw
	l32i	a9, a8, 28
	l32r	a10, .LCPI103_0
	or	a9, a9, a10
	memw
	s32i	a9, a8, 28
	movi	a9, 0
	bge	a6, a9, .LBB103_2
# %bb.1:
	addi	a4, a4, 4
.LBB103_2:                              # %entry
	extui	a9, a6, 0, 16
	movi	a10, -2
	movi	a11, 3
	beq	a9, a11, .LBB103_4
# %bb.3:                                # %entry
	movi	a10, -1
.LBB103_4:                              # %entry
	srai	a11, a6, 31
	and	a10, a11, a10
	memw
	movi	a11, 255
	bltu	a11, a3, .LBB103_6
# %bb.5:                                # %source.label81
	l16ui	a11, a1, 6
	slli	a11, a11, 16
	or	a11, a11, a3
	memw
	s32i	a11, a1, 4
	memw
	l32r	a11, .LCPI103_1
	l32i	a12, a1, 4
	and	a11, a12, a11
	memw
	s32i	a11, a1, 4
	memw
	l32r	a11, .LCPI103_3
	l32i	a12, a1, 4
	and	a11, a12, a11
	l32r	a12, .LCPI103_4
	or	a11, a11, a12
	memw
	s32i	a11, a1, 4
	movi	a11, 4
	j	.LBB103_7
.LBB103_6:                              # %source.label82
	extui	a11, a3, 0, 8
	l16ui	a12, a1, 10
	slli	a12, a12, 16
	or	a11, a12, a11
	memw
	s32i	a11, a1, 8
	memw
	l32r	a11, .LCPI103_1
	l32i	a12, a1, 8
	and	a11, a12, a11
	memw
	s32i	a11, a1, 8
	memw
	l32r	a11, .LCPI103_2
	l32i	a12, a1, 8
	or	a11, a12, a11
	memw
	s32i	a11, a1, 8
	movi	a11, 8
.LBB103_7:                              # %source.label83
	addi	a12, a1, 0
	or	a11, a12, a11
	add	a10, a5, a10
	memw
	l32i	a11, a11, 0
	memw
	s32i	a11, a8, 36
	memw
	l32i	a11, a8, 32
	l32r	a12, .LCPI103_5
	or	a11, a11, a12
	slli	a12, a4, 26
	add	a11, a11, a12
	memw
	s32i	a11, a8, 32
	movi	a11, 0
	movi	a12, 0
	beq	a4, a11, .LBB103_9
# %bb.8:                                # %source.label83
	l32r	a12, .LCPI103_6
.LBB103_9:                              # %source.label83
	memw
	l32i	a13, a8, 28
	l32r	a14, .LCPI103_7
	and	a13, a13, a14
	or	a12, a13, a12
	memw
	s32i	a12, a8, 28
	l8ui	a12, a2, 12
	add	a10, a10, a12
	beq	a10, a11, .LBB103_11
# %bb.10:                               # %source.label83
	l32r	a11, .LCPI103_8
.LBB103_11:                             # %source.label83
	memw
	l32i	a12, a8, 28
	l32r	a13, .LCPI103_9
	and	a12, a12, a13
	or	a11, a11, a12
	memw
	s32i	a11, a8, 28
	memw
	l32i	a11, a8, 32
	memw
	s32i	a11, a1, 0
	memw
	movi	a11, -256
	l32i	a12, a1, 0
	and	a11, a12, a11
	addi	a10, a10, -1
	extui	a10, a10, 0, 8
	or	a10, a11, a10
	memw
	s32i	a10, a1, 0
	memw
	l32i	a10, a1, 0
	memw
	s32i	a10, a8, 32
	memw
	l32i	a10, a8, 28
	l32r	a11, .LCPI103_10
	and	a10, a10, a11
	memw
	s32i	a10, a8, 28
	memw
	l8ui	a10, a8, 47
	memw
	slli	a10, a10, 24
	s32i	a10, a8, 44
	memw
	l32i	a10, a8, 28
	l32r	a11, .LCPI103_11
	and	a10, a10, a11
	memw
	s32i	a10, a8, 28
	memw
	l8ui	a10, a8, 43
	memw
	slli	a10, a10, 24
	s32i	a10, a8, 40
	memw
	l32i	a10, a8, 8
	l32r	a11, .LCPI103_12
	and	a10, a10, a11
	l32r	a11, .LCPI103_13
	memw
	memw
	memw
	bnei	a9, 3, .LBB103_16
# %bb.12:
	l32r	a9, .LCPI103_14
.LBB103_13:                             # %source.label62.sink.split.sink.split.i
	or	a10, a9, a10
	memw
.LBB103_14:                             # %source.label62.sink.split.i
	memw
.LBB103_15:                             # %abla_fn_377616730_667189379_direct.exit
	memw
	s32i	a10, a8, 8
	movi	a2, 0
	retw.n
.LBB103_16:                             # %source.label43.i
	bltui	a9, 4, .LBB103_20
# %bb.17:                               # %source.label44.i
	beqi	a9, 4, .LBB103_24
# %bb.18:                               # %source.label44.i
	bnei	a9, 5, .LBB103_26
# %bb.19:                               # %source.label48.i
	l32r	a9, .LCPI103_17
	j	.LBB103_13
.LBB103_20:                             # %source.label51.i
	beqz	a9, .LBB103_14
# %bb.21:                               # %source.label51.i
	beqi	a9, 1, .LBB103_25
# %bb.22:                               # %source.label51.i
	bnei	a9, 2, .LBB103_26
# %bb.23:
	l32r	a9, .LCPI103_15
	j	.LBB103_13
.LBB103_24:
	l32r	a9, .LCPI103_16
	j	.LBB103_13
.LBB103_25:
	or	a10, a10, a11
	j	.LBB103_15
.LBB103_26:                             # %source.label47.i
	ill.n
.Lfunc_end103:
	.size	abla_fn_797348383_613908390_direct, .Lfunc_end103-abla_fn_797348383_613908390_direct
                                        # -- End function
	.literal_position
	.literal .LCPI104_0, 536870912
	.literal .LCPI104_1, -536870913
	.literal .LCPI104_2, 134217728
	.literal .LCPI104_3, -134217729
	.literal .LCPI104_4, 268435456
	.literal .LCPI104_5, -268435457
	.literal .LCPI104_6, 262144
	.section	.text.abla_fn_797348383_613908390_direct,"ax",@progbits
	.section	.text.abla_fn_408654605_297463740_direct,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_408654605_297463740_direct
	.type	abla_fn_408654605_297463740_direct,@function
abla_fn_408654605_297463740_direct:     # @abla_fn_408654605_297463740_direct
# %bb.0:                                # %entry
	entry	a1, 128
	or	a10, a2, a2
	s32i	a10, a1, 52
	l32i	a8, a3, 16
	movi	a9, 2
	and	a8, a8, a9
	movi	a9, 0
	beq	a8, a9, .LBB104_2
# %bb.1:                                # %entry
	addi	a8, a3, 24
	j	.LBB104_3
.LBB104_2:
	addi	a8, a10, 20
.LBB104_3:                              # %entry
	l32i	a5, a8, 0
	l32i	a2, a10, 4
	l8ui	a12, a3, 3
	l8ui	a6, a3, 22
	l16ui	a11, a3, 20
	l32i	a8, a10, 0
	l32i	a8, a8, 60
	or	a13, a6, a6
	or	a14, a5, a5
	movi	a15, 0
	callx8	a8
	l8ui	a9, a3, 3
	l32i	a8, a3, 4
	movi	a10, 31
	bltu	a10, a9, .LBB104_6
# %bb.4:                                # %source.label63
	beqz.n	a9, .LBB104_8
# %bb.5:                                # %source.label64
	movi	a10, -1
	ssr	a9
	srl	a10, a10
	neg	a9, a9
	extui	a9, a9, 0, 5
	ssl	a9
	sll	a8, a8
	or	a8, a8, a10
	movi	a9, 4
	j	.LBB104_7
.LBB104_6:                              # %source.label67
	memw
	s32i	a8, a2, 4
	movi	a8, -1
	movi	a9, 48
.LBB104_7:                              # %source.label68.sink.split
	add	a9, a2, a9
	memw
	s32i	a8, a9, 0
.LBB104_8:                              # %source.label68
	l8ui	a8, a3, 2
	bnez	a8, .LBB104_12
# %bb.9:                                # %source.label69
	movi	a8, 0
	beq	a6, a8, .LBB104_11
# %bb.10:                               # %source.label69
	l32r	a8, .LCPI104_0
.LBB104_11:                             # %source.label69
	memw
	l32i	a9, a2, 28
	l32r	a10, .LCPI104_1
	and	a9, a9, a10
	or	a8, a9, a8
	memw
	s32i	a8, a2, 28
	memw
	l32i	a8, a2, 32
	memw
	s32i	a8, a1, 32
	memw
	movi	a8, -256
	l32i	a9, a1, 32
	and	a8, a9, a8
	addi	a9, a6, -1
	extui	a9, a9, 0, 8
	or	a8, a8, a9
	memw
	s32i	a8, a1, 32
	memw
	l32i	a8, a1, 32
	memw
	s32i	a8, a2, 32
.LBB104_12:                             # %source.label74
	s32i	a6, a1, 20                      # 4-byte Folded Spill
	l8ui	a8, a3, 1
	movi	a6, 0
	movi	a9, 0
	beq	a8, a6, .LBB104_14
# %bb.13:                               # %source.label74
	l32r	a9, .LCPI104_2
.LBB104_14:                             # %source.label74
	memw
	l32i	a10, a2, 28
	l32r	a11, .LCPI104_3
	and	a10, a10, a11
	or	a9, a10, a9
	memw
	s32i	a9, a2, 28
	movi	a9, 0
	beq	a8, a6, .LBB104_16
# %bb.15:                               # %source.label74
	movi	a9, -256
.LBB104_16:                             # %source.label74
	slli	a8, a8, 11
	add	a8, a9, a8
	srli	a8, a8, 8
	memw
	l8ui	a9, a2, 43
	slli	a9, a9, 24
	or	a8, a9, a8
	memw
	s32i	a8, a2, 40
	l32i	a7, a3, 8
	s32i	a3, a1, 16                      # 4-byte Folded Spill
	l8ui	a4, a3, 1
	addi	a8, a4, 3
	srli	a8, a8, 2
	s32i	a8, a1, 48
	movi	a8, 128
	add	a8, a2, a8
	s32i	a8, a1, 28                      # 4-byte Folded Spill
	movi	a10, 4
	addi	a8, a1, 32
	or	a8, a8, a10
	s32i	a8, a1, 24                      # 4-byte Folded Spill
	movi	a11, 0
.LBB104_17:                             # %source.label79.outer
                                        # =>This Loop Header: Depth=1
                                        #     Child Loop BB104_18 Depth 2
	movi	a8, 1
.LBB104_18:                             # %source.label79
                                        #   Parent Loop BB104_17 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	bbci	a8, 0, .LBB104_21
# %bb.19:                               # %source.label80
                                        #   in Loop: Header=BB104_18 Depth=2
	movi	a8, 0
	l32i	a9, a1, 48
	bge	a6, a9, .LBB104_18
# %bb.20:                               # %source.label81
                                        #   in Loop: Header=BB104_17 Depth=1
	or	a3, a2, a2
	l32i	a2, a1, 24                      # 4-byte Folded Reload
	s32i	a11, a2, 0
	s32i	a5, a1, 12                      # 4-byte Folded Spill
	minu	a5, a4, a10
	or	a10, a2, a2
	or	a11, a7, a7
	or	a12, a5, a5
	call8	abla_fn_334943840_569200394_direct
	movi	a11, 0
	movi	a10, 4
	l32i	a8, a1, 28                      # 4-byte Folded Reload
	addx4	a8, a6, a8
	l32i	a9, a2, 0
	or	a2, a3, a3
	memw
	s32i	a9, a8, 0
	add	a7, a5, a7
	sub	a4, a4, a5
	l32i	a5, a1, 12                      # 4-byte Folded Reload
	addi	a6, a6, 1
	j	.LBB104_17
.LBB104_21:                             # %source.label88
	l32i	a6, a1, 16                      # 4-byte Folded Reload
	l8ui	a8, a6, 2
	movi	a9, 0
	movi	a11, 0
	beq	a8, a9, .LBB104_23
# %bb.22:                               # %source.label88
	l32r	a11, .LCPI104_4
.LBB104_23:                             # %source.label88
	memw
	l32i	a10, a2, 28
	l32r	a12, .LCPI104_5
	and	a10, a10, a12
	or	a10, a10, a11
	memw
	s32i	a10, a2, 28
	movi	a10, 0
	l32i	a13, a1, 20                     # 4-byte Folded Reload
	beq	a8, a9, .LBB104_25
# %bb.24:                               # %source.label88
	movi	a10, -256
.LBB104_25:                             # %source.label88
	slli	a8, a8, 11
	add	a8, a10, a8
	srli	a8, a8, 8
	memw
	l8ui	a9, a2, 47
	slli	a9, a9, 24
	or	a8, a9, a8
	memw
	s32i	a8, a2, 44
	memw
	l32i	a8, a2, 0
	l32r	a9, .LCPI104_6
	or	a8, a8, a9
	memw
	s32i	a8, a2, 0
	l32i	a10, a1, 52
	l32i	a8, a10, 0
	l32i	a8, a8, 64
	or	a14, a5, a5
	movi	a15, 0
	callx8	a8
	l8ui	a7, a6, 2
	beqz	a7, .LBB104_39
# %bb.26:                               # %source.label92
	l32i	a6, a6, 12
	extui	a8, a6, 0, 2
	beqz	a8, .LBB104_32
# %bb.27:                               # %source.label95.preheader
	addi	a8, a7, 3
	srli	a4, a8, 2
	movi	a3, 0
	movi	a2, 4
.LBB104_28:                             # %source.label95.outer
                                        # =>This Loop Header: Depth=1
                                        #     Child Loop BB104_29 Depth 2
	movi	a8, 1
.LBB104_29:                             # %source.label95
                                        #   Parent Loop BB104_28 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	bbsi	a8, 0, .LBB104_30
	j	.LBB104_39
.LBB104_30:                             # %source.label96
                                        #   in Loop: Header=BB104_29 Depth=2
	movi	a8, 0
	bgeu	a3, a4, .LBB104_29
# %bb.31:                               # %source.label97
                                        #   in Loop: Header=BB104_28 Depth=1
	l32i	a8, a1, 28                      # 4-byte Folded Reload
	addx4	a8, a3, a8
	memw
	l32i	a8, a8, 0
	l32i	a11, a1, 24                     # 4-byte Folded Reload
	s32i	a8, a11, 0
	minu	a5, a7, a2
	or	a10, a6, a6
	or	a12, a5, a5
	call8	abla_fn_334943840_569200394_direct
	sub	a7, a7, a5
	add	a6, a5, a6
	addi	a3, a3, 1
	j	.LBB104_28
.LBB104_32:                             # %source.label105
	extui	a8, a7, 0, 2
	beqz	a8, .LBB104_38
# %bb.33:                               # %source.label108.preheader
	addi	a8, a7, 3
	srli	a4, a8, 2
	movi	a3, 0
	movi	a2, 4
.LBB104_34:                             # %source.label108.outer
                                        # =>This Loop Header: Depth=1
                                        #     Child Loop BB104_35 Depth 2
	movi	a8, 1
.LBB104_35:                             # %source.label108
                                        #   Parent Loop BB104_34 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	bbci	a8, 0, .LBB104_39
# %bb.36:                               # %source.label109
                                        #   in Loop: Header=BB104_35 Depth=2
	movi	a8, 0
	bgeu	a3, a4, .LBB104_35
# %bb.37:                               # %source.label110
                                        #   in Loop: Header=BB104_34 Depth=1
	l32i	a8, a1, 28                      # 4-byte Folded Reload
	addx4	a8, a3, a8
	memw
	l32i	a8, a8, 0
	l32i	a11, a1, 24                     # 4-byte Folded Reload
	s32i	a8, a11, 0
	minu	a5, a7, a2
	or	a10, a6, a6
	or	a12, a5, a5
	call8	abla_fn_334943840_569200394_direct
	sub	a7, a7, a5
	add	a6, a5, a6
	addi	a3, a3, 1
	j	.LBB104_34
.LBB104_38:                             # %source.label118
	or	a10, a6, a6
	l32i	a11, a1, 28                     # 4-byte Folded Reload
	or	a12, a7, a7
	call8	abla_fn_334943840_569200394_direct
.LBB104_39:                             # %source.label122
	movi	a2, 0
	retw.n
.Lfunc_end104:
	.size	abla_fn_408654605_297463740_direct, .Lfunc_end104-abla_fn_408654605_297463740_direct
                                        # -- End function
	.literal_position
	.literal .LCPI105_0, 2080374783
	.literal .LCPI105_1, 268435456
	.literal .LCPI105_2, -268435457
	.literal .LCPI105_3, 16777215
	.literal .LCPI105_4, 262144
	.section	.text.abla_fn_408654605_297463740_direct,"ax",@progbits
	.section	.text.abla_fn_825130761_53798174_direct,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_825130761_53798174_direct
	.type	abla_fn_825130761_53798174_direct,@function
abla_fn_825130761_53798174_direct:      # @abla_fn_825130761_53798174_direct
# %bb.0:                                # %entry
	entry	a1, 80
	or	a10, a2, a2
	l32i	a7, a10, 4
	memw
	l8ui	a8, a7, 31
	bbci	a8, 6, .LBB105_6
# %bb.1:                                # %source.label44
	memw
	l32i	a8, a7, 32
	l32r	a9, .LCPI105_0
	bltu	a9, a8, .LBB105_4
# %bb.2:                                # %source.label45
	extui	a8, a8, 26, 6
	addi	a8, a8, 1
	movi	a9, 120
	and	a9, a8, a9
	beqz.n	a9, .LBB105_6
# %bb.3:                                # %source.label46
	movi	a11, -1
	ssr	a9
	srl	a9, a11
	movi	a11, 24
	and	a8, a8, a11
	neg	a8, a8
	and	a8, a8, a11
	ssl	a8
	sll	a8, a4
	or	a8, a8, a9
	movi	a9, 4
	j	.LBB105_5
.LBB105_4:                              # %source.label49
	memw
	s32i	a4, a7, 4
	movi	a8, -1
	movi	a9, 48
.LBB105_5:                              # %source.label51.sink.split
	add	a9, a7, a9
	memw
	s32i	a8, a9, 0
.LBB105_6:                              # %source.label51
	slli	a8, a5, 3
	movi	a9, 0
	bne	a8, a9, .LBB105_8
# %bb.7:                                # %source.label51
	movi	a12, 0
	j	.LBB105_9
.LBB105_8:
	l32r	a12, .LCPI105_1
.LBB105_9:                              # %source.label51
	memw
	l32i	a11, a7, 28
	l32r	a13, .LCPI105_2
	and	a11, a11, a13
	or	a11, a11, a12
	memw
	s32i	a11, a7, 28
	movi	a11, 1
	bne	a8, a9, .LBB105_11
# %bb.10:                               # %source.label51
	movi	a11, 0
.LBB105_11:                             # %source.label51
	subx8	a8, a5, a11
	l32r	a9, .LCPI105_3
	and	a8, a8, a9
	memw
	l8ui	a9, a7, 47
	slli	a9, a9, 24
	or	a8, a9, a8
	memw
	s32i	a8, a7, 44
	memw
	l32i	a8, a7, 0
	l32r	a9, .LCPI105_4
	or	a8, a8, a9
	memw
	s32i	a8, a7, 0
	l32i	a8, a10, 0
	l32i	a8, a8, 64
	movi	a14, 0
	movi	a15, 0
	callx8	a8
	beqz	a5, .LBB105_25
# %bb.12:                               # %source.label55
	extui	a8, a3, 0, 2
	beqz	a8, .LBB105_18
# %bb.13:                               # %source.label58.preheader
	movi	a8, 128
	add	a6, a7, a8
	addi	a8, a5, 3
	srli	a4, a8, 2
	movi	a2, 0
	movi	a9, 4
.LBB105_14:                             # %source.label58.outer
                                        # =>This Loop Header: Depth=1
                                        #     Child Loop BB105_15 Depth 2
	movi	a8, 1
.LBB105_15:                             # %source.label58
                                        #   Parent Loop BB105_14 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	bbsi	a8, 0, .LBB105_16
	j	.LBB105_25
.LBB105_16:                             # %source.label59
                                        #   in Loop: Header=BB105_15 Depth=2
	movi	a8, 0
	bgeu	a2, a4, .LBB105_15
# %bb.17:                               # %source.label60
                                        #   in Loop: Header=BB105_14 Depth=1
	addx4	a8, a2, a6
	memw
	l32i	a8, a8, 0
	s32i	a8, a1, 0
	minu	a7, a5, a9
	addi	a11, a1, 0
	or	a10, a3, a3
	or	a12, a7, a7
	call8	abla_fn_334943840_569200394_direct
	movi	a9, 4
	sub	a5, a5, a7
	add	a3, a7, a3
	addi	a2, a2, 1
	j	.LBB105_14
.LBB105_18:                             # %source.label68
	extui	a8, a5, 0, 2
	beqz	a8, .LBB105_24
# %bb.19:                               # %source.label71.preheader
	movi	a8, 128
	add	a6, a7, a8
	addi	a8, a5, 3
	srli	a4, a8, 2
	movi	a2, 0
	movi	a9, 4
.LBB105_20:                             # %source.label71.outer
                                        # =>This Loop Header: Depth=1
                                        #     Child Loop BB105_21 Depth 2
	movi	a8, 1
.LBB105_21:                             # %source.label71
                                        #   Parent Loop BB105_20 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	bbci	a8, 0, .LBB105_25
# %bb.22:                               # %source.label72
                                        #   in Loop: Header=BB105_21 Depth=2
	movi	a8, 0
	bgeu	a2, a4, .LBB105_21
# %bb.23:                               # %source.label73
                                        #   in Loop: Header=BB105_20 Depth=1
	addx4	a8, a2, a6
	memw
	l32i	a8, a8, 0
	s32i	a8, a1, 0
	minu	a7, a5, a9
	addi	a11, a1, 0
	or	a10, a3, a3
	or	a12, a7, a7
	call8	abla_fn_334943840_569200394_direct
	movi	a9, 4
	sub	a5, a5, a7
	add	a3, a7, a3
	addi	a2, a2, 1
	j	.LBB105_20
.LBB105_24:                             # %source.label81
	movi	a8, 128
	add	a11, a7, a8
	or	a10, a3, a3
	or	a12, a5, a5
	call8	abla_fn_334943840_569200394_direct
.LBB105_25:                             # %source.label85
	movi	a2, 0
	retw.n
.Lfunc_end105:
	.size	abla_fn_825130761_53798174_direct, .Lfunc_end105-abla_fn_825130761_53798174_direct
                                        # -- End function
	.literal_position
	.literal .LCPI106_0, 4194304
	.section	.text.abla_fn_825130761_53798174_direct,"ax",@progbits
	.section	.text.abla_fn_211640061_192638264_direct,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_211640061_192638264_direct
	.type	abla_fn_211640061_192638264_direct,@function
abla_fn_211640061_192638264_direct:     # @abla_fn_211640061_192638264_direct
# %bb.0:                                # %entry
	entry	a1, 32
	l32i	a8, a2, 4
	memw
	l32i	a9, a8, 0
	l32r	a11, .LCPI106_0
	or	a9, a9, a11
	memw
	s32i	a9, a8, 0
	l32i	a8, a2, 0
	l32i	a8, a8, 64
	or	a10, a2, a2
	callx8	a8
	retw.n
.Lfunc_end106:
	.size	abla_fn_211640061_192638264_direct, .Lfunc_end106-abla_fn_211640061_192638264_direct
                                        # -- End function
	.literal_position
	.literal .LCPI107_0, 67108863
	.literal .LCPI107_1, 1543503872
	.literal .LCPI107_2, 1073741824
	.literal .LCPI107_3, 16777215
	.literal .LCPI107_4, 16777216
	.section	.text.abla_fn_211640061_192638264_direct,"ax",@progbits
	.section	.text.abla_fn_388532938_210786097_direct,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_388532938_210786097_direct
	.type	abla_fn_388532938_210786097_direct,@function
abla_fn_388532938_210786097_direct:     # @abla_fn_388532938_210786097_direct
# %bb.0:                                # %entry
	entry	a1, 32
	l32i	a8, a2, 4
	memw
	l32i	a9, a8, 32
	l32r	a10, .LCPI107_0
	and	a9, a9, a10
	l32r	a10, .LCPI107_1
	or	a9, a9, a10
	memw
	s32i	a9, a8, 32
	memw
	l32i	a9, a8, 28
	l32r	a10, .LCPI107_2
	or	a9, a9, a10
	memw
	s32i	a9, a8, 28
	l32r	a9, .LCPI107_3
	and	a9, a3, a9
	memw
	s32i	a9, a8, 4
	memw
	movi	a9, 0
	s32i	a9, a8, 8
	memw
	l32i	a9, a8, 0
	l32r	a11, .LCPI107_4
	or	a9, a9, a11
	memw
	s32i	a9, a8, 0
	l32i	a8, a2, 0
	l32i	a8, a8, 64
	or	a10, a2, a2
	callx8	a8
	retw.n
.Lfunc_end107:
	.size	abla_fn_388532938_210786097_direct, .Lfunc_end107-abla_fn_388532938_210786097_direct
                                        # -- End function
	.literal_position
	.literal .LCPI108_0, 67108863
	.literal .LCPI108_1, 1543503872
	.literal .LCPI108_2, 1073741824
	.literal .LCPI108_3, 16777215
	.literal .LCPI108_4, 8388608
	.section	.text.abla_fn_388532938_210786097_direct,"ax",@progbits
	.section	.text.abla_fn_915500565_990736757_direct,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_915500565_990736757_direct
	.type	abla_fn_915500565_990736757_direct,@function
abla_fn_915500565_990736757_direct:     # @abla_fn_915500565_990736757_direct
# %bb.0:                                # %entry
	entry	a1, 32
	l32i	a8, a2, 4
	memw
	l32i	a9, a8, 32
	l32r	a10, .LCPI108_0
	and	a9, a9, a10
	l32r	a10, .LCPI108_1
	or	a9, a9, a10
	memw
	s32i	a9, a8, 32
	memw
	l32i	a9, a8, 28
	l32r	a10, .LCPI108_2
	or	a9, a9, a10
	memw
	s32i	a9, a8, 28
	l32r	a9, .LCPI108_3
	and	a9, a3, a9
	memw
	s32i	a9, a8, 4
	memw
	l32i	a9, a8, 0
	l32r	a11, .LCPI108_4
	or	a9, a9, a11
	memw
	s32i	a9, a8, 0
	l32i	a8, a2, 0
	l32i	a8, a8, 64
	or	a10, a2, a2
	callx8	a8
	retw.n
.Lfunc_end108:
	.size	abla_fn_915500565_990736757_direct, .Lfunc_end108-abla_fn_915500565_990736757_direct
                                        # -- End function
	.literal_position
	.literal .LCPI109_0, 67108863
	.literal .LCPI109_1, 1543503872
	.literal .LCPI109_2, 1073741824
	.literal .LCPI109_3, 16777215
	.literal .LCPI109_4, -536870913
	.literal .LCPI109_5, 33554432
	.section	.text.abla_fn_915500565_990736757_direct,"ax",@progbits
	.section	.text.abla_fn_320681036_795427026_direct,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_320681036_795427026_direct
	.type	abla_fn_320681036_795427026_direct,@function
abla_fn_320681036_795427026_direct:     # @abla_fn_320681036_795427026_direct
# %bb.0:                                # %entry
	entry	a1, 96
	l32i	a6, a2, 4
	memw
	l32i	a8, a6, 32
	l32r	a9, .LCPI109_0
	and	a8, a8, a9
	l32r	a9, .LCPI109_1
	or	a8, a8, a9
	memw
	s32i	a8, a6, 32
	memw
	l32i	a8, a6, 28
	l32r	a9, .LCPI109_2
	or	a8, a8, a9
	memw
	s32i	a8, a6, 28
	l32r	a8, .LCPI109_3
	and	a8, a4, a8
	slli	a9, a5, 24
	or	a8, a9, a8
	memw
	s32i	a8, a6, 4
	memw
	l32i	a8, a6, 28
	l32r	a9, .LCPI109_4
	and	a8, a8, a9
	memw
	s32i	a8, a6, 28
	movi	a8, 128
	add	a10, a6, a8
	addi	a8, a5, 3
	srli	a4, a8, 2
	movi	a9, 0
	movi	a11, 4
	movi	a7, 0
.LBB109_1:                              # %source.label.i.outer
                                        # =>This Loop Header: Depth=1
                                        #     Child Loop BB109_2 Depth 2
	movi	a8, 1
.LBB109_2:                              # %source.label.i
                                        #   Parent Loop BB109_1 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	bbci	a8, 0, .LBB109_5
# %bb.3:                                # %source.label27.i
                                        #   in Loop: Header=BB109_2 Depth=2
	movi	a8, 0
	bgeu	a7, a4, .LBB109_2
# %bb.4:                                # %source.label28.i
                                        #   in Loop: Header=BB109_1 Depth=1
	s32i	a9, a1, 16
	s32i	a2, a1, 12                      # 4-byte Folded Spill
	minu	a2, a5, a11
	s32i	a5, a1, 8                       # 4-byte Folded Spill
	or	a5, a10, a10
	addi	a10, a1, 16
	or	a11, a3, a3
	or	a12, a2, a2
	call8	abla_fn_334943840_569200394_direct
	movi	a11, 4
	or	a10, a5, a5
	l32i	a5, a1, 8                       # 4-byte Folded Reload
	addx4	a8, a7, a10
	l32i	a9, a1, 16
	memw
	s32i	a9, a8, 0
	movi	a9, 0
	add	a3, a2, a3
	sub	a5, a5, a2
	l32i	a2, a1, 12                      # 4-byte Folded Reload
	addi	a7, a7, 1
	j	.LBB109_1
.LBB109_5:                              # %abla_fn_307479163_820821885_direct.exit
	memw
	l32i	a8, a6, 0
	l32r	a9, .LCPI109_5
	or	a8, a8, a9
	memw
	s32i	a8, a6, 0
	l32i	a8, a2, 0
	l32i	a8, a8, 64
	or	a10, a2, a2
	callx8	a8
	retw.n
.Lfunc_end109:
	.size	abla_fn_320681036_795427026_direct, .Lfunc_end109-abla_fn_320681036_795427026_direct
                                        # -- End function
	.literal_position
	.literal .LCPI110_0, 536870912
	.literal .LCPI110_1, 1073741824
	.section	.text.abla_fn_320681036_795427026_direct,"ax",@progbits
	.section	.text.abla_fn_641427985_702920430_direct,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_641427985_702920430_direct
	.type	abla_fn_641427985_702920430_direct,@function
abla_fn_641427985_702920430_direct:     # @abla_fn_641427985_702920430_direct
# %bb.0:                                # %entry
	entry	a1, 32
	or	a10, a2, a2
	extui	a8, a3, 0, 8
	movi	a9, 0
	beq	a8, a9, .LBB110_2
# %bb.1:                                # %entry
	l32r	a11, .LCPI110_0
	j	.LBB110_3
.LBB110_2:
	l32r	a11, .LCPI110_1
.LBB110_3:                              # %entry
	l32i	a8, a10, 4
	memw
	l32i	a9, a8, 0
	or	a9, a9, a11
	memw
	s32i	a9, a8, 0
	l32i	a8, a10, 0
	l32i	a8, a8, 64
	movi	a12, 0
	movi	a13, 0
	movi	a14, 0
	movi	a15, 0
	callx8	a8
	movi	a2, 0
	retw.n
.Lfunc_end110:
	.size	abla_fn_641427985_702920430_direct, .Lfunc_end110-abla_fn_641427985_702920430_direct
                                        # -- End function
	.literal_position
	.literal .LCPI111_0, 1072963584
	.literal .LCPI111_1, 1072967928
	.section	.text.abla_fn_641427985_702920430_direct,"ax",@progbits
	.section	.text.abla_fn_962365924_831598467_direct,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_962365924_831598467_direct
	.type	abla_fn_962365924_831598467_direct,@function
abla_fn_962365924_831598467_direct:     # @abla_fn_962365924_831598467_direct
# %bb.0:                                # %entry
	entry	a1, 32
	l32i	a10, a2, 4
	memw
	l32i	a8, a10, 248
	extui	a9, a8, 0, 3
	#APP
	nsau	a9, a9
	#NO_APP
	l32r	a11, .LCPI111_0
	bne	a10, a11, .LBB111_2
# %bb.1:                                # %source.label
	memw
	l32r	a9, .LCPI111_1
	l32i	a9, a9, 0
	or	a8, a9, a8
	extui	a8, a8, 0, 3
	#APP
	nsau	a9, a8
	#NO_APP
.LBB111_2:                              # %source.label18
	srli	a2, a9, 5
	retw.n
.Lfunc_end111:
	.size	abla_fn_962365924_831598467_direct, .Lfunc_end111-abla_fn_962365924_831598467_direct
                                        # -- End function
	.section	.text.abla_fn_590569238_852306334_direct,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_590569238_852306334_direct
	.type	abla_fn_590569238_852306334_direct,@function
abla_fn_590569238_852306334_direct:     # @abla_fn_590569238_852306334_direct
# %bb.0:                                # %entry
	entry	a1, 32
	movi	a2, 0
	retw.n
.Lfunc_end112:
	.size	abla_fn_590569238_852306334_direct, .Lfunc_end112-abla_fn_590569238_852306334_direct
                                        # -- End function
	.section	.text.unlikely.abla_fn_174183453_688535431_direct,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_174183453_688535431_direct
	.type	abla_fn_174183453_688535431_direct,@function
abla_fn_174183453_688535431_direct:     # @abla_fn_174183453_688535431_direct
# %bb.0:                                # %entry
	entry	a1, 32
	ill.n
.Lfunc_end113:
	.size	abla_fn_174183453_688535431_direct, .Lfunc_end113-abla_fn_174183453_688535431_direct
                                        # -- End function
	.section	.text.unlikely.abla_fn_597847875_749602468_direct,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_597847875_749602468_direct
	.type	abla_fn_597847875_749602468_direct,@function
abla_fn_597847875_749602468_direct:     # @abla_fn_597847875_749602468_direct
# %bb.0:                                # %entry
	entry	a1, 32
	ill.n
.Lfunc_end114:
	.size	abla_fn_597847875_749602468_direct, .Lfunc_end114-abla_fn_597847875_749602468_direct
                                        # -- End function
	.section	.text.abla_fn_841534189_540168598_direct,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_841534189_540168598_direct
	.type	abla_fn_841534189_540168598_direct,@function
abla_fn_841534189_540168598_direct:     # @abla_fn_841534189_540168598_direct
# %bb.0:                                # %entry
	entry	a1, 96
	movi	a8, 0
	s32i	a8, a1, 0
	movi	a8, 4
	addi	a6, a1, 0
	or	a7, a6, a8
	or	a10, a7, a7
	movi	a11, 0
	movi	a12, 28
	call8	abla_fn_853840267_528021067_direct
	movi	a8, 5
	s16i	a8, a1, 24
	s32i	a6, a1, 16
	movi	a8, 1
	s8i	a8, a1, 6
	l32i	a8, a2, 0
	l32i	a8, a8, 4
	or	a10, a2, a2
	or	a11, a7, a7
	callx8	a8
	bnez.n	a10, .LBB115_2
# %bb.1:                                # %source.label
	l32i	a8, a1, 0
	s8i	a8, a3, 0
.LBB115_2:                              # %source.label23
	or	a2, a10, a10
	retw.n
.Lfunc_end115:
	.size	abla_fn_841534189_540168598_direct, .Lfunc_end115-abla_fn_841534189_540168598_direct
                                        # -- End function
	.section	.text.abla_fn_548196426_722170064_direct,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_548196426_722170064_direct
	.type	abla_fn_548196426_722170064_direct,@function
abla_fn_548196426_722170064_direct:     # @abla_fn_548196426_722170064_direct
# %bb.0:                                # %entry
	entry	a1, 32
	l8ui	a8, a2, 36
	bbci	a8, 0, .LBB116_6
# %bb.1:                                # %source.label
	extui	a8, a4, 0, 1
	bbsi	a3, 0, .LBB116_3
# %bb.2:                                # %source.label16
	add	a4, a8, a4
	j	.LBB116_6
.LBB116_3:                              # %source.label20
	addi	a3, a3, -1
	bnez.n	a8, .LBB116_5
# %bb.4:                                # %source.label21
	addi	a4, a4, 2
	j	.LBB116_6
.LBB116_5:                              # %source.label22
	addi	a4, a4, 1
.LBB116_6:                              # %source.label26
	beqz.n	a6, .LBB116_8
# %bb.7:                                # %scalar.divide.checked
	s32i	a3, a5, 0
	remu	a8, a3, a6
	sub	a8, a6, a8
	minu	a8, a8, a4
	movi	a9, 64
	minu	a2, a8, a9
	retw.n
.LBB116_8:                              # %scalar.division.by.zero
	ill.n
.Lfunc_end116:
	.size	abla_fn_548196426_722170064_direct, .Lfunc_end116-abla_fn_548196426_722170064_direct
                                        # -- End function
	.section	.text.abla_fn_770566306_790016489_direct,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_770566306_790016489_direct
	.type	abla_fn_770566306_790016489_direct,@function
abla_fn_770566306_790016489_direct:     # @abla_fn_770566306_790016489_direct
# %bb.0:                                # %entry
	entry	a1, 32
	l8ui	a8, a2, 36
	bbci	a8, 0, .LBB117_6
# %bb.1:                                # %source.label
	extui	a8, a4, 0, 1
	bbsi	a3, 0, .LBB117_3
# %bb.2:                                # %source.label16
	add	a4, a8, a4
	j	.LBB117_6
.LBB117_3:                              # %source.label20
	addi	a3, a3, -1
	bnez.n	a8, .LBB117_5
# %bb.4:                                # %source.label21
	addi	a4, a4, 2
	j	.LBB117_6
.LBB117_5:                              # %source.label22
	addi	a4, a4, 1
.LBB117_6:                              # %source.label26
	s32i	a3, a5, 0
	movi	a8, 64
	minu	a2, a4, a8
	retw.n
.Lfunc_end117:
	.size	abla_fn_770566306_790016489_direct, .Lfunc_end117-abla_fn_770566306_790016489_direct
                                        # -- End function
	.literal_position
	.literal .LCPI118_0, -16777215
	.literal .LCPI118_1, .Labla_string_abla_fn_627837887_633683867_1604.native.bytes
	.literal .LCPI118_2, .Labla_string_abla_fn_627837887_633683867_1597.native.bytes
	.literal .LCPI118_3, 16711680
	.literal .LCPI118_4, 65280
	.section	.text.abla_fn_770566306_790016489_direct,"ax",@progbits
	.section	.text.abla_fn_657068560_251506979_direct,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_657068560_251506979_direct
	.type	abla_fn_657068560_251506979_direct,@function
abla_fn_657068560_251506979_direct:     # @abla_fn_657068560_251506979_direct
# %bb.0:                                # %entry
	entry	a1, 128
	or	a6, a2, a2
	movi	a2, 0
	s32i	a2, a1, 32
	movi	a8, 4
	addi	a5, a1, 32
	or	a7, a5, a8
	or	a10, a7, a7
	movi	a11, 0
	movi	a12, 28
	call8	abla_fn_853840267_528021067_direct
	movi	a8, 159
	s16i	a8, a1, 56
	s32i	a5, a1, 48
	movi	a8, 3
	s8i	a8, a1, 38
	l32i	a8, a6, 0
	l32i	a8, a8, 4
	or	a10, a6, a6
	or	a11, a7, a7
	callx8	a8
	l32r	a9, .LCPI118_0
	l32i	a8, a1, 32
	add	a9, a8, a9
	#APP
	nsau	a9, a9
	#NO_APP
	#APP
	nsau	a10, a8
	#NO_APP
	or	a9, a10, a9
	movi	a10, 31
	bltu	a10, a9, .LBB118_2
# %bb.1:                                # %source.label
	slli	a9, a8, 16
	l32r	a10, .LCPI118_3
	and	a9, a9, a10
	l32r	a10, .LCPI118_4
	and	a10, a8, a10
	extui	a8, a8, 16, 16
	or	a8, a8, a10
	or	a8, a8, a9
	s32i	a8, a3, 0
	retw.n
.LBB118_2:                              # %source.label22
	call8	abla_fn_11786425_863113934_direct
	or	a11, a10, a10
	l32i	a14, a7, 0
	l32i	a13, a1, 32
	l32i	a15, a1, 40
	l32i	a8, a1, 44
	l32i	a9, a1, 48
	l32i	a10, a1, 52
	l32i	a12, a1, 56
	l32i	a7, a1, 60
	l32i	a6, a1, 64
	l32i	a5, a1, 68
	s32i	a5, a1, 24
	s32i	a6, a1, 20
	s32i	a7, a1, 16
	s32i	a12, a1, 12
	s32i	a10, a1, 8
	s32i	a9, a1, 4
	s32i	a8, a1, 0
	l32r	a10, .LCPI118_1
	l32r	a12, .LCPI118_2
	call8	abla_fn_248569758_289064282_direct
	movi	a2, 264
	retw.n
.Lfunc_end118:
	.size	abla_fn_657068560_251506979_direct, .Lfunc_end118-abla_fn_657068560_251506979_direct
                                        # -- End function
	.literal_position
	.literal .LCPI119_0, 1072963584
	.literal .LCPI119_1, -65536
	.literal .LCPI119_2, 65535
	.literal .LCPI119_3, abla_static_abla_fn_627837887_633683867_2249
	.literal .LCPI119_4, abla_fn_368275349_679717816_direct
	.literal .LCPI119_5, 1073406580
	.literal .LCPI119_6, 65536
	.section	.text.abla_fn_657068560_251506979_direct,"ax",@progbits
	.section	.text.abla_fn_127496518_302417924_direct,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_127496518_302417924_direct
	.type	abla_fn_127496518_302417924_direct,@function
abla_fn_127496518_302417924_direct:     # @abla_fn_127496518_302417924_direct
# %bb.0:                                # %entry
	entry	a1, 32
	l32i	a8, a2, 4
	l32r	a9, .LCPI119_0
	beq	a8, a9, .LBB119_1
	j	.LBB119_28
.LBB119_1:                              # %source.label
	l32r	a9, .LCPI119_1
	and	a8, a3, a9
	l32r	a10, .LCPI119_2
	and	a11, a3, a10
	add	a11, a4, a11
	add	a10, a11, a10
	and	a9, a10, a9
	add	a9, a9, a8
	l32r	a10, .LCPI119_3
	l32i	a11, a10, 0
	movi	a15, 6
	movi	a12, 40
	movi	a13, 0
.LBB119_2:                              # %source.label.i
                                        # =>This Loop Header: Depth=1
                                        #     Child Loop BB119_6 Depth 2
                                        #       Child Loop BB119_7 Depth 3
                                        #       Child Loop BB119_10 Depth 3
	extui	a14, a15, 0, 3
	beqi	a14, 6, .LBB119_3
	j	.LBB119_26
.LBB119_3:                              # %source.label19.i
                                        #   in Loop: Header=BB119_2 Depth=1
	movi	a15, 7
	bgeu	a8, a9, .LBB119_2
# %bb.4:                                # %source.label20.i
                                        #   in Loop: Header=BB119_2 Depth=1
	l32r	a14, .LCPI119_5
	l32i	a14, a14, 0
	movi	a15, 5
	bgeu	a8, a14, .LBB119_2
# %bb.5:                                # %source.label20.i.i.i.outer.preheader
                                        #   in Loop: Header=BB119_2 Depth=1
	movi	a15, 0
	movi	a14, 0
.LBB119_6:                              # %source.label20.i.i.i.outer
                                        #   Parent Loop BB119_2 Depth=1
                                        # =>  This Loop Header: Depth=2
                                        #       Child Loop BB119_7 Depth 3
                                        #       Child Loop BB119_10 Depth 3
	movi	a7, 1
.LBB119_7:                              # %source.label20.i.i.i
                                        #   Parent Loop BB119_2 Depth=1
                                        #     Parent Loop BB119_6 Depth=2
                                        # =>    This Inner Loop Header: Depth=3
	bbci	a7, 0, .LBB119_22
# %bb.8:                                # %source.label21.i.i.i
                                        #   in Loop: Header=BB119_7 Depth=3
	movi	a7, 0
	bgeu	a15, a11, .LBB119_7
# %bb.9:                                # %source.label22.i.i.i
                                        #   in Loop: Header=BB119_6 Depth=2
	mull	a7, a15, a12
	add	a7, a10, a7
	l32i	a6, a7, 36
	movi	a4, 0
	or	a5, a6, a6
.LBB119_10:                             # %source.label24.i.i.i
                                        #   Parent Loop BB119_2 Depth=1
                                        #     Parent Loop BB119_6 Depth=2
                                        # =>    This Inner Loop Header: Depth=3
	extui	a4, a4, 0, 2
	bnez.n	a4, .LBB119_19
# %bb.11:                               # %source.label25.i.i.i
                                        #   in Loop: Header=BB119_10 Depth=3
	beqz.n	a5, .LBB119_16
# %bb.12:                               # %source.label26.i.i.i
                                        #   in Loop: Header=BB119_10 Depth=3
	beq	a5, a6, .LBB119_17
# %bb.13:                               # %source.label28.i.i.i
                                        #   in Loop: Header=BB119_10 Depth=3
	l32i	a4, a7, 40
	l32i	a4, a4, 4
	l32i	a4, a4, 0
	beq	a4, a5, .LBB119_18
# %bb.14:                               # %source.label30.i.i.i
                                        #   in Loop: Header=BB119_10 Depth=3
	l32i	a4, a5, 24
	bltu	a8, a4, .LBB119_18
# %bb.15:                               # %source.label32.i.i.i
                                        #   in Loop: Header=BB119_10 Depth=3
	l32i	a3, a5, 28
	movi	a4, 2
	bltu	a8, a3, .LBB119_10
	j	.LBB119_18
.LBB119_16:                             #   in Loop: Header=BB119_10 Depth=3
	movi	a4, 1
	movi	a5, 0
	j	.LBB119_10
.LBB119_17:                             #   in Loop: Header=BB119_10 Depth=3
	or	a5, a6, a6
.LBB119_18:                             # %source.label40.sink.split.i.i.i
                                        #   in Loop: Header=BB119_10 Depth=3
	l32i	a5, a5, 36
	movi	a4, 0
	j	.LBB119_10
.LBB119_19:                             # %source.label24.i.i.i
                                        #   in Loop: Header=BB119_6 Depth=2
	beqi	a4, 1, .LBB119_21
# %bb.20:                               # %source.label44.i.i.i.loopexit
                                        #   in Loop: Header=BB119_6 Depth=2
	movi	a14, 1
.LBB119_21:                             # %source.label44.i.i.i
                                        #   in Loop: Header=BB119_6 Depth=2
	addi	a15, a15, 1
	j	.LBB119_6
.LBB119_22:                             # %abla_fn_827937126_733782404_direct.exit.i
                                        #   in Loop: Header=BB119_2 Depth=1
	movi	a15, -2
	beq	a14, a13, .LBB119_24
# %bb.23:                               # %abla_fn_827937126_733782404_direct.exit.i
                                        #   in Loop: Header=BB119_2 Depth=1
	movi	a15, 3
.LBB119_24:                             # %abla_fn_827937126_733782404_direct.exit.i
                                        #   in Loop: Header=BB119_2 Depth=1
	beq	a14, a13, .LBB119_25
	j	.LBB119_2
.LBB119_25:                             #   in Loop: Header=BB119_2 Depth=1
	l32r	a14, .LCPI119_6
	add	a8, a8, a14
	j	.LBB119_2
.LBB119_26:                             # %source.label.i
	bnei	a14, 3, .LBB119_28
# %bb.27:                               # %source.label30.i
	l32r	a8, .LCPI119_4
	callx8	a8
.LBB119_28:                             # %source.label17
	movi	a2, 0
	retw.n
.Lfunc_end119:
	.size	abla_fn_127496518_302417924_direct, .Lfunc_end119-abla_fn_127496518_302417924_direct
                                        # -- End function
	.literal_position
	.literal .LCPI120_0, abla_fn_887465115_248809038_direct
	.section	.text.abla_fn_127496518_302417924_direct,"ax",@progbits
	.section	.text.abla_fn_225896877_719081260_direct,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_225896877_719081260_direct
	.type	abla_fn_225896877_719081260_direct,@function
abla_fn_225896877_719081260_direct:     # @abla_fn_225896877_719081260_direct
# %bb.0:                                # %entry
	entry	a1, 32
	or	a10, a3, a3
	l32r	a8, .LCPI120_0
	callx8	a8
	movi	a2, 0
	retw.n
.Lfunc_end120:
	.size	abla_fn_225896877_719081260_direct, .Lfunc_end120-abla_fn_225896877_719081260_direct
                                        # -- End function
	.literal_position
	.literal .LCPI121_0, abla_fn_764337598_298335200_direct
	.literal .LCPI121_1, abla_fn_799638508_495272519_direct
	.literal .LCPI121_2, abla_fn_180033588_623469740_direct
	.literal .LCPI121_3, abla_fn_764337598_298335200_direct
	.literal .LCPI121_4, abla_fn_799638508_495272519_direct
	.literal .LCPI121_5, abla_fn_180033588_623469740_direct
	.section	.text.abla_fn_225896877_719081260_direct,"ax",@progbits
	.section	.text.abla_fn_243591001_677668472_direct,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_243591001_677668472_direct
	.type	abla_fn_243591001_677668472_direct,@function
abla_fn_243591001_677668472_direct:     # @abla_fn_243591001_677668472_direct
# %bb.0:                                # %entry
	entry	a1, 32
	l32r	a8, .LCPI121_0
	callx8	a8
	l32r	a8, .LCPI121_1
	movi	a10, 0
	callx8	a8
	l32r	a8, .LCPI121_2
	callx8	a8
	l32r	a8, .LCPI121_3
	callx8	a8
	l32r	a8, .LCPI121_4
	movi	a10, 1
	callx8	a8
	l32r	a8, .LCPI121_5
	callx8	a8
	movi	a2, 0
	retw.n
.Lfunc_end121:
	.size	abla_fn_243591001_677668472_direct, .Lfunc_end121-abla_fn_243591001_677668472_direct
                                        # -- End function
	.literal_position
	.literal .LCPI122_0, abla_fn_764337598_298335200_direct
	.literal .LCPI122_1, abla_fn_675579554_510628185_direct
	.literal .LCPI122_2, abla_fn_180033588_623469740_direct
	.literal .LCPI122_3, abla_fn_764337598_298335200_direct
	.literal .LCPI122_4, abla_fn_675579554_510628185_direct
	.literal .LCPI122_5, abla_fn_180033588_623469740_direct
	.section	.text.abla_fn_243591001_677668472_direct,"ax",@progbits
	.section	.text.abla_fn_673055136_650356638_direct,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_673055136_650356638_direct
	.type	abla_fn_673055136_650356638_direct,@function
abla_fn_673055136_650356638_direct:     # @abla_fn_673055136_650356638_direct
# %bb.0:                                # %entry
	entry	a1, 32
	l32r	a8, .LCPI122_0
	callx8	a8
	l32r	a8, .LCPI122_1
	movi	a10, 0
	callx8	a8
	l32r	a8, .LCPI122_2
	callx8	a8
	l32r	a8, .LCPI122_3
	callx8	a8
	l32r	a8, .LCPI122_4
	movi	a10, 1
	callx8	a8
	l32r	a8, .LCPI122_5
	callx8	a8
	movi	a2, 0
	retw.n
.Lfunc_end122:
	.size	abla_fn_673055136_650356638_direct, .Lfunc_end122-abla_fn_673055136_650356638_direct
                                        # -- End function
	.literal_position
	.literal .LCPI123_0, .Labla_string_abla_fn_627837887_633683867_2033.native.mutable.u32s
	.literal .LCPI123_1, .Labla_string_abla_fn_627837887_633683867_1952.native.mutable.u32s
	.literal .LCPI123_2, abla_static_abla_fn_627837887_633683867_2081
	.literal .LCPI123_3, abla_static_abla_fn_627837887_633683867_2084
	.literal .LCPI123_4, .Labla_string_abla_fn_627837887_633683867_2000.native.mutable.u32s
	.literal .LCPI123_5, -1287651329
	.literal .LCPI123_6, 4194305
	.literal .LCPI123_7, 262165
	.literal .LCPI123_8, 16405
	.literal .LCPI123_9, 16384
	.literal .LCPI123_10, 33554432
	.literal .LCPI123_11, abla_static_abla_fn_627837887_633683867_4112
	.literal .LCPI123_12, 2052
	.section	.text.abla_fn_673055136_650356638_direct,"ax",@progbits
	.section	.text.abla_fn_338872068_789649821_direct,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_338872068_789649821_direct
	.type	abla_fn_338872068_789649821_direct,@function
abla_fn_338872068_789649821_direct:     # @abla_fn_338872068_789649821_direct
# %bb.0:                                # %entry
	entry	a1, 64
	l32r	a7, .LCPI123_0
	or	a10, a7, a7
	or	a11, a7, a7
	movi	a12, 72
	call8	abla_fn_334943840_569200394_direct
	movi	a8, 1
	movi	a9, 9
	addi	a10, a7, 4
.LBB123_1:                              # %source.label.i.i.i
                                        # =>This Loop Header: Depth=1
                                        #     Child Loop BB123_2 Depth 2
	or	a15, a8, a8
	beq	a8, a9, .LBB123_6
.LBB123_2:                              # %source.label8.i.i.i
                                        #   Parent Loop BB123_1 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	or	a13, a15, a15
	beqz.n	a13, .LBB123_5
# %bb.3:                                # %source.label9.i.i.i
                                        #   in Loop: Header=BB123_2 Depth=2
	addx8	a11, a13, a7
	l32i	a14, a11, 0
	addi	a11, a13, -1
	addx8	a12, a11, a7
	l32i	a12, a12, 0
	movi	a15, 0
	bgeu	a14, a12, .LBB123_2
# %bb.4:                                # %source.label13.i.i.i
                                        #   in Loop: Header=BB123_2 Depth=2
	slli	a13, a13, 3
	slli	a15, a11, 3
	add	a6, a15, a10
	l32i	a5, a6, 0
	add	a15, a7, a15
	s32i	a14, a15, 0
	add	a14, a13, a10
	l32i	a15, a14, 0
	s32i	a15, a6, 0
	add	a13, a7, a13
	s32i	a12, a13, 0
	s32i	a5, a14, 0
	or	a15, a11, a11
	j	.LBB123_2
.LBB123_5:                              # %source.label15.i.i.i
                                        #   in Loop: Header=BB123_1 Depth=1
	addi	a8, a8, 1
	j	.LBB123_1
.LBB123_6:                              # %source.label17.i.i.i.preheader
	movi	a8, 0
	movi	a9, 72
	movi	a10, -4
	beq	a8, a9, .LBB123_12
.LBB123_7:                              # %source.label18.i.i.i
                                        # =>This Inner Loop Header: Depth=1
	add	a12, a8, a7
	l32i	a11, a12, 0
	and	a11, a11, a10
	s32i	a11, a12, 0
	l32i	a13, a12, 4
	addi	a13, a13, 3
	and	a13, a13, a10
	s32i	a13, a12, 4
	bgeu	a13, a11, .LBB123_8
	j	.LBB123_108
.LBB123_8:                              # %source.label24.i.i.i
                                        #   in Loop: Header=BB123_7 Depth=1
	beqi	a8, 64, .LBB123_11
# %bb.9:                                # %source.label25.i.i.i
                                        #   in Loop: Header=BB123_7 Depth=1
	l32i	a12, a12, 8
	and	a12, a12, a10
	bltu	a11, a12, .LBB123_10
	j	.LBB123_108
.LBB123_10:                             # %source.label25.i.i.i
                                        #   in Loop: Header=BB123_7 Depth=1
	bgeu	a12, a13, .LBB123_11
	j	.LBB123_108
.LBB123_11:                             # %source.label17.i.i.i.backedge
                                        #   in Loop: Header=BB123_7 Depth=1
	addi	a8, a8, 8
	bne	a8, a9, .LBB123_7
.LBB123_12:                             # %source.label.i138.i.preheader
	movi	a6, 0
	movi	a9, 20
	movi	a11, 8
	movi	a13, 0
.LBB123_13:                             # %source.label.i138.i
                                        # =>This Loop Header: Depth=1
                                        #     Child Loop BB123_15 Depth 2
                                        #       Child Loop BB123_16 Depth 3
                                        #         Child Loop BB123_17 Depth 4
	movi	a8, 43
	bne	a13, a8, .LBB123_14
	j	.LBB123_32
.LBB123_14:                             # %source.label17.i.i
                                        #   in Loop: Header=BB123_13 Depth=1
	mull	a8, a13, a9
	l32r	a10, .LCPI123_1
	add	a14, a8, a10
	l32i	a4, a14, 0
	l32i	a8, a14, 4
	add	a15, a8, a4
	movi	a5, 0
.LBB123_15:                             # %source.label23.i.i.outer
                                        #   Parent Loop BB123_13 Depth=1
                                        # =>  This Loop Header: Depth=2
                                        #       Child Loop BB123_16 Depth 3
                                        #         Child Loop BB123_17 Depth 4
	movi	a2, 0
.LBB123_16:                             # %source.label23.i.i.outer
                                        #   Parent Loop BB123_13 Depth=1
                                        #     Parent Loop BB123_15 Depth=2
                                        # =>    This Loop Header: Depth=3
                                        #         Child Loop BB123_17 Depth 4
	slli	a8, a5, 3
	add	a8, a7, a8
.LBB123_17:                             # %source.label23.i.i
                                        #   Parent Loop BB123_13 Depth=1
                                        #     Parent Loop BB123_15 Depth=2
                                        #       Parent Loop BB123_16 Depth=3
                                        # =>      This Inner Loop Header: Depth=4
	mull	a10, a6, a9
	bltu	a11, a5, .LBB123_28
# %bb.18:                               # %source.label23.i.i
                                        #   in Loop: Header=BB123_17 Depth=4
	bbsi	a2, 0, .LBB123_28
# %bb.19:                               # %source.label28.i.i
                                        #   in Loop: Header=BB123_17 Depth=4
	l32i	a3, a8, 4
	bgeu	a4, a3, .LBB123_27
# %bb.20:                               # %source.label33.i.i
                                        #   in Loop: Header=BB123_17 Depth=4
	l32i	a12, a8, 0
	movi	a2, 1
	bgeu	a12, a15, .LBB123_17
# %bb.21:                               # %source.label35.i.i
                                        #   in Loop: Header=BB123_16 Depth=3
	bgeu	a4, a12, .LBB123_24
# %bb.22:                               # %source.label35.i.i
                                        #   in Loop: Header=BB123_16 Depth=3
	sub	a8, a12, a4
	movi	a12, 17
	bltu	a8, a12, .LBB123_24
# %bb.23:                               # %source.label40.i.i
                                        #   in Loop: Header=BB123_16 Depth=3
	addi	a6, a6, 1
	l32r	a12, .LCPI123_2
	add	a10, a10, a12
	s32i	a8, a10, 4
	s32i	a4, a10, 0
	l32i	a8, a14, 8
	s32i	a8, a10, 8
	l32i	a8, a14, 12
	s32i	a8, a10, 12
	l32i	a8, a14, 16
	s32i	a8, a10, 16
.LBB123_24:                             # %source.label43.i.i
                                        #   in Loop: Header=BB123_16 Depth=3
	bgeu	a3, a15, .LBB123_26
# %bb.25:                               # %source.label43.i.i
                                        #   in Loop: Header=BB123_16 Depth=3
	movi	a2, 0
.LBB123_26:                             # %source.label43.i.i
                                        #   in Loop: Header=BB123_16 Depth=3
	addi	a5, a5, 1
	or	a4, a3, a3
	j	.LBB123_16
.LBB123_27:                             # %source.label32.i.i
                                        #   in Loop: Header=BB123_15 Depth=2
	addi	a5, a5, 1
	j	.LBB123_15
.LBB123_28:                             # %source.label52.i.i
                                        #   in Loop: Header=BB123_13 Depth=1
	bgeu	a4, a15, .LBB123_31
# %bb.29:                               # %source.label52.i.i
                                        #   in Loop: Header=BB123_13 Depth=1
	sub	a8, a15, a4
	movi	a12, 17
	bltu	a8, a12, .LBB123_31
# %bb.30:                               # %source.label57.i.i
                                        #   in Loop: Header=BB123_13 Depth=1
	l32r	a12, .LCPI123_2
	add	a10, a10, a12
	s32i	a8, a10, 4
	s32i	a4, a10, 0
	l32i	a8, a14, 8
	s32i	a8, a10, 8
	l32i	a8, a14, 12
	s32i	a8, a10, 12
	l32i	a8, a14, 16
	s32i	a8, a10, 16
	addi	a6, a6, 1
.LBB123_31:                             # %source.label60.i.i
                                        #   in Loop: Header=BB123_13 Depth=1
	addi	a13, a13, 1
	j	.LBB123_13
.LBB123_32:                             # %source.label31.preheader.i
	movi	a8, 1
	maxu	a8, a6, a8
	addi	a8, a8, -1
	l32r	a9, .LCPI123_2
	addi	a9, a9, 36
	movi	a10, -1
	or	a4, a6, a6
	beqz	a8, .LBB123_38
.LBB123_33:                             # %source.label32.i
                                        # =>This Inner Loop Header: Depth=1
	addi	a11, a9, -36
	l32i	a12, a11, 0
	addi	a11, a9, -32
	l32i	a11, a11, 0
	add	a14, a11, a12
	addi	a13, a9, -16
	l32i	a15, a13, 0
	bne	a15, a14, .LBB123_37
# %bb.34:                               # %source.label38.i
                                        #   in Loop: Header=BB123_33 Depth=1
	addi	a14, a9, -28
	l32i	a15, a14, 0
	addi	a7, a9, -8
	l32i	a7, a7, 0
	bne	a7, a15, .LBB123_37
# %bb.35:                               # %source.label39.i
                                        #   in Loop: Header=BB123_33 Depth=1
	l32i	a15, a9, 0
	addi	a7, a9, -20
	l32i	a7, a7, 0
	bne	a15, a7, .LBB123_37
# %bb.36:                               # %source.label42.i
                                        #   in Loop: Header=BB123_33 Depth=1
	s32i	a12, a13, 0
	s32i	a10, a14, 0
	addi	a12, a9, -12
	l32i	a13, a12, 0
	add	a11, a13, a11
	s32i	a11, a12, 0
	addi	a4, a4, -1
.LBB123_37:                             # %source.label44.i
                                        #   in Loop: Header=BB123_33 Depth=1
	addi	a8, a8, -1
	addi	a9, a9, 20
	bnez	a8, .LBB123_33
.LBB123_38:                             # %source.label45.i
	movi	a8, 16
	bgeu	a8, a4, .LBB123_39
	j	.LBB123_108
.LBB123_39:                             # %source.label50.i.preheader
	l32r	a3, .LCPI123_3
	movi	a5, 0
	movi	a11, 0
	s32i	a4, a1, 24                      # 4-byte Folded Spill
	bne	a11, a6, .LBB123_40
	j	.LBB123_85
.LBB123_40:                             # %source.label51.i
                                        # =>This Loop Header: Depth=1
                                        #     Child Loop BB123_55 Depth 2
                                        #       Child Loop BB123_56 Depth 3
	movi	a8, 20
	mull	a8, a11, a8
	l32r	a9, .LCPI123_2
	add	a4, a9, a8
	l32i	a2, a4, 8
	bnei	a2, -1, .LBB123_41
	j	.LBB123_71
.LBB123_41:                             # %source.label54.i
                                        #   in Loop: Header=BB123_40 Depth=1
	s32i	a11, a1, 20                     # 4-byte Folded Spill
	l32i	a8, a1, 24                      # 4-byte Folded Reload
	bltu	a5, a8, .LBB123_42
	j	.LBB123_108
.LBB123_42:                             # %source.label57.i
                                        #   in Loop: Header=BB123_40 Depth=1
	movi	a8, 36
	mull	a8, a5, a8
	add	a7, a8, a3
	or	a10, a7, a7
	movi	a11, 0
	movi	a12, 36
	call8	abla_fn_853840267_528021067_direct
	slli	a8, a2, 4
	l32r	a9, .LCPI123_4
	add	a8, a9, a8
	addi	a11, a8, 4
	or	a10, a7, a7
	movi	a12, 12
	call8	abla_fn_334943840_569200394_direct
	l32i	a8, a4, 0
	s32i	a8, a7, 12
	l32i	a9, a4, 4
	l32r	a10, .LCPI123_5
	s32i	a10, a7, 20
	movi	a10, 0
	s32i	a10, a7, 24
	add	a8, a9, a8
	s32i	a8, a7, 16
	l32i	a8, a4, 16
	bnez	a8, .LBB123_83
# %bb.43:                               # %source.label60.i
                                        #   in Loop: Header=BB123_40 Depth=1
	s32i	a5, a1, 16                      # 4-byte Folded Spill
	l32i	a8, a7, 12
	l32i	a9, a7, 16
	sub	a10, a9, a8
	l32r	a9, .LCPI123_6
	bltu	a10, a9, .LBB123_44
	j	.LBB123_108
.LBB123_44:                             # %source.label6.i.i
                                        #   in Loop: Header=BB123_40 Depth=1
	movi	a4, 0
	beqz	a8, .LBB123_82
# %bb.45:                               # %source.label6.i.i
                                        #   in Loop: Header=BB123_40 Depth=1
	movi	a9, 20
	bgeu	a10, a9, .LBB123_46
	j	.LBB123_82
.LBB123_46:                             # %source.label9.i.i170.i
                                        #   in Loop: Header=BB123_40 Depth=1
	addi	a9, a8, 20
	movi	a13, 0
	movi	a14, 16
	beqz	a9, .LBB123_81
# %bb.47:                               # %source.label9.i.i170.i
                                        #   in Loop: Header=BB123_40 Depth=1
	extui	a11, a8, 0, 2
	bnez	a11, .LBB123_81
# %bb.48:                               # %source.label9.i.i170.i
                                        #   in Loop: Header=BB123_40 Depth=1
	movi	a11, 56
	bgeu	a10, a11, .LBB123_49
	j	.LBB123_81
.LBB123_49:                             # %source.label15.i.i.i.i.i.i
                                        #   in Loop: Header=BB123_40 Depth=1
	movi	a12, 4
	l32r	a11, .LCPI123_7
	bltu	a10, a11, .LBB123_51
# %bb.50:                               # %source.label15.i.i.i.i.i.i
                                        #   in Loop: Header=BB123_40 Depth=1
	movi	a12, 5
.LBB123_51:                             # %source.label15.i.i.i.i.i.i
                                        #   in Loop: Header=BB123_40 Depth=1
	movi	a11, 3
	l32r	a15, .LCPI123_8
	bltu	a10, a15, .LBB123_53
# %bb.52:                               # %source.label15.i.i.i.i.i.i
                                        #   in Loop: Header=BB123_40 Depth=1
	or	a11, a12, a12
.LBB123_53:                             # %source.label15.i.i.i.i.i.i
                                        #   in Loop: Header=BB123_40 Depth=1
	addi	a5, a10, -20
	addi	a15, a11, 2
	#APP
	nsau	a12, a5
	#NO_APP
	movi	a10, 32
	s32i	a12, a1, 12                     # 4-byte Folded Spill
	sub	a10, a10, a12
	s32i	a10, a1, 4                      # 4-byte Folded Spill
	s32i	a15, a1, 0                      # 4-byte Folded Spill
	sub	a10, a10, a15
	addi	a12, a10, 1
	ssl	a11
	sll	a4, a12
	slli	a10, a12, 2
	addx4	a2, a4, a10
	addi	a15, a2, 48
	movi	a4, 0
	s32i	a5, a1, 8                       # 4-byte Folded Spill
	bgeu	a5, a15, .LBB123_54
	j	.LBB123_81
.LBB123_54:                             # %source.label33.i.i.i.i.i.i
                                        #   in Loop: Header=BB123_40 Depth=1
	addi	a14, a2, 36
	s32i	a13, a8, 44
	s32i	a14, a8, 40
	s32i	a9, a8, 32
	s32i	a9, a8, 28
	addi	a14, a8, 56
	s32i	a14, a8, 48
	add	a10, a10, a14
	s32i	a10, a8, 52
	l32r	a10, .LCPI123_9
	l32r	a15, .LCPI123_10
	or	a10, a15, a10
	ssl	a11
	sll	a10, a10
	l32i	a15, a1, 0                      # 4-byte Folded Reload
	slli	a15, a15, 5
	or	a10, a10, a15
	slli	a15, a11, 20
	or	a10, a10, a15
	l32i	a15, a1, 4                      # 4-byte Folded Reload
	slli	a15, a15, 8
	or	a10, a15, a10
	or	a10, a10, a12
	s32i	a10, a8, 36
	l32i	a10, a1, 12                     # 4-byte Folded Reload
	add	a10, a11, a10
	slli	a10, a10, 2
	sub	a10, a8, a10
	movi	a15, 180
	add	a10, a10, a15
	l32i	a5, a1, 8                       # 4-byte Folded Reload
	beq	a13, a12, .LBB123_59
.LBB123_55:                             # %source.label38.i.i.i.i.i.i
                                        #   Parent Loop BB123_40 Depth=1
                                        # =>  This Loop Header: Depth=2
                                        #       Child Loop BB123_56 Depth 3
	addx4	a4, a13, a14
	movi	a15, 0
	s32i	a15, a4, 0
	ssl	a11
	sll	a4, a13
	addx4	a4, a4, a10
.LBB123_56:                             # %source.label40.i.i.i.i.i.i
                                        #   Parent Loop BB123_40 Depth=1
                                        #     Parent Loop BB123_55 Depth=2
                                        # =>    This Inner Loop Header: Depth=3
	ssr	a11
	srl	a2, a15
	bnez.n	a2, .LBB123_58
# %bb.57:                               # %source.label41.i.i.i.i.i.i
                                        #   in Loop: Header=BB123_56 Depth=3
	s32i	a9, a4, 0
	addi	a4, a4, 4
	addi	a15, a15, 1
	j	.LBB123_56
.LBB123_58:                             # %source.label42.i.i.i.i.i.i
                                        #   in Loop: Header=BB123_55 Depth=2
	addi	a13, a13, 1
	bne	a13, a12, .LBB123_55
.LBB123_59:                             # %abla_fn_842431889_601053633_direct.exit.i.i.i.i
                                        #   in Loop: Header=BB123_40 Depth=1
	l32i	a10, a8, 40
	bltu	a10, a5, .LBB123_60
	j	.LBB123_80
.LBB123_60:                             # %source.label6.i.i.i.i
                                        #   in Loop: Header=BB123_40 Depth=1
	extui	a11, a10, 0, 2
	bnez	a11, .LBB123_80
# %bb.61:                               # %source.label6.i.i.i.i
                                        #   in Loop: Header=BB123_40 Depth=1
	add	a11, a10, a9
	beqz	a11, .LBB123_80
# %bb.62:                               # %source.label6.i.i.i.i
                                        #   in Loop: Header=BB123_40 Depth=1
	sub	a10, a5, a10
	bgeui	a10, 8, .LBB123_63
	j	.LBB123_80
.LBB123_63:                             # %source.label13.i.i.i.i.i
                                        #   in Loop: Header=BB123_40 Depth=1
	movi	a12, -4
	and	a10, a10, a12
	addi	a12, a10, -8
	bgeui	a12, 12, .LBB123_64
	j	.LBB123_80
.LBB123_64:                             # %source.label16.i.i.i.i.i
                                        #   in Loop: Header=BB123_40 Depth=1
	l32i	a10, a8, 36
	extui	a13, a10, 8, 6
	ssl	a13
	movi	a10, 1
	sll	a10, a10
	movi	a14, 31
	bgeu	a14, a13, .LBB123_66
# %bb.65:                               # %source.label16.i.i.i.i.i
                                        #   in Loop: Header=BB123_40 Depth=1
	movi	a10, 0
.LBB123_66:                             # %source.label16.i.i.i.i.i
                                        #   in Loop: Header=BB123_40 Depth=1
	bgeu	a10, a12, .LBB123_67
	j	.LBB123_80
.LBB123_67:                             # %source.label21.i.i.i.i.i
                                        #   in Loop: Header=BB123_40 Depth=1
	movi	a4, 1
	or	a10, a12, a4
	s32i	a10, a11, 0
	l32i	a10, a8, 36
	extui	a14, a10, 23, 8
	bgeu	a12, a14, .LBB123_72
# %bb.68:                               # %source.label.i.i.i.i.i.i.i
                                        #   in Loop: Header=BB123_40 Depth=1
	extui	a13, a10, 14, 6
	beqz	a13, .LBB123_108
# %bb.69:                               # %scalar.divide.checked.i.i.i.i.i.i.i
                                        #   in Loop: Header=BB123_40 Depth=1
	bgeu	a14, a13, .LBB123_70
	j	.LBB123_108
.LBB123_70:                             # %scalar.divide.checked13.i.i.i.i.i.i.i
                                        #   in Loop: Header=BB123_40 Depth=1
	extui	a10, a10, 23, 9
	extui	a10, a10, 0, 8
	quou	a10, a10, a13
	extui	a12, a12, 0, 8
	quou	a10, a12, a10
	slli	a14, a10, 8
	j	.LBB123_75
.LBB123_71:                             #   in Loop: Header=BB123_40 Depth=1
	l32i	a4, a1, 24                      # 4-byte Folded Reload
	j	.LBB123_84
.LBB123_72:                             # %abla_fn_173146590_885096896_direct.exit.i.i.i.i.i.i.i
                                        #   in Loop: Header=BB123_40 Depth=1
	#APP
	nsau	a13, a12
	#NO_APP
	l32i	a10, a8, 36
	extui	a14, a10, 20, 3
	add	a15, a14, a13
	movi	a2, 31
	sub	a4, a2, a15
	ssr	a4
	srl	a12, a12
	bgeu	a2, a15, .LBB123_74
# %bb.73:                               # %abla_fn_173146590_885096896_direct.exit.i.i.i.i.i.i.i
                                        #   in Loop: Header=BB123_40 Depth=1
	movi	a12, 0
.LBB123_74:                             # %abla_fn_173146590_885096896_direct.exit.i.i.i.i.i.i.i
                                        #   in Loop: Header=BB123_40 Depth=1
	ssl	a14
	movi	a4, 1
	sll	a14, a4
	xor	a12, a12, a14
	slli	a12, a12, 8
	extui	a14, a10, 5, 3
	add	a13, a13, a14
	movi	a14, 32
	sub	a13, a14, a13
	or	a14, a12, a13
	extui	a13, a10, 14, 6
.LBB123_75:                             # %abla_fn_386852483_179931374_direct.exit.i.i.i.i.i
                                        #   in Loop: Header=BB123_40 Depth=1
	addi	a12, a11, -4
	extui	a10, a14, 0, 8
	mull	a15, a10, a13
	extui	a13, a14, 8, 8
	add	a14, a15, a13
	l32i	a15, a8, 52
	addx4	a14, a14, a15
	l32i	a15, a14, 0
	s32i	a9, a11, 8
	s32i	a15, a11, 4
	s32i	a12, a15, 12
	s32i	a12, a14, 0
	ssl	a10
	sll	a14, a4
	movi	a15, 31
	bgeu	a15, a10, .LBB123_77
# %bb.76:                               # %abla_fn_386852483_179931374_direct.exit.i.i.i.i.i
                                        #   in Loop: Header=BB123_40 Depth=1
	movi	a14, 0
.LBB123_77:                             # %abla_fn_386852483_179931374_direct.exit.i.i.i.i.i
                                        #   in Loop: Header=BB123_40 Depth=1
	l32i	a15, a8, 44
	or	a14, a15, a14
	s32i	a14, a8, 44
	ssl	a13
	sll	a14, a4
	movi	a15, 31
	bgeu	a15, a13, .LBB123_79
# %bb.78:                               # %abla_fn_386852483_179931374_direct.exit.i.i.i.i.i
                                        #   in Loop: Header=BB123_40 Depth=1
	movi	a14, 0
.LBB123_79:                             # %abla_fn_386852483_179931374_direct.exit.i.i.i.i.i
                                        #   in Loop: Header=BB123_40 Depth=1
	l32i	a13, a8, 48
	addx4	a10, a10, a13
	l32i	a13, a10, 0
	or	a13, a13, a14
	s32i	a13, a10, 0
	l32i	a10, a11, 0
	movi	a13, -4
	and	a10, a10, a13
	add	a10, a10, a11
	movi	a11, 2
	s32i	a11, a10, 4
	s32i	a12, a10, 0
.LBB123_80:                             # %abla_fn_230002481_458798260_direct.exit.i.i.i
                                        #   in Loop: Header=BB123_40 Depth=1
	movi	a10, 0
	s32i	a10, a8, 0
	s32i	a9, a8, 16
	s32i	a5, a8, 12
	l32i	a9, a8, 40
	sub	a13, a5, a9
	s32i	a13, a8, 4
	movi	a14, 8
	or	a4, a8, a8
.LBB123_81:                             # %common.ret.sink.split.i.i.i
                                        #   in Loop: Header=BB123_40 Depth=1
	add	a8, a14, a8
	s32i	a13, a8, 0
.LBB123_82:                             # %abla_fn_36645824_190734380_direct.exit.i
                                        #   in Loop: Header=BB123_40 Depth=1
	s32i	a4, a7, 28
	l32i	a5, a1, 16                      # 4-byte Folded Reload
.LBB123_83:                             # %source.label62.i
                                        #   in Loop: Header=BB123_40 Depth=1
	addi	a5, a5, 1
	l32i	a4, a1, 24                      # 4-byte Folded Reload
	l32i	a11, a1, 20                     # 4-byte Folded Reload
.LBB123_84:                             # %source.label64.i
                                        #   in Loop: Header=BB123_40 Depth=1
	addi	a11, a11, 1
	beq	a11, a6, .LBB123_85
	j	.LBB123_40
.LBB123_85:                             # %source.label65.i
	beq	a5, a4, .LBB123_86
	j	.LBB123_108
.LBB123_86:                             # %source.label68.i
	l32r	a2, .LCPI123_11
	movi	a7, 0
	s32i	a7, a2, 0
	movi	a8, 36
	mull	a8, a4, a8
	s32i	a8, a1, 20                      # 4-byte Folded Spill
	movi	a6, 0
	bnez	a7, .LBB123_96
.LBB123_87:                             # %source.label71.i
                                        # =>This Inner Loop Header: Depth=1
	bgeu	a6, a4, .LBB123_96
# %bb.88:                               # %source.label76.i
                                        #   in Loop: Header=BB123_87 Depth=1
	movi	a7, 0
	beqz	a3, .LBB123_95
# %bb.89:                               # %source.label.i.i
                                        #   in Loop: Header=BB123_87 Depth=1
	l32i	a5, a3, 28
	beqz	a5, .LBB123_95
# %bb.90:                               # %source.label5.i.i
                                        #   in Loop: Header=BB123_87 Depth=1
	l32i	a8, a3, 0
	l32i	a9, a3, 4
	or	a8, a9, a8
	l32i	a9, a3, 8
	or	a8, a8, a9
	l32r	a9, .LCPI123_12
	and	a8, a8, a9
	bne	a8, a9, .LBB123_95
# %bb.91:                               # %source.label8.i.i
                                        #   in Loop: Header=BB123_87 Depth=1
	or	a10, a5, a5
	call8	abla_fn_524213402_227204421_direct
	l32i	a10, a5, 16
	l32i	a11, a1, 20                     # 4-byte Folded Reload
	call8	abla_fn_946434868_368388687_direct
	or	a7, a10, a10
	beqz.n	a7, .LBB123_94
# %bb.92:                               # %source.label10.i.i
                                        #   in Loop: Header=BB123_87 Depth=1
	addi	a8, a7, -4
	l32i	a8, a8, 0
	movi	a9, -4
	and	a8, a8, a9
	l32i	a9, a5, 4
	sub	a8, a9, a8
	addi	a8, a8, -4
	s32i	a8, a5, 4
	l32i	a9, a5, 8
	bgeu	a8, a9, .LBB123_94
# %bb.93:                               # %source.label12.i.i
                                        #   in Loop: Header=BB123_87 Depth=1
	s32i	a8, a5, 8
.LBB123_94:                             # %source.label16.i.i
                                        #   in Loop: Header=BB123_87 Depth=1
	or	a10, a5, a5
	call8	abla_fn_973951929_967810110_direct
.LBB123_95:                             # %source.label80.i
                                        #   in Loop: Header=BB123_87 Depth=1
	addi	a3, a3, 36
	addi	a6, a6, 1
	beqz	a7, .LBB123_87
.LBB123_96:                             # %source.label81.i
	beqz	a7, .LBB123_108
# %bb.97:                               # %source.label84.i
	l32r	a11, .LCPI123_3
	or	a10, a7, a7
	l32i	a12, a1, 20                     # 4-byte Folded Reload
	call8	abla_fn_334943840_569200394_direct
	movi	a8, 0
	movi	a9, 36
	movi	a10, 0
	beq	a10, a4, .LBB123_107
.LBB123_98:                             # %source.label86.i
                                        # =>This Loop Header: Depth=1
                                        #     Child Loop BB123_102 Depth 2
	mull	a11, a10, a9
	add	a11, a11, a7
	s32i	a8, a11, 24
	l32r	a12, .LCPI123_5
	s32i	a12, a11, 20
	l32i	a12, a11, 28
	beqz.n	a12, .LBB123_100
# %bb.99:                               # %source.label89.i
                                        #   in Loop: Header=BB123_98 Depth=1
	addi	a13, a11, 20
	s32i	a13, a12, 0
.LBB123_100:                            # %source.label91.i
                                        #   in Loop: Header=BB123_98 Depth=1
	l32i	a12, a2, 0
	s32i	a8, a11, 32
	or	a14, a2, a2
	beqz.n	a12, .LBB123_106
# %bb.101:                              # %source.label10.i194.i
                                        #   in Loop: Header=BB123_98 Depth=1
	l32i	a13, a11, 12
	l32i	a14, a11, 16
	sub	a14, a14, a13
	movi	a13, 0
	beqz.n	a12, .LBB123_104
.LBB123_102:                            # %source.label16.i196.i
                                        #   Parent Loop BB123_98 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	l32i	a15, a12, 12
	l32i	a6, a12, 16
	sub	a15, a6, a15
	bgeu	a15, a14, .LBB123_104
# %bb.103:                              # %source.label19.i.i
                                        #   in Loop: Header=BB123_102 Depth=2
	l32i	a15, a12, 32
	or	a13, a12, a12
	or	a12, a15, a15
	bnez	a12, .LBB123_102
.LBB123_104:                            # %source.label20.i.i
                                        #   in Loop: Header=BB123_98 Depth=1
	s32i	a12, a11, 32
	or	a14, a2, a2
	beqz.n	a13, .LBB123_106
# %bb.105:                              # %source.label22.i.i
                                        #   in Loop: Header=BB123_98 Depth=1
	addi	a14, a13, 32
.LBB123_106:                            # %abla_fn_79810203_64921798_direct.exit.i
                                        #   in Loop: Header=BB123_98 Depth=1
	s32i	a11, a14, 0
	addi	a10, a10, 1
	bne	a10, a4, .LBB123_98
.LBB123_107:                            # %abla_fn_275724278_886444281_direct.exit
	memw
	movi	a2, 0
	retw.n
.LBB123_108:                            # %source.label22.i.i.i
	ill.n
.Lfunc_end123:
	.size	abla_fn_338872068_789649821_direct, .Lfunc_end123-abla_fn_338872068_789649821_direct
                                        # -- End function
	.literal_position
	.literal .LCPI124_0, abla_fn_952490526_932962922_direct
	.literal .LCPI124_1, .Labla_string_abla_fn_627837887_633683867_2164.native.mutable.u32s
	.literal .LCPI124_2, abla_fn_186944242_355245718_direct
	.literal .LCPI124_3, abla_static_abla_fn_627837887_633683867_2151
	.literal .LCPI124_4, abla_static_abla_fn_627837887_633683867_2145
	.literal .LCPI124_5, abla_static_abla_fn_627837887_633683867_2157
	.literal .LCPI124_6, abla_fn_952490526_932962922_direct
	.literal .LCPI124_7, abla_fn_707068177_288599970_direct
	.section	.text.abla_fn_338872068_789649821_direct,"ax",@progbits
	.section	.iram1.4.abla.esp32RecoveredEspIntrNoniramDisable,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_43435178_164432985_direct
	.type	abla_fn_43435178_164432985_direct,@function
abla_fn_43435178_164432985_direct:      # @abla_fn_43435178_164432985_direct
# %bb.0:                                # %entry
	entry	a1, 32
	l32r	a8, .LCPI124_0
	callx8	a8
	l32r	a10, .LCPI124_1
	l32r	a8, .LCPI124_2
	callx8	a8
	#APP
	rsr	a8, prid
	#NO_APP
	extui	a9, a8, 13, 1
	l32r	a8, .LCPI124_3
	or	a8, a9, a8
	l8ui	a10, a8, 0
	bnez	a10, .LBB124_2
# %bb.1:                                # %source.label22
	slli	a9, a9, 2
	l32r	a10, .LCPI124_4
	or	a10, a9, a10
	l32i	a10, a10, 0
	movi	a11, 1
	s8i	a11, a8, 0
	movi	a8, -1
	xor	a8, a10, a8
	#APP
	rsr	a11, intenable
	#NO_APP
	movi	a12, 0
	#APP
	or	a12, a12, a12
	xsr	a12, intenable
	rsync

	#NO_APP
	and	a8, a12, a8
	#APP
	isync

	#NO_APP
	#APP
	wsr	a8, intenable
	rsync

	#NO_APP
	l32r	a8, .LCPI124_5
	or	a8, a9, a8
	and	a9, a11, a10
	#APP
	isync

	#NO_APP
	s32i	a9, a8, 0
	l32r	a8, .LCPI124_6
	callx8	a8
	l32r	a10, .LCPI124_1
	l32r	a8, .LCPI124_7
	callx8	a8
	retw.n
.LBB124_2:                              # %source.label20
	ill.n
.Lfunc_end124:
	.size	abla_fn_43435178_164432985_direct, .Lfunc_end124-abla_fn_43435178_164432985_direct
                                        # -- End function
	.literal_position
	.literal .LCPI125_0, abla_fn_952490526_932962922_direct
	.literal .LCPI125_1, .Labla_string_abla_fn_627837887_633683867_2164.native.mutable.u32s
	.literal .LCPI125_2, abla_fn_186944242_355245718_direct
	.literal .LCPI125_3, abla_static_abla_fn_627837887_633683867_2151
	.literal .LCPI125_4, abla_static_abla_fn_627837887_633683867_2157
	.literal .LCPI125_5, abla_fn_952490526_932962922_direct
	.literal .LCPI125_6, abla_fn_707068177_288599970_direct
	.section	.iram1.4.abla.esp32RecoveredEspIntrNoniramDisable,"ax",@progbits
	.section	.iram1.5.abla.esp32RecoveredEspIntrNoniramEnable,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_262508538_723171161_direct
	.type	abla_fn_262508538_723171161_direct,@function
abla_fn_262508538_723171161_direct:     # @abla_fn_262508538_723171161_direct
# %bb.0:                                # %entry
	entry	a1, 32
	l32r	a8, .LCPI125_0
	callx8	a8
	l32r	a10, .LCPI125_1
	l32r	a8, .LCPI125_2
	callx8	a8
	#APP
	rsr	a8, prid
	#NO_APP
	extui	a9, a8, 13, 1
	l32r	a8, .LCPI125_3
	or	a8, a9, a8
	l8ui	a10, a8, 0
	beqz	a10, .LBB125_2
# %bb.1:                                # %source.label20
	slli	a9, a9, 2
	l32r	a10, .LCPI125_4
	or	a9, a9, a10
	l32i	a9, a9, 0
	movi	a10, 0
	s8i	a10, a8, 0
	#APP
	or	a8, a10, a10
	xsr	a8, intenable
	rsync

	#NO_APP
	or	a8, a8, a9
	#APP
	isync

	#NO_APP
	#APP
	wsr	a8, intenable
	rsync

	#NO_APP
	#APP
	isync

	#NO_APP
	l32r	a8, .LCPI125_5
	callx8	a8
	l32r	a10, .LCPI125_1
	l32r	a8, .LCPI125_6
	callx8	a8
	retw.n
.LBB125_2:                              # %source.label18
	ill.n
.Lfunc_end125:
	.size	abla_fn_262508538_723171161_direct, .Lfunc_end125-abla_fn_262508538_723171161_direct
                                        # -- End function
	.literal_position
	.literal .LCPI126_0, -4194304
	.literal .LCPI126_1, -1065353217
	.literal .LCPI126_2, 1065353216
	.literal .LCPI126_3, 4194304
	.literal .LCPI126_4, -1061158913
	.literal .LCPI126_5, 1061158912
	.literal .LCPI126_6, -1074593793
	.literal .LCPI126_7, -1074593792
	.literal .LCPI126_8, 3342335
	.literal .LCPI126_9, 3342336
	.literal .LCPI126_10, -1077936129
	.literal .LCPI126_11, 1077936128
	.literal .LCPI126_12, -1082130433
	.literal .LCPI126_13, 1082130432
	.literal .LCPI126_14, 4194303
	.section	.iram1.5.abla.esp32RecoveredEspIntrNoniramEnable,"ax",@progbits
	.section	.iram1.abla.mmu_hal_check_vaddr,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_205989963_612999693_direct
	.type	abla_fn_205989963_612999693_direct,@function
abla_fn_205989963_612999693_direct:     # @abla_fn_205989963_612999693_direct
# %bb.0:                                # %entry
	entry	a1, 32
	l32r	a8, .LCPI126_0
	and	a9, a2, a8
	add	a8, a3, a2
	l32r	a10, .LCPI126_2
	bne	a9, a10, .LBB126_2
# %bb.1:                                # %entry
	l32r	a10, .LCPI126_1
	add	a10, a8, a10
	l32r	a11, .LCPI126_3
	bltu	a10, a11, .LBB126_10
.LBB126_2:                              # %source.label3
	l32r	a10, .LCPI126_5
	bne	a9, a10, .LBB126_4
# %bb.3:                                # %source.label3
	l32r	a10, .LCPI126_4
	add	a10, a8, a10
	l32r	a11, .LCPI126_3
	bltu	a10, a11, .LBB126_10
.LBB126_4:                              # %source.label12
	l32r	a10, .LCPI126_7
	add	a10, a2, a10
	l32r	a11, .LCPI126_8
	bltu	a11, a10, .LBB126_6
# %bb.5:                                # %source.label12
	l32r	a10, .LCPI126_6
	add	a10, a8, a10
	l32r	a11, .LCPI126_9
	bltu	a10, a11, .LBB126_10
.LBB126_6:                              # %source.label14
	l32r	a10, .LCPI126_11
	bne	a9, a10, .LBB126_8
# %bb.7:                                # %source.label14
	l32r	a10, .LCPI126_10
	add	a10, a8, a10
	l32r	a11, .LCPI126_3
	bltu	a10, a11, .LBB126_10
.LBB126_8:                              # %source.label15
	movi	a2, 0
	l32r	a10, .LCPI126_13
	bne	a9, a10, .LBB126_11
# %bb.9:                                # %source.label15
	l32r	a9, .LCPI126_12
	add	a8, a8, a9
	l32r	a9, .LCPI126_14
	bltu	a9, a8, .LBB126_11
.LBB126_10:                             # %source.label19.thread
	movi	a2, 1
.LBB126_11:                             # %source.label19.thread47
	retw.n
.Lfunc_end126:
	.size	abla_fn_205989963_612999693_direct, .Lfunc_end126-abla_fn_205989963_612999693_direct
                                        # -- End function
	.literal_position
	.literal .LCPI127_0, 65536
	.literal .LCPI127_1, abla_fn_205989963_612999693_direct
	.literal .LCPI127_2, -4194304
	.literal .LCPI127_3, 1061158912
	.literal .LCPI127_4, -1074593792
	.literal .LCPI127_5, 3342335
	.literal .LCPI127_6, 1065353216
	.literal .LCPI127_7, 1082130432
	.literal .LCPI127_8, 1077936128
	.literal .LCPI127_9, 4608
	.literal .LCPI127_10, 1072758784
	.literal .LCPI127_11, 1072766976
	.section	.iram1.abla.mmu_hal_check_vaddr,"ax",@progbits
	.section	.iram1.abla.mmu_hal_map_region,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_431008372_47994410_direct
	.type	abla_fn_431008372_47994410_direct,@function
abla_fn_431008372_47994410_direct:      # @abla_fn_431008372_47994410_direct
# %bb.0:                                # %entry
	entry	a1, 32
	extui	a8, a3, 0, 16
	bnez	a8, .LBB127_17
# %bb.1:                                # %source.label5
	l32r	a11, .LCPI127_0
	l32r	a8, .LCPI127_1
	or	a10, a3, a3
	callx8	a8
	beqz	a10, .LBB127_17
# %bb.2:                                # %source.label10
	l32r	a8, .LCPI127_0
	s32i	a8, a4, 0
	l32r	a8, .LCPI127_2
	and	a8, a3, a8
	l32r	a9, .LCPI127_3
	bne	a8, a9, .LBB127_4
# %bb.3:                                # %source.label.i
	srli	a8, a3, 14
	movi	a9, 252
	and	a8, a8, a9
	j	.LBB127_13
.LBB127_4:                              # %source.label2.i
	l32r	a9, .LCPI127_4
	add	a9, a3, a9
	l32r	a10, .LCPI127_5
	bltu	a10, a9, .LBB127_6
# %bb.5:                                # %source.label3.i
	srli	a8, a3, 14
	movi	a9, 252
	and	a8, a8, a9
	movi	a9, 256
	j	.LBB127_12
.LBB127_6:                              # %source.label5.i
	l32r	a9, .LCPI127_6
	beq	a8, a9, .LBB127_11
# %bb.7:                                # %source.label5.i
	l32r	a9, .LCPI127_7
	beq	a8, a9, .LBB127_10
# %bb.8:                                # %source.label5.i
	l32r	a9, .LCPI127_8
	bne	a8, a9, .LBB127_17
# %bb.9:                                # %source.label6.i
	srli	a8, a3, 14
	movi	a9, 252
	and	a8, a8, a9
	movi	a9, 512
	j	.LBB127_12
.LBB127_10:                             # %source.label9.i
	srli	a8, a3, 14
	movi	a9, 252
	and	a8, a8, a9
	movi	a9, 768
	j	.LBB127_12
.LBB127_11:                             # %source.label12.i
	srli	a8, a3, 13
	movi	a9, 248
	and	a8, a8, a9
	l32r	a9, .LCPI127_9
.LBB127_12:                             # %abla_fn_145410656_358470551_direct.exit
	or	a8, a8, a9
.LBB127_13:                             # %abla_fn_145410656_358470551_direct.exit
	extui	a10, a2, 0, 1
	movi	a9, 0
	bne	a10, a9, .LBB127_15
# %bb.14:                               # %abla_fn_145410656_358470551_direct.exit
	l32r	a10, .LCPI127_10
	j	.LBB127_16
.LBB127_15:
	l32r	a10, .LCPI127_11
.LBB127_16:                             # %abla_fn_145410656_358470551_direct.exit
	or	a8, a8, a10
	#APP
	rsil	a10, 5
	#NO_APP
	memw
	s32i	a9, a8, 0
	memw
	#APP
	wsr	a10, ps
	rsync

	#NO_APP
	retw.n
.LBB127_17:                             # %source.label8
	ill.n
.Lfunc_end127:
	.size	abla_fn_431008372_47994410_direct, .Lfunc_end127-abla_fn_431008372_47994410_direct
                                        # -- End function
	.literal_position
	.literal .LCPI128_0, abla_fn_205989963_612999693_direct
	.literal .LCPI128_1, 1072758784
	.literal .LCPI128_2, 1072766976
	.literal .LCPI128_3, 65535
	.literal .LCPI128_4, -4194304
	.literal .LCPI128_5, 1061158912
	.literal .LCPI128_6, -1074593792
	.literal .LCPI128_7, 3342335
	.literal .LCPI128_8, 1065353216
	.literal .LCPI128_9, 1082130432
	.literal .LCPI128_10, 1077936128
	.literal .LCPI128_11, 4608
	.literal .LCPI128_12, 65536
	.section	.iram1.abla.mmu_hal_map_region,"ax",@progbits
	.section	.iram1.abla.mmu_hal_unmap_region,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_121431496_464001390_direct
	.type	abla_fn_121431496_464001390_direct,@function
abla_fn_121431496_464001390_direct:     # @abla_fn_121431496_464001390_direct
# %bb.0:                                # %entry
	entry	a1, 32
	extui	a8, a3, 0, 16
	bnez	a8, .LBB128_17
# %bb.1:                                # %source.label
	l32r	a8, .LCPI128_0
	or	a10, a3, a3
	or	a11, a4, a4
	callx8	a8
	beqz	a10, .LBB128_17
# %bb.2:                                # %source.label7
	extui	a8, a2, 0, 1
	movi	a9, 0
	bne	a8, a9, .LBB128_4
# %bb.3:                                # %source.label7
	l32r	a8, .LCPI128_1
	j	.LBB128_5
.LBB128_4:
	l32r	a8, .LCPI128_2
.LBB128_5:                              # %source.label7
	l32r	a9, .LCPI128_3
	add	a9, a4, a9
	extui	a9, a9, 16, 16
	srli	a10, a3, 13
	srli	a11, a3, 14
	movi	a12, 252
	movi	a13, 256
	movi	a14, 248
	movi	a15, 768
	movi	a7, 512
	beqz	a9, .LBB128_16
.LBB128_6:                              # %source.label11
                                        # =>This Inner Loop Header: Depth=1
	l32r	a6, .LCPI128_4
	and	a5, a3, a6
	l32r	a4, .LCPI128_5
	and	a6, a11, a12
	beq	a5, a4, .LBB128_15
# %bb.7:                                # %source.label2.i
                                        #   in Loop: Header=BB128_6 Depth=1
	l32r	a4, .LCPI128_6
	add	a4, a3, a4
	l32r	a2, .LCPI128_7
	bltu	a2, a4, .LBB128_9
# %bb.8:                                # %source.label3.i
                                        #   in Loop: Header=BB128_6 Depth=1
	or	a6, a6, a13
	j	.LBB128_15
.LBB128_9:                              # %source.label5.i
                                        #   in Loop: Header=BB128_6 Depth=1
	l32r	a4, .LCPI128_8
	beq	a5, a4, .LBB128_14
# %bb.10:                               # %source.label5.i
                                        #   in Loop: Header=BB128_6 Depth=1
	l32r	a4, .LCPI128_9
	beq	a5, a4, .LBB128_13
# %bb.11:                               # %source.label5.i
                                        #   in Loop: Header=BB128_6 Depth=1
	l32r	a4, .LCPI128_10
	bne	a5, a4, .LBB128_17
# %bb.12:                               # %source.label6.i
                                        #   in Loop: Header=BB128_6 Depth=1
	or	a6, a6, a7
	j	.LBB128_15
.LBB128_13:                             # %source.label9.i
                                        #   in Loop: Header=BB128_6 Depth=1
	or	a6, a6, a15
	j	.LBB128_15
.LBB128_14:                             # %source.label12.i
                                        #   in Loop: Header=BB128_6 Depth=1
	and	a6, a10, a14
	l32r	a5, .LCPI128_11
	or	a6, a6, a5
.LBB128_15:                             # %abla_fn_145410656_358470551_direct.exit
                                        #   in Loop: Header=BB128_6 Depth=1
	or	a6, a6, a8
	#APP
	rsil	a5, 5
	#NO_APP
	memw
	s32i	a13, a6, 0
	memw
	#APP
	wsr	a5, ps
	rsync

	#NO_APP
	l32r	a6, .LCPI128_12
	add	a3, a3, a6
	addi	a10, a10, 8
	addi	a11, a11, 4
	addi	a9, a9, -1
	bnez	a9, .LBB128_6
.LBB128_16:                             # %source.label12
	retw.n
.LBB128_17:                             # %source.label5
	ill.n
.Lfunc_end128:
	.size	abla_fn_121431496_464001390_direct, .Lfunc_end128-abla_fn_121431496_464001390_direct
                                        # -- End function
	.literal_position
	.literal .LCPI129_0, abla_fn_764337598_298335200_direct
	.literal .LCPI129_1, 1072693336
	.literal .LCPI129_2, 1072693312
	.literal .LCPI129_3, abla_fn_180033588_623469740_direct
	.section	.iram1.abla.mmu_hal_unmap_region,"ax",@progbits
	.section	.iram1.abla.cache_flush,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_944518206_913693093_direct
	.type	abla_fn_944518206_913693093_direct,@function
abla_fn_944518206_913693093_direct:     # @abla_fn_944518206_913693093_direct
# %bb.0:                                # %entry
	entry	a1, 32
	l32r	a8, .LCPI129_0
	callx8	a8
	movi	a8, 0
	beq	a2, a8, .LBB129_2
# %bb.1:                                # %entry
	l32r	a8, .LCPI129_1
	j	.LBB129_3
.LBB129_2:
	l32r	a8, .LCPI129_2
.LBB129_3:                              # %entry
	memw
	l32i	a9, a8, 0
	movi	a10, -17
	and	a9, a9, a10
	memw
	s32i	a9, a8, 0
	memw
	memw
	l32i	a9, a8, 0
	movi	a10, 16
	or	a9, a9, a10
	memw
	s32i	a9, a8, 0
	memw
.LBB129_4:                              # %source.label.i.i
                                        # =>This Inner Loop Header: Depth=1
	memw
	l32i	a9, a8, 0
	bbci	a9, 5, .LBB129_4
# %bb.5:                                # %abla_fn_336494584_234869064_direct.exit
	memw
	l32i	a9, a8, 0
	movi	a10, -17
	and	a9, a9, a10
	memw
	s32i	a9, a8, 0
	memw
	l32r	a8, .LCPI129_3
	callx8	a8
	retw.n
.Lfunc_end129:
	.size	abla_fn_944518206_913693093_direct, .Lfunc_end129-abla_fn_944518206_913693093_direct
                                        # -- End function
	.literal_position
	.literal .LCPI130_0, .Labla_string_abla_fn_627837887_633683867_2208.native.mutable.u32s
	.section	.iram1.abla.cache_flush,"ax",@progbits
	.section	.iram1.abla.cache_sync_recovered,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_368275349_679717816_direct
	.type	abla_fn_368275349_679717816_direct,@function
abla_fn_368275349_679717816_direct:     # @abla_fn_368275349_679717816_direct
# %bb.0:                                # %entry
	entry	a1, 32
	l32r	a7, .LCPI130_0
	l32i	a8, a7, 4
	beqz.n	a8, .LBB130_2
# %bb.1:                                # %source.label.i
	movi	a10, 0
	movi	a11, 0
	movi	a12, 0
	movi	a13, 0
	movi	a14, 0
	movi	a15, 0
	callx8	a8
.LBB130_2:                              # %abla_fn_435122805_35923361_direct.exit
	l32i	a7, a7, 0
	movi	a10, 0
	movi	a11, 0
	movi	a12, 0
	movi	a13, 0
	movi	a14, 0
	movi	a15, 0
	callx8	a7
	movi	a10, 1
	callx8	a7
	retw.n
.Lfunc_end130:
	.size	abla_fn_368275349_679717816_direct, .Lfunc_end130-abla_fn_368275349_679717816_direct
                                        # -- End function
	.literal_position
	.literal .LCPI131_0, abla_fn_321888515_252845378_direct
	.literal .LCPI131_1, abla_fn_431008372_47994410_direct
	.literal .LCPI131_2, abla_fn_431008372_47994410_direct
	.literal .LCPI131_3, 65535
	.literal .LCPI131_4, 1086324736
	.literal .LCPI131_5, 1082130431
	.literal .LCPI131_6, 1077936127
	.literal .LCPI131_7, 1082130432
	.literal .LCPI131_8, 1074593791
	.literal .LCPI131_9, 1077936128
	.literal .LCPI131_10, 1065353215
	.literal .LCPI131_11, 1069547520
	.literal .LCPI131_12, .Labla_string_abla_fn_627837887_633683867_2241.native.bytes
	.literal .LCPI131_13, .Labla_string_abla_fn_627837887_633683867_2316.native.bytes
	.literal .LCPI131_14, abla_fn_343754787_547301002_direct
	.literal .LCPI131_15, 1061158911
	.literal .LCPI131_16, 1065353216
	.literal .LCPI131_17, 1072955512
	.literal .LCPI131_18, 1072693316
	.literal .LCPI131_19, abla_fn_343754787_547301002_direct
	.literal .LCPI131_20, 1072693340
	.literal .LCPI131_21, abla_fn_368275349_679717816_direct
	.literal .LCPI131_22, abla_fn_795904359_267395915_direct
	.literal .LCPI131_23, abla_fn_343754787_547301002_direct
	.literal .LCPI131_24, abla_fn_343754787_547301002_direct
	.literal .LCPI131_25, abla_fn_343754787_547301002_direct
	.literal .LCPI131_26, abla_fn_343754787_547301002_direct
	.section	.iram1.abla.cache_sync_recovered,"ax",@progbits
	.section	.iram1.abla.mmu_do_mapping,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_865116771_688464545_direct
	.type	abla_fn_865116771_688464545_direct,@function
abla_fn_865116771_688464545_direct:     # @abla_fn_865116771_688464545_direct
# %bb.0:                                # %entry
	entry	a1, 80
	l32r	a8, .LCPI131_0
	callx8	a8
	movi	a8, 0
	s32i	a8, a1, 0
	addi	a7, a1, 0
	l32r	a8, .LCPI131_1
	movi	a10, 0
	or	a11, a2, a2
	or	a12, a7, a7
	callx8	a8
	l32r	a8, .LCPI131_2
	movi	a10, 1
	or	a11, a2, a2
	or	a12, a7, a7
	callx8	a8
	l32r	a8, .LCPI131_4
	bltu	a2, a8, .LBB131_1
	j	.LBB131_26
.LBB131_1:                              # %source.label24
	l32r	a8, .LCPI131_3
	add	a9, a2, a8
	movi	a8, 4
	l32r	a10, .LCPI131_5
	movi	a12, 4
	bltu	a10, a2, .LBB131_13
# %bb.2:                                # %source.label25
	l32r	a10, .LCPI131_6
	bltu	a10, a2, .LBB131_8
# %bb.3:                                # %source.label26
	l32r	a10, .LCPI131_8
	bltu	a10, a2, .LBB131_10
# %bb.4:                                # %source.label27
	l32r	a10, .LCPI131_10
	bltu	a10, a2, .LBB131_12
# %bb.5:                                # %source.label28
	l32r	a10, .LCPI131_15
	bltu	a10, a2, .LBB131_6
	j	.LBB131_28
.LBB131_6:                              # %source.label30
	movi	a12, 8
	l32r	a10, .LCPI131_16
	bltu	a9, a10, .LBB131_13
# %bb.7:                                # %source.label35
	l32r	a12, .LCPI131_12
	l32r	a10, .LCPI131_13
	l32r	a8, .LCPI131_24
	j	.LBB131_19
.LBB131_8:                              # %source.label63
	movi	a12, 2
	l32r	a10, .LCPI131_7
	bltu	a9, a10, .LBB131_13
# %bb.9:                                # %source.label63
	movi	a12, 6
	j	.LBB131_13
.LBB131_10:                             # %source.label55
	movi	a12, 1
	l32r	a10, .LCPI131_9
	bltu	a9, a10, .LBB131_13
# %bb.11:                               # %source.label55
	movi	a12, 3
	j	.LBB131_13
.LBB131_12:                             # %source.label38
	movi	a12, 16
	l32r	a10, .LCPI131_11
	bltu	a9, a10, .LBB131_13
	j	.LBB131_29
.LBB131_13:                             # %source.label69
	#APP
	rsil	a10, 5
	#NO_APP
	l32r	a11, .LCPI131_17
	memw
	l32i	a11, a11, 0
	l32r	a13, .LCPI131_18
	memw
	l32i	a14, a13, 0
	#APP
	wsr	a10, ps
	rsync

	#NO_APP
	srli	a11, a12, 1
	movi	a10, 8
	and	a15, a11, a10
	slli	a7, a12, 1
	movi	a11, 16
	and	a7, a7, a11
	extui	a12, a12, 0, 3
	or	a12, a7, a12
	or	a15, a12, a15
	movi	a12, -1
	xor	a15, a15, a12
	and	a14, a14, a15
	memw
	s32i	a14, a13, 0
	l32r	a13, .LCPI131_5
	bltu	a13, a2, .LBB131_25
# %bb.14:                               # %source.label70
	l32r	a8, .LCPI131_6
	bltu	a8, a2, .LBB131_20
# %bb.15:                               # %source.label71
	l32r	a8, .LCPI131_8
	bltu	a8, a2, .LBB131_22
# %bb.16:                               # %source.label72
	l32r	a8, .LCPI131_10
	bltu	a8, a2, .LBB131_24
# %bb.17:                               # %source.label75
	movi	a8, 8
	l32r	a13, .LCPI131_16
	bltu	a9, a13, .LBB131_25
# %bb.18:                               # %source.label80
	l32r	a12, .LCPI131_12
	l32r	a10, .LCPI131_13
	l32r	a8, .LCPI131_23
.LBB131_19:                             # %source.label35
	movi	a11, 121
	j	.LBB131_27
.LBB131_20:                             # %source.label108
	movi	a8, 2
	l32r	a13, .LCPI131_7
	bltu	a9, a13, .LBB131_25
# %bb.21:                               # %source.label108
	movi	a8, 6
	j	.LBB131_25
.LBB131_22:                             # %source.label100
	movi	a8, 1
	l32r	a13, .LCPI131_9
	bltu	a9, a13, .LBB131_25
# %bb.23:                               # %source.label100
	movi	a8, 3
	j	.LBB131_25
.LBB131_24:                             # %source.label83
	movi	a8, 16
	l32r	a13, .LCPI131_11
	bgeu	a9, a13, .LBB131_30
.LBB131_25:                             # %source.label114
	#APP
	rsil	a9, 5
	#NO_APP
	l32r	a13, .LCPI131_17
	memw
	l32i	a13, a13, 0
	l32r	a13, .LCPI131_20
	memw
	l32i	a14, a13, 0
	#APP
	wsr	a9, ps
	rsync

	#NO_APP
	srli	a9, a8, 1
	and	a9, a9, a10
	slli	a10, a8, 1
	and	a10, a10, a11
	extui	a8, a8, 0, 3
	or	a8, a10, a8
	or	a8, a8, a9
	xor	a8, a8, a12
	and	a8, a14, a8
	memw
	s32i	a8, a13, 0
	l32r	a8, .LCPI131_21
	callx8	a8
	l32r	a8, .LCPI131_22
	callx8	a8
	retw.n
.LBB131_26:                             # %source.label
	l32r	a12, .LCPI131_12
	l32r	a10, .LCPI131_13
	l32r	a8, .LCPI131_26
	movi	a11, 107
.LBB131_27:                             # %source.label35
	or	a13, a10, a10
	callx8	a8
.LBB131_28:                             # %source.label29
	l32r	a12, .LCPI131_12
	l32r	a10, .LCPI131_13
	l32r	a8, .LCPI131_25
	movi	a11, 124
	j	.LBB131_27
.LBB131_29:                             # %source.label43
	l32r	a12, .LCPI131_12
	l32r	a10, .LCPI131_13
	l32r	a8, .LCPI131_14
	j	.LBB131_31
.LBB131_30:                             # %source.label88
	l32r	a12, .LCPI131_12
	l32r	a10, .LCPI131_13
	l32r	a8, .LCPI131_19
.LBB131_31:                             # %source.label43
	movi	a11, 118
	j	.LBB131_27
.Lfunc_end131:
	.size	abla_fn_865116771_688464545_direct, .Lfunc_end131-abla_fn_865116771_688464545_direct
                                        # -- End function
	.literal_position
	.literal .LCPI132_0, abla_static_abla_fn_627837887_633683867_2249
	.literal .LCPI132_1, 33554431
	.literal .LCPI132_2, abla_fn_321888515_252845378_direct
	.literal .LCPI132_3, abla_fn_121431496_464001390_direct
	.literal .LCPI132_4, abla_fn_121431496_464001390_direct
	.literal .LCPI132_5, abla_fn_795904359_267395915_direct
	.literal .LCPI132_6, abla_fn_213944016_953228118_direct
	.literal .LCPI132_7, .Labla_string_abla_fn_627837887_633683867_2302.native.bytes
	.literal .LCPI132_8, .Labla_string_abla_fn_627837887_633683867_2330.native.bytes
	.literal .LCPI132_9, .Labla_string_abla_fn_627837887_633683867_2274.native.bytes
	.literal .LCPI132_10, .Labla_string_abla_fn_627837887_633683867_2295.native.bytes
	.section	.iram1.abla.mmu_do_mapping,"ax",@progbits
	.section	.text.abla_fn_318984852_605722137_direct,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_318984852_605722137_direct
	.type	abla_fn_318984852_605722137_direct,@function
abla_fn_318984852_605722137_direct:     # @abla_fn_318984852_605722137_direct
# %bb.0:                                # %entry
	entry	a1, 32
	beqz	a2, .LBB132_25
# %bb.1:                                # %source.label
	l32r	a6, .LCPI132_0
	addi	a7, a6, 124
	or	a10, a7, a7
	call8	abla_fn_396055959_456822569_direct
	l32r	a8, .LCPI132_1
	and	a9, a2, a8
	l32i	a10, a6, 0
	movi	a8, 0
	movi	a11, 40
	movi	a12, 0
.LBB132_2:                              # %source.label26.outer
                                        # =>This Loop Header: Depth=1
                                        #     Child Loop BB132_3 Depth 2
	movi	a13, 1
.LBB132_3:                              # %source.label26
                                        #   Parent Loop BB132_2 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	bbci	a13, 0, .LBB132_9
# %bb.4:                                # %source.label27
                                        #   in Loop: Header=BB132_3 Depth=2
	movi	a13, 0
	bgeu	a12, a10, .LBB132_3
# %bb.5:                                # %source.label28
                                        #   in Loop: Header=BB132_2 Depth=1
	mull	a13, a12, a11
	add	a13, a6, a13
	l32i	a14, a13, 20
	bltu	a9, a14, .LBB132_8
# %bb.6:                                # %source.label29
                                        #   in Loop: Header=BB132_2 Depth=1
	l32i	a14, a13, 12
	bgeu	a9, a14, .LBB132_8
# %bb.7:                                #   in Loop: Header=BB132_2 Depth=1
	addi	a8, a13, 4
.LBB132_8:                              # %source.label34
                                        #   in Loop: Header=BB132_2 Depth=1
	addi	a12, a12, 1
	j	.LBB132_2
.LBB132_9:                              # %source.label37
	beqz	a8, .LBB132_24
# %bb.10:                               # %source.label38
	addi	a10, a8, 36
	l32i	a11, a8, 32
	movi	a12, 17
	or	a6, a11, a11
.LBB132_11:                             # %source.label40.outer
                                        # =>This Loop Header: Depth=1
                                        #     Child Loop BB132_12 Depth 2
	movi	a13, 17
.LBB132_12:                             # %source.label40
                                        #   Parent Loop BB132_11 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	extui	a13, a13, 0, 5
	bne	a13, a12, .LBB132_20
# %bb.13:                               # %source.label41
                                        #   in Loop: Header=BB132_12 Depth=2
	beqz.n	a6, .LBB132_17
# %bb.14:                               # %source.label42
                                        #   in Loop: Header=BB132_12 Depth=2
	beq	a11, a6, .LBB132_18
# %bb.15:                               # %source.label44
                                        #   in Loop: Header=BB132_12 Depth=2
	l32i	a13, a10, 0
	l32i	a13, a13, 4
	l32i	a13, a13, 0
	beq	a13, a6, .LBB132_19
# %bb.16:                               # %source.label46
                                        #   in Loop: Header=BB132_12 Depth=2
	l32i	a14, a6, 0
	movi	a13, 14
	beq	a9, a14, .LBB132_12
	j	.LBB132_19
.LBB132_17:                             #   in Loop: Header=BB132_12 Depth=2
	movi	a13, 18
	movi	a6, 0
	j	.LBB132_12
.LBB132_18:                             #   in Loop: Header=BB132_11 Depth=1
	or	a6, a11, a11
.LBB132_19:                             # %source.label53.sink.split
                                        #   in Loop: Header=BB132_11 Depth=1
	l32i	a6, a6, 36
	j	.LBB132_11
.LBB132_20:                             # %source.label40
	movi	a9, 14
	bne	a13, a9, .LBB132_24
# %bb.21:                               # %source.label55
	l32i	a9, a6, 36
	l32i	a9, a9, 0
	l32i	a11, a6, 40
	l32i	a11, a11, 4
	l32i	a11, a11, 0
	l32i	a11, a11, 4
	sub	a9, a9, a11
	l32i	a11, a8, 20
	maxu	a9, a9, a11
	s32i	a9, a8, 20
	l32i	a8, a6, 36
	movi	a2, 0
	beq	a8, a2, .LBB132_23
# %bb.22:                               # %source.label55
	addi	a10, a8, 40
.LBB132_23:                             # %source.label55
	l32i	a8, a6, 40
	s32i	a8, a10, 0
	l32i	a9, a6, 36
	s32i	a9, a8, 0
	l32i	a5, a6, 8
	l32i	a4, a6, 16
	l32r	a8, .LCPI132_2
	callx8	a8
	l32r	a8, .LCPI132_3
	movi	a10, 0
	or	a11, a5, a5
	or	a12, a4, a4
	callx8	a8
	l32r	a8, .LCPI132_4
	movi	a10, 1
	or	a11, a5, a5
	or	a12, a4, a4
	callx8	a8
	l32r	a8, .LCPI132_5
	callx8	a8
	l32r	a8, .LCPI132_6
	or	a10, a6, a6
	callx8	a8
	or	a10, a7, a7
	call8	abla_fn_954702414_417902696_direct
	retw.n
.LBB132_24:                             # %source.label65
	call8	abla_fn_11786425_863113934_direct
	or	a12, a10, a10
	l32r	a11, .LCPI132_7
	l32r	a10, .LCPI132_8
	l32r	a14, .LCPI132_9
	or	a13, a10, a10
	call8	abla_fn_992771427_703335695_direct
	or	a10, a7, a7
	call8	abla_fn_954702414_417902696_direct
	movi	a2, 261
	retw.n
.LBB132_25:                             # %source.label67
	call8	abla_fn_11786425_863113934_direct
	or	a12, a10, a10
	l32r	a11, .LCPI132_10
	l32r	a10, .LCPI132_8
	l32r	a14, .LCPI132_9
	or	a13, a10, a10
	call8	abla_fn_992771427_703335695_direct
	movi	a2, 258
	retw.n
.Lfunc_end132:
	.size	abla_fn_318984852_605722137_direct, .Lfunc_end132-abla_fn_318984852_605722137_direct
                                        # -- End function
	.literal_position
	.literal .LCPI133_0, 1073082488
	.literal .LCPI133_1, 1073082480
	.literal .LCPI133_2, 1073082496
	.literal .LCPI133_3, 1073082492
	.section	.text.abla_fn_318984852_605722137_direct,"ax",@progbits
	.section	.text.abla_fn_928611835_706970686_direct,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_928611835_706970686_direct
	.type	abla_fn_928611835_706970686_direct,@function
abla_fn_928611835_706970686_direct:     # @abla_fn_928611835_706970686_direct
# %bb.0:                                # %entry
	entry	a1, 32
	l32r	a8, .LCPI133_0
	memw
	l32i	a8, a8, 0
	l32r	a9, .LCPI133_1
	memw
	l32i	a9, a9, 0
	l32r	a10, .LCPI133_2
	movi	a11, 1
	memw
	s32i	a11, a10, 0
	memw
	extui	a9, a9, 13, 16
.LBB133_1:                              # %source.label.i.i.i
                                        # =>This Inner Loop Header: Depth=1
	movi	a10, 0
	movi	a11, 1
	bne	a9, a10, .LBB133_3
# %bb.2:                                # %source.label.i.i.i
                                        #   in Loop: Header=BB133_1 Depth=1
	movi	a11, 0
.LBB133_3:                              # %source.label.i.i.i
                                        #   in Loop: Header=BB133_1 Depth=1
	l32r	a10, .LCPI133_0
	memw
	l32i	a10, a10, 0
	bne	a10, a8, .LBB133_5
# %bb.4:                                # %source.label.i.i.i
                                        #   in Loop: Header=BB133_1 Depth=1
	addi	a9, a9, -1
	bbsi	a11, 0, .LBB133_1
.LBB133_5:                              # %source.label18.i.i.i
                                        # =>This Inner Loop Header: Depth=1
	or	a8, a10, a10
	l32r	a9, .LCPI133_3
	memw
	l32i	a9, a9, 0
	l32r	a10, .LCPI133_0
	memw
	l32i	a10, a10, 0
	bne	a10, a8, .LBB133_5
# %bb.6:                                # %abla_fn_808394598_299016420_direct.exit
	slli	a9, a9, 31
	srli	a8, a8, 1
	or	a2, a8, a9
	retw.n
.Lfunc_end133:
	.size	abla_fn_928611835_706970686_direct, .Lfunc_end133-abla_fn_928611835_706970686_direct
                                        # -- End function
	.literal_position
	.literal .LCPI134_0, errno@TPOFF
	.section	.text.abla_fn_928611835_706970686_direct,"ax",@progbits
	.section	.text.abla_fn_452289154_438779919_direct,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_452289154_438779919_direct
	.type	abla_fn_452289154_438779919_direct,@function
abla_fn_452289154_438779919_direct:     # @abla_fn_452289154_438779919_direct
# %bb.0:                                # %entry
	entry	a1, 32
	beqz.n	a3, .LBB134_5
# %bb.1:                                # %source.label2
	l8ui	a8, a2, 0
	bbsi	a8, 1, .LBB134_6
# %bb.2:                                # %source.label18
	or	a10, a5, a5
	beqi	a4, 2, .LBB134_9
# %bb.3:                                # %source.label18
	bnei	a4, 1, .LBB134_12
# %bb.4:                                # %source.label19
	callx8	a3
	j	.LBB134_14
.LBB134_5:                              # %source.label
	l32r	a8, .LCPI134_0
	rur	a9, threadptr
	add	a8, a9, a8
	movi	a9, 88
	s32i	a9, a8, 0
	movi	a2, -1
	retw.n
.LBB134_6:                              # %source.label6
	l32i	a10, a2, 8
	or	a11, a5, a5
	beqi	a4, 2, .LBB134_11
# %bb.7:                                # %source.label6
	beqi	a4, 1, .LBB134_10
# %bb.8:                                # %source.label11
	or	a12, a6, a6
	or	a13, a7, a7
	callx8	a3
	j	.LBB134_14
.LBB134_9:                              # %source.label21
	or	a11, a6, a6
.LBB134_10:                             # %common.ret
	callx8	a3
	j	.LBB134_14
.LBB134_11:                             # %source.label9
	or	a12, a6, a6
	j	.LBB134_13
.LBB134_12:                             # %source.label23
	or	a11, a6, a6
	or	a12, a7, a7
.LBB134_13:                             # %common.ret
	callx8	a3
.LBB134_14:                             # %common.ret
	or	a2, a10, a10
	retw.n
.Lfunc_end134:
	.size	abla_fn_452289154_438779919_direct, .Lfunc_end134-abla_fn_452289154_438779919_direct
                                        # -- End function
	.literal_position
	.literal .LCPI135_0, .Labla_string_abla_fn_627837887_633683867_484.native.mutable.u32s
	.literal .LCPI135_1, errno@TPOFF
	.section	.text.abla_fn_452289154_438779919_direct,"ax",@progbits
	.section	.text.abla_fn_667695803_816934227_direct,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_667695803_816934227_direct
	.type	abla_fn_667695803_816934227_direct,@function
abla_fn_667695803_816934227_direct:     # @abla_fn_667695803_816934227_direct
# %bb.0:                                # %entry
	entry	a1, 32
	or	a10, a2, a2
	call8	abla_fn_478584785_547940653_direct
	beqz.n	a10, .LBB135_3
# %bb.1:                                # %entry
	movi	a8, 63
	bltu	a8, a2, .LBB135_3
# %bb.2:                                # %abla_fn_446612303_673402789_direct.exit
	l32i	a8, a10, 4
	add	a8, a8, a3
	l32i	a11, a8, 0
	movi	a8, 3
	mull	a8, a2, a8
	l32r	a9, .LCPI135_0
	add	a8, a9, a8
	l8ui	a13, a8, 2
	addi	a12, a4, 1
	or	a14, a5, a5
	or	a15, a6, a6
	call8	abla_fn_452289154_438779919_direct
	or	a2, a10, a10
	retw.n
.LBB135_3:                              # %source.label5
	l32r	a8, .LCPI135_1
	rur	a9, threadptr
	add	a8, a9, a8
	movi	a9, 9
	s32i	a9, a8, 0
	movi	a2, -1
	retw.n
.Lfunc_end135:
	.size	abla_fn_667695803_816934227_direct, .Lfunc_end135-abla_fn_667695803_816934227_direct
                                        # -- End function
	.literal_position
	.literal .LCPI136_0, 16711680
	.literal .LCPI136_1, 8388608
	.literal .LCPI136_2, 1610801152
	.literal .LCPI136_3, 1610678272
	.literal .LCPI136_4, 1073020928
	.literal .LCPI136_5, 1610612736
	.literal .LCPI136_6, 1072955392
	.section	.text.abla_fn_667695803_816934227_direct,"ax",@progbits
	.section	.iram1.0.abla.uartHalWriteTxfifo,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_805044211_235537658_direct
	.type	abla_fn_805044211_235537658_direct,@function
abla_fn_805044211_235537658_direct:     # @abla_fn_805044211_235537658_direct
# %bb.0:                                # %entry
	entry	a1, 32
	l32i	a8, a2, 0
	memw
	l32i	a9, a8, 28
	l32r	a10, .LCPI136_0
	and	a9, a9, a10
	movi	a11, 1
	l32r	a10, .LCPI136_1
	bne	a9, a10, .LBB136_2
# %bb.1:                                # %entry
	movi	a11, 0
.LBB136_2:                              # %entry
	s32i	a11, a4, 0
	beq	a9, a10, .LBB136_9
# %bb.3:                                # %source.label13
	l32r	a9, .LCPI136_4
	beq	a8, a9, .LBB136_5
# %bb.4:                                # %source.label13
	l32r	a9, .LCPI136_2
	j	.LBB136_6
.LBB136_5:
	l32r	a9, .LCPI136_3
.LBB136_6:                              # %source.label13
	l32r	a10, .LCPI136_6
	bne	a8, a10, .LBB136_8
# %bb.7:
	l32r	a9, .LCPI136_5
.LBB136_8:                              # %source.label13
	l8ui	a8, a3, 0
	memw
	s32i	a8, a9, 0
.LBB136_9:                              # %source.label15
	retw.n
.Lfunc_end136:
	.size	abla_fn_805044211_235537658_direct, .Lfunc_end136-abla_fn_805044211_235537658_direct
                                        # -- End function
	.section	.text.abla_fn_551184966_589531566_direct,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_551184966_589531566_direct
	.type	abla_fn_551184966_589531566_direct,@function
abla_fn_551184966_589531566_direct:     # @abla_fn_551184966_589531566_direct
# %bb.0:                                # %entry
	entry	a1, 32
	call8	abla_fn_381068499_488660261_direct
	retw.n
.Lfunc_end137:
	.size	abla_fn_551184966_589531566_direct, .Lfunc_end137-abla_fn_551184966_589531566_direct
                                        # -- End function
	.literal_position
	.literal .LCPI138_0, .Labla_string_abla_fn_627837887_633683867_2569.native.mutable.u32s
	.literal .LCPI138_1, abla_fn_186944242_355245718_direct
	.literal .LCPI138_2, abla_fn_985332523_289608079_direct
	.literal .LCPI138_3, abla_fn_707068177_288599970_direct
	.section	.text.abla_fn_551184966_589531566_direct,"ax",@progbits
	.section	.text.abla_fn_67065606_756116608_direct,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_67065606_756116608_direct
	.type	abla_fn_67065606_756116608_direct,@function
abla_fn_67065606_756116608_direct:      # @abla_fn_67065606_756116608_direct
# %bb.0:                                # %entry
	entry	a1, 32
	or	a7, a1, a1
	slli	a8, a2, 7
	l32r	a9, .LCPI138_0
	add	a8, a9, a8
	l32i	a5, a8, 84
	beqz	a5, .LBB138_8
# %bb.1:                                # %source.label7
	addi	a8, a1, -32
	movsp	a1, a8
	or	a4, a1, a1
	addi	a8, a1, -32
	movsp	a1, a8
	or	a2, a1, a1
	movi	a6, 0
	or	a10, a4, a4
	movi	a11, 0
	movi	a12, 12
	call8	abla_fn_853840267_528021067_direct
	s32i	a3, a4, 0
	s32i	a6, a4, 4
	s8i	a6, a4, 8
	memw
	l32i	a8, a5, 64
	addi	a6, a5, 76
	l32r	a8, .LCPI138_1
	or	a10, a6, a6
	callx8	a8
	memw
	memw
	l32i	a8, a5, 56
	memw
	l32i	a9, a5, 60
	bgeu	a8, a9, .LBB138_7
# %bb.2:                                # %source.label27.i
	or	a10, a5, a5
	or	a11, a4, a4
	call8	abla_fn_723211900_405790393_direct
	memw
	l32i	a8, a5, 72
	beqz.n	a8, .LBB138_4
# %bb.3:                                # %source.label36.i
	or	a10, a5, a5
	call8	abla_fn_905045920_888357933_direct
	bnez.n	a10, .LBB138_6
	j	.LBB138_7
.LBB138_4:                              # %source.label39.i
	memw
	l32i	a8, a5, 36
	beqz.n	a8, .LBB138_7
# %bb.5:                                # %source.label40.i
	addi	a10, a5, 36
	l32r	a8, .LCPI138_2
	callx8	a8
	beqz.n	a10, .LBB138_7
.LBB138_6:                              # %source.label48.i
	movi	a8, 1
	memw
	s32i	a8, a2, 0
.LBB138_7:                              # %abla_fn_693607457_885789403_direct.exit
	l32r	a8, .LCPI138_3
	or	a10, a6, a6
	callx8	a8
.LBB138_8:                              # %common.ret
	retw.n
.Lfunc_end138:
	.size	abla_fn_67065606_756116608_direct, .Lfunc_end138-abla_fn_67065606_756116608_direct
                                        # -- End function
	.literal_position
	.literal .LCPI139_0, .Labla_string_abla_fn_627837887_633683867_2468.native.mutable.u32s
	.literal .LCPI139_1, .Labla_string_abla_fn_627837887_633683867_2569.native.mutable.u32s
	.literal .LCPI139_2, abla_global_447666338_361957421
	.section	.text.abla_fn_67065606_756116608_direct,"ax",@progbits
	.section	.text.abla_fn_679210682_215216081_direct,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_679210682_215216081_direct
	.type	abla_fn_679210682_215216081_direct,@function
abla_fn_679210682_215216081_direct:     # @abla_fn_679210682_215216081_direct
# %bb.0:                                # %entry
	entry	a1, 32
	l32r	a7, .LCPI139_0
	addx4	a8, a2, a7
	l32i	a8, a8, 0
	memw
	l32i	a9, a8, 28
	slli	a10, a2, 7
	slli	a6, a2, 2
	l32r	a11, .LCPI139_1
	add	a5, a11, a10
.LBB139_1:                              # %source.label
                                        # =>This Inner Loop Header: Depth=1
	extui	a9, a9, 0, 8
	beqz	a9, .LBB139_21
# %bb.2:                                # %source.label4
                                        #   in Loop: Header=BB139_1 Depth=1
	memw
	l32i	a10, a8, 0
	l32i	a9, a5, 12
	beqz	a9, .LBB139_18
# %bb.3:                                # %source.label4
                                        #   in Loop: Header=BB139_1 Depth=1
	l32i	a8, a5, 24
	bltu	a8, a9, .LBB139_4
	j	.LBB139_18
.LBB139_4:                              # %source.label11.i
                                        #   in Loop: Header=BB139_1 Depth=1
	l32i	a11, a5, 20
	l32i	a12, a5, 8
	add	a12, a12, a11
	s8i	a10, a12, 0
	addi	a8, a8, 1
	s32i	a8, a5, 24
	addi	a12, a11, 1
	movi	a11, 0
	beq	a12, a9, .LBB139_6
# %bb.5:                                # %source.label11.i
                                        #   in Loop: Header=BB139_1 Depth=1
	or	a11, a12, a12
.LBB139_6:                              # %source.label11.i
                                        #   in Loop: Header=BB139_1 Depth=1
	s32i	a11, a5, 20
	l32i	a9, a5, 56
	beqz	a9, .LBB139_17
# %bb.7:                                # %source.label18.i
                                        #   in Loop: Header=BB139_1 Depth=1
	extui	a11, a10, 0, 8
	l32i	a12, a5, 52
	movi	a10, 0
	bne	a11, a12, .LBB139_9
# %bb.8:                                # %source.label20.i
                                        #   in Loop: Header=BB139_1 Depth=1
	l32i	a10, a5, 60
	addi	a10, a10, 1
.LBB139_9:                              # %source.label22.i
                                        #   in Loop: Header=BB139_1 Depth=1
	bltu	a10, a9, .LBB139_16
# %bb.10:                               # %source.label24.i
                                        #   in Loop: Header=BB139_1 Depth=1
	l32i	a11, a5, 32
	beqz.n	a11, .LBB139_15
# %bb.11:                               # %source.label24.i
                                        #   in Loop: Header=BB139_1 Depth=1
	l32i	a12, a5, 48
	l32i	a10, a5, 36
	bgeu	a12, a10, .LBB139_15
# %bb.12:                               # %source.label10.i.i
                                        #   in Loop: Header=BB139_1 Depth=1
	sub	a8, a8, a9
	l32i	a9, a5, 44
	addx4	a11, a9, a11
	s32i	a8, a11, 0
	addi	a8, a12, 1
	s32i	a8, a5, 48
	addi	a9, a9, 1
	movi	a8, 0
	beq	a9, a10, .LBB139_14
# %bb.13:                               # %source.label10.i.i
                                        #   in Loop: Header=BB139_1 Depth=1
	or	a8, a9, a9
.LBB139_14:                             # %source.label10.i.i
                                        #   in Loop: Header=BB139_1 Depth=1
	s32i	a8, a5, 44
.LBB139_15:                             # %abla_fn_996855976_870078053_direct.exit.i
                                        #   in Loop: Header=BB139_1 Depth=1
	or	a10, a2, a2
	movi	a11, 7
	call8	abla_fn_67065606_756116608_direct
	movi	a10, 0
.LBB139_16:                             # %source.label26.i
                                        #   in Loop: Header=BB139_1 Depth=1
	s32i	a10, a5, 60
.LBB139_17:                             # %source.label7
                                        #   in Loop: Header=BB139_1 Depth=1
	add	a8, a7, a6
	l32i	a8, a8, 0
	memw
	l32i	a9, a8, 28
	j	.LBB139_1
.LBB139_18:                             # %source.label5
	or	a10, a2, a2
	movi	a11, 2
	call8	abla_fn_67065606_756116608_direct
	add	a8, a7, a6
	l32i	a8, a8, 0
	memw
	l32i	a9, a8, 12
	l32r	a10, .LCPI139_2
	l8ui	a11, a10, 0
	movi	a10, -258
	movi	a12, 0
	bne	a11, a12, .LBB139_20
# %bb.19:                               # %source.label5
	movi	a10, -1
.LBB139_20:                             # %source.label5
	and	a9, a10, a9
	memw
	s32i	a9, a8, 12
.LBB139_21:                             # %common.ret
	retw.n
.Lfunc_end139:
	.size	abla_fn_679210682_215216081_direct, .Lfunc_end139-abla_fn_679210682_215216081_direct
                                        # -- End function
	.literal_position
	.literal .LCPI140_0, .Labla_string_abla_fn_627837887_633683867_2569.native.mutable.u32s
	.literal .LCPI140_1, .Labla_string_abla_fn_627837887_633683867_2468.native.mutable.u32s
	.literal .LCPI140_2, abla_fn_805044211_235537658_direct
	.section	.text.abla_fn_679210682_215216081_direct,"ax",@progbits
	.section	.text.abla_fn_382802497_482883497_direct,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_382802497_482883497_direct
	.type	abla_fn_382802497_482883497_direct,@function
abla_fn_382802497_482883497_direct:     # @abla_fn_382802497_482883497_direct
# %bb.0:                                # %entry
	entry	a1, 32
	or	a7, a1, a1
	slli	a8, a2, 7
	l32r	a9, .LCPI140_0
	add	a4, a8, a9
	l32i	a8, a4, 0
	movi	a6, -1
	beqz	a8, .LBB140_6
# %bb.1:                                # %source.label
	beqz	a3, .LBB140_6
# %bb.2:                                # %source.label12
	addi	a8, a1, -32
	movsp	a1, a8
	movi	a6, 0
	or	a5, a1, a1
	s32i	a6, a5, 0
	l32r	a8, .LCPI140_1
	addx4	a10, a2, a8
	l32r	a8, .LCPI140_2
	or	a11, a3, a3
	or	a12, a5, a5
	callx8	a8
	l32i	a5, a5, 0
	beqz.n	a5, .LBB140_6
# %bb.3:                                # %source.label15
	addi	a8, a1, -32
	movsp	a1, a8
	movi	a8, 0
	s32i	a8, a1, 0
	l32i	a8, a4, 64
	beqz.n	a8, .LBB140_5
# %bb.4:                                # %source.label.i
	or	a12, a1, a1
	or	a10, a2, a2
	movi	a11, 1
	callx8	a8
.LBB140_5:
	or	a6, a5, a5
.LBB140_6:                              # %common.ret
	or	a2, a6, a6
	retw.n
.Lfunc_end140:
	.size	abla_fn_382802497_482883497_direct, .Lfunc_end140-abla_fn_382802497_482883497_direct
                                        # -- End function
	.literal_position
	.literal .LCPI141_0, .Labla_string_abla_fn_627837887_633683867_2569.native.mutable.u32s
	.section	.text.abla_fn_382802497_482883497_direct,"ax",@progbits
	.section	.text.abla_fn_705339533_209250841_direct,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_705339533_209250841_direct
	.type	abla_fn_705339533_209250841_direct,@function
abla_fn_705339533_209250841_direct:     # @abla_fn_705339533_209250841_direct
# %bb.0:                                # %entry
	entry	a1, 32
	or	a10, a2, a2
	movi	a2, -1
	movi	a8, 2
	bltu	a8, a10, .LBB141_4
# %bb.1:                                # %entry
	beqz.n	a3, .LBB141_4
# %bb.2:                                # %source.label1
	slli	a8, a10, 7
	l32r	a9, .LCPI141_0
	add	a7, a8, a9
	l32i	a8, a7, 0
	beqz.n	a8, .LBB141_4
# %bb.3:                                # %source.label6
	call8	abla_fn_679210682_215216081_direct
	l32i	a8, a7, 24
	s32i	a8, a3, 0
	movi	a2, 0
.LBB141_4:                              # %common.ret
	retw.n
.Lfunc_end141:
	.size	abla_fn_705339533_209250841_direct, .Lfunc_end141-abla_fn_705339533_209250841_direct
                                        # -- End function
	.literal_position
	.literal .LCPI142_0, abla_static_abla_fn_627837887_633683867_2645
	.section	.text.abla_fn_705339533_209250841_direct,"ax",@progbits
	.section	.text.abla_fn_657069300_560441530_direct,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_657069300_560441530_direct
	.type	abla_fn_657069300_560441530_direct,@function
abla_fn_657069300_560441530_direct:     # @abla_fn_657069300_560441530_direct
# %bb.0:                                # %entry
	entry	a1, 32
	extui	a9, a3, 0, 1
	movi	a8, 4
	movi	a10, 0
	bne	a9, a10, .LBB142_2
# %bb.1:                                # %entry
	movi	a8, 0
.LBB142_2:                              # %entry
	l32r	a9, .LCPI142_0
	addx8	a9, a2, a9
	or	a10, a9, a8
	call8	abla_fn_462535929_882602012_direct
	retw.n
.Lfunc_end142:
	.size	abla_fn_657069300_560441530_direct, .Lfunc_end142-abla_fn_657069300_560441530_direct
                                        # -- End function
	.literal_position
	.literal .LCPI143_0, abla_static_abla_fn_627837887_633683867_2645
	.section	.text.abla_fn_657069300_560441530_direct,"ax",@progbits
	.section	.text.abla_fn_697917503_516092084_direct,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_697917503_516092084_direct
	.type	abla_fn_697917503_516092084_direct,@function
abla_fn_697917503_516092084_direct:     # @abla_fn_697917503_516092084_direct
# %bb.0:                                # %entry
	entry	a1, 32
	extui	a9, a3, 0, 1
	movi	a8, 4
	movi	a10, 0
	bne	a9, a10, .LBB143_2
# %bb.1:                                # %entry
	movi	a8, 0
.LBB143_2:                              # %entry
	l32r	a9, .LCPI143_0
	addx8	a9, a2, a9
	or	a10, a9, a8
	call8	abla_fn_412776580_912333539_direct
	retw.n
.Lfunc_end143:
	.size	abla_fn_697917503_516092084_direct, .Lfunc_end143-abla_fn_697917503_516092084_direct
                                        # -- End function
	.literal_position
	.literal .LCPI144_0, .Labla_string_abla_fn_627837887_633683867_2605.native.mutable.u32s
	.section	.text.abla_fn_697917503_516092084_direct,"ax",@progbits
	.section	.text.abla_fn_180920739_941301973_direct,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_180920739_941301973_direct
	.type	abla_fn_180920739_941301973_direct,@function
abla_fn_180920739_941301973_direct:     # @abla_fn_180920739_941301973_direct
# %bb.0:                                # %entry
	entry	a1, 32
	l32r	a8, .LCPI144_0
	addx4	a8, a2, a8
	l32i	a9, a8, 0
	memw
	l32i	a8, a9, 28
	memw
	l32i	a10, a9, 96
	extui	a9, a10, 13, 11
	extui	a10, a10, 2, 11
	bgeu	a10, a9, .LBB144_2
# %bb.1:                                # %source.label.i
	sub	a2, a9, a10
	retw.n
.LBB144_2:                              # %source.label5.i
	bgeu	a9, a10, .LBB144_4
# %bb.3:                                # %source.label6.i
	sub	a8, a9, a10
	movi	a9, 128
	add	a2, a8, a9
	retw.n
.LBB144_4:                              # %source.label8.i
	extui	a8, a8, 0, 8
	movi	a2, 0
	beq	a8, a2, .LBB144_6
# %bb.5:                                # %source.label8.i
	movi	a2, 128
.LBB144_6:                              # %abla_fn_133827264_97595391_direct.exit
	retw.n
.Lfunc_end144:
	.size	abla_fn_180920739_941301973_direct, .Lfunc_end144-abla_fn_180920739_941301973_direct
                                        # -- End function
	.literal_position
	.literal .LCPI145_0, abla_static_abla_fn_627837887_633683867_2639
	.section	.text.abla_fn_180920739_941301973_direct,"ax",@progbits
	.section	.text.abla_fn_220071587_806136104_direct,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_220071587_806136104_direct
	.type	abla_fn_220071587_806136104_direct,@function
abla_fn_220071587_806136104_direct:     # @abla_fn_220071587_806136104_direct
# %bb.0:                                # %entry
	entry	a1, 32
	or	a7, a1, a1
	or	a10, a2, a2
	l32r	a8, .LCPI145_0
	addx4	a8, a10, a8
	l32i	a8, a8, 0
	beqz.n	a8, .LBB145_2
# %bb.1:                                # %source.label2
	addi	a8, a1, -32
	movsp	a1, a8
	movi	a8, 0
	or	a6, a1, a1
	s32i	a8, a6, 0
	or	a11, a6, a6
	call8	abla_fn_705339533_209250841_direct
	l32i	a2, a6, 0
	retw.n
.LBB145_2:                              # %source.label
	call8	abla_fn_180920739_941301973_direct
	or	a2, a10, a10
	retw.n
.Lfunc_end145:
	.size	abla_fn_220071587_806136104_direct, .Lfunc_end145-abla_fn_220071587_806136104_direct
                                        # -- End function
	.literal_position
	.literal .LCPI146_0, abla_static_abla_fn_627837887_633683867_2639
	.literal .LCPI146_1, .Labla_string_abla_fn_627837887_633683867_2569.native.mutable.u32s
	.literal .LCPI146_2, .Labla_string_abla_fn_627837887_633683867_2468.native.mutable.u32s
	.literal .LCPI146_3, abla_fn_805044211_235537658_direct
	.section	.text.abla_fn_220071587_806136104_direct,"ax",@progbits
	.section	.text.abla_fn_598330571_468812472_direct,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_598330571_468812472_direct
	.type	abla_fn_598330571_468812472_direct,@function
abla_fn_598330571_468812472_direct:     # @abla_fn_598330571_468812472_direct
# %bb.0:                                # %entry
	entry	a1, 64
	or	a7, a1, a1
	l32r	a8, .LCPI146_0
	addx4	a8, a2, a8
	l32i	a8, a8, 0
	beqz.n	a8, .LBB146_7
# %bb.1:                                # %source.label5
	addi	a8, a1, -32
	movsp	a1, a8
	s8i	a3, a1, 0
	slli	a8, a2, 7
	l32r	a9, .LCPI146_1
	add	a8, a8, a9
	l32i	a8, a8, 0
	beqz	a8, .LBB146_9
# %bb.2:                                # %source.label9.i.preheader
	or	a6, a1, a1
	movi	a5, 0
.LBB146_3:                              # %source.label9.i
                                        # =>This Inner Loop Header: Depth=1
	bnez	a5, .LBB146_9
# %bb.4:                                # %source.label10.i
                                        #   in Loop: Header=BB146_3 Depth=1
	or	a10, a2, a2
	or	a11, a6, a6
	call8	abla_fn_382802497_482883497_direct
	or	a5, a10, a10
	beqz.n	a5, .LBB146_6
# %bb.5:                                # %source.label10.i
                                        #   in Loop: Header=BB146_3 Depth=1
	bnei	a5, -1, .LBB146_3
	j	.LBB146_9
.LBB146_6:                              # %source.label15.i
                                        #   in Loop: Header=BB146_3 Depth=1
	call8	abla_fn_551184966_589531566_direct
	j	.LBB146_3
.LBB146_7:                              # %source.label
	slli	a8, a2, 2
	s8i	a3, a7, 16
	l32r	a9, .LCPI146_2
	add	a6, a8, a9
	movi	a5, 0
	l32r	a4, .LCPI146_3
	movi	a8, 0
	bnez.n	a8, .LBB146_9
.LBB146_8:                              # %source.label6.i
                                        # =>This Inner Loop Header: Depth=1
	s32i	a5, a7, 0
	addi	a11, a7, 16
	addi	a12, a7, 0
	or	a10, a6, a6
	callx8	a4
	l32i	a8, a7, 0
	beqz	a8, .LBB146_8
.LBB146_9:                              # %common.ret
	retw.n
.Lfunc_end146:
	.size	abla_fn_598330571_468812472_direct, .Lfunc_end146-abla_fn_598330571_468812472_direct
                                        # -- End function
	.literal_position
	.literal .LCPI147_0, .Labla_string_abla_fn_627837887_633683867_2613.native.mutable.u32s
	.literal .LCPI147_1, abla_static_abla_fn_627837887_633683867_2639
	.literal .LCPI147_2, abla_static_abla_fn_627837887_633683867_2619
	.literal .LCPI147_3, .Labla_string_abla_fn_627837887_633683867_2569.native.mutable.u32s
	.literal .LCPI147_4, abla_global_447666338_361957421
	.literal .LCPI147_5, .Labla_string_abla_fn_627837887_633683867_2468.native.mutable.u32s
	.literal .LCPI147_6, .Labla_string_abla_fn_627837887_633683867_2605.native.mutable.u32s
	.section	.text.abla_fn_598330571_468812472_direct,"ax",@progbits
	.section	.text.abla_fn_41065587_559615030_direct,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_41065587_559615030_direct
	.type	abla_fn_41065587_559615030_direct,@function
abla_fn_41065587_559615030_direct:      # @abla_fn_41065587_559615030_direct
# %bb.0:                                # %entry
	entry	a1, 32
	or	a7, a2, a2
	l32r	a8, .LCPI147_0
	addx4	a9, a7, a8
	l32i	a2, a9, 0
	slli	a4, a7, 2
	beqi	a2, -1, .LBB147_3
# %bb.1:                                # %source.label
	add	a8, a8, a4
	movi	a9, -1
	s32i	a9, a8, 0
.LBB147_2:                              # %common.ret
	retw.n
.LBB147_3:                              # %source.label2
	l32r	a8, .LCPI147_1
	add	a8, a4, a8
	l32i	a8, a8, 0
	beqz	a8, .LBB147_30
# %bb.4:                                # %source.label2.i
	slli	a8, a7, 7
	l32r	a9, .LCPI147_3
	add	a6, a8, a9
	l32i	a8, a6, 0
	movi	a2, -1
	beqz	a8, .LBB147_2
# %bb.5:                                # %source.label14.i.i
	l32r	a8, .LCPI147_2
	add	a8, a4, a8
	l32i	a5, a8, 0
	memw
	movi	a10, 0
	l32r	a8, .LCPI147_5
	add	a3, a8, a4
                                        # implicit-def: $a4
	movi	a8, 0
.LBB147_6:                              # %source.label17.i.i.outer
                                        # =>This Loop Header: Depth=1
                                        #     Child Loop BB147_9 Depth 2
                                        #     Child Loop BB147_13 Depth 2
                                        #     Child Loop BB147_21 Depth 2
	movi	a9, 1
	beq	a8, a10, .LBB147_8
# %bb.7:                                # %source.label17.i.i.outer
                                        #   in Loop: Header=BB147_6 Depth=1
	movi	a9, 0
.LBB147_8:                              # %source.label17.i.i
                                        #   in Loop: Header=BB147_6 Depth=1
	bbsi	a9, 0, .LBB147_9
	j	.LBB147_32
.LBB147_9:                              # %source.label18.i.i
                                        #   Parent Loop BB147_6 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	or	a10, a7, a7
	call8	abla_fn_679210682_215216081_direct
	l32i	a9, a6, 24
	bnez.n	a9, .LBB147_12
# %bb.10:                               # %source.label20.i.i
                                        #   in Loop: Header=BB147_9 Depth=2
	bnez	a5, .LBB147_2
# %bb.11:                               # %source.label22.i.i
                                        #   in Loop: Header=BB147_9 Depth=2
	call8	abla_fn_551184966_589531566_direct
	movi	a9, 1
	bbsi	a9, 0, .LBB147_9
	j	.LBB147_32
.LBB147_12:                             # %source.label28.i.i
                                        #   in Loop: Header=BB147_6 Depth=1
	l32i	a10, a6, 12
	l32i	a11, a6, 16
	movi	a12, 0
	movi	a14, 1
	or	a13, a9, a9
	movi	a8, 0
.LBB147_13:                             # %source.label32.i.i
                                        #   Parent Loop BB147_6 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	movi	a15, 1
	bne	a13, a12, .LBB147_15
# %bb.14:                               # %source.label32.i.i
                                        #   in Loop: Header=BB147_13 Depth=2
	movi	a15, 0
.LBB147_15:                             # %source.label32.i.i
                                        #   in Loop: Header=BB147_13 Depth=2
	bnei	a15, 1, .LBB147_20
# %bb.16:                               # %source.label32.i.i
                                        #   in Loop: Header=BB147_13 Depth=2
	bbci	a14, 0, .LBB147_20
# %bb.17:                               # %source.label37.i.i
                                        #   in Loop: Header=BB147_13 Depth=2
	addi	a8, a11, 1
	movi	a14, 0
	movi	a15, 0
	beq	a8, a10, .LBB147_19
# %bb.18:                               # %source.label37.i.i
                                        #   in Loop: Header=BB147_13 Depth=2
	or	a15, a8, a8
.LBB147_19:                             # %source.label37.i.i
                                        #   in Loop: Header=BB147_13 Depth=2
	addi	a13, a13, -1
	l32i	a8, a6, 8
	add	a8, a8, a11
	l8ui	a4, a8, 0
	movi	a8, 1
	or	a11, a15, a15
	j	.LBB147_13
.LBB147_20:                             # %source.label42.i.i
                                        #   in Loop: Header=BB147_6 Depth=1
	addi	a9, a9, -1
	s32i	a9, a6, 24
	s32i	a11, a6, 16
	l32i	a9, a6, 48
	l32i	a13, a6, 40
	l32i	a10, a6, 36
	l32i	a11, a6, 32
	or	a12, a9, a9
	beqz.n	a9, .LBB147_27
.LBB147_21:                             # %source.label8.i.i.i
                                        #   Parent Loop BB147_6 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	addi	a15, a13, 1
	movi	a14, 0
	beq	a15, a10, .LBB147_23
# %bb.22:                               # %source.label8.i.i.i
                                        #   in Loop: Header=BB147_21 Depth=2
	or	a14, a15, a15
.LBB147_23:                             # %source.label8.i.i.i
                                        #   in Loop: Header=BB147_21 Depth=2
	addx4	a15, a13, a11
	l32i	a15, a15, 0
	bgeu	a15, a8, .LBB147_25
# %bb.24:                               # %source.label16.i.i.i
                                        #   in Loop: Header=BB147_21 Depth=2
	addi	a12, a12, -1
	s32i	a12, a6, 48
	s32i	a14, a6, 40
	j	.LBB147_26
.LBB147_25:                             # %source.label17.i.i.i
                                        #   in Loop: Header=BB147_21 Depth=2
	slli	a13, a13, 2
	add	a13, a13, a11
	sub	a15, a15, a8
	s32i	a15, a13, 0
.LBB147_26:                             # %source.label18.i.i.i
                                        #   in Loop: Header=BB147_21 Depth=2
	addi	a9, a9, -1
	or	a13, a14, a14
	bnez	a9, .LBB147_21
.LBB147_27:                             # %abla_fn_710539107_23362691_direct.exit.i.i
                                        #   in Loop: Header=BB147_6 Depth=1
	l32r	a9, .LCPI147_4
	l8ui	a10, a9, 0
	movi	a9, 257
	movi	a11, 0
	bne	a10, a11, .LBB147_29
# %bb.28:                               # %abla_fn_710539107_23362691_direct.exit.i.i
                                        #   in Loop: Header=BB147_6 Depth=1
	movi	a9, 0
.LBB147_29:                             # %abla_fn_710539107_23362691_direct.exit.i.i
                                        #   in Loop: Header=BB147_6 Depth=1
	l32i	a10, a6, 80
	and	a9, a9, a10
	l32i	a10, a3, 0
	memw
	s32i	a9, a10, 16
	l32i	a10, a3, 0
	memw
	l32i	a11, a10, 12
	or	a9, a11, a9
	memw
	s32i	a9, a10, 12
	movi	a10, 0
	j	.LBB147_6
.LBB147_30:                             # %source.label.i
	or	a10, a7, a7
	call8	abla_fn_180920739_941301973_direct
	beqz.n	a10, .LBB147_33
# %bb.31:                               # %source.label2.i.i
	l32r	a8, .LCPI147_6
	add	a8, a4, a8
	l32i	a8, a8, 0
	memw
	l32i	a8, a8, 0
	extui	a2, a8, 0, 8
	retw.n
.LBB147_32:                             # %source.label9.i
	extui	a2, a4, 0, 8
	retw.n
.LBB147_33:
	movi	a2, -1
	retw.n
.Lfunc_end147:
	.size	abla_fn_41065587_559615030_direct, .Lfunc_end147-abla_fn_41065587_559615030_direct
                                        # -- End function
	.literal_position
	.literal .LCPI148_0, abla_static_abla_fn_627837887_633683867_2625
	.section	.text.abla_fn_41065587_559615030_direct,"ax",@progbits
	.section	.text.abla_fn_315095783_945796533_direct,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_315095783_945796533_direct
	.type	abla_fn_315095783_945796533_direct,@function
abla_fn_315095783_945796533_direct:     # @abla_fn_315095783_945796533_direct
# %bb.0:                                # %entry
	entry	a1, 32
	movi	a2, -1
	movi	a8, 2
	bltu	a8, a3, .LBB148_9
# %bb.1:                                # %entry
	beqz	a4, .LBB148_9
# %bb.2:                                # %source.label10
	or	a10, a3, a3
	movi	a11, 1
	call8	abla_fn_657069300_560441530_direct
	l32r	a8, .LCPI148_0
	addx4	a8, a3, a8
	l32i	a6, a8, 0
	movi	a2, 0
	beq	a5, a2, .LBB148_8
.LBB148_3:                              # %source.label14
                                        # =>This Inner Loop Header: Depth=1
	add	a8, a4, a2
	l8ui	a7, a8, 0
	bnei	a7, 10, .LBB148_6
# %bb.4:                                # %source.label14
                                        #   in Loop: Header=BB148_3 Depth=1
	beqz.n	a6, .LBB148_6
# %bb.5:                                # %source.label20
                                        #   in Loop: Header=BB148_3 Depth=1
	or	a10, a3, a3
	movi	a11, 13
	call8	abla_fn_598330571_468812472_direct
	beqi	a6, 1, .LBB148_7
.LBB148_6:                              # %source.label25.sink.split
                                        #   in Loop: Header=BB148_3 Depth=1
	or	a10, a3, a3
	or	a11, a7, a7
	call8	abla_fn_598330571_468812472_direct
.LBB148_7:                              # %source.label25
                                        #   in Loop: Header=BB148_3 Depth=1
	addi	a2, a2, 1
	bne	a5, a2, .LBB148_3
.LBB148_8:                              # %source.label26
	or	a10, a3, a3
	movi	a11, 1
	call8	abla_fn_697917503_516092084_direct
	or	a2, a5, a5
.LBB148_9:                              # %common.ret
	retw.n
.Lfunc_end148:
	.size	abla_fn_315095783_945796533_direct, .Lfunc_end148-abla_fn_315095783_945796533_direct
                                        # -- End function
	.literal_position
	.literal .LCPI149_0, abla_static_abla_fn_627837887_633683867_2619
	.literal .LCPI149_1, .Labla_string_abla_fn_627837887_633683867_2613.native.mutable.u32s
	.literal .LCPI149_2, .Labla_string_abla_fn_627837887_633683867_2633.native.mutable.u32s
	.literal .LCPI149_3, errno@TPOFF
	.section	.text.abla_fn_315095783_945796533_direct,"ax",@progbits
	.section	.text.abla_fn_422061067_936412767_direct,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_422061067_936412767_direct
	.type	abla_fn_422061067_936412767_direct,@function
abla_fn_422061067_936412767_direct:     # @abla_fn_422061067_936412767_direct
# %bb.0:                                # %entry
	entry	a1, 48
	movi	a2, -1
	movi	a8, 2
	bgeu	a8, a3, .LBB149_1
	j	.LBB149_25
.LBB149_1:                              # %entry
	beqz	a4, .LBB149_25
# %bb.2:                                # %source.label12
	s32i	a5, a1, 0                       # 4-byte Folded Spill
	movi	a6, 0
	or	a10, a3, a3
	movi	a11, 0
	call8	abla_fn_657069300_560441530_direct
	l32r	a8, .LCPI149_0
	addx4	a8, a3, a8
	l32i	a8, a8, 0
	movi	a9, -1
	movi	a7, -1
	bnez.n	a8, .LBB149_4
# %bb.3:                                # %source.label14
	or	a10, a3, a3
	call8	abla_fn_41065587_559615030_direct
	movi	a9, -1
	or	a7, a10, a10
.LBB149_4:                              # %source.label16
	slli	a5, a3, 2
	movi	a2, 1
	bne	a7, a9, .LBB149_6
# %bb.5:                                # %source.label16
	movi	a2, 0
.LBB149_6:                              # %source.label16
	or	a10, a3, a3
	call8	abla_fn_220071587_806136104_direct
	add	a8, a10, a2
	l32r	a9, .LCPI149_1
	add	a9, a5, a9
	s32i	a9, a1, 4                       # 4-byte Folded Spill
	l32i	a9, a9, 0
	movi	a10, -1
	movi	a11, 1
	bne	a9, a10, .LBB149_8
# %bb.7:                                # %source.label16
	movi	a11, 0
.LBB149_8:                              # %source.label16
	add	a8, a8, a11
	l32i	a9, a1, 0                       # 4-byte Folded Reload
	minu	a2, a8, a9
	l32r	a8, .LCPI149_2
	add	a5, a8, a5
	beq	a2, a6, .LBB149_21
.LBB149_9:                              # %source.label32
                                        # =>This Inner Loop Header: Depth=1
	bnei	a7, -1, .LBB149_11
# %bb.10:                               # %source.label33
                                        #   in Loop: Header=BB149_9 Depth=1
	or	a10, a3, a3
	call8	abla_fn_41065587_559615030_direct
	or	a7, a10, a10
.LBB149_11:                             # %source.label35
                                        #   in Loop: Header=BB149_9 Depth=1
	movi	a8, 13
	beq	a7, a8, .LBB149_13
# %bb.12:                               # %source.label35
                                        #   in Loop: Header=BB149_9 Depth=1
	beqi	a7, -1, .LBB149_23
	j	.LBB149_20
.LBB149_13:                             # %source.label39
                                        #   in Loop: Header=BB149_9 Depth=1
	l32i	a8, a5, 0
	beqi	a8, 1, .LBB149_19
# %bb.14:                               # %source.label39
                                        #   in Loop: Header=BB149_9 Depth=1
	bnei	a8, 2, .LBB149_18
# %bb.15:                               # %source.label43
                                        #   in Loop: Header=BB149_9 Depth=1
	or	a10, a3, a3
	call8	abla_fn_41065587_559615030_direct
	or	a7, a10, a10
	beqi	a7, -1, .LBB149_18
# %bb.16:                               # %source.label43
                                        #   in Loop: Header=BB149_9 Depth=1
	beqi	a7, 10, .LBB149_20
# %bb.17:                               # %source.label47
                                        #   in Loop: Header=BB149_9 Depth=1
	l32i	a8, a1, 4                       # 4-byte Folded Reload
	s32i	a7, a8, 0
.LBB149_18:                             # %source.label55.fold.split17
                                        #   in Loop: Header=BB149_9 Depth=1
	movi	a7, 13
	j	.LBB149_20
.LBB149_19:                             #   in Loop: Header=BB149_9 Depth=1
	movi	a7, 10
.LBB149_20:                             # %source.label55
                                        #   in Loop: Header=BB149_9 Depth=1
	add	a8, a4, a6
	s8i	a7, a8, 0
	addi	a6, a6, 1
	movi	a7, -1
	bne	a2, a6, .LBB149_9
.LBB149_21:                             # %source.label56
	beqi	a7, -1, .LBB149_24
# %bb.22:                               # %source.label57
	l32i	a8, a1, 4                       # 4-byte Folded Reload
	s32i	a7, a8, 0
	j	.LBB149_24
.LBB149_23:                             # %source.label59.loopexit
	or	a2, a6, a6
.LBB149_24:                             # %source.label59
	or	a10, a3, a3
	movi	a11, 0
	call8	abla_fn_697917503_516092084_direct
	beqz.n	a2, .LBB149_26
.LBB149_25:                             # %common.ret
	retw.n
.LBB149_26:                             # %source.label62
	l32r	a8, .LCPI149_3
	rur	a9, threadptr
	add	a8, a9, a8
	movi	a9, 11
	s32i	a9, a8, 0
	movi	a2, -1
	retw.n
.Lfunc_end149:
	.size	abla_fn_422061067_936412767_direct, .Lfunc_end149-abla_fn_422061067_936412767_direct
                                        # -- End function
	.section	.text.abla_fn_315762766_523979072_direct,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_315762766_523979072_direct
	.type	abla_fn_315762766_523979072_direct,@function
abla_fn_315762766_523979072_direct:     # @abla_fn_315762766_523979072_direct
# %bb.0:                                # %entry
	entry	a1, 32
	or	a8, a2, a2
	movi	a2, -1
	beqz.n	a8, .LBB150_3
# %bb.1:                                # %source.label
	l8ui	a9, a8, 0
	movi	a10, 47
	bne	a9, a10, .LBB150_3
# %bb.2:                                # %source.label1
	l8ui	a9, a8, 2
	beqz.n	a9, .LBB150_4
.LBB150_3:                              # %common.ret
	retw.n
.LBB150_4:                              # %source.label6
	l8ui	a8, a8, 1
	addi	a2, a8, -48
	extui	a8, a2, 0, 8
	movi	a9, 3
	bltu	a8, a9, .LBB150_3
# %bb.5:                                # %source.label6
	movi	a2, -1
	retw.n
.Lfunc_end150:
	.size	abla_fn_315762766_523979072_direct, .Lfunc_end150-abla_fn_315762766_523979072_direct
                                        # -- End function
	.literal_position
	.literal .LCPI151_0, abla_static_abla_fn_627837887_633683867_2619
	.literal .LCPI151_1, errno@TPOFF
	.section	.text.abla_fn_315762766_523979072_direct,"ax",@progbits
	.section	.text.abla_fn_322401140_130420176_direct,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_322401140_130420176_direct
	.type	abla_fn_322401140_130420176_direct,@function
abla_fn_322401140_130420176_direct:     # @abla_fn_322401140_130420176_direct
# %bb.0:                                # %entry
	entry	a1, 32
	or	a10, a3, a3
	call8	abla_fn_315762766_523979072_direct
	beqi	a10, -1, .LBB151_2
# %bb.1:                                # %source.label3
	l32r	a8, .LCPI151_0
	addx4	a8, a10, a8
	extui	a9, a4, 14, 1
	j	.LBB151_3
.LBB151_2:                              # %source.label
	l32r	a8, .LCPI151_1
	rur	a9, threadptr
	add	a8, a9, a8
	movi	a9, 2
.LBB151_3:                              # %common.ret
	s32i	a9, a8, 0
	or	a2, a10, a10
	retw.n
.Lfunc_end151:
	.size	abla_fn_322401140_130420176_direct, .Lfunc_end151-abla_fn_322401140_130420176_direct
                                        # -- End function
	.section	.text.abla_fn_546143059_927569099_direct,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_546143059_927569099_direct
	.type	abla_fn_546143059_927569099_direct,@function
abla_fn_546143059_927569099_direct:     # @abla_fn_546143059_927569099_direct
# %bb.0:                                # %entry
	entry	a1, 32
	movi	a2, 0
	movi	a8, 2
	bgeu	a8, a3, .LBB152_2
# %bb.1:                                # %entry
	movi	a2, -1
.LBB152_2:                              # %entry
	retw.n
.Lfunc_end152:
	.size	abla_fn_546143059_927569099_direct, .Lfunc_end152-abla_fn_546143059_927569099_direct
                                        # -- End function
	.literal_position
	.literal .LCPI153_0, 8192
	.section	.text.abla_fn_546143059_927569099_direct,"ax",@progbits
	.section	.text.abla_fn_500858384_48428969_direct,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_500858384_48428969_direct
	.type	abla_fn_500858384_48428969_direct,@function
abla_fn_500858384_48428969_direct:      # @abla_fn_500858384_48428969_direct
# %bb.0:                                # %entry
	entry	a1, 32
	movi	a2, -1
	movi	a8, 2
	bltu	a8, a3, .LBB153_3
# %bb.1:                                # %entry
	beqz.n	a4, .LBB153_3
# %bb.2:                                # %source.label5
	movi	a2, 0
	or	a10, a4, a4
	movi	a11, 0
	movi	a12, 88
	call8	abla_fn_853840267_528021067_direct
	l32r	a8, .LCPI153_0
	s32i	a8, a4, 4
.LBB153_3:                              # %common.ret
	retw.n
.Lfunc_end153:
	.size	abla_fn_500858384_48428969_direct, .Lfunc_end153-abla_fn_500858384_48428969_direct
                                        # -- End function
	.literal_position
	.literal .LCPI154_0, abla_static_abla_fn_627837887_633683867_2619
	.literal .LCPI154_1, 16386
	.literal .LCPI154_2, errno@TPOFF
	.section	.text.abla_fn_500858384_48428969_direct,"ax",@progbits
	.section	.text.abla_fn_925668403_79311636_direct,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_925668403_79311636_direct
	.type	abla_fn_925668403_79311636_direct,@function
abla_fn_925668403_79311636_direct:      # @abla_fn_925668403_79311636_direct
# %bb.0:                                # %entry
	entry	a1, 32
	movi	a2, -1
	bgeui	a3, 3, .LBB154_7
# %bb.1:                                # %source.label3
	beqi	a4, 4, .LBB154_5
# %bb.2:                                # %source.label3
	bnei	a4, 3, .LBB154_6
# %bb.3:                                # %source.label4
	l32r	a8, .LCPI154_0
	addx4	a8, a3, a8
	l32i	a8, a8, 0
	movi	a2, 2
	movi	a9, 0
	beq	a8, a9, .LBB154_7
# %bb.4:                                # %source.label4
	l32r	a2, .LCPI154_1
	retw.n
.LBB154_5:                              # %source.label10
	l32r	a8, .LCPI154_0
	addx4	a8, a3, a8
	extui	a9, a5, 14, 1
	s32i	a9, a8, 0
	movi	a2, 0
	retw.n
.LBB154_6:                              # %source.label16
	l32r	a8, .LCPI154_2
	rur	a9, threadptr
	add	a8, a9, a8
	movi	a9, 88
	s32i	a9, a8, 0
.LBB154_7:                              # %common.ret
	retw.n
.Lfunc_end154:
	.size	abla_fn_925668403_79311636_direct, .Lfunc_end154-abla_fn_925668403_79311636_direct
                                        # -- End function
	.literal_position
	.literal .LCPI155_0, 1073143836
	.literal .LCPI155_1, 1073020956
	.literal .LCPI155_2, 1072955420
	.literal .LCPI155_3, -65536
	.literal .LCPI155_4, 268369920
	.section	.text.abla_fn_925668403_79311636_direct,"ax",@progbits
	.section	.text.abla_fn_64859000_962709316_direct,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_64859000_962709316_direct
	.type	abla_fn_64859000_962709316_direct,@function
abla_fn_64859000_962709316_direct:      # @abla_fn_64859000_962709316_direct
# %bb.0:                                # %entry
	entry	a1, 32
	movi	a2, -1
	bgeui	a3, 3, .LBB155_11
# %bb.1:                                # %source.label4
	movi	a7, 1
	or	a10, a3, a3
	movi	a11, 1
	call8	abla_fn_657069300_560441530_direct
	beq	a3, a7, .LBB155_3
# %bb.2:                                # %source.label4
	l32r	a8, .LCPI155_0
	j	.LBB155_4
.LBB155_3:
	l32r	a8, .LCPI155_1
.LBB155_4:                              # %source.label4
	movi	a9, 0
	bne	a3, a9, .LBB155_6
# %bb.5:
	l32r	a8, .LCPI155_2
.LBB155_6:                              # %source.label4
	memw
	l32i	a10, a8, 0
	l32r	a9, .LCPI155_3
.LBB155_7:                              # %source.label.i
                                        # =>This Inner Loop Header: Depth=1
	l32r	a11, .LCPI155_4
	and	a10, a10, a11
	beqz.n	a10, .LBB155_10
# %bb.8:                                # %source.label.i
                                        #   in Loop: Header=BB155_7 Depth=1
	beqz.n	a9, .LBB155_10
# %bb.9:                                # %source.label12.i
                                        #   in Loop: Header=BB155_7 Depth=1
	addi	a9, a9, 1
	memw
	l32i	a10, a8, 0
	j	.LBB155_7
.LBB155_10:                             # %abla_fn_225629314_620667663_direct.exit
	or	a10, a3, a3
	movi	a11, 1
	call8	abla_fn_697917503_516092084_direct
	movi	a2, 0
.LBB155_11:                             # %common.ret
	retw.n
.Lfunc_end155:
	.size	abla_fn_64859000_962709316_direct, .Lfunc_end155-abla_fn_64859000_962709316_direct
                                        # -- End function
	.literal_position
	.literal .LCPI156_0, errno@TPOFF
	.section	.text.abla_fn_64859000_962709316_direct,"ax",@progbits
	.section	.text.abla_fn_748403643_303058322_direct,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_748403643_303058322_direct
	.type	abla_fn_748403643_303058322_direct,@function
abla_fn_748403643_303058322_direct:     # @abla_fn_748403643_303058322_direct
# %bb.0:                                # %entry
	entry	a1, 32
	or	a10, a3, a3
	call8	abla_fn_315762766_523979072_direct
	beqi	a10, -1, .LBB156_5
# %bb.1:                                # %source.label3
	movi	a2, 0
	beqz.n	a4, .LBB156_4
# %bb.2:                                # %source.label4
	movi	a8, 13
	bbsi	a4, 0, .LBB156_6
# %bb.3:                                # %source.label4
	movi	a9, 6
	and	a9, a4, a9
	beqz.n	a9, .LBB156_6
.LBB156_4:                              # %common.ret
	retw.n
.LBB156_5:
	movi	a8, 2
.LBB156_6:                              # %common.ret.sink.split
	l32r	a9, .LCPI156_0
	rur	a10, threadptr
	add	a9, a10, a9
	s32i	a8, a9, 0
	movi	a2, -1
	retw.n
.Lfunc_end156:
	.size	abla_fn_748403643_303058322_direct, .Lfunc_end156-abla_fn_748403643_303058322_direct
                                        # -- End function
	.literal_position
	.literal .LCPI157_0, 536870908
	.section	.text.abla_fn_748403643_303058322_direct,"ax",@progbits
	.section	.text.abla_fn_839717268_361574761_direct,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_839717268_361574761_direct
	.type	abla_fn_839717268_361574761_direct,@function
abla_fn_839717268_361574761_direct:     # @abla_fn_839717268_361574761_direct
# %bb.0:                                # %entry
	entry	a1, 32
	beqz.n	a2, .LBB157_2
# %bb.1:                                # %source.label
	srli	a8, a3, 3
	l32r	a9, .LCPI157_0
	and	a8, a8, a9
	add	a8, a8, a2
	l32i	a8, a8, 0
	neg	a9, a3
	extui	a9, a9, 0, 5
	ssr	a9
	srl	a8, a8
	extui	a2, a8, 0, 1
	retw.n
.LBB157_2:
	movi	a2, 0
	retw.n
.Lfunc_end157:
	.size	abla_fn_839717268_361574761_direct, .Lfunc_end157-abla_fn_839717268_361574761_direct
                                        # -- End function
	.literal_position
	.literal .LCPI158_0, 536870908
	.section	.text.abla_fn_839717268_361574761_direct,"ax",@progbits
	.section	.text.abla_fn_197142075_60446859_direct,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_197142075_60446859_direct
	.type	abla_fn_197142075_60446859_direct,@function
abla_fn_197142075_60446859_direct:      # @abla_fn_197142075_60446859_direct
# %bb.0:                                # %entry
	entry	a1, 32
	beqz.n	a2, .LBB158_2
# %bb.1:                                # %source.label
	neg	a8, a3
	extui	a8, a8, 0, 5
	movi	a9, 1
	ssl	a8
	sll	a8, a9
	srli	a9, a3, 3
	l32r	a10, .LCPI158_0
	and	a9, a9, a10
	add	a9, a9, a2
	l32i	a10, a9, 0
	or	a8, a10, a8
	s32i	a8, a9, 0
.LBB158_2:                              # %source.label4
	retw.n
.Lfunc_end158:
	.size	abla_fn_197142075_60446859_direct, .Lfunc_end158-abla_fn_197142075_60446859_direct
                                        # -- End function
	.section	.text.abla_fn_14439772_458449324_direct,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_14439772_458449324_direct
	.type	abla_fn_14439772_458449324_direct,@function
abla_fn_14439772_458449324_direct:      # @abla_fn_14439772_458449324_direct
# %bb.0:                                # %entry
	entry	a1, 32
	addi	a10, a2, 20
	or	a11, a3, a3
	call8	abla_fn_839717268_361574761_direct
	movi	a7, 1
	bbsi	a10, 0, .LBB159_3
# %bb.1:                                # %source.label
	addi	a10, a2, 28
	or	a11, a3, a3
	call8	abla_fn_839717268_361574761_direct
	bbsi	a10, 0, .LBB159_3
# %bb.2:                                # %source.label1
	addi	a10, a2, 36
	or	a11, a3, a3
	call8	abla_fn_839717268_361574761_direct
	or	a7, a10, a10
.LBB159_3:                              # %source.label3
	or	a2, a7, a7
	retw.n
.Lfunc_end159:
	.size	abla_fn_14439772_458449324_direct, .Lfunc_end159-abla_fn_14439772_458449324_direct
                                        # -- End function
	.literal_position
	.literal .LCPI160_0, .Labla_string_abla_fn_627837887_633683867_2670.native.mutable.u32s
	.literal .LCPI160_1, abla_fn_186944242_355245718_direct
	.literal .LCPI160_2, abla_static_abla_fn_627837887_633683867_2657.0
	.literal .LCPI160_3, abla_static_abla_fn_627837887_633683867_2651.0
	.literal .LCPI160_4, abla_static_abla_fn_627837887_633683867_425.0
	.literal .LCPI160_5, abla_fn_707068177_288599970_direct
	.section	.text.abla_fn_14439772_458449324_direct,"ax",@progbits
	.section	.text.abla_fn_151098913_597939834_direct,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_151098913_597939834_direct
	.type	abla_fn_151098913_597939834_direct,@function
abla_fn_151098913_597939834_direct:     # @abla_fn_151098913_597939834_direct
# %bb.0:                                # %entry
	entry	a1, 48
	s32i	a4, a1, 0                       # 4-byte Folded Spill
	or	a7, a3, a3
	s32i	a2, a1, 12                      # 4-byte Folded Spill
	l32r	a10, .LCPI160_0
	l32r	a8, .LCPI160_1
	callx8	a8
	movi	a9, 12
	movi	a8, 1
	beq	a7, a8, .LBB160_2
# %bb.1:                                # %entry
	movi	a9, 16
.LBB160_2:                              # %entry
	movi	a10, 8
	s32i	a10, a1, 4                      # 4-byte Folded Spill
	movi	a5, 0
	beq	a7, a5, .LBB160_4
# %bb.3:                                # %entry
	s32i	a9, a1, 4                       # 4-byte Folded Spill
.LBB160_4:                              # %entry
	movi	a9, 28
	beq	a7, a8, .LBB160_6
# %bb.5:                                # %entry
	movi	a9, 36
.LBB160_6:                              # %entry
	movi	a8, 20
	s32i	a8, a1, 8                       # 4-byte Folded Spill
	beq	a7, a5, .LBB160_8
# %bb.7:                                # %entry
	s32i	a9, a1, 8                       # 4-byte Folded Spill
.LBB160_8:                              # %entry
	l32r	a8, .LCPI160_2
	l32i	a3, a8, 0
	l32r	a8, .LCPI160_3
	l32i	a4, a8, 0
	beq	a5, a3, .LBB160_20
.LBB160_9:                              # %source.label6
                                        # =>This Loop Header: Depth=1
                                        #     Child Loop BB160_15 Depth 2
	addx4	a8, a5, a4
	l32i	a6, a8, 0
	beqz.n	a6, .LBB160_13
# %bb.10:                               # %source.label8
                                        #   in Loop: Header=BB160_9 Depth=1
	l32i	a8, a1, 8                       # 4-byte Folded Reload
	add	a10, a6, a8
	l32i	a11, a1, 12                     # 4-byte Folded Reload
	call8	abla_fn_839717268_361574761_direct
	bbci	a10, 0, .LBB160_13
# %bb.11:                               # %source.label27
                                        #   in Loop: Header=BB160_9 Depth=1
	l32i	a8, a1, 4                       # 4-byte Folded Reload
	add	a8, a6, a8
	l32i	a10, a8, 0
	l32i	a11, a1, 12                     # 4-byte Folded Reload
	call8	abla_fn_197142075_60446859_direct
	l32i	a7, a6, 4
	l32i	a8, a6, 0
	beqz.n	a8, .LBB160_14
# %bb.12:                               # %source.label.i.i
                                        #   in Loop: Header=BB160_9 Depth=1
	or	a10, a7, a7
	l32i	a11, a1, 0                      # 4-byte Folded Reload
	call8	abla_fn_637939547_606627930_direct
.LBB160_13:                             # %source.label31
                                        #   in Loop: Header=BB160_9 Depth=1
	addi	a5, a5, 1
	bne	a5, a3, .LBB160_9
	j	.LBB160_20
.LBB160_14:                             # %source.label6.preheader.i.i
                                        #   in Loop: Header=BB160_9 Depth=1
	l32r	a8, .LCPI160_4
	l32i	a2, a8, 0
	movi	a6, 0
	beq	a2, a6, .LBB160_13
.LBB160_15:                             # %source.label7.i.i
                                        #   Parent Loop BB160_9 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	or	a10, a6, a6
	call8	abla_fn_391416991_223417075_direct
	beqz.n	a10, .LBB160_18
# %bb.16:                               # %abla_fn_717417159_734732094_direct.exit.i.i
                                        #   in Loop: Header=BB160_15 Depth=2
	l32i	a8, a10, 4
	l32i	a8, a8, 48
	beqz.n	a8, .LBB160_18
# %bb.17:                               # %source.label10.i.i
                                        #   in Loop: Header=BB160_15 Depth=2
	l32i	a8, a8, 12
	bnez.n	a8, .LBB160_19
.LBB160_18:                             # %source.label15.i.i
                                        #   in Loop: Header=BB160_15 Depth=2
	addi	a6, a6, 1
	beq	a2, a6, .LBB160_13
	j	.LBB160_15
.LBB160_19:                             # %source.label13.i.i
                                        #   in Loop: Header=BB160_9 Depth=1
	or	a10, a7, a7
	l32i	a11, a1, 0                      # 4-byte Folded Reload
	callx8	a8
	j	.LBB160_13
.LBB160_20:                             # %source.label32
	l32r	a10, .LCPI160_0
	l32r	a8, .LCPI160_5
	callx8	a8
	retw.n
.Lfunc_end160:
	.size	abla_fn_151098913_597939834_direct, .Lfunc_end160-abla_fn_151098913_597939834_direct
                                        # -- End function
	.literal_position
	.literal .LCPI161_0, .Labla_string_abla_fn_627837887_633683867_2569.native.mutable.u32s
	.literal .LCPI161_1, abla_fn_500235045_572962334_direct
	.literal .LCPI161_2, .Labla_string_abla_fn_627837887_633683867_2576.native.mutable.u32s
	.literal .LCPI161_3, abla_fn_186944242_355245718_direct
	.literal .LCPI161_4, abla_static_abla_fn_627837887_633683867_2663
	.literal .LCPI161_5, abla_fn_151098913_597939834_direct
	.literal .LCPI161_6, abla_static_abla_fn_627837887_633683867_425.0
	.literal .LCPI161_7, abla_static_abla_fn_627837887_633683867_2651.0
	.literal .LCPI161_8, abla_static_abla_fn_627837887_633683867_2657.0
	.literal .LCPI161_9, abla_static_abla_fn_627837887_633683867_4085.0
	.literal .LCPI161_10, 5120
	.literal .LCPI161_11, 6144
	.literal .LCPI161_12, abla_fn_627273554_864281065_direct
	.literal .LCPI161_13, 4096
	.literal .LCPI161_14, abla_fn_627273554_864281065_direct
	.literal .LCPI161_15, abla_fn_627273554_864281065_direct
	.literal .LCPI161_16, abla_fn_707068177_288599970_direct
	.literal .LCPI161_17, abla_fn_213944016_953228118_direct
	.section	.text.abla_fn_151098913_597939834_direct,"ax",@progbits
	.section	.text.abla_fn_369693268_153718691_direct,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_369693268_153718691_direct
	.type	abla_fn_369693268_153718691_direct,@function
abla_fn_369693268_153718691_direct:     # @abla_fn_369693268_153718691_direct
# %bb.0:                                # %entry
	entry	a1, 64
	or	a8, a7, a7
	or	a7, a1, a1
	s32i	a8, a7, 12                      # 4-byte Folded Spill
	s32i	a6, a7, 16                      # 4-byte Folded Spill
	s32i	a5, a7, 20                      # 4-byte Folded Spill
	or	a6, a4, a4
	s32i	a3, a7, 28                      # 4-byte Folded Spill
	l32i	a9, a7, 64
	beqz	a9, .LBB161_28
# %bb.1:                                # %source.label18
	movi	a8, 3
	minu	a2, a2, a8
	movi	a5, 0
	s32i	a9, a7, 8                       # 4-byte Folded Spill
	s32i	a5, a9, 0
	l32r	a4, .LCPI161_0
	movi	a3, 128
	beq	a2, a5, .LBB161_7
.LBB161_2:                              # %source.label21
                                        # =>This Inner Loop Header: Depth=1
	l32i	a10, a7, 28                     # 4-byte Folded Reload
	or	a11, a5, a5
	call8	abla_fn_839717268_361574761_direct
	bbsi	a10, 0, .LBB161_5
# %bb.3:                                # %source.label24
                                        #   in Loop: Header=BB161_2 Depth=1
	or	a10, a6, a6
	or	a11, a5, a5
	call8	abla_fn_839717268_361574761_direct
	bbsi	a10, 0, .LBB161_5
# %bb.4:                                # %source.label25
                                        #   in Loop: Header=BB161_2 Depth=1
	l32i	a10, a7, 20                     # 4-byte Folded Reload
	or	a11, a5, a5
	call8	abla_fn_839717268_361574761_direct
	bbci	a10, 0, .LBB161_6
.LBB161_5:                              # %source.label28
                                        #   in Loop: Header=BB161_2 Depth=1
	l32i	a8, a4, 0
	beqz	a8, .LBB161_29
.LBB161_6:                              # %source.label33
                                        #   in Loop: Header=BB161_2 Depth=1
	add	a4, a4, a3
	addi	a5, a5, 1
	bne	a2, a5, .LBB161_2
.LBB161_7:                              # %source.label34
	l32r	a8, .LCPI161_1
	movi	a10, 44
	callx8	a8
	or	a4, a10, a10
	beqz	a4, .LBB161_30
# %bb.8:                                # %source.label38
	l32i	a8, a7, 20                      # 4-byte Folded Reload
	s32i	a8, a4, 16
	s32i	a6, a4, 12
	l32i	a3, a7, 28                      # 4-byte Folded Reload
	s32i	a3, a4, 8
	l32i	a8, a7, 12                      # 4-byte Folded Reload
	s32i	a8, a4, 4
	l32i	a8, a7, 16                      # 4-byte Folded Reload
	s32i	a8, a4, 0
	addi	a5, a4, 20
	or	a10, a5, a5
	or	a11, a3, a3
	movi	a12, 8
	call8	abla_fn_334943840_569200394_direct
	addi	a10, a4, 28
	or	a11, a6, a6
	movi	a12, 8
	call8	abla_fn_334943840_569200394_direct
	s32i	a4, a7, 24                      # 4-byte Folded Spill
	addi	a10, a4, 36
	l32i	a11, a7, 20                     # 4-byte Folded Reload
	movi	a12, 8
	call8	abla_fn_334943840_569200394_direct
	movi	a4, 0
	or	a10, a3, a3
	movi	a11, 0
	movi	a12, 8
	call8	abla_fn_853840267_528021067_direct
	or	a10, a6, a6
	movi	a11, 0
	movi	a12, 8
	call8	abla_fn_853840267_528021067_direct
	l32i	a10, a7, 20                     # 4-byte Folded Reload
	movi	a11, 0
	movi	a12, 8
	call8	abla_fn_853840267_528021067_direct
	l32r	a10, .LCPI161_2
	l32r	a8, .LCPI161_3
	callx8	a8
	bne	a4, a2, .LBB161_9
	j	.LBB161_26
.LBB161_9:                              # %source.label40
                                        # =>This Loop Header: Depth=1
                                        #     Child Loop BB161_20 Depth 2
	l32i	a10, a7, 24                     # 4-byte Folded Reload
	or	a11, a4, a4
	call8	abla_fn_14439772_458449324_direct
	bbci	a10, 0, .LBB161_14
# %bb.10:                               # %source.label41
                                        #   in Loop: Header=BB161_9 Depth=1
	l32r	a8, .LCPI161_4
	addx4	a8, a4, a8
	l32i	a8, a8, 0
	bnez.n	a8, .LBB161_13
# %bb.11:                               # %source.label44
                                        #   in Loop: Header=BB161_9 Depth=1
	slli	a9, a4, 7
	l32r	a10, .LCPI161_0
	add	a9, a9, a10
	l32i	a10, a9, 0
	beqz.n	a10, .LBB161_13
# %bb.12:                               # %source.label3.i
                                        #   in Loop: Header=BB161_9 Depth=1
	l32r	a10, .LCPI161_5
	s32i	a10, a9, 64
.LBB161_13:                             # %source.label46
                                        #   in Loop: Header=BB161_9 Depth=1
	slli	a9, a4, 2
	l32r	a10, .LCPI161_4
	add	a9, a10, a9
	addi	a8, a8, 1
	s32i	a8, a9, 0
.LBB161_14:                             # %source.label48
                                        #   in Loop: Header=BB161_9 Depth=1
	or	a10, a5, a5
	or	a11, a4, a4
	call8	abla_fn_839717268_361574761_direct
	bbci	a10, 0, .LBB161_25
# %bb.15:                               # %source.label49
                                        #   in Loop: Header=BB161_9 Depth=1
	addi	a8, a1, -32
	movsp	a1, a8
	or	a6, a1, a1
	or	a10, a4, a4
	or	a11, a6, a6
	call8	abla_fn_705339533_209250841_direct
	bnez	a10, .LBB161_25
# %bb.16:                               # %source.label49
                                        #   in Loop: Header=BB161_9 Depth=1
	l32i	a8, a6, 0
	beqz	a8, .LBB161_25
# %bb.17:                               # %source.label55
                                        #   in Loop: Header=BB161_9 Depth=1
	l32i	a10, a7, 28                     # 4-byte Folded Reload
	or	a11, a4, a4
	call8	abla_fn_197142075_60446859_direct
	l32i	a8, a7, 16                      # 4-byte Folded Reload
	beqz.n	a8, .LBB161_19
# %bb.18:                               # %source.label.i
                                        #   in Loop: Header=BB161_9 Depth=1
	l32i	a10, a7, 12                     # 4-byte Folded Reload
	call8	abla_fn_522837838_820976022_direct
	j	.LBB161_25
.LBB161_19:                             # %source.label6.preheader.i
                                        #   in Loop: Header=BB161_9 Depth=1
	l32r	a8, .LCPI161_6
	l32i	a3, a8, 0
	movi	a6, 0
	beq	a3, a6, .LBB161_25
.LBB161_20:                             # %source.label7.i
                                        #   Parent Loop BB161_9 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	or	a10, a6, a6
	call8	abla_fn_391416991_223417075_direct
	beqz.n	a10, .LBB161_23
# %bb.21:                               # %abla_fn_717417159_734732094_direct.exit.i
                                        #   in Loop: Header=BB161_20 Depth=2
	l32i	a8, a10, 4
	l32i	a8, a8, 48
	beqz.n	a8, .LBB161_23
# %bb.22:                               # %source.label10.i
                                        #   in Loop: Header=BB161_20 Depth=2
	l32i	a8, a8, 8
	bnez.n	a8, .LBB161_24
.LBB161_23:                             # %source.label15.i
                                        #   in Loop: Header=BB161_20 Depth=2
	addi	a6, a6, 1
	beq	a3, a6, .LBB161_25
	j	.LBB161_20
.LBB161_24:                             # %source.label13.i
                                        #   in Loop: Header=BB161_9 Depth=1
	l32i	a10, a7, 12                     # 4-byte Folded Reload
	callx8	a8
.LBB161_25:                             # %source.label59
                                        #   in Loop: Header=BB161_9 Depth=1
	addi	a4, a4, 1
	beq	a4, a2, .LBB161_26
	j	.LBB161_9
.LBB161_26:                             # %source.label60
	l32r	a3, .LCPI161_7
	l32i	a5, a3, 0
	l32r	a8, .LCPI161_8
	l32i	a4, a8, 0
	addi	a2, a4, 1
	slli	a6, a2, 2
	l32r	a8, .LCPI161_9
	l8ui	a8, a8, 0
	beqz.n	a8, .LBB161_31
# %bb.27:                               # %source.label.i.i.i
	l32r	a12, .LCPI161_11
	l32r	a8, .LCPI161_15
	or	a10, a5, a5
	or	a11, a6, a6
	callx8	a8
	beqz	a10, .LBB161_38
	j	.LBB161_39
.LBB161_28:
	movi	a2, 258
	retw.n
.LBB161_29:
	movi	a2, 259
	retw.n
.LBB161_30:
	movi	a2, 257
	retw.n
.LBB161_31:                             # %source.label2.i.i.i
	movi	a8, 0
	beq	a6, a8, .LBB161_33
# %bb.32:                               # %source.label2.i.i.i
	l32r	a12, .LCPI161_10
	j	.LBB161_34
.LBB161_33:
	l32r	a12, .LCPI161_11
.LBB161_34:                             # %source.label2.i.i.i
	l32r	a8, .LCPI161_12
	or	a10, a5, a5
	or	a11, a6, a6
	callx8	a8
	bnez.n	a10, .LBB161_37
# %bb.35:                               # %source.label2.i.i.i
	beqz.n	a6, .LBB161_37
# %bb.36:                               # %source.label13.i.i.i
	l32r	a12, .LCPI161_13
	l32r	a8, .LCPI161_14
	or	a10, a5, a5
	or	a11, a6, a6
	callx8	a8
.LBB161_37:                             # %source.label15.i.i.i
	bnez.n	a10, .LBB161_39
.LBB161_38:                             # %source.label15.i.i.i
	bnez.n	a6, .LBB161_41
.LBB161_39:                             # %abla_fn_836551756_987280724_direct.exit.i
	beqz.n	a10, .LBB161_41
# %bb.40:                               # %source.label5.i
	addx4	a8, a4, a10
	l32i	a5, a7, 24                      # 4-byte Folded Reload
	s32i	a5, a8, 0
	l32r	a8, .LCPI161_8
	s32i	a2, a8, 0
	s32i	a10, a3, 0
	movi	a2, 0
	movi	a6, 1
	j	.LBB161_42
.LBB161_41:
	movi	a2, 257
	movi	a6, 0
	l32i	a5, a7, 24                      # 4-byte Folded Reload
.LBB161_42:                             # %abla_fn_602049220_774364212_direct.exit
	l32r	a10, .LCPI161_2
	l32r	a8, .LCPI161_16
	callx8	a8
	beqz.n	a6, .LBB161_44
# %bb.43:                               # %source.label64
	l32i	a8, a7, 8                       # 4-byte Folded Reload
	s32i	a5, a8, 0
	movi	a2, 0
	retw.n
.LBB161_44:                             # %source.label62
	l32r	a8, .LCPI161_17
	or	a10, a5, a5
	callx8	a8
	retw.n
.Lfunc_end161:
	.size	abla_fn_369693268_153718691_direct, .Lfunc_end161-abla_fn_369693268_153718691_direct
                                        # -- End function
	.literal_position
	.literal .LCPI162_0, .Labla_string_abla_fn_627837887_633683867_2576.native.mutable.u32s
	.literal .LCPI162_1, abla_fn_186944242_355245718_direct
	.literal .LCPI162_2, abla_static_abla_fn_627837887_633683867_2657.0
	.literal .LCPI162_3, abla_static_abla_fn_627837887_633683867_2651.0
	.literal .LCPI162_4, abla_static_abla_fn_627837887_633683867_2663
	.literal .LCPI162_5, .Labla_string_abla_fn_627837887_633683867_2569.native.mutable.u32s
	.literal .LCPI162_6, abla_fn_707068177_288599970_direct
	.literal .LCPI162_7, abla_fn_213944016_953228118_direct
	.section	.text.abla_fn_369693268_153718691_direct,"ax",@progbits
	.section	.text.abla_fn_870340349_402015619_direct,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_870340349_402015619_direct
	.type	abla_fn_870340349_402015619_direct,@function
abla_fn_870340349_402015619_direct:     # @abla_fn_870340349_402015619_direct
# %bb.0:                                # %entry
	entry	a1, 32
	or	a7, a2, a2
	beqz.n	a7, .LBB162_5
# %bb.1:                                # %source.label4
	l32r	a10, .LCPI162_0
	l32r	a8, .LCPI162_1
	callx8	a8
	l32r	a8, .LCPI162_2
	l32i	a11, a8, 0
	l32r	a9, .LCPI162_3
	l32i	a9, a9, 0
	movi	a12, 0
	or	a10, a9, a9
	beq	a11, a12, .LBB162_4
.LBB162_2:                              # %source.label5.i
                                        # =>This Inner Loop Header: Depth=1
	l32i	a13, a10, 0
	beq	a13, a7, .LBB162_6
# %bb.3:                                # %source.label11.i
                                        #   in Loop: Header=BB162_2 Depth=1
	addi	a10, a10, 4
	addi	a12, a12, 1
	bne	a11, a12, .LBB162_2
.LBB162_4:
	movi	a2, 259
	j	.LBB162_9
.LBB162_5:
	movi	a2, 258
	retw.n
.LBB162_6:                              # %source.label6.i
	addi	a11, a11, -1
	bgeu	a12, a11, .LBB162_8
# %bb.7:                                # %source.label7.i
	addx4	a9, a11, a9
	l32i	a9, a9, 0
	s32i	a9, a10, 0
.LBB162_8:                              # %source.label9.i
	s32i	a11, a8, 0
	movi	a2, 0
.LBB162_9:                              # %abla_fn_953663827_753963868_direct.exit
	l32r	a4, .LCPI162_4
	l32r	a3, .LCPI162_5
	movi	a5, 128
	movi	a6, 0
	beqi	a6, 3, .LBB162_15
.LBB162_10:                             # %source.label7
                                        # =>This Inner Loop Header: Depth=1
	or	a10, a7, a7
	or	a11, a6, a6
	call8	abla_fn_14439772_458449324_direct
	bbci	a10, 0, .LBB162_14
# %bb.11:                               # %source.label8
                                        #   in Loop: Header=BB162_10 Depth=1
	l32i	a8, a4, 0
	addi	a8, a8, -1
	s32i	a8, a4, 0
	bnez.n	a8, .LBB162_14
# %bb.12:                               # %source.label11
                                        #   in Loop: Header=BB162_10 Depth=1
	l32i	a8, a3, 0
	beqz.n	a8, .LBB162_14
# %bb.13:                               # %source.label3.i
                                        #   in Loop: Header=BB162_10 Depth=1
	movi	a8, 0
	s32i	a8, a3, 64
.LBB162_14:                             # %source.label15
                                        #   in Loop: Header=BB162_10 Depth=1
	add	a3, a3, a5
	addi	a4, a4, 4
	addi	a6, a6, 1
	bnei	a6, 3, .LBB162_10
.LBB162_15:                             # %source.label16
	l32r	a10, .LCPI162_0
	l32r	a8, .LCPI162_6
	callx8	a8
	l32r	a8, .LCPI162_7
	or	a10, a7, a7
	callx8	a8
	retw.n
.Lfunc_end162:
	.size	abla_fn_870340349_402015619_direct, .Lfunc_end162-abla_fn_870340349_402015619_direct
                                        # -- End function
	.literal_position
	.literal .LCPI163_0, abla_static_abla_fn_627837887_633683867_425.0
	.literal .LCPI163_1, .Labla_string_abla_fn_627837887_633683867_2675.native.bytes
	.literal .LCPI163_2, abla_static_abla_fn_627837887_633683867_419
	.literal .LCPI163_3, 6144
	.literal .LCPI163_4, .Labla_string_abla_fn_627837887_633683867_2747.native.u32s
	.section	.text.abla_fn_870340349_402015619_direct,"ax",@progbits
	.section	.text.abla_fn_337303989_705926631_direct,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_337303989_705926631_direct
	.type	abla_fn_337303989_705926631_direct,@function
abla_fn_337303989_705926631_direct:     # @abla_fn_337303989_705926631_direct
# %bb.0:                                # %entry
	entry	a1, 32
	l32r	a6, .LCPI163_0
	l32i	a5, a6, 0
	movi	a8, 7
	bltu	a8, a5, .LBB163_2
# %bb.1:                                # %abla_fn_698704446_201113315_direct.exit.i
	l32r	a8, .LCPI163_1
	l8ui	a8, a8, 8
	movi	a9, 47
	bne	a8, a9, .LBB163_3
.LBB163_2:                              # %abla_fn_117261465_542631747_direct.exit
	movi	a2, 0
	retw.n
.LBB163_3:                              # %source.label.i.i.preheader
	movi	a4, 0
	l32r	a3, .LCPI163_2
	beqi	a4, 8, .LBB163_2
.LBB163_4:                              # %source.label1.i.i
                                        # =>This Inner Loop Header: Depth=1
	l32i	a8, a3, 0
	beqz.n	a8, .LBB163_6
# %bb.5:                                # %source.label4.i.i
                                        #   in Loop: Header=BB163_4 Depth=1
	addi	a3, a3, 4
	addi	a4, a4, 1
	beqi	a4, 8, .LBB163_2
	j	.LBB163_4
.LBB163_6:                              # %source.label22.i
	l32r	a11, .LCPI163_3
	movi	a10, 30
	call8	abla_fn_607480688_644791182_direct
	or	a7, a10, a10
	beqz	a7, .LBB163_2
# %bb.7:                                # %source.label28.i
	movi	a8, 9
	s32i	a8, a7, 16
	s32i	a4, a7, 12
	movi	a8, 0
	s32i	a8, a7, 8
	l32r	a8, .LCPI163_4
	s32i	a8, a7, 4
	movi	a8, 10
	s32i	a8, a7, 0
	addi	a10, a7, 20
	l32r	a11, .LCPI163_1
	movi	a12, 10
	call8	abla_fn_334943840_569200394_direct
	s32i	a7, a3, 0
	bne	a5, a4, .LBB163_2
# %bb.8:                                # %source.label29.i
	addi	a8, a5, 1
	s32i	a8, a6, 0
	j	.LBB163_2
.Lfunc_end163:
	.size	abla_fn_337303989_705926631_direct, .Lfunc_end163-abla_fn_337303989_705926631_direct
                                        # -- End function
	.literal_position
	.literal .LCPI164_0, .Labla_string_abla_fn_627837887_633683867_2747.native.u32s
	.literal .LCPI164_1, abla_static_abla_fn_627837887_633683867_2759.0
	.section	.text.abla_fn_337303989_705926631_direct,"ax",@progbits
	.section	.text.abla_fn_156319067_875660471_direct,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_156319067_875660471_direct
	.type	abla_fn_156319067_875660471_direct,@function
abla_fn_156319067_875660471_direct:     # @abla_fn_156319067_875660471_direct
# %bb.0:                                # %entry
	entry	a1, 48
	l32r	a8, .LCPI164_1
	l8ui	a8, a8, 0
	movi	a9, 0
	bne	a8, a9, .LBB164_2
# %bb.1:                                # %entry
	movi	a8, 48
	j	.LBB164_3
.LBB164_2:
	l32r	a8, .LCPI164_0
	addi	a8, a8, 48
.LBB164_3:                              # %entry
	l32i	a8, a8, 0
	l32i	a8, a8, 0
	beqz.n	a8, .LBB164_5
# %bb.4:                                # %source.label4
	l32i	a9, a1, 48
	s32i	a9, a1, 0
	or	a10, a2, a2
	or	a11, a3, a3
	or	a12, a4, a4
	or	a13, a5, a5
	or	a14, a6, a6
	or	a15, a7, a7
	callx8	a8
	or	a2, a10, a10
	retw.n
.LBB164_5:
	movi	a2, 262
	retw.n
.Lfunc_end164:
	.size	abla_fn_156319067_875660471_direct, .Lfunc_end164-abla_fn_156319067_875660471_direct
                                        # -- End function
	.literal_position
	.literal .LCPI165_0, .Labla_string_abla_fn_627837887_633683867_2747.native.u32s
	.literal .LCPI165_1, abla_static_abla_fn_627837887_633683867_2759.0
	.section	.text.abla_fn_156319067_875660471_direct,"ax",@progbits
	.section	.text.abla_fn_891148129_194415638_direct,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_891148129_194415638_direct
	.type	abla_fn_891148129_194415638_direct,@function
abla_fn_891148129_194415638_direct:     # @abla_fn_891148129_194415638_direct
# %bb.0:                                # %entry
	entry	a1, 32
	l32r	a8, .LCPI165_1
	l8ui	a8, a8, 0
	movi	a9, 0
	bne	a8, a9, .LBB165_2
# %bb.1:                                # %entry
	movi	a8, 48
	j	.LBB165_3
.LBB165_2:
	l32r	a8, .LCPI165_0
	addi	a8, a8, 48
.LBB165_3:                              # %entry
	l32i	a8, a8, 0
	l32i	a8, a8, 20
	beqz.n	a8, .LBB165_5
# %bb.4:                                # %source.label4
	or	a10, a2, a2
	callx8	a8
	or	a2, a10, a10
	retw.n
.LBB165_5:
	movi	a2, 262
	retw.n
.Lfunc_end165:
	.size	abla_fn_891148129_194415638_direct, .Lfunc_end165-abla_fn_891148129_194415638_direct
                                        # -- End function
	.literal_position
	.literal .LCPI166_0, abla_static_abla_fn_627837887_633683867_2765.0
	.literal .LCPI166_1, .Labla_string_abla_fn_627837887_633683867_484.native.mutable.u32s
	.literal .LCPI166_2, errno@TPOFF
	.literal .LCPI166_3, abla_static_abla_fn_627837887_633683867_2771.0
	.section	.text.abla_fn_891148129_194415638_direct,"ax",@progbits
	.section	.text.abla_fn_51800387_177339318_direct,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_51800387_177339318_direct
	.type	abla_fn_51800387_177339318_direct,@function
abla_fn_51800387_177339318_direct:      # @abla_fn_51800387_177339318_direct
# %bb.0:                                # %entry
	entry	a1, 32
	l32r	a3, .LCPI166_0
	l32i	a8, a3, 0
	beqz.n	a8, .LBB166_2
# %bb.1:                                # %source.label
	addi	a8, a8, 1
	j	.LBB166_17
.LBB166_2:                              # %source.label5
	call8	abla_fn_758233383_766816536_direct
	or	a7, a10, a10
	beqz	a7, .LBB166_10
# %bb.3:                                # %source.label4.i.i.i
	extui	a8, a4, 0, 2
	beqz.n	a8, .LBB166_5
# %bb.4:                                # %source.label6.i.i.i
	l8ui	a9, a7, 0
	movi	a8, 30
	bbci	a9, 2, .LBB166_5
	j	.LBB166_14
.LBB166_5:                              # %abla_fn_333152199_631801320_direct.exit43.i.i.i
	slli	a8, a4, 25
	srai	a8, a8, 31
	and	a6, a8, a5
	l32i	a8, a7, 4
	l32i	a5, a8, 20
	or	a10, a7, a7
	call8	abla_fn_296193149_144011569_direct
	or	a13, a10, a10
	or	a10, a7, a7
	or	a11, a5, a5
	movi	a12, 3
	or	a14, a4, a4
	or	a15, a6, a6
	call8	abla_fn_452289154_438779919_direct
	or	a6, a10, a10
	bltz	a6, .LBB166_15
# %bb.6:                                # %source.label15.i.i.i
	l32i	a4, a7, 12
	call8	abla_fn_816159239_883263028_direct
	movi	a5, 0
	l32r	a8, .LCPI166_1
	movi	a9, 255
	movi	a2, -1
	beqi	a5, 64, .LBB166_9
.LBB166_7:                              # %source.label5.i.i.i.i
                                        # =>This Inner Loop Header: Depth=1
	l8ui	a10, a8, 1
	beq	a10, a9, .LBB166_11
# %bb.8:                                # %source.label8.i.i.i.i
                                        #   in Loop: Header=BB166_7 Depth=1
	addi	a8, a8, 3
	addi	a5, a5, 1
	bnei	a5, 64, .LBB166_7
.LBB166_9:
	movi	a5, -1
	j	.LBB166_12
.LBB166_10:
	movi	a8, 2
	j	.LBB166_14
.LBB166_11:                             # %source.label6.i.i.i.i
	s8i	a6, a8, 2
	s8i	a4, a8, 1
	movi	a9, 0
	s8i	a9, a8, 0
.LBB166_12:                             # %abla_fn_274487006_235702009_direct.exit.i.i.i
	call8	abla_fn_579039599_215173597_direct
	blt	a2, a5, .LBB166_16
# %bb.13:                               # %abla_fn_333152199_631801320_direct.exit.i.i.i
	l32i	a8, a7, 4
	l32i	a11, a8, 24
	or	a10, a7, a7
	movi	a12, 1
	or	a13, a6, a6
	movi	a14, 0
	movi	a15, 0
	call8	abla_fn_452289154_438779919_direct
	movi	a8, 23
.LBB166_14:                             # %common.ret.sink.split.i.i.i
	l32r	a9, .LCPI166_2
	rur	a10, threadptr
	add	a9, a10, a9
	s32i	a8, a9, 0
.LBB166_15:
	movi	a5, -1
.LBB166_16:                             # %abla_fn_409272514_522187710_direct.exit
	l32r	a8, .LCPI166_3
	s32i	a5, a8, 0
	movi	a8, 1
.LBB166_17:                             # %common.ret
	s32i	a8, a3, 0
	movi	a2, 0
	retw.n
.Lfunc_end166:
	.size	abla_fn_51800387_177339318_direct, .Lfunc_end166-abla_fn_51800387_177339318_direct
                                        # -- End function
	.literal_position
	.literal .LCPI167_0, abla_static_abla_fn_627837887_633683867_2771.0
	.section	.text.abla_fn_51800387_177339318_direct,"ax",@progbits
	.section	.text.abla_fn_902582166_734695485_direct,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_902582166_734695485_direct
	.type	abla_fn_902582166_734695485_direct,@function
abla_fn_902582166_734695485_direct:     # @abla_fn_902582166_734695485_direct
# %bb.0:                                # %entry
	entry	a1, 32
	or	a2, a5, a5
	or	a13, a4, a4
	l32r	a8, .LCPI167_0
	l32i	a10, a8, 0
	movi	a11, 0
	movi	a12, 2
	or	a14, a2, a2
	call8	abla_fn_667695803_816934227_direct
	retw.n
.Lfunc_end167:
	.size	abla_fn_902582166_734695485_direct, .Lfunc_end167-abla_fn_902582166_734695485_direct
                                        # -- End function
	.literal_position
	.literal .LCPI168_0, abla_static_abla_fn_627837887_633683867_2771.0
	.section	.text.abla_fn_902582166_734695485_direct,"ax",@progbits
	.section	.text.abla_fn_276581088_959060495_direct,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_276581088_959060495_direct
	.type	abla_fn_276581088_959060495_direct,@function
abla_fn_276581088_959060495_direct:     # @abla_fn_276581088_959060495_direct
# %bb.0:                                # %entry
	entry	a1, 32
	or	a13, a4, a4
	l32r	a8, .LCPI168_0
	l32i	a10, a8, 0
	movi	a11, 28
	movi	a12, 1
	movi	a14, 0
	call8	abla_fn_667695803_816934227_direct
	or	a2, a10, a10
	retw.n
.Lfunc_end168:
	.size	abla_fn_276581088_959060495_direct, .Lfunc_end168-abla_fn_276581088_959060495_direct
                                        # -- End function
	.literal_position
	.literal .LCPI169_0, abla_static_abla_fn_627837887_633683867_2765.0
	.literal .LCPI169_1, abla_static_abla_fn_627837887_633683867_2771.0
	.literal .LCPI169_2, .Labla_string_abla_fn_627837887_633683867_484.native.mutable.u32s
	.literal .LCPI169_3, errno@TPOFF
	.section	.text.abla_fn_276581088_959060495_direct,"ax",@progbits
	.section	.text.abla_fn_332235414_655482945_direct,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_332235414_655482945_direct
	.type	abla_fn_332235414_655482945_direct,@function
abla_fn_332235414_655482945_direct:     # @abla_fn_332235414_655482945_direct
# %bb.0:                                # %entry
	entry	a1, 32
	l32r	a8, .LCPI169_0
	l32i	a9, a8, 0
	beqz.n	a9, .LBB169_3
# %bb.1:                                # %source.label4
	addi	a9, a9, -1
	s32i	a9, a8, 0
	movi	a2, 0
	beqz.n	a9, .LBB169_4
.LBB169_2:                              # %common.ret
	retw.n
.LBB169_3:                              # %source.label
	l32r	a8, .LCPI169_3
	rur	a9, threadptr
	add	a8, a9, a8
	movi	a9, 9
	s32i	a9, a8, 0
	movi	a2, -1
	retw.n
.LBB169_4:                              # %source.label6
	l32r	a8, .LCPI169_1
	l32i	a7, a8, 0
	or	a10, a7, a7
	movi	a11, 24
	movi	a12, 0
	movi	a13, 0
	movi	a14, 0
	call8	abla_fn_667695803_816934227_direct
	bnei	a10, -1, .LBB169_6
# %bb.5:                                # %source.label.i.i.i
	or	a10, a7, a7
	call8	abla_fn_478584785_547940653_direct
	beqz	a10, .LBB169_2
.LBB169_6:                              # %source.label4.i.i.i
	movi	a8, 63
	bltu	a8, a7, .LBB169_2
# %bb.7:                                # %source.label6.i.i.i.i
	movi	a8, 3
	mull	a8, a7, a8
	l32r	a9, .LCPI169_2
	add	a7, a8, a9
	call8	abla_fn_816159239_883263028_direct
	l8ui	a8, a7, 0
	bbsi	a8, 0, .LBB169_11
# %bb.8:                                # %source.label7.i.i.i.i
	bbsi	a8, 2, .LBB169_10
# %bb.9:                                # %source.label9.i.i.i.i
	movi	a8, 255
	s8i	a8, a7, 1
	movi	a9, 0
	s8i	a9, a7, 0
	s8i	a8, a7, 2
	j	.LBB169_11
.LBB169_10:                             # %source.label8.i.i.i.i
	movi	a9, 2
	or	a8, a8, a9
	s8i	a8, a7, 0
.LBB169_11:                             # %source.label12.i.i.i.i
	call8	abla_fn_579039599_215173597_direct
	retw.n
.Lfunc_end169:
	.size	abla_fn_332235414_655482945_direct, .Lfunc_end169-abla_fn_332235414_655482945_direct
                                        # -- End function
	.literal_position
	.literal .LCPI170_0, abla_static_abla_fn_627837887_633683867_2771.0
	.section	.text.abla_fn_332235414_655482945_direct,"ax",@progbits
	.section	.text.abla_fn_972528636_40049108_direct,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_972528636_40049108_direct
	.type	abla_fn_972528636_40049108_direct,@function
abla_fn_972528636_40049108_direct:      # @abla_fn_972528636_40049108_direct
# %bb.0:                                # %entry
	entry	a1, 32
	or	a14, a5, a5
	or	a13, a4, a4
	l32r	a8, .LCPI170_0
	l32i	a10, a8, 0
	movi	a11, 8
	movi	a12, 2
	call8	abla_fn_667695803_816934227_direct
	or	a2, a10, a10
	retw.n
.Lfunc_end170:
	.size	abla_fn_972528636_40049108_direct, .Lfunc_end170-abla_fn_972528636_40049108_direct
                                        # -- End function
	.literal_position
	.literal .LCPI171_0, abla_static_abla_fn_627837887_633683867_2771.0
	.section	.text.abla_fn_972528636_40049108_direct,"ax",@progbits
	.section	.text.abla_fn_722127480_787560196_direct,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_722127480_787560196_direct
	.type	abla_fn_722127480_787560196_direct,@function
abla_fn_722127480_787560196_direct:     # @abla_fn_722127480_787560196_direct
# %bb.0:                                # %entry
	entry	a1, 32
	or	a14, a5, a5
	or	a13, a4, a4
	l32r	a8, .LCPI171_0
	l32i	a10, a8, 0
	movi	a11, 32
	movi	a12, 2
	call8	abla_fn_667695803_816934227_direct
	or	a2, a10, a10
	retw.n
.Lfunc_end171:
	.size	abla_fn_722127480_787560196_direct, .Lfunc_end171-abla_fn_722127480_787560196_direct
                                        # -- End function
	.literal_position
	.literal .LCPI172_0, abla_static_abla_fn_627837887_633683867_2771.0
	.section	.text.abla_fn_722127480_787560196_direct,"ax",@progbits
	.section	.text.abla_fn_71339790_974836269_direct,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_71339790_974836269_direct
	.type	abla_fn_71339790_974836269_direct,@function
abla_fn_71339790_974836269_direct:      # @abla_fn_71339790_974836269_direct
# %bb.0:                                # %entry
	entry	a1, 32
	l32r	a8, .LCPI172_0
	l32i	a10, a8, 0
	movi	a11, 40
	movi	a12, 0
	movi	a13, 0
	movi	a14, 0
	call8	abla_fn_667695803_816934227_direct
	or	a2, a10, a10
	retw.n
.Lfunc_end172:
	.size	abla_fn_71339790_974836269_direct, .Lfunc_end172-abla_fn_71339790_974836269_direct
                                        # -- End function
	.literal_position
	.literal .LCPI173_0, errno@TPOFF
	.section	.text.abla_fn_71339790_974836269_direct,"ax",@progbits
	.section	.text.abla_fn_115387104_275846057_direct,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_115387104_275846057_direct
	.type	abla_fn_115387104_275846057_direct,@function
abla_fn_115387104_275846057_direct:     # @abla_fn_115387104_275846057_direct
# %bb.0:                                # %entry
	entry	a1, 32
	call8	abla_fn_758233383_766816536_direct
	or	a7, a10, a10
	beqz.n	a7, .LBB173_3
# %bb.1:                                # %source.label2.i.i
	l32i	a8, a7, 4
	l32i	a8, a8, 44
	beqz.n	a8, .LBB173_4
# %bb.2:                                # %source.label2.i.i.i
	l32i	a6, a8, 48
	j	.LBB173_5
.LBB173_3:                              # %source.label.i.i
	l32r	a8, .LCPI173_0
	rur	a9, threadptr
	add	a8, a9, a8
	movi	a9, 2
	s32i	a9, a8, 0
	movi	a2, -1
	retw.n
.LBB173_4:
	movi	a6, 0
.LBB173_5:                              # %abla_fn_252296738_853804276_direct.exit.i.i
	or	a10, a7, a7
	call8	abla_fn_296193149_144011569_direct
	or	a13, a10, a10
	or	a10, a7, a7
	or	a11, a6, a6
	movi	a12, 2
	or	a14, a4, a4
	movi	a15, 0
	call8	abla_fn_452289154_438779919_direct
	or	a2, a10, a10
	retw.n
.Lfunc_end173:
	.size	abla_fn_115387104_275846057_direct, .Lfunc_end173-abla_fn_115387104_275846057_direct
                                        # -- End function
	.literal_position
	.literal .LCPI174_0, abla_static_abla_fn_627837887_633683867_2759.0
	.literal .LCPI174_1, abla_static_abla_fn_627837887_633683867_425.0
	.literal .LCPI174_2, .Labla_string_abla_fn_627837887_633683867_2776.native.mutable.bytes
	.literal .LCPI174_3, abla_static_abla_fn_627837887_633683867_419
	.literal .LCPI174_4, 6144
	.literal .LCPI174_5, .Labla_string_abla_fn_627837887_633683867_2859.native.mutable.u32s
	.section	.text.abla_fn_115387104_275846057_direct,"ax",@progbits
	.section	.text.abla_fn_368411890_169521707_direct,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_368411890_169521707_direct
	.type	abla_fn_368411890_169521707_direct,@function
abla_fn_368411890_169521707_direct:     # @abla_fn_368411890_169521707_direct
# %bb.0:                                # %entry
	entry	a1, 48
	l32r	a8, .LCPI174_0
	movi	a9, 1
	s8i	a9, a8, 0
	l32r	a6, .LCPI174_1
	l32i	a5, a6, 0
	movi	a8, 7
	bgeu	a8, a5, .LBB174_2
.LBB174_1:
	movi	a2, 257
	retw.n
.LBB174_2:                              # %source.label11.i
	l32r	a4, .LCPI174_2
	l8ui	a9, a4, 12
	movi	a2, 258
	movi	a8, 47
	bne	a9, a8, .LBB174_4
# %bb.3:                                # %abla_fn_698704446_201113315_direct.exit.i
	l8ui	a9, a4, 23
	bne	a9, a8, .LBB174_5
.LBB174_4:                              # %abla_fn_117261465_542631747_direct.exit
	retw.n
.LBB174_5:                              # %source.label.i.i.preheader
	movi	a3, 0
	l32r	a7, .LCPI174_3
	beqi	a3, 8, .LBB174_1
.LBB174_6:                              # %source.label1.i.i
                                        # =>This Inner Loop Header: Depth=1
	l32i	a8, a7, 0
	beqz.n	a8, .LBB174_8
# %bb.7:                                # %source.label4.i.i
                                        #   in Loop: Header=BB174_6 Depth=1
	addi	a7, a7, 4
	addi	a3, a3, 1
	beqi	a3, 8, .LBB174_1
	j	.LBB174_6
.LBB174_8:                              # %source.label22.i
	l32r	a11, .LCPI174_4
	movi	a10, 33
	call8	abla_fn_607480688_644791182_direct
	movi	a2, 257
	beqz	a10, .LBB174_4
# %bb.9:                                # %source.label28.i
	movi	a8, 12
	s32i	a8, a10, 16
	s32i	a3, a10, 12
	movi	a2, 0
	s32i	a2, a10, 8
	l32r	a8, .LCPI174_5
	s32i	a8, a10, 4
	movi	a8, 10
	s32i	a8, a10, 0
	s32i	a10, a1, 0                      # 4-byte Folded Spill
	addi	a10, a10, 20
	addi	a11, a4, 12
	movi	a12, 13
	call8	abla_fn_334943840_569200394_direct
	l32i	a8, a1, 0                       # 4-byte Folded Reload
	s32i	a8, a7, 0
	bne	a5, a3, .LBB174_4
# %bb.10:                               # %source.label29.i
	addi	a8, a5, 1
	s32i	a8, a6, 0
	retw.n
.Lfunc_end174:
	.size	abla_fn_368411890_169521707_direct, .Lfunc_end174-abla_fn_368411890_169521707_direct
                                        # -- End function
	.literal_position
	.literal .LCPI175_0, abla_static_abla_fn_627837887_633683867_3205.0
	.literal .LCPI175_1, abla_static_abla_fn_627837887_633683867_3211
	.literal .LCPI175_2, 271733878
	.literal .LCPI175_3, -1732584194
	.literal .LCPI175_4, -271733879
	.literal .LCPI175_5, 1732584193
	.literal .LCPI175_6, abla_static_abla_fn_627837887_633683867_2249
	.literal .LCPI175_7, 65536
	.literal .LCPI175_8, 65535
	.literal .LCPI175_9, -65536
	.literal .LCPI175_10, abla_fn_213944016_953228118_direct
	.literal .LCPI175_11, abla_fn_213944016_953228118_direct
	.literal .LCPI175_12, .Labla_string_abla_fn_627837887_633683867_2288.native.bytes
	.literal .LCPI175_13, .Labla_string_abla_fn_627837887_633683867_2330.native.bytes
	.literal .LCPI175_14, .Labla_string_abla_fn_627837887_633683867_2260.native.bytes
	.literal .LCPI175_15, abla_fn_213944016_953228118_direct
	.literal .LCPI175_16, abla_fn_213944016_953228118_direct
	.literal .LCPI175_17, 2052
	.literal .LCPI175_18, abla_fn_652716366_793746133_direct
	.literal .LCPI175_19, 1073741824
	.literal .LCPI175_20, 1040187392
	.literal .LCPI175_21, abla_fn_865116771_688464545_direct
	.literal .LCPI175_22, .Labla_string_abla_fn_627837887_633683867_2323.native.bytes
	.literal .LCPI175_23, .Labla_string_abla_fn_627837887_633683867_2267.native.bytes
	.literal .LCPI175_24, abla_fn_213944016_953228118_direct
	.literal .LCPI175_25, abla_fn_213944016_953228118_direct
	.literal .LCPI175_26, abla_fn_652716366_793746133_direct
	.literal .LCPI175_27, abla_fn_652716366_793746133_direct
	.literal .LCPI175_28, abla_fn_213944016_953228118_direct
	.literal .LCPI175_29, abla_fn_213944016_953228118_direct
	.literal .LCPI175_30, abla_fn_213944016_953228118_direct
	.literal .LCPI175_31, abla_fn_213944016_953228118_direct
	.literal .LCPI175_32, abla_fn_652716366_793746133_direct
	.literal .LCPI175_33, abla_fn_865116771_688464545_direct
	.literal .LCPI175_34, abla_fn_213944016_953228118_direct
	.literal .LCPI175_35, abla_fn_213944016_953228118_direct
	.literal .LCPI175_36, abla_fn_213944016_953228118_direct
	.literal .LCPI175_37, abla_fn_213944016_953228118_direct
	.literal .LCPI175_38, abla_fn_213944016_953228118_direct
	.literal .LCPI175_39, abla_fn_213944016_953228118_direct
	.literal .LCPI175_40, 2048
	.literal .LCPI175_41, abla_fn_652716366_793746133_direct
	.literal .LCPI175_42, abla_fn_652716366_793746133_direct
	.literal .LCPI175_43, 32768
	.literal .LCPI175_44, 36864
	.literal .LCPI175_45, .Labla_string_abla_fn_627837887_633683867_3256.native.bytes
	.literal .LCPI175_46, abla_fn_213944016_953228118_direct
	.literal .LCPI175_47, abla_fn_213944016_953228118_direct
	.literal .LCPI175_48, 60395
	.literal .LCPI175_49, 20650
	.literal .LCPI175_50, abla_fn_500235045_572962334_direct
	.literal .LCPI175_51, memset
	.literal .LCPI175_52, abla_static_abla_fn_627837887_633683867_3703.0
	.literal .LCPI175_53, .Labla_string_abla_fn_627837887_633683867_3725.native.mutable.u32s
	.literal .LCPI175_54, 4096
	.literal .LCPI175_55, 1073061888
	.literal .LCPI175_56, abla_fn_213944016_953228118_direct
	.literal .LCPI175_57, abla_fn_213944016_953228118_direct
	.literal .LCPI175_58, abla_fn_500235045_572962334_direct
	.literal .LCPI175_59, .Labla_string_abla_fn_627837887_633683867_3494.native.bytes
	.literal .LCPI175_60, .Labla_string_abla_fn_627837887_633683867_3487.native.bytes
	.literal .LCPI175_61, .Labla_string_abla_fn_627837887_633683867_3501.native.bytes
	.literal .LCPI175_62, abla_fn_213944016_953228118_direct
	.literal .LCPI175_63, abla_fn_213944016_953228118_direct
	.literal .LCPI175_64, .Labla_string_abla_fn_627837887_633683867_3230.native.bytes
	.section	.text.abla_fn_368411890_169521707_direct,"ax",@progbits
	.section	.text.abla_fn_729003036_956798390_direct,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_729003036_956798390_direct
	.type	abla_fn_729003036_956798390_direct,@function
abla_fn_729003036_956798390_direct:     # @abla_fn_729003036_956798390_direct
# %bb.0:                                # %entry
	entry	a1, 352
	l32r	a3, .LCPI175_0
	l32i	a8, a3, 0
	bnez.n	a8, .LBB175_3
# %bb.1:                                # %source.label2.i.i
	l32r	a10, .LCPI175_1
	call8	abla_fn_396055959_456822569_direct
	l32i	a8, a3, 0
	beqz.n	a8, .LBB175_5
.LBB175_2:                              # %source.label13.i.critedge
	l32r	a10, .LCPI175_1
	call8	abla_fn_954702414_417902696_direct
.LBB175_3:                              # %source.label13.i
	l32r	a8, .LCPI175_58
	movi	a10, 20
	callx8	a8
	beqz	a10, .LBB175_139
# %bb.4:                                # %source.label17.i
	movi	a8, 0
	s32i	a8, a10, 8
	movi	a9, 255
	s32i	a9, a10, 4
	s32i	a2, a10, 0
	l32i	a9, a3, 0
	s32i	a8, a10, 16
	s32i	a9, a10, 12
	call8	abla_fn_340404077_510317132_direct
	or	a2, a10, a10
	retw.n
.LBB175_5:                              # %source.label5.i.i
	movi	a7, 0
	s32i	a7, a1, 92
	s32i	a7, a1, 88
	l32r	a8, .LCPI175_2
	s32i	a8, a1, 84
	l32r	a8, .LCPI175_3
	s32i	a8, a1, 80
	l32r	a8, .LCPI175_4
	s32i	a8, a1, 76
	l32r	a8, .LCPI175_5
	s32i	a8, a1, 72
	s32i	a7, a1, 224
	s32i	a7, a1, 264
	movi	a8, 18
	s32i	a8, a1, 260
	movi	a8, 224
	add	a8, a1, a8
	addi	a8, a8, 0
	s32i	a8, a1, 272
	l32r	a4, .LCPI175_6
	addi	a6, a4, 124
	or	a10, a6, a6
	call8	abla_fn_396055959_456822569_direct
	movi	a8, 4
	addi	a9, a1, 48
	or	a8, a9, a8
	s32i	a8, a1, 44                      # 4-byte Folded Spill
	addi	a5, a9, 24
	l32i	a8, a4, 0
	movi	a11, 1
	l32i	a9, a1, 260
	movi	a10, 40
.LBB175_6:                              # %source.label.i.i.i.i.i.i
                                        # =>This Inner Loop Header: Depth=1
	extui	a11, a11, 0, 2
	bnei	a11, 1, .LBB175_15
# %bb.7:                                # %source.label17.i.i.i.i.i.i
                                        #   in Loop: Header=BB175_6 Depth=1
	movi	a11, 2
	bgeu	a7, a8, .LBB175_6
# %bb.8:                                # %source.label18.i.i.i.i.i.i
                                        #   in Loop: Header=BB175_6 Depth=1
	mull	a11, a7, a10
	add	a13, a4, a11
	l32i	a11, a13, 28
	and	a14, a11, a9
	movi	a12, 1
	movi	a11, 1
	bne	a14, a9, .LBB175_14
# %bb.9:                                # %source.label20.i.i.i.i.i.i
                                        #   in Loop: Header=BB175_6 Depth=1
	l8ui	a14, a13, 32
	bbci	a14, 0, .LBB175_14
# %bb.10:                               # %source.label22.i.i.i.i.i.i
                                        #   in Loop: Header=BB175_6 Depth=1
	l32i	a13, a13, 24
	l32r	a14, .LCPI175_7
	bltu	a13, a14, .LBB175_12
# %bb.11:                               # %source.label22.i.i.i.i.i.i
                                        #   in Loop: Header=BB175_6 Depth=1
	movi	a11, -1
.LBB175_12:                             # %source.label22.i.i.i.i.i.i
                                        #   in Loop: Header=BB175_6 Depth=1
	bltu	a13, a14, .LBB175_14
# %bb.13:                               # %source.label22.i.i.i.i.i.i
                                        #   in Loop: Header=BB175_6 Depth=1
	movi	a12, 0
.LBB175_14:                             # %source.label.i.i.i.i.i.i.outer.backedge
                                        #   in Loop: Header=BB175_6 Depth=1
	add	a7, a7, a12
	j	.LBB175_6
.LBB175_15:                             # %source.label.i.i.i.i.i.i
	bnei	a11, 2, .LBB175_17
# %bb.16:                               # %abla_fn_966995707_418654989_direct.exit.thread.i.i.i.i.i
	movi	a8, -1
	s32i	a8, a1, 268
	j	.LBB175_31
.LBB175_17:                             # %abla_fn_966995707_418654989_direct.exit.i.i.i.i.i
	s32i	a7, a1, 268
	bnei	a7, -1, .LBB175_18
	j	.LBB175_31
.LBB175_18:                             # %source.label112.i.i.i.i.i
	movi	a8, 40
	mull	a9, a7, a8
	add	a9, a4, a9
	l32i	a9, a9, 36
	beqz	a9, .LBB175_92
# %bb.19:                               # %source.label113.i.i.i.i.i
	movi	a9, 0
	s32i	a9, a1, 276
	s32i	a9, a1, 284
	movi	a10, 1
	s32i	a10, a1, 256
	l32i	a10, a1, 268
	mull	a8, a10, a8
	add	a8, a4, a8
	l32i	a8, a8, 36
	s32i	a9, a1, 280
.LBB175_20:                             # %source.label115.i.i.i.i.i.outer
                                        # =>This Loop Header: Depth=1
                                        #     Child Loop BB175_21 Depth 2
	movi	a9, 2
.LBB175_21:                             # %source.label115.i.i.i.i.i
                                        #   Parent Loop BB175_20 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	extui	a9, a9, 0, 3
	beqi	a9, 2, .LBB175_22
	j	.LBB175_86
.LBB175_22:                             # %source.label116.i.i.i.i.i
                                        #   in Loop: Header=BB175_21 Depth=2
	beqz.n	a8, .LBB175_29
# %bb.23:                               # %source.label117.i.i.i.i.i
                                        #   in Loop: Header=BB175_21 Depth=2
	l32i	a9, a8, 32
	or	a10, a7, a7
	bnei	a9, 1, .LBB175_30
# %bb.24:                               # %source.label119.i.i.i.i.i
                                        #   in Loop: Header=BB175_21 Depth=2
	l32i	a11, a8, 28
	l32i	a12, a8, 24
	movi	a7, 1
	bnez.n	a12, .LBB175_26
# %bb.25:                               # %source.label119.i.i.i.i.i
                                        #   in Loop: Header=BB175_21 Depth=2
	movi	a9, 4
	l32r	a10, .LCPI175_8
	bltu	a10, a11, .LBB175_21
.LBB175_26:                             # %source.label121.i.i.i.i.i
                                        #   in Loop: Header=BB175_21 Depth=2
	movi	a10, 0
	l32i	a9, a1, 256
	bnez.n	a9, .LBB175_30
# %bb.27:                               # %source.label123.i.i.i.i.i
                                        #   in Loop: Header=BB175_21 Depth=2
	l32r	a13, .LCPI175_9
	add	a12, a12, a13
	movi	a9, 5
	bltu	a13, a12, .LBB175_21
# %bb.28:                               # %source.label123.i.i.i.i.i
                                        #   in Loop: Header=BB175_21 Depth=2
	add	a11, a11, a13
	l32r	a12, .LCPI175_9
	bltu	a12, a11, .LBB175_21
	j	.LBB175_30
.LBB175_29:                             #   in Loop: Header=BB175_21 Depth=2
	movi	a9, 3
	movi	a8, 0
	j	.LBB175_21
.LBB175_30:                             # %source.label131.sink.split.i.i.i.i.i
                                        #   in Loop: Header=BB175_20 Depth=1
	l32i	a8, a8, 36
	or	a7, a10, a10
	j	.LBB175_20
.LBB175_31:                             # %source.label284.i.i.i.i.i
	call8	abla_fn_11786425_863113934_direct
	or	a12, a10, a10
	movi	a8, 479
	s32i	a8, a1, 240
	l32r	a11, .LCPI175_12
	l32r	a10, .LCPI175_13
	l32r	a14, .LCPI175_14
	or	a13, a10, a10
	call8	abla_fn_992771427_703335695_direct
	movi	a8, 261
	s32i	a8, a1, 264
	movi	a8, 0
	s32i	a8, a1, 276
	beqz.n	a8, .LBB175_34
# %bb.32:                               # %source.label285.i.i.i.i.i
	l32r	a8, .LCPI175_39
	movi	a10, 0
.LBB175_33:                             # %abla_fn_145328139_22042706_direct.exit.i.i.i.i
	callx8	a8
.LBB175_34:                             # %abla_fn_145328139_22042706_direct.exit.i.i.i.i
	or	a10, a6, a6
	call8	abla_fn_954702414_417902696_direct
	l32i	a7, a1, 264
	movi	a8, 259
	beq	a7, a8, .LBB175_36
# %bb.35:                               # %abla_fn_145328139_22042706_direct.exit.i.i.i.i
	bnez	a7, .LBB175_80
.LBB175_36:                             # %source.label28.i.i.i.i
	s32i	a5, a1, 40                      # 4-byte Folded Spill
	l32i	a6, a1, 224
	l32r	a11, .LCPI175_40
	l32r	a8, .LCPI175_41
	movi	a10, 8
	callx8	a8
	or	a5, a10, a10
	beqz	a5, .LBB175_84
# %bb.37:                               # %source.label36.i.i.i.i
	l32r	a11, .LCPI175_40
	l32r	a8, .LCPI175_42
	movi	a10, 4
	callx8	a8
	beqz	a10, .LBB175_89
# %bb.38:                               # %source.label43.i.i.i.i
	s32i	a10, a5, 0
	movi	a11, 0
	movi	a8, 0
	bnez.n	a7, .LBB175_40
# %bb.39:                               # %source.label44.i.i.i.i
	s32i	a6, a10, 0
	movi	a8, 1
.LBB175_40:                             # %source.label.i.i.i
	s32i	a8, a5, 4
	s32i	a6, a1, 48
	l32i	a8, a1, 44                      # 4-byte Folded Reload
	s32i	a5, a8, 0
	l32r	a8, .LCPI175_43
	l32i	a9, a1, 48
	add	a5, a9, a8
	s32i	a5, a1, 48
	l32r	a8, .LCPI175_44
	add	a6, a9, a8
	addi	a8, a1, 48
	addi	a9, a8, 124
	s32i	a9, a1, 36                      # 4-byte Folded Spill
	addi	a13, a8, 48
	addi	a15, a8, 112
	movi	a4, 48
	movi	a14, 0
	movi	a7, 0
.LBB175_41:                             # %source.label38.i.i.i.outer
                                        # =>This Loop Header: Depth=1
                                        #     Child Loop BB175_42 Depth 2
                                        #     Child Loop BB175_59 Depth 2
                                        #     Child Loop BB175_69 Depth 2
	movi	a8, 48
.LBB175_42:                             # %source.label38.i.i.i
                                        #   Parent Loop BB175_41 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	extui	a8, a8, 0, 6
	beq	a8, a4, .LBB175_43
	j	.LBB175_81
.LBB175_43:                             # %source.label39.i.i.i
                                        #   in Loop: Header=BB175_42 Depth=2
	movi	a8, 50
	bgeu	a5, a6, .LBB175_42
# %bb.44:                               # %source.label41.i.i.i
                                        #   in Loop: Header=BB175_42 Depth=2
	s32i	a11, a1, 28                     # 4-byte Folded Spill
	s32i	a13, a1, 32                     # 4-byte Folded Spill
	or	a10, a15, a15
	or	a11, a5, a5
	movi	a12, 32
	or	a4, a15, a15
	call8	abla_fn_334943840_569200394_direct
	l16ui	a9, a1, 160
	l32r	a8, .LCPI175_48
	beq	a9, a8, .LBB175_51
# %bb.45:                               # %source.label41.i.i.i
                                        #   in Loop: Header=BB175_42 Depth=2
	movi	a8, 15
	l32r	a10, .LCPI175_49
	or	a14, a4, a4
	l32i	a13, a1, 32                     # 4-byte Folded Reload
	l32i	a11, a1, 28                     # 4-byte Folded Reload
	or	a15, a4, a4
	movi	a4, 48
	movi	a12, -257
	bne	a9, a10, .LBB175_42
# %bb.46:                               # %source.label43.i.i.i
                                        #   in Loop: Header=BB175_42 Depth=2
	l32i	a8, a1, 88
	addmi	a9, a8, 256
	s32i	a9, a1, 88
	movi	a9, 1
	bltu	a12, a8, .LBB175_48
# %bb.47:                               # %source.label43.i.i.i
                                        #   in Loop: Header=BB175_42 Depth=2
	movi	a9, 0
.LBB175_48:                             # %source.label43.i.i.i
                                        #   in Loop: Header=BB175_42 Depth=2
	l32i	a10, a1, 92
	add	a9, a10, a9
	s32i	a9, a1, 92
	extui	a9, a8, 3, 6
	s32i	a15, a1, 24                     # 4-byte Folded Spill
	beqz.n	a9, .LBB175_52
# %bb.49:                               # %source.label17.i.i.i.i
                                        #   in Loop: Header=BB175_42 Depth=2
	add	a10, a9, a13
	movi	a8, 31
	bltu	a8, a9, .LBB175_53
# %bb.50:                               # %source.label19.i.i.i.i
                                        #   in Loop: Header=BB175_42 Depth=2
	or	a11, a15, a15
	movi	a12, 32
	j	.LBB175_55
.LBB175_51:                             # %source.label52.i.i.i
                                        #   in Loop: Header=BB175_42 Depth=2
	movi	a8, 13
	or	a14, a4, a4
	l32i	a13, a1, 32                     # 4-byte Folded Reload
	l32i	a11, a1, 28                     # 4-byte Folded Reload
	or	a15, a4, a4
	movi	a4, 48
	j	.LBB175_42
.LBB175_52:                             #   in Loop: Header=BB175_42 Depth=2
	movi	a12, 32
	or	a11, a15, a15
	j	.LBB175_54
.LBB175_53:                             # %source.label21.i.i.i.i
                                        #   in Loop: Header=BB175_42 Depth=2
	movi	a8, 64
	sub	a12, a8, a9
	s32i	a12, a1, 16                     # 4-byte Folded Spill
	or	a11, a15, a15
	or	a4, a15, a15
	s32i	a9, a1, 20                      # 4-byte Folded Spill
	call8	abla_fn_76595254_971146377_direct
	l32i	a10, a1, 40                     # 4-byte Folded Reload
	call8	abla_fn_606531235_302569135_direct
	l32i	a8, a1, 16                      # 4-byte Folded Reload
	add	a11, a8, a4
	movi	a4, 48
	l32i	a8, a1, 20                      # 4-byte Folded Reload
	addi	a12, a8, -32
	l32i	a13, a1, 32                     # 4-byte Folded Reload
.LBB175_54:                             # %source.label26.i.i.i.i
                                        #   in Loop: Header=BB175_42 Depth=2
	or	a10, a13, a13
.LBB175_55:                             # %abla_fn_768182749_823544243_direct.exit.i.i.i
                                        #   in Loop: Header=BB175_42 Depth=2
	call8	abla_fn_76595254_971146377_direct
	movi	a10, 52
	l32r	a8, .LCPI175_50
	callx8	a8
	movi	a8, 45
	movi	a14, 0
	l32i	a13, a1, 32                     # 4-byte Folded Reload
	l32i	a11, a1, 28                     # 4-byte Folded Reload
	l32i	a15, a1, 24                     # 4-byte Folded Reload
	beqz	a10, .LBB175_42
# %bb.56:                               # %source.label45.i.i.i
                                        #   in Loop: Header=BB175_41 Depth=1
	s32i	a10, a1, 20                     # 4-byte Folded Spill
	addi	a10, a10, 4
	movi	a11, 0
	movi	a12, 48
	l32r	a8, .LCPI175_51
	callx8	a8
	movi	a13, 0
	l32r	a8, .LCPI175_52
	l8ui	a9, a8, 0
	l32r	a8, .LCPI175_53
	bne	a9, a13, .LBB175_58
# %bb.57:                               # %source.label45.i.i.i
                                        #   in Loop: Header=BB175_41 Depth=1
	movi	a8, 0
.LBB175_58:                             # %source.label45.i.i.i
                                        #   in Loop: Header=BB175_41 Depth=1
	l32i	a9, a1, 20                      # 4-byte Folded Reload
	s32i	a8, a9, 0
	l32i	a8, a1, 164
	s32i	a8, a9, 12
	l32i	a8, a1, 168
	s32i	a8, a9, 16
	l32r	a8, .LCPI175_54
	s32i	a8, a9, 20
	l8ui	a11, a1, 162
	s32i	a11, a9, 4
	l8ui	a10, a1, 163
	s32i	a10, a9, 8
	l32i	a8, a1, 188
	s32i	a8, a1, 12                      # 4-byte Folded Spill
	l32r	a8, .LCPI175_55
	memw
	l32i	a8, a8, 0
	extui	a8, a8, 20, 7
	l32i	a15, a1, 24                     # 4-byte Folded Reload
	beqz.n	a8, .LBB175_60
.LBB175_59:                             # %source.label2.i.i.i.i.i.i.i
                                        #   Parent Loop BB175_41 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	xor	a13, a13, a8
	srli	a8, a8, 1
	bnez	a8, .LBB175_59
.LBB175_60:                             # %abla_fn_709582471_918948478_direct.exit.i.i.i.i
                                        #   in Loop: Header=BB175_41 Depth=1
	movi	a8, 0
	movi	a12, 0
	s32i	a13, a1, 16                     # 4-byte Folded Spill
	bbci	a13, 0, .LBB175_68
# %bb.61:                               # %source.label.i.i.i.i
                                        #   in Loop: Header=BB175_41 Depth=1
	#APP
	nsau	a12, a11
	#NO_APP
	addi	a13, a11, -2
	#APP
	nsau	a13, a13
	#NO_APP
	or	a13, a13, a12
	movi	a12, 1
	movi	a14, 31
	bltu	a14, a13, .LBB175_67
# %bb.62:                               # %source.label.i.i.i.i
                                        #   in Loop: Header=BB175_41 Depth=1
	beqi	a11, 3, .LBB175_67
# %bb.63:                               # %source.label17.i171.i.i.i
                                        #   in Loop: Header=BB175_41 Depth=1
	#APP
	nsau	a13, a10
	#NO_APP
	addi	a11, a11, -1
	#APP
	nsau	a11, a11
	#NO_APP
	and	a13, a13, a11
	bltu	a14, a13, .LBB175_67
# %bb.64:                               # %source.label18.i.i.i.i
                                        #   in Loop: Header=BB175_41 Depth=1
	movi	a9, -144
	add	a13, a10, a9
	#APP
	nsau	a13, a13
	#NO_APP
	and	a13, a13, a11
	l32i	a15, a1, 24                     # 4-byte Folded Reload
	movi	a4, 48
	movi	a9, 31
	bltu	a9, a13, .LBB175_68
# %bb.65:                               # %source.label19.i173.i.i.i
                                        #   in Loop: Header=BB175_41 Depth=1
	addi	a10, a10, -4
	#APP
	nsau	a10, a10
	#NO_APP
	and	a10, a10, a11
	movi	a11, 32
	bltu	a10, a11, .LBB175_78
# %bb.66:                               # %source.label19.i173.i.i.i
                                        #   in Loop: Header=BB175_41 Depth=1
	l32i	a9, a1, 16                      # 4-byte Folded Reload
	j	.LBB175_79
.LBB175_67:                             #   in Loop: Header=BB175_41 Depth=1
	l32i	a15, a1, 24                     # 4-byte Folded Reload
	movi	a4, 48
.LBB175_68:                             # %abla_fn_927087206_970660176_direct.exit.i.i.i
                                        #   in Loop: Header=BB175_41 Depth=1
	l32i	a9, a1, 20                      # 4-byte Folded Reload
	s8i	a12, a9, 41
	or	a12, a9, a9
	l8ui	a9, a1, 188
	s8i	a8, a12, 44
	extui	a9, a9, 1, 1
	s8i	a9, a12, 42
	addi	a14, a12, 24
	movi	a9, 0
	l32i	a13, a1, 32                     # 4-byte Folded Reload
	beqi	a8, 16, .LBB175_74
.LBB175_69:                             # %source.label3.i.i.i.i
                                        #   Parent Loop BB175_41 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	movi	a10, 0
	movi	a11, 0
	bbsi	a9, 0, .LBB175_71
# %bb.70:                               # %source.label6.i.i.i.i
                                        #   in Loop: Header=BB175_69 Depth=2
	l32i	a11, a1, 36                     # 4-byte Folded Reload
	add	a11, a11, a8
	l8ui	a11, a11, 0
.LBB175_71:                             # %source.label7.i.i.i.i
                                        #   in Loop: Header=BB175_69 Depth=2
	add	a12, a12, a8
	s8i	a11, a12, 24
	movi	a12, 1
	beq	a11, a10, .LBB175_73
# %bb.72:                               # %source.label7.i.i.i.i
                                        #   in Loop: Header=BB175_69 Depth=2
	movi	a12, 0
.LBB175_73:                             # %source.label7.i.i.i.i
                                        #   in Loop: Header=BB175_69 Depth=2
	or	a9, a12, a9
	addi	a8, a8, 1
	l32i	a12, a1, 20                     # 4-byte Folded Reload
	bnei	a8, 16, .LBB175_69
.LBB175_74:                             # %abla_fn_931881578_670483309_direct.exit.i.i.i
                                        #   in Loop: Header=BB175_41 Depth=1
	l32i	a9, a1, 28                      # 4-byte Folded Reload
	beqz.n	a9, .LBB175_76
# %bb.75:                               # %source.label46.i.i.i
                                        #   in Loop: Header=BB175_41 Depth=1
	l32i	a8, a9, 48
	s32i	a8, a12, 48
	s32i	a12, a9, 48
	j	.LBB175_77
.LBB175_76:                             # %source.label47.i.i.i
                                        #   in Loop: Header=BB175_41 Depth=1
	s32i	a7, a12, 48
	or	a7, a12, a12
.LBB175_77:                             # %source.label48.i.i.i
                                        #   in Loop: Header=BB175_41 Depth=1
	addi	a5, a5, 32
	or	a11, a12, a12
	j	.LBB175_41
.LBB175_78:                             #   in Loop: Header=BB175_41 Depth=1
	l32i	a9, a1, 12                      # 4-byte Folded Reload
.LBB175_79:                             # %source.label19.i173.i.i.i
                                        #   in Loop: Header=BB175_41 Depth=1
	extui	a12, a9, 0, 1
	l32i	a15, a1, 24                     # 4-byte Folded Reload
	j	.LBB175_68
.LBB175_80:
	or	a4, a7, a7
	j	.LBB175_138
.LBB175_81:                             # %source.label38.i.i.i
	movi	a9, 13
	bne	a8, a9, .LBB175_82
	j	.LBB175_95
.LBB175_82:                             # %source.label38.i.i.i
	movi	a9, 45
	or	a5, a14, a14
	beq	a8, a9, .LBB175_83
	j	.LBB175_99
.LBB175_83:                             # %source.label64.i.i.i.loopexit
	movi	a4, 257
	movi	a8, 0
	j	.LBB175_96
.LBB175_84:                             # %source.label31.i.i.i.i
	movi	a4, 257
	bnez	a7, .LBB175_138
# %bb.85:                               # %source.label32.i.i.i.i
	or	a10, a6, a6
	call8	abla_fn_318984852_605722137_direct
	j	.LBB175_138
.LBB175_86:                             # %source.label115.i.i.i.i.i
	bnei	a9, 3, .LBB175_87
	j	.LBB175_106
.LBB175_87:                             # %source.label115.i.i.i.i.i
	beqi	a9, 4, .LBB175_88
	j	.LBB175_107
.LBB175_88:                             # %source.label138.i.i.i.i.i.loopexit
	movi	a9, 0
	or	a10, a7, a7
	j	.LBB175_108
.LBB175_89:                             # %source.label38.i.i.i.i
	bnez.n	a7, .LBB175_91
# %bb.90:                               # %source.label39.i.i.i.i
	or	a10, a6, a6
	call8	abla_fn_318984852_605722137_direct
.LBB175_91:                             # %source.label41.i.i.i.i
	l32r	a8, .LCPI175_63
	or	a10, a5, a5
	callx8	a8
	movi	a4, 257
	j	.LBB175_138
.LBB175_92:                             # %source.label189.i.i.i.i.i
	l32r	a11, .LCPI175_17
	l32r	a8, .LCPI175_26
	movi	a10, 44
	callx8	a8
	s32i	a10, a1, 276
	beqz	a10, .LBB175_140
# %bb.93:                               # %source.label190.i.i.i.i.i
	movi	a8, 40
	l32i	a9, a1, 268
	mull	a9, a9, a8
	add	a9, a4, a9
	l32i	a11, a9, 20
	movi	a12, 0
	s32i	a12, a10, 16
	s32i	a11, a10, 4
	s32i	a11, a10, 0
	l32i	a11, a1, 260
	s32i	a11, a10, 20
	l32i	a11, a9, 36
	s32i	a11, a10, 36
	beqz	a11, .LBB175_148
# %bb.94:                               # %source.label192.i.i.i.i.i
	addi	a9, a10, 36
	addi	a8, a11, 40
	j	.LBB175_149
.LBB175_95:                             # %source.label64.i.i.i.loopexit3
	movi	a4, 0
	movi	a8, 1
.LBB175_96:                             # %source.label64.i.i.i
	beqz	a5, .LBB175_99
# %bb.97:                               # %source.label65.i.i.i
	s32i	a8, a1, 32                      # 4-byte Folded Spill
	l32i	a8, a1, 88
	extui	a9, a8, 3, 6
	add	a8, a9, a13
	movi	a10, 128
	s8i	a10, a8, 0
	movi	a10, 8
	addi	a11, a1, 48
	or	a10, a11, a10
	s32i	a10, a1, 36                     # 4-byte Folded Spill
	movi	a10, 63
	xor	a11, a9, a10
	movi	a10, 7
	bgeu	a10, a11, .LBB175_98
	j	.LBB175_118
.LBB175_98:                             # %source.label.i194.i.i.i
	addi	a10, a8, 1
	s32i	a5, a1, 28                      # 4-byte Folded Spill
	or	a5, a13, a13
	call8	abla_fn_210504413_369462158_direct
	l32i	a6, a1, 40                      # 4-byte Folded Reload
	or	a10, a6, a6
	call8	abla_fn_606531235_302569135_direct
	or	a10, a5, a5
	l32i	a5, a1, 28                      # 4-byte Folded Reload
	movi	a11, 56
	call8	abla_fn_210504413_369462158_direct
	j	.LBB175_119
.LBB175_99:                             # %source.label86.i.i.i
	call8	abla_fn_11786425_863113934_direct
	or	a12, a10, a10
	l32r	a10, .LCPI175_45
	or	a11, a10, a10
	or	a13, a10, a10
	movi	a14, 0
	call8	abla_fn_992771427_703335695_direct
	movi	a5, 1
	l32r	a6, .LCPI175_62
.LBB175_100:                            # %source.label88.i.i.i
                                        # =>This Inner Loop Header: Depth=1
	or	a10, a7, a7
	bbci	a5, 0, .LBB175_105
# %bb.101:                              # %source.label89.i.i.i
                                        #   in Loop: Header=BB175_100 Depth=1
	movi	a5, 1
	movi	a7, 0
	bne	a10, a7, .LBB175_103
# %bb.102:                              # %source.label89.i.i.i
                                        #   in Loop: Header=BB175_100 Depth=1
	movi	a5, 0
.LBB175_103:                            # %source.label89.i.i.i
                                        #   in Loop: Header=BB175_100 Depth=1
	beqz	a10, .LBB175_100
# %bb.104:                              # %source.label90.i.i.i
                                        #   in Loop: Header=BB175_100 Depth=1
	l32i	a7, a10, 48
	callx8	a6
	j	.LBB175_100
.LBB175_105:
	movi	a4, 261
	j	.LBB175_131
.LBB175_106:                            # %source.label138.i.i.i.i.i.loopexit5
	or	a9, a8, a8
	or	a10, a8, a8
	j	.LBB175_108
.LBB175_107:                            # %source.label136.i.i.i.i.i
	l32i	a10, a1, 256
	or	a9, a7, a7
.LBB175_108:                            # %source.label138.i.i.i.i.i
	beqz.n	a10, .LBB175_113
# %bb.109:                              # %source.label181.i.i.i.i.i
	l32i	a9, a8, 24
	l32i	a8, a8, 8
	sub	a8, a8, a9
	l32i	a9, a1, 272
	s32i	a8, a9, 0
	movi	a8, 259
	s32i	a8, a1, 264
	l32i	a10, a1, 284
	beqz.n	a10, .LBB175_111
# %bb.110:                              # %source.label182.i.i.i.i.i
	l32r	a8, .LCPI175_10
	callx8	a8
.LBB175_111:                            # %source.label184.i.i.i.i.i
	l32i	a10, a1, 276
	beqz	a10, .LBB175_34
# %bb.112:                              # %source.label185.i.i.i.i.i
	l32r	a8, .LCPI175_11
	j	.LBB175_33
.LBB175_113:                            # %source.label139.i.i.i.i.i
	movi	a8, 1
	movi	a10, 256
	add	a10, a1, a10
	l8ui	a10, a10, 0
	xor	a8, a10, a8
	and	a8, a8, a9
	beqz	a8, .LBB175_165
# %bb.114:                              # %source.label173.i.i.i.i.i
	call8	abla_fn_11786425_863113934_direct
	or	a12, a10, a10
	movi	a8, 546
	s32i	a8, a1, 240
	l32r	a11, .LCPI175_12
	l32r	a10, .LCPI175_13
	l32r	a14, .LCPI175_14
	or	a13, a10, a10
	call8	abla_fn_992771427_703335695_direct
	movi	a8, 258
	s32i	a8, a1, 264
	l32i	a10, a1, 284
	beqz.n	a10, .LBB175_116
# %bb.115:                              # %source.label174.i.i.i.i.i
	l32r	a8, .LCPI175_15
	callx8	a8
.LBB175_116:                            # %source.label176.i.i.i.i.i
	l32i	a10, a1, 276
	beqz	a10, .LBB175_34
# %bb.117:                              # %source.label177.i.i.i.i.i
	l32r	a8, .LCPI175_16
	j	.LBB175_33
.LBB175_118:                            # %source.label12.i.i.i.i
	movi	a10, 55
	sub	a11, a10, a9
	addi	a10, a8, 1
	call8	abla_fn_210504413_369462158_direct
	l32i	a6, a1, 40                      # 4-byte Folded Reload
.LBB175_119:                            # %abla_fn_955475390_192763429_direct.exit.i.i.i
	l32i	a8, a1, 88
	s32i	a8, a1, 152
	l32i	a8, a1, 92
	s32i	a8, a1, 156
	or	a10, a6, a6
	call8	abla_fn_606531235_302569135_direct
	l32i	a10, a1, 36                     # 4-byte Folded Reload
	or	a11, a6, a6
	movi	a12, 16
	call8	abla_fn_76595254_971146377_direct
	or	a10, a6, a6
	movi	a11, 88
	call8	abla_fn_210504413_369462158_direct
	movi	a8, 8
	addi	a9, a1, 48
	or	a8, a9, a8
	addi	a9, a5, 16
	movi	a10, 0
.LBB175_120:                            # %source.label.i195.i.i.i
                                        # =>This Inner Loop Header: Depth=1
	beqi	a10, 16, .LBB175_128
# %bb.121:                              # %source.label1.i.i.i.i
                                        #   in Loop: Header=BB175_120 Depth=1
	add	a11, a9, a10
	l8ui	a11, a11, 0
	add	a12, a8, a10
	l8ui	a12, a12, 0
	addi	a10, a10, 1
	beq	a12, a11, .LBB175_120
# %bb.122:                              # %source.label77.i.i.i
	call8	abla_fn_11786425_863113934_direct
	or	a12, a10, a10
	l32r	a10, .LCPI175_45
	or	a11, a10, a10
	or	a13, a10, a10
	movi	a14, 0
	call8	abla_fn_992771427_703335695_direct
	movi	a5, 1
	l32r	a6, .LCPI175_46
.LBB175_123:                            # %source.label79.i.i.i
                                        # =>This Inner Loop Header: Depth=1
	or	a10, a7, a7
	bbci	a5, 0, .LBB175_130
# %bb.124:                              # %source.label80.i.i.i
                                        #   in Loop: Header=BB175_123 Depth=1
	movi	a5, 1
	movi	a7, 0
	bne	a10, a7, .LBB175_126
# %bb.125:                              # %source.label80.i.i.i
                                        #   in Loop: Header=BB175_123 Depth=1
	movi	a5, 0
.LBB175_126:                            # %source.label80.i.i.i
                                        #   in Loop: Header=BB175_123 Depth=1
	beqz	a10, .LBB175_123
# %bb.127:                              # %source.label81.i.i.i
                                        #   in Loop: Header=BB175_123 Depth=1
	l32i	a7, a10, 48
	callx8	a6
	j	.LBB175_123
.LBB175_128:                            # %source.label66.i.i.i
	l32i	a8, a1, 32                      # 4-byte Folded Reload
	beqz	a8, .LBB175_142
# %bb.129:                              # %source.label75.i.i.i
	s32i	a7, a3, 0
	movi	a4, 0
	j	.LBB175_131
.LBB175_130:
	movi	a4, 259
.LBB175_131:                            # %source.label94.i.i.i
	l32i	a8, a1, 44                      # 4-byte Folded Reload
	l32i	a7, a8, 0
	movi	a6, 0
	movi	a5, 261
.LBB175_132:                            # %source.label.i213.i.i.i.outer
                                        # =>This Loop Header: Depth=1
                                        #     Child Loop BB175_133 Depth 2
	movi	a8, 1
.LBB175_133:                            # %source.label.i213.i.i.i
                                        #   Parent Loop BB175_132 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	bbci	a8, 0, .LBB175_137
# %bb.134:                              # %source.label17.i216.i.i.i
                                        #   in Loop: Header=BB175_133 Depth=2
	l32i	a9, a7, 4
	movi	a8, 0
	bge	a6, a9, .LBB175_133
# %bb.135:                              # %source.label18.i218.i.i.i
                                        #   in Loop: Header=BB175_132 Depth=1
	l32i	a8, a7, 0
	addx4	a8, a6, a8
	l32i	a10, a8, 0
	call8	abla_fn_318984852_605722137_direct
	bne	a10, a5, .LBB175_136
	j	.LBB175_218
.LBB175_136:                            # %source.label21.i220.i.i.i
                                        #   in Loop: Header=BB175_132 Depth=1
	addi	a6, a6, 1
	j	.LBB175_132
.LBB175_137:                            # %abla_fn_467768929_240580385_direct.exit.i.i
	l32i	a10, a7, 0
	l32r	a8, .LCPI175_56
	callx8	a8
	l32r	a8, .LCPI175_57
	or	a10, a7, a7
	callx8	a8
	beqz	a4, .LBB175_2
.LBB175_138:                            # %source.label6.i.i
	call8	abla_fn_11786425_863113934_direct
	or	a12, a10, a10
	l32r	a11, .LCPI175_64
	l32r	a10, .LCPI175_45
	or	a13, a10, a10
	or	a14, a4, a4
	call8	abla_fn_992771427_703335695_direct
	l32r	a10, .LCPI175_1
	call8	abla_fn_954702414_417902696_direct
.LBB175_139:
	movi	a2, 0
	retw.n
.LBB175_140:                            # %source.label278.i.i.i.i.i
	call8	abla_fn_11786425_863113934_direct
	or	a12, a10, a10
	movi	a8, 487
	s32i	a8, a1, 240
	l32r	a11, .LCPI175_12
	l32r	a10, .LCPI175_13
	l32r	a14, .LCPI175_14
	or	a13, a10, a10
	call8	abla_fn_992771427_703335695_direct
	movi	a8, 257
	s32i	a8, a1, 264
	l32i	a10, a1, 276
	beqz	a10, .LBB175_34
# %bb.141:                              # %source.label279.i.i.i.i.i
	l32r	a8, .LCPI175_38
	j	.LBB175_33
.LBB175_142:                            # %source.label69.i.i.i.preheader
	movi	a5, 1
	l32r	a6, .LCPI175_47
.LBB175_143:                            # %source.label69.i.i.i
                                        # =>This Inner Loop Header: Depth=1
	or	a10, a7, a7
	bbsi	a5, 0, .LBB175_144
	j	.LBB175_131
.LBB175_144:                            # %source.label70.i.i.i
                                        #   in Loop: Header=BB175_143 Depth=1
	movi	a5, 1
	movi	a7, 0
	bne	a10, a7, .LBB175_146
# %bb.145:                              # %source.label70.i.i.i
                                        #   in Loop: Header=BB175_143 Depth=1
	movi	a5, 0
.LBB175_146:                            # %source.label70.i.i.i
                                        #   in Loop: Header=BB175_143 Depth=1
	beqz	a10, .LBB175_143
# %bb.147:                              # %source.label71.i.i.i
                                        #   in Loop: Header=BB175_143 Depth=1
	l32i	a7, a10, 48
	callx8	a6
	j	.LBB175_143
.LBB175_148:                            # %source.label191.i.i.i.i.i
	l32i	a9, a1, 268
	mull	a8, a9, a8
	add	a8, a4, a8
	addi	a8, a8, 40
	l32i	a9, a1, 276
	addi	a9, a9, 36
.LBB175_149:                            # %source.label193.i.i.i.i.i
	s32i	a9, a8, 0
	movi	a7, 40
	l32i	a8, a1, 268
	mull	a8, a8, a7
	add	a8, a4, a8
	l32i	a9, a1, 276
	s32i	a9, a8, 36
	addi	a8, a8, 36
	s32i	a8, a9, 40
	l32r	a11, .LCPI175_17
	l32r	a8, .LCPI175_27
	movi	a10, 44
	callx8	a8
	s32i	a10, a1, 284
	beqz	a10, .LBB175_174
# %bb.150:                              # %source.label194.i.i.i.i.i
	l32i	a8, a1, 268
	mull	a8, a8, a7
	add	a8, a4, a8
	l32i	a9, a8, 12
	movi	a11, 0
	s32i	a11, a10, 16
	s32i	a9, a10, 4
	s32i	a9, a10, 0
	l32i	a9, a1, 260
	s32i	a11, a10, 36
	s32i	a9, a10, 20
	l32i	a9, a8, 40
	s32i	a9, a10, 40
	s32i	a10, a9, 0
	addi	a9, a10, 36
	s32i	a9, a8, 40
	movi	a8, 1
	s32i	a8, a1, 256
	l32i	a8, a1, 268
	mull	a8, a8, a7
	add	a8, a4, a8
	l32i	a8, a8, 36
	s32i	a11, a1, 280
.LBB175_151:                            # %source.label196.i.i.i.i.i.outer
                                        # =>This Loop Header: Depth=1
                                        #     Child Loop BB175_152 Depth 2
	movi	a9, 2
.LBB175_152:                            # %source.label196.i.i.i.i.i
                                        #   Parent Loop BB175_151 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	extui	a9, a9, 0, 3
	bnei	a9, 2, .LBB175_162
# %bb.153:                              # %source.label197.i.i.i.i.i
                                        #   in Loop: Header=BB175_152 Depth=2
	beqz.n	a8, .LBB175_160
# %bb.154:                              # %source.label198.i.i.i.i.i
                                        #   in Loop: Header=BB175_152 Depth=2
	l32i	a9, a8, 32
	or	a11, a10, a10
	bnei	a9, 1, .LBB175_161
# %bb.155:                              # %source.label200.i.i.i.i.i
                                        #   in Loop: Header=BB175_152 Depth=2
	l32i	a12, a8, 28
	l32i	a13, a8, 24
	movi	a10, 1
	bnez.n	a13, .LBB175_157
# %bb.156:                              # %source.label200.i.i.i.i.i
                                        #   in Loop: Header=BB175_152 Depth=2
	movi	a9, 4
	l32r	a11, .LCPI175_8
	bltu	a11, a12, .LBB175_152
.LBB175_157:                            # %source.label202.i.i.i.i.i
                                        #   in Loop: Header=BB175_152 Depth=2
	movi	a11, 0
	l32i	a9, a1, 256
	bnez.n	a9, .LBB175_161
# %bb.158:                              # %source.label204.i.i.i.i.i
                                        #   in Loop: Header=BB175_152 Depth=2
	l32r	a14, .LCPI175_9
	add	a13, a13, a14
	movi	a9, 5
	bltu	a14, a13, .LBB175_152
# %bb.159:                              # %source.label204.i.i.i.i.i
                                        #   in Loop: Header=BB175_152 Depth=2
	add	a12, a12, a14
	l32r	a13, .LCPI175_9
	bltu	a13, a12, .LBB175_152
	j	.LBB175_161
.LBB175_160:                            #   in Loop: Header=BB175_152 Depth=2
	movi	a9, 3
	movi	a8, 0
	j	.LBB175_152
.LBB175_161:                            # %source.label212.sink.split.i.i.i.i.i
                                        #   in Loop: Header=BB175_151 Depth=1
	l32i	a8, a8, 36
	or	a10, a11, a11
	j	.LBB175_151
.LBB175_162:                            # %source.label196.i.i.i.i.i
	bnei	a9, 3, .LBB175_163
	j	.LBB175_181
.LBB175_163:                            # %source.label196.i.i.i.i.i
	beqi	a9, 4, .LBB175_164
	j	.LBB175_182
.LBB175_164:                            # %source.label219.i.i.i.i.i.loopexit
	movi	a9, 0
	or	a11, a10, a10
	j	.LBB175_183
.LBB175_165:                            # %source.label140.i.i.i.i.i
	or	a7, a5, a5
	l32r	a11, .LCPI175_17
	l32r	a8, .LCPI175_18
	movi	a10, 44
	callx8	a8
	or	a5, a10, a10
	beqz	a5, .LBB175_193
# %bb.166:                              # %source.label141.i.i.i.i.i
	movi	a8, 40
	l32i	a9, a1, 268
	mull	a8, a9, a8
	add	a8, a4, a8
	l32i	a12, a8, 36
	movi	a9, 0
	movi	a10, 0
	or	a11, a12, a12
	movi	a8, 0
.LBB175_167:                            # %source.label143.i.i.i.i.i.outer
                                        # =>This Loop Header: Depth=1
                                        #     Child Loop BB175_168 Depth 2
	l32i	a13, a11, 4
	movi	a14, 1
.LBB175_168:                            # %source.label143.i.i.i.i.i
                                        #   Parent Loop BB175_167 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	or	a11, a12, a12
	bbci	a14, 0, .LBB175_178
# %bb.169:                              # %source.label144.i.i.i.i.i
                                        #   in Loop: Header=BB175_168 Depth=2
	movi	a12, 0
	movi	a14, 0
	beqz	a11, .LBB175_168
# %bb.170:                              # %source.label145.i.i.i.i.i
                                        #   in Loop: Header=BB175_167 Depth=1
	l32i	a12, a11, 0
	sub	a12, a12, a13
	bnez.n	a10, .LBB175_173
# %bb.171:                              # %source.label145.i.i.i.i.i
                                        #   in Loop: Header=BB175_167 Depth=1
	l32r	a14, .LCPI175_7
	bltu	a12, a14, .LBB175_173
# %bb.172:                              # %source.label147.i.i.i.i.i
                                        #   in Loop: Header=BB175_167 Depth=1
	s32i	a13, a5, 0
	l32r	a9, .LCPI175_9
	add	a12, a12, a9
	movi	a10, 1
	or	a9, a11, a11
.LBB175_173:                            # %source.label151.i.i.i.i.i
                                        #   in Loop: Header=BB175_167 Depth=1
	maxu	a8, a8, a12
	l32i	a12, a11, 36
	j	.LBB175_167
.LBB175_174:                            # %source.label270.i.i.i.i.i
	call8	abla_fn_11786425_863113934_direct
	or	a12, a10, a10
	movi	a8, 497
	s32i	a8, a1, 240
	l32r	a11, .LCPI175_12
	l32r	a10, .LCPI175_13
	l32r	a14, .LCPI175_14
	or	a13, a10, a10
	call8	abla_fn_992771427_703335695_direct
	movi	a8, 257
	s32i	a8, a1, 264
	l32i	a10, a1, 284
	beqz.n	a10, .LBB175_176
# %bb.175:                              # %source.label271.i.i.i.i.i
	l32r	a8, .LCPI175_36
	callx8	a8
.LBB175_176:                            # %source.label273.i.i.i.i.i
	l32i	a10, a1, 276
	beqz	a10, .LBB175_34
# %bb.177:                              # %source.label274.i.i.i.i.i
	l32r	a8, .LCPI175_37
	j	.LBB175_33
.LBB175_178:                            # %source.label158.i.i.i.i.i
	beqz	a10, .LBB175_219
# %bb.179:                              # %source.label161.i.i.i.i.i
	l32i	a10, a9, 40
	s32i	a9, a5, 36
	s32i	a10, a5, 40
	l32i	a10, a9, 40
	s32i	a5, a10, 0
	addi	a10, a5, 36
	s32i	a10, a9, 40
	movi	a9, 40
	l32i	a10, a1, 268
	mull	a9, a10, a9
	add	a9, a4, a9
	s32i	a8, a9, 24
	l32r	a10, .LCPI175_7
	s32i	a10, a5, 16
	l32i	a9, a5, 0
	add	a8, a9, a10
	s32i	a8, a5, 4
	l32i	a11, a1, 260
	s32i	a11, a5, 20
	movi	a12, 0
	s32i	a12, a5, 24
	s32i	a10, a5, 28
	movi	a10, 1
	s32i	a10, a5, 32
	extui	a10, a11, 0, 1
	bne	a10, a12, .LBB175_180
	j	.LBB175_197
.LBB175_180:                            # %source.label161.i.i.i.i.i
	l32r	a11, .LCPI175_19
	j	.LBB175_198
.LBB175_181:                            # %source.label219.i.i.i.i.i.loopexit4
	or	a9, a8, a8
	or	a11, a8, a8
	j	.LBB175_183
.LBB175_182:                            # %source.label217.i.i.i.i.i
	l32i	a11, a1, 256
	or	a9, a10, a10
.LBB175_183:                            # %source.label219.i.i.i.i.i
	beqz.n	a11, .LBB175_188
# %bb.184:                              # %source.label262.i.i.i.i.i
	l32i	a9, a8, 24
	l32i	a8, a8, 8
	sub	a8, a8, a9
	l32i	a9, a1, 272
	s32i	a8, a9, 0
	movi	a8, 259
	s32i	a8, a1, 264
	l32i	a10, a1, 284
	beqz.n	a10, .LBB175_186
# %bb.185:                              # %source.label263.i.i.i.i.i
	l32r	a8, .LCPI175_28
	callx8	a8
.LBB175_186:                            # %source.label265.i.i.i.i.i
	l32i	a10, a1, 276
	bnez.n	a10, .LBB175_187
	j	.LBB175_34
.LBB175_187:                            # %source.label266.i.i.i.i.i
	l32r	a8, .LCPI175_29
	j	.LBB175_33
.LBB175_188:                            # %source.label220.i.i.i.i.i
	movi	a8, 1
	movi	a10, 256
	add	a10, a1, a10
	l8ui	a10, a10, 0
	xor	a8, a10, a8
	and	a8, a8, a9
	beqz	a8, .LBB175_200
# %bb.189:                              # %source.label254.i.i.i.i.i
	call8	abla_fn_11786425_863113934_direct
	or	a12, a10, a10
	movi	a8, 546
	s32i	a8, a1, 240
	l32r	a11, .LCPI175_12
	l32r	a10, .LCPI175_13
	l32r	a14, .LCPI175_14
	or	a13, a10, a10
	call8	abla_fn_992771427_703335695_direct
	movi	a8, 258
	s32i	a8, a1, 264
	l32i	a10, a1, 284
	beqz.n	a10, .LBB175_191
# %bb.190:                              # %source.label255.i.i.i.i.i
	l32r	a8, .LCPI175_30
	callx8	a8
.LBB175_191:                            # %source.label257.i.i.i.i.i
	l32i	a10, a1, 276
	bnez.n	a10, .LBB175_192
	j	.LBB175_34
.LBB175_192:                            # %source.label258.i.i.i.i.i
	l32r	a8, .LCPI175_31
	j	.LBB175_33
.LBB175_193:                            # %source.label165.i.i.i.i.i
	call8	abla_fn_11786425_863113934_direct
	or	a12, a10, a10
	movi	a8, 551
	s32i	a8, a1, 240
	l32r	a11, .LCPI175_12
	l32r	a10, .LCPI175_13
	l32r	a14, .LCPI175_14
	or	a13, a10, a10
	call8	abla_fn_992771427_703335695_direct
	movi	a8, 257
	s32i	a8, a1, 264
	l32i	a10, a1, 284
	beqz.n	a10, .LBB175_195
# %bb.194:                              # %source.label166.i.i.i.i.i
	l32r	a8, .LCPI175_24
	callx8	a8
.LBB175_195:                            # %source.label168.i.i.i.i.i
	l32i	a10, a1, 276
	or	a5, a7, a7
	bnez.n	a10, .LBB175_196
	j	.LBB175_34
.LBB175_196:                            # %source.label169.i.i.i.i.i
	l32r	a8, .LCPI175_25
	j	.LBB175_33
.LBB175_197:
	l32r	a11, .LCPI175_20
.LBB175_198:                            # %source.label161.i.i.i.i.i
	or	a10, a11, a9
	s32i	a10, a5, 8
	or	a8, a11, a8
	s32i	a8, a5, 12
	l32r	a8, .LCPI175_21
.LBB175_199:                            # %abla_fn_145328139_22042706_direct.exit.i.i.i.i
	callx8	a8
	l32i	a8, a5, 8
	l32i	a9, a1, 272
	s32i	a8, a9, 0
	or	a5, a7, a7
	j	.LBB175_34
.LBB175_200:                            # %source.label221.i.i.i.i.i
	or	a7, a5, a5
	l32r	a11, .LCPI175_17
	l32r	a8, .LCPI175_32
	movi	a10, 44
	callx8	a8
	or	a5, a10, a10
	beqz	a5, .LBB175_212
# %bb.201:                              # %source.label222.i.i.i.i.i
	movi	a8, 40
	l32i	a9, a1, 268
	mull	a8, a9, a8
	add	a8, a4, a8
	l32i	a12, a8, 36
	movi	a9, 0
	movi	a10, 0
	or	a11, a12, a12
	movi	a8, 0
.LBB175_202:                            # %source.label224.i.i.i.i.i.outer
                                        # =>This Loop Header: Depth=1
                                        #     Child Loop BB175_203 Depth 2
	l32i	a13, a11, 4
	movi	a14, 1
.LBB175_203:                            # %source.label224.i.i.i.i.i
                                        #   Parent Loop BB175_202 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	or	a11, a12, a12
	bbci	a14, 0, .LBB175_209
# %bb.204:                              # %source.label225.i.i.i.i.i
                                        #   in Loop: Header=BB175_203 Depth=2
	movi	a12, 0
	movi	a14, 0
	beqz	a11, .LBB175_203
# %bb.205:                              # %source.label226.i.i.i.i.i
                                        #   in Loop: Header=BB175_202 Depth=1
	l32i	a12, a11, 0
	sub	a12, a12, a13
	bnez.n	a10, .LBB175_208
# %bb.206:                              # %source.label226.i.i.i.i.i
                                        #   in Loop: Header=BB175_202 Depth=1
	l32r	a14, .LCPI175_7
	bltu	a12, a14, .LBB175_208
# %bb.207:                              # %source.label228.i.i.i.i.i
                                        #   in Loop: Header=BB175_202 Depth=1
	s32i	a13, a5, 0
	l32r	a9, .LCPI175_9
	add	a12, a12, a9
	movi	a10, 1
	or	a9, a11, a11
.LBB175_208:                            # %source.label232.i.i.i.i.i
                                        #   in Loop: Header=BB175_202 Depth=1
	maxu	a8, a8, a12
	l32i	a12, a11, 36
	j	.LBB175_202
.LBB175_209:                            # %source.label239.i.i.i.i.i
	beqz	a10, .LBB175_219
# %bb.210:                              # %source.label242.i.i.i.i.i
	l32i	a10, a9, 40
	s32i	a9, a5, 36
	s32i	a10, a5, 40
	l32i	a10, a9, 40
	s32i	a5, a10, 0
	addi	a10, a5, 36
	s32i	a10, a9, 40
	movi	a9, 40
	l32i	a10, a1, 268
	mull	a9, a10, a9
	add	a9, a4, a9
	s32i	a8, a9, 24
	l32r	a10, .LCPI175_7
	s32i	a10, a5, 16
	l32i	a9, a5, 0
	add	a8, a9, a10
	s32i	a8, a5, 4
	l32i	a11, a1, 260
	s32i	a11, a5, 20
	movi	a12, 0
	s32i	a12, a5, 24
	s32i	a10, a5, 28
	movi	a10, 1
	s32i	a10, a5, 32
	extui	a10, a11, 0, 1
	beq	a10, a12, .LBB175_216
# %bb.211:                              # %source.label242.i.i.i.i.i
	l32r	a11, .LCPI175_19
	j	.LBB175_217
.LBB175_212:                            # %source.label246.i.i.i.i.i
	call8	abla_fn_11786425_863113934_direct
	or	a12, a10, a10
	movi	a8, 551
	s32i	a8, a1, 240
	l32r	a11, .LCPI175_12
	l32r	a10, .LCPI175_13
	l32r	a14, .LCPI175_14
	or	a13, a10, a10
	call8	abla_fn_992771427_703335695_direct
	movi	a8, 257
	s32i	a8, a1, 264
	l32i	a10, a1, 284
	beqz.n	a10, .LBB175_214
# %bb.213:                              # %source.label247.i.i.i.i.i
	l32r	a8, .LCPI175_34
	callx8	a8
.LBB175_214:                            # %source.label249.i.i.i.i.i
	l32i	a10, a1, 276
	or	a5, a7, a7
	bnez.n	a10, .LBB175_215
	j	.LBB175_34
.LBB175_215:                            # %source.label250.i.i.i.i.i
	l32r	a8, .LCPI175_35
	j	.LBB175_33
.LBB175_216:
	l32r	a11, .LCPI175_20
.LBB175_217:                            # %source.label242.i.i.i.i.i
	or	a10, a11, a9
	s32i	a10, a5, 8
	or	a8, a11, a8
	s32i	a8, a5, 12
	l32r	a8, .LCPI175_33
	j	.LBB175_199
.LBB175_218:                            # %source.label19.i221.i.i.i
	l32r	a8, .LCPI175_59
	addi	a10, a8, 55
	l32r	a12, .LCPI175_60
	l32r	a13, .LCPI175_61
	movi	a11, 266
	call8	abla_fn_343754787_547301002_direct
.LBB175_219:                            # %source.label159.i.i.i.i.i
	movi	a8, 176
	l32r	a9, .LCPI175_22
	add	a10, a9, a8
	l32r	a12, .LCPI175_23
	l32r	a13, .LCPI175_12
	movi	a11, 578
	call8	abla_fn_343754787_547301002_direct
.Lfunc_end175:
	.size	abla_fn_729003036_956798390_direct, .Lfunc_end175-abla_fn_729003036_956798390_direct
                                        # -- End function
	.literal_position
	.literal .LCPI176_0, abla_static_abla_fn_627837887_633683867_3211
	.literal .LCPI176_1, abla_fn_213944016_953228118_direct
	.literal .LCPI176_2, abla_fn_213944016_953228118_direct
	.section	.text.abla_fn_729003036_956798390_direct,"ax",@progbits
	.section	.text.abla_fn_340404077_510317132_direct,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_340404077_510317132_direct
	.type	abla_fn_340404077_510317132_direct,@function
abla_fn_340404077_510317132_direct:     # @abla_fn_340404077_510317132_direct
# %bb.0:                                # %entry
	entry	a1, 48
	l32i	a6, a2, 12
	beqz	a6, .LBB176_17
# %bb.1:                                # %source.label10
	l32r	a10, .LCPI176_0
	call8	abla_fn_396055959_456822569_direct
	l32i	a7, a2, 8
	l32i	a5, a2, 4
	s32i	a2, a1, 0                       # 4-byte Folded Spill
	l32i	a4, a2, 0
	movi	a10, 255
	beqz	a6, .LBB176_16
.LBB176_2:                              # %source.label13
                                        # =>This Inner Loop Header: Depth=1
	movi	a3, 0
	movi	a2, 0
	beq	a4, a10, .LBB176_5
# %bb.3:                                # %source.label18
                                        #   in Loop: Header=BB176_2 Depth=1
	l32i	a8, a6, 4
	movi	a2, 1
	bne	a4, a8, .LBB176_5
# %bb.4:                                # %source.label18
                                        #   in Loop: Header=BB176_2 Depth=1
	movi	a2, 0
.LBB176_5:                              # %source.label20
                                        #   in Loop: Header=BB176_2 Depth=1
	beq	a5, a10, .LBB176_8
# %bb.6:                                # %source.label23
                                        #   in Loop: Header=BB176_2 Depth=1
	l32i	a8, a6, 8
	movi	a3, 1
	bne	a5, a8, .LBB176_8
# %bb.7:                                # %source.label23
                                        #   in Loop: Header=BB176_2 Depth=1
	movi	a3, 0
.LBB176_8:                              # %source.label25
                                        #   in Loop: Header=BB176_2 Depth=1
	beqz.n	a7, .LBB176_12
# %bb.9:                                # %source.label28
                                        #   in Loop: Header=BB176_2 Depth=1
	addi	a11, a6, 24
	or	a10, a7, a7
	call8	abla_fn_934637158_713051631_direct
	movi	a8, 1
	movi	a9, 0
	beq	a10, a9, .LBB176_11
# %bb.10:                               # %source.label28
                                        #   in Loop: Header=BB176_2 Depth=1
	movi	a8, 0
.LBB176_11:                             # %source.label28
                                        #   in Loop: Header=BB176_2 Depth=1
	movi	a10, 255
	j	.LBB176_13
.LBB176_12:                             #   in Loop: Header=BB176_2 Depth=1
	movi	a8, 1
.LBB176_13:                             # %source.label30
                                        #   in Loop: Header=BB176_2 Depth=1
	or	a9, a2, a3
	bbsi	a9, 0, .LBB176_15
# %bb.14:                               # %source.label30
                                        #   in Loop: Header=BB176_2 Depth=1
	bbsi	a8, 0, .LBB176_19
.LBB176_15:                             # %source.label39
                                        #   in Loop: Header=BB176_2 Depth=1
	l32i	a6, a6, 48
	bnez	a6, .LBB176_2
.LBB176_16:                             # %source.label41.critedge
	l32r	a10, .LCPI176_0
	call8	abla_fn_954702414_417902696_direct
	l32r	a8, .LCPI176_1
	l32i	a10, a1, 0                      # 4-byte Folded Reload
	j	.LBB176_18
.LBB176_17:                             # %source.label8
	l32r	a8, .LCPI176_2
	or	a10, a2, a2
.LBB176_18:                             # %common.ret
	callx8	a8
	movi	a2, 0
	retw.n
.LBB176_19:                             # %source.label40
	l32r	a10, .LCPI176_0
	call8	abla_fn_954702414_417902696_direct
	l32i	a2, a1, 0                       # 4-byte Folded Reload
	s32i	a6, a2, 16
	l32i	a8, a6, 48
	s32i	a8, a2, 12
	retw.n
.Lfunc_end176:
	.size	abla_fn_340404077_510317132_direct, .Lfunc_end176-abla_fn_340404077_510317132_direct
                                        # -- End function
	.literal_position
	.literal .LCPI177_0, .Labla_string_abla_fn_627837887_633683867_2295.native.bytes
	.literal .LCPI177_1, abla_fn_205989963_612999693_direct
	.literal .LCPI177_2, .Labla_string_abla_fn_627837887_633683867_2309.native.bytes
	.literal .LCPI177_3, abla_static_abla_fn_627837887_633683867_2249
	.literal .LCPI177_4, -4194304
	.literal .LCPI177_5, 1061158912
	.literal .LCPI177_6, -1074593792
	.literal .LCPI177_7, 3342335
	.literal .LCPI177_8, 1082130432
	.literal .LCPI177_9, 1077936128
	.literal .LCPI177_10, 1072955512
	.literal .LCPI177_11, 1072758784
	.literal .LCPI177_12, .Labla_string_abla_fn_627837887_633683867_2330.native.bytes
	.literal .LCPI177_13, .Labla_string_abla_fn_627837887_633683867_2281.native.bytes
	.section	.text.abla_fn_340404077_510317132_direct,"ax",@progbits
	.section	.text.abla_fn_994130324_279377218_direct,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_994130324_279377218_direct
	.type	abla_fn_994130324_279377218_direct,@function
abla_fn_994130324_279377218_direct:     # @abla_fn_994130324_279377218_direct
# %bb.0:                                # %entry
	entry	a1, 96
	or	a7, a1, a1
	or	a6, a2, a2
	movi	a2, -1
	beqz	a6, .LBB177_16
# %bb.1:                                # %source.label3
	addi	a8, a1, -32
	movsp	a1, a8
	movi	a8, 0
	or	a3, a1, a1
	s32i	a8, a3, 0
	s32i	a8, a3, 4
	#APP
	nsau	a8, a6
	#NO_APP
	#APP
	nsau	a9, a3
	#NO_APP
	or	a8, a9, a8
	movi	a9, 31
	bltu	a9, a8, .LBB177_5
# %bb.2:                                # %source.label.i
	l32r	a8, .LCPI177_1
	or	a10, a6, a6
	movi	a11, 1
	callx8	a8
	l32r	a5, .LCPI177_2
	beqz.n	a10, .LBB177_6
# %bb.3:                                # %source.label4.i.i.i
	movi	a8, 0
	s32i	a8, a7, 20
	s32i	a8, a7, 16
	l32r	a8, .LCPI177_3
	addi	a4, a8, 124
	or	a10, a4, a4
	call8	abla_fn_396055959_456822569_direct
	l32r	a8, .LCPI177_4
	and	a8, a6, a8
	l32r	a9, .LCPI177_5
	bne	a8, a9, .LBB177_7
# %bb.4:                                # %source.label.i7.i.i.i
	extui	a8, a6, 16, 6
	j	.LBB177_14
.LBB177_5:
	l32r	a5, .LCPI177_0
	movi	a6, 805
	j	.LBB177_18
.LBB177_6:
	movi	a6, 806
	j	.LBB177_18
.LBB177_7:                              # %source.label2.i.i.i.i
	l32r	a9, .LCPI177_6
	add	a9, a6, a9
	l32r	a10, .LCPI177_7
	bltu	a10, a9, .LBB177_9
# %bb.8:                                # %source.label3.i.i.i.i
	extui	a8, a6, 16, 6
	movi	a9, 64
	j	.LBB177_13
.LBB177_9:                              # %source.label5.i.i.i.i
	l32r	a9, .LCPI177_8
	beq	a8, a9, .LBB177_12
# %bb.10:                               # %source.label5.i.i.i.i
	l32r	a9, .LCPI177_9
	beq	a8, a9, .LBB177_11
	j	.LBB177_19
.LBB177_11:                             # %source.label6.i.i.i.i
	extui	a8, a6, 16, 6
	movi	a9, 128
	j	.LBB177_13
.LBB177_12:                             # %source.label9.i.i.i.i
	extui	a8, a6, 16, 6
	movi	a9, 192
.LBB177_13:                             # %abla_fn_522045837_648800950_direct.exit.i.i.i
	or	a8, a8, a9
.LBB177_14:                             # %abla_fn_522045837_648800950_direct.exit.i.i.i
	#APP
	rsil	a9, 5
	#NO_APP
	l32r	a10, .LCPI177_10
	memw
	l32i	a10, a10, 0
	slli	a8, a8, 2
	l32r	a10, .LCPI177_11
	or	a10, a8, a10
	memw
	l32i	a10, a10, 0
	#APP
	wsr	a9, ps
	rsync

	#NO_APP
	bbsi	a10, 8, .LBB177_17
# %bb.15:                               # %source.label7
	movi	a9, 4
	or	a5, a3, a9
	#APP
	rsil	a9, 5
	#NO_APP
	l32r	a10, .LCPI177_10
	memw
	l32i	a10, a10, 0
	l32r	a10, .LCPI177_11
	or	a8, a8, a10
	memw
	l32i	a8, a8, 0
	#APP
	wsr	a9, ps
	rsync

	#NO_APP
	movi	a9, 1
	s32i	a9, a7, 20
	slli	a8, a8, 16
	extui	a9, a6, 0, 16
	or	a8, a8, a9
	s32i	a8, a7, 16
	or	a10, a4, a4
	call8	abla_fn_954702414_417902696_direct
	l32i	a8, a7, 16
	s32i	a8, a3, 0
	l32i	a8, a7, 20
	s32i	a8, a5, 0
	l32i	a2, a3, 0
.LBB177_16:                             # %common.ret
	retw.n
.LBB177_17:                             # %source.label25.critedge.i
	or	a10, a4, a4
	call8	abla_fn_954702414_417902696_direct
	movi	a6, 812
.LBB177_18:                             # %abla_fn_493526331_273590510_direct.exit.thread
	call8	abla_fn_11786425_863113934_direct
	or	a12, a10, a10
	s32i	a6, a7, 0
	l32r	a10, .LCPI177_12
	l32r	a14, .LCPI177_13
	or	a11, a5, a5
	or	a13, a10, a10
	call8	abla_fn_992771427_703335695_direct
	retw.n
.LBB177_19:                             # %source.label11.i.i.i.i
	ill.n
.Lfunc_end177:
	.size	abla_fn_994130324_279377218_direct, .Lfunc_end177-abla_fn_994130324_279377218_direct
                                        # -- End function
	.literal_position
	.literal .LCPI178_0, abla_static_abla_fn_627837887_633683867_3539.0
	.literal .LCPI178_1, .Labla_string_abla_fn_627837887_633683867_3561.native.u32s
	.literal .LCPI178_2, abla_fn_213944016_953228118_direct
	.literal .LCPI178_3, .Labla_string_abla_fn_627837887_633683867_3551.native.bytes
	.literal .LCPI178_4, .Labla_string_abla_fn_627837887_633683867_3544.native.bytes
	.section	.text.abla_fn_994130324_279377218_direct,"ax",@progbits
	.section	.text.abla_fn_945139464_207419804_direct,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_945139464_207419804_direct
	.type	abla_fn_945139464_207419804_direct,@function
abla_fn_945139464_207419804_direct:     # @abla_fn_945139464_207419804_direct
# %bb.0:                                # %entry
	entry	a1, 32
	l32r	a6, .LCPI178_0
	l32i	a2, a6, 0
	beqz.n	a2, .LBB178_2
# %bb.1:                                # %common.ret
	retw.n
.LBB178_2:                              # %source.label5
	l32r	a8, .LCPI178_1
	memw
	l32i	a10, a8, 0
	call8	abla_fn_994130324_279377218_direct
	or	a7, a10, a10
	beqi	a7, -1, .LBB178_10
# %bb.3:                                # %source.label10
	movi	a10, 0
	call8	abla_fn_729003036_956798390_direct
	beqz.n	a10, .LBB178_11
# %bb.4:                                # %source.label15
	beqz.n	a10, .LBB178_8
.LBB178_5:                              # %source.label16
                                        # =>This Inner Loop Header: Depth=1
	l32i	a2, a10, 16
	l32i	a8, a2, 12
	bltu	a7, a8, .LBB178_7
# %bb.6:                                # %source.label21
                                        #   in Loop: Header=BB178_5 Depth=1
	l32i	a9, a2, 16
	add	a8, a9, a8
	bltu	a7, a8, .LBB178_9
.LBB178_7:                              # %source.label26
                                        #   in Loop: Header=BB178_5 Depth=1
	call8	abla_fn_340404077_510317132_direct
	bnez	a10, .LBB178_5
.LBB178_8:                              # %source.label27
	ill.n
.LBB178_9:                              # %source.label24
	l32r	a8, .LCPI178_2
	callx8	a8
	s32i	a2, a6, 0
	retw.n
.LBB178_10:                             # %source.label8
	l32r	a13, .LCPI178_3
	addi	a10, a13, 68
	l32r	a12, .LCPI178_4
	movi	a11, 880
	call8	abla_fn_343754787_547301002_direct
.LBB178_11:                             # %source.label12
	l32r	a13, .LCPI178_3
	addi	a10, a13, 68
	l32r	a12, .LCPI178_4
	movi	a11, 885
	call8	abla_fn_343754787_547301002_direct
.Lfunc_end178:
	.size	abla_fn_945139464_207419804_direct, .Lfunc_end178-abla_fn_945139464_207419804_direct
                                        # -- End function
	.literal_position
	.literal .LCPI179_0, abla_fn_923148460_536466818_direct
	.section	.text.abla_fn_945139464_207419804_direct,"ax",@progbits
	.section	.text.abla_fn_689607981_668554081_direct,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_689607981_668554081_direct
	.type	abla_fn_689607981_668554081_direct,@function
abla_fn_689607981_668554081_direct:     # @abla_fn_689607981_668554081_direct
# %bb.0:                                # %entry
	entry	a1, 32
	l32r	a8, .LCPI179_0
	callx8	a8
	call8	abla_fn_928611835_706970686_direct
	s32i	a10, a2, 8
	movi	a2, 0
	retw.n
.Lfunc_end179:
	.size	abla_fn_689607981_668554081_direct, .Lfunc_end179-abla_fn_689607981_668554081_direct
                                        # -- End function
	.literal_position
	.literal .LCPI180_0, .Labla_string_abla_fn_627837887_633683867_3634.native.bytes
	.literal .LCPI180_1, .Labla_string_abla_fn_627837887_633683867_3621.native.bytes
	.literal .LCPI180_2, 20000
	.section	.text.abla_fn_689607981_668554081_direct,"ax",@progbits
	.section	.text.abla_fn_792983549_415993329_direct,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_792983549_415993329_direct
	.type	abla_fn_792983549_415993329_direct,@function
abla_fn_792983549_415993329_direct:     # @abla_fn_792983549_415993329_direct
# %bb.0:                                # %entry
	entry	a1, 32
	bnez	a3, .LBB180_10
# %bb.1:                                # %source.label17
	call8	abla_fn_928611835_706970686_direct
	l32i	a8, a2, 12
	sub	a8, a10, a8
	movi	a9, 999
	bltu	a9, a8, .LBB180_4
# %bb.2:                                # %source.label.i
	l32i	a8, a2, 8
	sub	a9, a10, a8
	movi	a8, 1
	l32r	a10, .LCPI180_2
	bltu	a9, a10, .LBB180_5
# %bb.3:                                # %source.label.i
	movi	a8, 0
	j	.LBB180_5
.LBB180_4:                              # %source.label19.i
	s32i	a10, a2, 8
	movi	a8, 1
.LBB180_5:                              # %abla_fn_3439303_124515886_direct.exit
	beqz.n	a4, .LBB180_7
# %bb.6:                                # %source.label21
	movi	a9, -1
	xor	a9, a8, a9
	extui	a9, a9, 0, 1
	s32i	a9, a4, 0
.LBB180_7:                              # %source.label23
	extui	a8, a8, 0, 1
	movi	a2, 263
	movi	a9, 0
	bne	a8, a9, .LBB180_9
# %bb.8:                                # %source.label23
	movi	a2, 0
.LBB180_9:                              # %source.label23
	retw.n
.LBB180_10:                             # %source.label
	l32r	a13, .LCPI180_0
	addi	a10, a13, 47
	l32r	a12, .LCPI180_1
	movi	a11, 203
	call8	abla_fn_343754787_547301002_direct
.Lfunc_end180:
	.size	abla_fn_792983549_415993329_direct, .Lfunc_end180-abla_fn_792983549_415993329_direct
                                        # -- End function
	.literal_position
	.literal .LCPI181_0, abla_fn_213944016_953228118_direct
	.section	.text.abla_fn_792983549_415993329_direct,"ax",@progbits
	.section	.text.abla_fn_518574188_300923136_direct,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_518574188_300923136_direct
	.type	abla_fn_518574188_300923136_direct,@function
abla_fn_518574188_300923136_direct:     # @abla_fn_518574188_300923136_direct
# %bb.0:                                # %entry
	entry	a1, 32
	or	a10, a3, a3
	l32r	a8, .LCPI181_0
	callx8	a8
	retw.n
.Lfunc_end181:
	.size	abla_fn_518574188_300923136_direct, .Lfunc_end181-abla_fn_518574188_300923136_direct
                                        # -- End function
	.literal_position
	.literal .LCPI182_0, abla_static_abla_fn_627837887_633683867_4112
	.literal .LCPI182_1, 2052
	.literal .LCPI182_2, abla_fn_724969459_465497474_direct
	.literal .LCPI182_3, -2147483648
	.section	.text.abla_fn_518574188_300923136_direct,"ax",@progbits
	.section	.text.abla_fn_367195186_502328401_direct,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_367195186_502328401_direct
	.type	abla_fn_367195186_502328401_direct,@function
abla_fn_367195186_502328401_direct:     # @abla_fn_367195186_502328401_direct
# %bb.0:                                # %entry
	entry	a1, 192
	movi	a8, 12
	addi	a9, a1, 32
	or	a12, a9, a8
	movi	a10, 8
	or	a13, a9, a10
	movi	a11, 4
	or	a14, a9, a11
	addi	a9, a1, 96
	or	a15, a9, a8
	or	a10, a9, a10
	or	a9, a9, a11
	movi	a5, 5
	movi	a6, 0
	l32r	a11, .LCPI182_0
	movi	a2, 0
.LBB182_1:                              # %source.label.outer.outer
                                        # =>This Loop Header: Depth=1
                                        #     Child Loop BB182_2 Depth 2
                                        #       Child Loop BB182_3 Depth 3
                                        #     Child Loop BB182_7 Depth 2
                                        #       Child Loop BB182_14 Depth 3
                                        #       Child Loop BB182_18 Depth 3
	movi	a8, 1
.LBB182_2:                              # %source.label.outer
                                        #   Parent Loop BB182_1 Depth=1
                                        # =>  This Loop Header: Depth=2
                                        #       Child Loop BB182_3 Depth 3
	or	a7, a5, a5
.LBB182_3:                              # %source.label
                                        #   Parent Loop BB182_1 Depth=1
                                        #     Parent Loop BB182_2 Depth=2
                                        # =>    This Inner Loop Header: Depth=3
	bbsi	a8, 0, .LBB182_4
	j	.LBB182_40
.LBB182_4:                              # %source.label18
                                        #   in Loop: Header=BB182_3 Depth=3
	movi	a8, 0
	bnez	a2, .LBB182_3
# %bb.5:                                # %source.label20
                                        #   in Loop: Header=BB182_2 Depth=2
	movi	a2, 0
	movi	a5, 0
	beqz	a7, .LBB182_2
# %bb.6:                                # %source.label21
                                        #   in Loop: Header=BB182_1 Depth=1
	s32i	a9, a1, 28                      # 4-byte Folded Spill
	s32i	a10, a1, 4                      # 4-byte Folded Spill
	s32i	a4, a1, 0                       # 4-byte Folded Spill
	addi	a10, a1, 32
	or	a2, a11, a11
	movi	a11, 0
	s32i	a3, a1, 16                      # 4-byte Folded Spill
	s32i	a12, a1, 12                     # 4-byte Folded Spill
	movi	a12, 28
	s32i	a13, a1, 20                     # 4-byte Folded Spill
	s32i	a14, a1, 8                      # 4-byte Folded Spill
	s32i	a15, a1, 24                     # 4-byte Folded Spill
	call8	abla_fn_853840267_528021067_direct
	l32i	a11, a1, 20                     # 4-byte Folded Reload
	l32i	a10, a1, 16                     # 4-byte Folded Reload
	addi	a5, a7, -1
	l32i	a8, a2, 0
	movi	a4, 1
	movi	a3, -4
.LBB182_7:                              # %source.label.i.i
                                        #   Parent Loop BB182_1 Depth=1
                                        # =>  This Loop Header: Depth=2
                                        #       Child Loop BB182_14 Depth 3
                                        #       Child Loop BB182_18 Depth 3
	or	a2, a8, a8
	bbsi	a4, 0, .LBB182_8
	j	.LBB182_39
.LBB182_8:                              # %source.label26.i.i
                                        #   in Loop: Header=BB182_7 Depth=2
	movi	a4, 1
	movi	a8, 0
	bne	a2, a8, .LBB182_10
# %bb.9:                                # %source.label26.i.i
                                        #   in Loop: Header=BB182_7 Depth=2
	movi	a4, 0
.LBB182_10:                             # %source.label26.i.i
                                        #   in Loop: Header=BB182_7 Depth=2
	beqz	a2, .LBB182_7
# %bb.11:                               # %source.label.i.i.i
                                        #   in Loop: Header=BB182_7 Depth=2
	l32i	a7, a2, 28
	beqz	a7, .LBB182_38
# %bb.12:                               # %source.label5.i.i.i
                                        #   in Loop: Header=BB182_7 Depth=2
	l32i	a8, a2, 0
	l32i	a9, a2, 4
	or	a8, a9, a8
	l32i	a9, a2, 8
	or	a8, a8, a9
	l32r	a9, .LCPI182_1
	and	a8, a8, a9
	beq	a8, a9, .LBB182_13
	j	.LBB182_38
.LBB182_13:                             # %source.label.i59.i.i.preheader
                                        #   in Loop: Header=BB182_7 Depth=2
	movi	a8, 0
	movi	a10, 27
	bltu	a10, a8, .LBB182_15
.LBB182_14:                             # %source.label14.i.i.i
                                        #   Parent Loop BB182_1 Depth=1
                                        #     Parent Loop BB182_7 Depth=2
                                        # =>    This Inner Loop Header: Depth=3
	addi	a9, a1, 96
	add	a9, a9, a8
	s32i	a6, a9, 0
	addi	a8, a8, 4
	bgeu	a10, a8, .LBB182_14
.LBB182_15:                             # %source.label18.i.i.i
                                        #   in Loop: Header=BB182_7 Depth=2
	or	a10, a7, a7
	call8	abla_fn_524213402_227204421_direct
	l32i	a12, a7, 16
	movi	a11, 0
	movi	a8, 0
	beqz.n	a12, .LBB182_17
# %bb.16:                               # %source.label1.i.i.i.i.i
                                        #   in Loop: Header=BB182_7 Depth=2
	l32i	a8, a12, 20
.LBB182_17:                             # %abla_fn_896935147_719056048_direct.exit.i.i.i
                                        #   in Loop: Header=BB182_7 Depth=2
	add	a8, a12, a8
	addi	a13, a8, -4
	movi	a8, 0
	movi	a9, 0
	movi	a10, 0
.LBB182_18:                             # %source.label25.i.i.i
                                        #   Parent Loop BB182_1 Depth=1
                                        #     Parent Loop BB182_7 Depth=2
                                        # =>    This Inner Loop Header: Depth=3
	l32i	a15, a13, 4
	and	a14, a15, a3
	beqz.n	a14, .LBB182_22
# %bb.19:                               # %source.label26.i.i.i
                                        #   in Loop: Header=BB182_18 Depth=3
	extui	a15, a15, 0, 1
	beq	a15, a6, .LBB182_21
# %bb.20:                               #   in Loop: Header=BB182_18 Depth=3
	maxu	a11, a14, a11
.LBB182_21:                             # %source.label26.i.i.i
                                        #   in Loop: Header=BB182_18 Depth=3
	addi	a13, a13, 4
	add	a13, a14, a13
	add	a8, a15, a8
	movi	a14, 1
	xor	a14, a15, a14
	add	a10, a14, a10
	addi	a9, a9, 1
	j	.LBB182_18
.LBB182_22:                             # %source.label34.i.i.i
                                        #   in Loop: Header=BB182_7 Depth=2
	l32i	a14, a7, 4
	s32i	a14, a1, 96
	l32i	a15, a7, 12
	movi	a13, 0
	beqz.n	a12, .LBB182_24
# %bb.23:                               # %source.label1.i.i.i.i
                                        #   in Loop: Header=BB182_7 Depth=2
	l32i	a13, a12, 20
.LBB182_24:                             # %abla_fn_842431889_601053633_direct.exit.i.i.i
                                        #   in Loop: Header=BB182_7 Depth=2
	add	a13, a14, a13
	addx4	a13, a10, a13
	sub	a13, a15, a13
	l32i	a14, a1, 28                     # 4-byte Folded Reload
	s32i	a13, a14, 0
	beqz.n	a12, .LBB182_31
# %bb.25:                               # %abla_fn_842431889_601053633_direct.exit.i.i.i
                                        #   in Loop: Header=BB182_7 Depth=2
	l32i	a15, a1, 24                     # 4-byte Folded Reload
	beqz.n	a11, .LBB182_32
# %bb.26:                               # %source.label5.i.i.i.i
                                        #   in Loop: Header=BB182_7 Depth=2
	l32i	a14, a12, 16
	extui	a13, a14, 23, 8
	bgeu	a11, a13, .LBB182_33
# %bb.27:                               # %abla_fn_259878424_650702494_direct.exit.i.i.i.i.i
                                        #   in Loop: Header=BB182_7 Depth=2
	addi	a12, a11, 3
	and	a12, a12, a3
	extui	a14, a14, 8, 6
	ssr	a14
	srl	a13, a12
	movi	a3, 31
	bltu	a3, a14, .LBB182_32
# %bb.28:                               # %abla_fn_259878424_650702494_direct.exit.i.i.i.i.i
                                        #   in Loop: Header=BB182_7 Depth=2
	movi	a14, 0
	bnez.n	a13, .LBB182_37
# %bb.29:                               # %source.label5.i.i.i.i.i
                                        #   in Loop: Header=BB182_7 Depth=2
	movi	a14, 12
	movi	a13, 9
	bltu	a11, a13, .LBB182_37
# %bb.30:                               # %source.label5.i.i.i.i.i
                                        #   in Loop: Header=BB182_7 Depth=2
	or	a14, a12, a12
	j	.LBB182_37
.LBB182_31:                             #   in Loop: Header=BB182_7 Depth=2
	l32i	a15, a1, 24                     # 4-byte Folded Reload
.LBB182_32:                             #   in Loop: Header=BB182_7 Depth=2
	movi	a14, 0
	j	.LBB182_37
.LBB182_33:                             # %abla_fn_173146590_885096896_direct.exit.i.i.i.i
                                        #   in Loop: Header=BB182_7 Depth=2
	#APP
	nsau	a13, a11
	#NO_APP
	l32i	a12, a12, 16
	extui	a12, a12, 14, 6
	beqz	a12, .LBB182_43
# %bb.34:                               # %scalar.divide.checked.i.i.i.i
                                        #   in Loop: Header=BB182_7 Depth=2
	l32r	a14, .LCPI182_3
	ssr	a13
	srl	a14, a14
	movi	a3, 31
	bgeu	a3, a13, .LBB182_36
# %bb.35:                               # %scalar.divide.checked.i.i.i.i
                                        #   in Loop: Header=BB182_7 Depth=2
	movi	a14, 0
.LBB182_36:                             # %scalar.divide.checked.i.i.i.i
                                        #   in Loop: Header=BB182_7 Depth=2
	quou	a12, a14, a12
	neg	a12, a12
	and	a14, a11, a12
.LBB182_37:                             # %abla_fn_412914826_26068325_direct.exit.i.i
                                        #   in Loop: Header=BB182_7 Depth=2
	l32i	a3, a1, 4                       # 4-byte Folded Reload
	s32i	a14, a3, 0
	l32i	a11, a7, 8
	s32i	a11, a15, 0
	s32i	a9, a1, 120
	s32i	a8, a1, 116
	s32i	a10, a1, 112
	or	a10, a7, a7
	call8	abla_fn_973951929_967810110_direct
	l32i	a8, a1, 32
	l32i	a9, a1, 96
	add	a8, a9, a8
	s32i	a8, a1, 32
	l32i	a10, a1, 8                      # 4-byte Folded Reload
	l32i	a8, a10, 0
	l32i	a9, a1, 28                      # 4-byte Folded Reload
	l32i	a9, a9, 0
	add	a8, a9, a8
	s32i	a8, a10, 0
	l32i	a11, a1, 20                     # 4-byte Folded Reload
	l32i	a8, a11, 0
	l32i	a9, a3, 0
	movi	a3, -4
	maxu	a8, a9, a8
	s32i	a8, a11, 0
	l32i	a10, a1, 12                     # 4-byte Folded Reload
	l32i	a8, a10, 0
	l32i	a9, a1, 24                      # 4-byte Folded Reload
	l32i	a9, a9, 0
	add	a8, a9, a8
	s32i	a8, a10, 0
	l32i	a8, a1, 48
	l32i	a9, a1, 112
	add	a8, a9, a8
	s32i	a8, a1, 48
	l32i	a8, a1, 52
	l32i	a9, a1, 116
	add	a8, a9, a8
	s32i	a8, a1, 52
	l32i	a8, a1, 56
	l32i	a9, a1, 120
	add	a8, a9, a8
	s32i	a8, a1, 56
	l32i	a10, a1, 16                     # 4-byte Folded Reload
.LBB182_38:                             # %source.label34.i.i
                                        #   in Loop: Header=BB182_7 Depth=2
	l32i	a8, a2, 32
	j	.LBB182_7
.LBB182_39:                             # %abla_fn_503608565_888143580_direct.exit
                                        #   in Loop: Header=BB182_1 Depth=1
	l32i	a8, a11, 0
	minu	a8, a10, a8
	addi	a8, a8, 3
	movi	a9, -4
	and	a3, a8, a9
	l32r	a11, .LCPI182_1
	or	a10, a3, a3
	l32r	a8, .LCPI182_2
	callx8	a8
	l32i	a15, a1, 24                     # 4-byte Folded Reload
	l32i	a14, a1, 8                      # 4-byte Folded Reload
	l32i	a13, a1, 20                     # 4-byte Folded Reload
	l32i	a12, a1, 12                     # 4-byte Folded Reload
	or	a2, a10, a10
	l32i	a4, a1, 0                       # 4-byte Folded Reload
	l32i	a10, a1, 4                      # 4-byte Folded Reload
	l32i	a9, a1, 28                      # 4-byte Folded Reload
	l32r	a11, .LCPI182_0
	j	.LBB182_1
.LBB182_40:                             # %source.label29
	movi	a8, 0
	beq	a2, a8, .LBB182_42
# %bb.41:                               # %source.label29
	or	a8, a3, a3
.LBB182_42:                             # %source.label29
	s32i	a8, a4, 0
	retw.n
.LBB182_43:                             # %scalar.division.by.zero.i.i.i.i
	ill.n
.Lfunc_end182:
	.size	abla_fn_367195186_502328401_direct, .Lfunc_end182-abla_fn_367195186_502328401_direct
                                        # -- End function
	.literal_position
	.literal .LCPI183_0, abla_fn_887465115_248809038_direct
	.section	.text.abla_fn_367195186_502328401_direct,"ax",@progbits
	.section	.text.abla_fn_384677981_576167795_direct,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_384677981_576167795_direct
	.type	abla_fn_384677981_576167795_direct,@function
abla_fn_384677981_576167795_direct:     # @abla_fn_384677981_576167795_direct
# %bb.0:                                # %entry
	entry	a1, 32
	or	a10, a3, a3
	l32r	a8, .LCPI183_0
	callx8	a8
	movi	a2, 0
	retw.n
.Lfunc_end183:
	.size	abla_fn_384677981_576167795_direct, .Lfunc_end183-abla_fn_384677981_576167795_direct
                                        # -- End function
	.section	.text.abla_fn_453137308_422103327_direct,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_453137308_422103327_direct
	.type	abla_fn_453137308_422103327_direct,@function
abla_fn_453137308_422103327_direct:     # @abla_fn_453137308_422103327_direct
# %bb.0:                                # %entry
	entry	a1, 32
	retw.n
.Lfunc_end184:
	.size	abla_fn_453137308_422103327_direct, .Lfunc_end184-abla_fn_453137308_422103327_direct
                                        # -- End function
	.literal_position
	.literal .LCPI185_0, 35841
	.section	.text.abla_fn_453137308_422103327_direct,"ax",@progbits
	.section	.text.abla_fn_563991449_691852434_direct,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_563991449_691852434_direct
	.type	abla_fn_563991449_691852434_direct,@function
abla_fn_563991449_691852434_direct:     # @abla_fn_563991449_691852434_direct
# %bb.0:                                # %entry
	entry	a1, 32
	add	a7, a4, a3
	movi	a10, 255
	call8	abla_fn_729003036_956798390_direct
.LBB185_1:                              # %source.label.i.outer
                                        # =>This Loop Header: Depth=1
                                        #     Child Loop BB185_2 Depth 2
	movi	a8, 7
.LBB185_2:                              # %source.label.i
                                        #   Parent Loop BB185_1 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	extui	a8, a8, 0, 4
	bnei	a8, 7, .LBB185_10
# %bb.3:                                # %source.label17.i
                                        #   in Loop: Header=BB185_2 Depth=2
	beqz.n	a10, .LBB185_8
# %bb.4:                                # %source.label18.i
                                        #   in Loop: Header=BB185_2 Depth=2
	l32i	a8, a10, 16
	l8ui	a9, a8, 42
	beqz.n	a9, .LBB185_9
# %bb.5:                                # %source.label20.i
                                        #   in Loop: Header=BB185_2 Depth=2
	l32i	a9, a8, 12
	bgeu	a3, a9, .LBB185_7
# %bb.6:                                # %source.label23.i
                                        #   in Loop: Header=BB185_2 Depth=2
	movi	a8, 10
	bltu	a9, a7, .LBB185_2
	j	.LBB185_9
.LBB185_7:                              # %source.label28.i
                                        #   in Loop: Header=BB185_2 Depth=2
	l32i	a8, a8, 16
	add	a9, a8, a9
	movi	a8, 9
	bltu	a3, a9, .LBB185_2
	j	.LBB185_9
.LBB185_8:                              #   in Loop: Header=BB185_2 Depth=2
	movi	a8, 8
	movi	a10, 0
	j	.LBB185_2
.LBB185_9:                              # %source.label41.sink.split.i
                                        #   in Loop: Header=BB185_1 Depth=1
	call8	abla_fn_340404077_510317132_direct
	j	.LBB185_1
.LBB185_10:                             # %source.label.i
	bnei	a8, 8, .LBB185_13
# %bb.11:                               # %source.label16
	l8ui	a8, a2, 4
	movi	a2, 0
	beqz.n	a8, .LBB185_14
.LBB185_12:                             # %source.label23
	retw.n
.LBB185_13:                             # %source.label23.loopexit
	movi	a2, 269
	retw.n
.LBB185_14:                             # %source.label18
	movi	a2, 262
	l32r	a8, .LCPI185_0
	bltu	a3, a8, .LBB185_12
# %bb.15:                               # %source.label16.i
	call8	abla_fn_945139464_207419804_direct
	l32i	a8, a10, 12
	bgeu	a3, a8, .LBB185_17
# %bb.16:                               # %abla_fn_140136229_158123167_direct.exit
	bltu	a8, a7, .LBB185_12
	j	.LBB185_18
.LBB185_17:                             # %source.label24.i
	l32i	a9, a10, 16
	add	a8, a9, a8
	bltu	a3, a8, .LBB185_12
.LBB185_18:
	movi	a2, 0
	retw.n
.Lfunc_end185:
	.size	abla_fn_563991449_691852434_direct, .Lfunc_end185-abla_fn_563991449_691852434_direct
                                        # -- End function
	.literal_position
	.literal .LCPI186_0, abla_fn_795904359_267395915_direct
	.section	.text.abla_fn_563991449_691852434_direct,"ax",@progbits
	.section	.text.abla_fn_526172849_945061129_direct,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_526172849_945061129_direct
	.type	abla_fn_526172849_945061129_direct,@function
abla_fn_526172849_945061129_direct:     # @abla_fn_526172849_945061129_direct
# %bb.0:                                # %entry
	entry	a1, 32
	l32r	a8, .LCPI186_0
	callx8	a8
	call8	abla_fn_928611835_706970686_direct
	s32i	a10, a2, 12
	movi	a2, 0
	retw.n
.Lfunc_end186:
	.size	abla_fn_526172849_945061129_direct, .Lfunc_end186-abla_fn_526172849_945061129_direct
                                        # -- End function
	.literal_position
	.literal .LCPI187_0, abla_fn_321888515_252845378_direct
	.section	.text.abla_fn_526172849_945061129_direct,"ax",@progbits
	.section	.text.abla_fn_986977340_555538594_direct,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_986977340_555538594_direct
	.type	abla_fn_986977340_555538594_direct,@function
abla_fn_986977340_555538594_direct:     # @abla_fn_986977340_555538594_direct
# %bb.0:                                # %entry
	entry	a1, 32
	s32i	a3, a2, 16
	l32r	a8, .LCPI187_0
	callx8	a8
	movi	a2, 0
	retw.n
.Lfunc_end187:
	.size	abla_fn_986977340_555538594_direct, .Lfunc_end187-abla_fn_986977340_555538594_direct
                                        # -- End function
	.literal_position
	.literal .LCPI188_0, abla_static_abla_fn_627837887_633683867_124
	.literal .LCPI188_1, -1287651329
	.literal .LCPI188_2, abla_static_abla_fn_627837887_633683867_3629
	.literal .LCPI188_3, abla_static_abla_fn_627837887_633683867_118.0
	.literal .LCPI188_4, .Labla_string_abla_fn_627837887_633683867_3725.native.mutable.u32s
	.literal .LCPI188_5, .Labla_string_abla_fn_627837887_633683867_3669.native.mutable.u32s
	.literal .LCPI188_6, abla_static_abla_fn_627837887_633683867_3709
	.literal .LCPI188_7, 4097
	.literal .LCPI188_8, 1072963584
	.literal .LCPI188_9, .Labla_string_abla_fn_627837887_633683867_1675.native.mutable.u32s
	.literal .LCPI188_10, 13123606
	.literal .LCPI188_11, 4194304
	.literal .LCPI188_12, .Labla_string_abla_fn_627837887_633683867_3951.native.mutable.u32s
	.literal .LCPI188_13, abla_static_abla_fn_627837887_633683867_3703.0
	.literal .LCPI188_14, 1073406578
	.section	.text.abla_fn_986977340_555538594_direct,"ax",@progbits
	.section	.text.abla_fn_300212323_608936396_direct,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_300212323_608936396_direct
	.type	abla_fn_300212323_608936396_direct,@function
abla_fn_300212323_608936396_direct:     # @abla_fn_300212323_608936396_direct
# %bb.0:                                # %entry
	entry	a1, 32
	l32r	a9, .LCPI188_0
	movi	a8, 0
	memw
	s32i	a8, a9, 0
	memw
	s32i	a9, a9, 4
	memw
	s32i	a8, a9, 8
	memw
	s32i	a8, a9, 12
	memw
	s32i	a8, a9, 16
	addi	a10, a9, 24
	memw
	s32i	a10, a9, 20
	movi	a11, -1
	memw
	s32i	a11, a9, 24
	memw
	s32i	a10, a9, 28
	memw
	s32i	a10, a9, 32
	memw
	s32i	a8, a9, 36
	addi	a10, a9, 44
	memw
	s32i	a10, a9, 40
	memw
	s32i	a11, a9, 44
	memw
	s32i	a10, a9, 48
	memw
	s32i	a10, a9, 52
	movi	a6, 1
	memw
	s32i	a6, a9, 56
	memw
	s32i	a6, a9, 60
	memw
	s32i	a8, a9, 64
	memw
	s32i	a8, a9, 72
	l32r	a10, .LCPI188_1
	memw
	s32i	a10, a9, 76
	s8i	a6, a9, 68
	memw
	s32i	a8, a9, 80
	memw
	l32r	a9, .LCPI188_2
	s32i	a8, a9, 16
	s32i	a8, a9, 12
	s32i	a8, a9, 8
	s32i	a8, a9, 4
	s32i	a8, a9, 0
	l32r	a8, .LCPI188_3
	s8i	a6, a8, 0
	l32r	a5, .LCPI188_4
	s32i	a9, a5, 12
	l32r	a8, .LCPI188_5
	s32i	a8, a5, 8
	l32r	a7, .LCPI188_6
	or	a10, a7, a7
	movi	a11, 0
	movi	a12, 48
	call8	abla_fn_853840267_528021067_direct
	movi	a8, 40
	s32i	a8, a7, 40
	l32r	a8, .LCPI188_7
	s32i	a8, a7, 16
	s8i	a6, a7, 14
	l32r	a8, .LCPI188_8
	s32i	a8, a7, 4
	l32r	a8, .LCPI188_9
	s32i	a8, a7, 0
	l32r	a8, .LCPI188_10
	s32i	a8, a5, 24
	l32r	a8, .LCPI188_11
	s32i	a8, a5, 20
	l32r	a8, .LCPI188_12
	s32i	a8, a5, 4
	s32i	a7, a5, 0
	l32r	a8, .LCPI188_13
	s8i	a6, a8, 0
	memw
	l32r	a8, .LCPI188_14
	memw
	l16ui	a8, a8, 0
	movi	a2, 0
	retw.n
.Lfunc_end188:
	.size	abla_fn_300212323_608936396_direct, .Lfunc_end188-abla_fn_300212323_608936396_direct
                                        # -- End function
	.section	.text.abla_fn_770005555_678222947_direct,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_770005555_678222947_direct
	.type	abla_fn_770005555_678222947_direct,@function
abla_fn_770005555_678222947_direct:     # @abla_fn_770005555_678222947_direct
# %bb.0:                                # %entry
	entry	a1, 96
	movi	a8, 0
	s32i	a8, a1, 0
	movi	a8, 4
	addi	a6, a1, 0
	or	a7, a6, a8
	or	a10, a7, a7
	movi	a11, 0
	movi	a12, 28
	call8	abla_fn_853840267_528021067_direct
	s16i	a3, a1, 24
	s32i	a6, a1, 16
	movi	a8, 1
	s8i	a8, a1, 6
	l32i	a10, a2, 0
	l32i	a8, a10, 0
	l32i	a8, a8, 4
	or	a11, a7, a7
	callx8	a8
	l32i	a8, a1, 0
	s32i	a8, a4, 0
	or	a2, a10, a10
	retw.n
.Lfunc_end189:
	.size	abla_fn_770005555_678222947_direct, .Lfunc_end189-abla_fn_770005555_678222947_direct
                                        # -- End function
	.section	.text.abla_fn_501841392_527998006_direct,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_501841392_527998006_direct
	.type	abla_fn_501841392_527998006_direct,@function
abla_fn_501841392_527998006_direct:     # @abla_fn_501841392_527998006_direct
# %bb.0:                                # %entry
	entry	a1, 112
	s32i	a5, a1, 32
	addi	a7, a1, 0
	or	a10, a7, a7
	movi	a11, 0
	movi	a12, 28
	call8	abla_fn_853840267_528021067_direct
	s16i	a3, a1, 20
	addi	a8, a7, 32
	s32i	a8, a1, 8
	srli	a8, a4, 3
	s8i	a8, a1, 1
	l32i	a10, a2, 0
	l32i	a8, a10, 0
	l32i	a8, a8, 4
	or	a11, a7, a7
	callx8	a8
	or	a2, a10, a10
	retw.n
.Lfunc_end190:
	.size	abla_fn_501841392_527998006_direct, .Lfunc_end190-abla_fn_501841392_527998006_direct
                                        # -- End function
	.section	.text.abla_fn_415918908_162849687_direct,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_415918908_162849687_direct
	.type	abla_fn_415918908_162849687_direct,@function
abla_fn_415918908_162849687_direct:     # @abla_fn_415918908_162849687_direct
# %bb.0:                                # %entry
	entry	a1, 96
	addi	a7, a1, 0
	or	a10, a7, a7
	movi	a11, 0
	movi	a12, 28
	call8	abla_fn_853840267_528021067_direct
	movi	a8, 102
	s16i	a8, a1, 20
	l32i	a10, a2, 0
	l32i	a8, a10, 0
	l32i	a8, a8, 4
	or	a11, a7, a7
	callx8	a8
	bnez	a10, .LBB191_3
# %bb.1:                                # %source.label
	addi	a7, a1, 0
	or	a10, a7, a7
	movi	a11, 0
	movi	a12, 28
	call8	abla_fn_853840267_528021067_direct
	movi	a8, 153
	s16i	a8, a1, 20
	l32i	a10, a2, 0
	l32i	a8, a10, 0
	l32i	a8, a8, 4
	or	a11, a7, a7
	callx8	a8
	bnez.n	a10, .LBB191_3
# %bb.2:                                # %source.label18
	l32i	a8, a2, 4
	l32i	a9, a8, 84
	l32i	a8, a8, 4
	l32i	a11, a8, 0
	or	a10, a2, a2
	movi	a12, 28
	movi	a13, 0
	movi	a14, 0
	movi	a15, 0
	callx8	a9
.LBB191_3:                              # %source.label22
	or	a2, a10, a10
	retw.n
.Lfunc_end191:
	.size	abla_fn_415918908_162849687_direct, .Lfunc_end191-abla_fn_415918908_162849687_direct
                                        # -- End function
	.section	.text.abla_fn_746975339_875058026_direct,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_746975339_875058026_direct
	.type	abla_fn_746975339_875058026_direct,@function
abla_fn_746975339_875058026_direct:     # @abla_fn_746975339_875058026_direct
# %bb.0:                                # %entry
	entry	a1, 32
	l32i	a8, a2, 4
	l32i	a8, a8, 44
	movi	a7, 0
	or	a10, a2, a2
	movi	a11, 0
	movi	a12, 0
	movi	a13, 0
	movi	a14, 0
	movi	a15, 0
	callx8	a8
	or	a6, a10, a10
	bnez.n	a6, .LBB192_2
# %bb.1:                                # %source.label
	l32i	a8, a2, 4
	l32i	a9, a8, 84
	l32i	a8, a8, 4
	l32i	a7, a8, 0
	or	a10, a2, a2
	or	a11, a7, a7
	movi	a12, 0
	movi	a13, 0
	movi	a14, 0
	movi	a15, 0
	callx8	a9
	or	a6, a10, a10
.LBB192_2:                              # %source.label17
	movi	a8, -262
	add	a8, a6, a8
	#APP
	nsau	a8, a8
	#NO_APP
	#APP
	nsau	a9, a6
	#NO_APP
	or	a8, a8, a9
	bgeui	a8, 32, .LBB192_3
	j	.LBB192_9
.LBB192_3:                              # %source.label18
	l32i	a8, a2, 8
	l32i	a8, a8, 36
	beqz.n	a8, .LBB192_5
# %bb.4:                                # %source.label19
	movi	a10, 1
	or	a11, a7, a7
	movi	a12, 0
	movi	a13, 0
	movi	a14, 0
	movi	a15, 0
	callx8	a8
.LBB192_5:                              # %source.label21
	l32i	a10, a2, 0
	l32i	a8, a10, 0
	l32i	a8, a8, 12
	or	a11, a7, a7
	movi	a12, 0
	movi	a13, 0
	movi	a14, 0
	movi	a15, 0
	callx8	a8
	l32i	a8, a2, 28
	movi	a9, 1
	or	a8, a8, a9
	s32i	a8, a2, 28
	l32i	a8, a2, 4
	l32i	a9, a8, 84
	l32i	a8, a8, 4
	l32i	a7, a8, 4
	or	a10, a2, a2
	or	a11, a7, a7
	callx8	a9
	or	a6, a10, a10
	l32i	a8, a2, 8
	l32i	a8, a8, 36
	beqz.n	a8, .LBB192_7
# %bb.6:                                # %source.label22
	movi	a10, 0
	or	a11, a7, a7
	movi	a12, 0
	movi	a13, 0
	movi	a14, 0
	movi	a15, 0
	callx8	a8
.LBB192_7:                              # %source.label24
	movi	a8, 262
	bne	a6, a8, .LBB192_9
# %bb.8:                                # %source.label25
	l32i	a8, a2, 4
	l32i	a8, a8, 44
	or	a10, a2, a2
	movi	a11, 1
	movi	a12, 0
	movi	a13, 0
	movi	a14, 0
	movi	a15, 0
	callx8	a8
	or	a6, a10, a10
.LBB192_9:                              # %source.label29
	or	a2, a6, a6
	retw.n
.Lfunc_end192:
	.size	abla_fn_746975339_875058026_direct, .Lfunc_end192-abla_fn_746975339_875058026_direct
                                        # -- End function
	.section	.text.abla_fn_87105386_416578553_direct,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_87105386_416578553_direct
	.type	abla_fn_87105386_416578553_direct,@function
abla_fn_87105386_416578553_direct:      # @abla_fn_87105386_416578553_direct
# %bb.0:                                # %entry
	entry	a1, 80
	l32i	a8, a2, 4
	l32i	a9, a8, 84
	l32i	a8, a8, 4
	l32i	a11, a8, 0
	movi	a6, 0
	or	a10, a2, a2
	movi	a12, 0
	movi	a13, 0
	movi	a14, 0
	movi	a15, 0
	callx8	a9
	#APP
	nsau	a8, a10
	#NO_APP
	movi	a9, -262
	add	a9, a10, a9
	#APP
	nsau	a9, a9
	#NO_APP
	or	a8, a9, a8
	extui	a7, a3, 0, 8
	bltui	a8, 32, .LBB193_2
# %bb.1:                                # %source.label
	l32i	a10, a2, 0
	l32i	a8, a10, 0
	l32i	a8, a8, 28
	or	a11, a7, a7
	movi	a12, 0
	movi	a13, 0
	movi	a14, 0
	movi	a15, 0
	callx8	a8
.LBB193_2:                              # %source.label18
	l32i	a8, a2, 4
	l32i	a8, a8, 40
	addi	a11, a1, 0
	or	a10, a2, a2
	movi	a12, 0
	movi	a13, 0
	movi	a14, 0
	movi	a15, 0
	callx8	a8
	l8ui	a8, a1, 0
	movi	a2, 0
	bne	a8, a7, .LBB193_5
# %bb.3:                                # %source.label18
	bne	a10, a6, .LBB193_6
.LBB193_4:                              # %source.label18
	retw.n
.LBB193_5:                              # %source.label18
	movi	a2, 261
	beq	a10, a6, .LBB193_4
.LBB193_6:                              # %source.label18
	or	a2, a10, a10
	retw.n
.Lfunc_end193:
	.size	abla_fn_87105386_416578553_direct, .Lfunc_end193-abla_fn_87105386_416578553_direct
                                        # -- End function
	.section	.text.abla_fn_526680780_930051525_direct,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_526680780_930051525_direct
	.type	abla_fn_526680780_930051525_direct,@function
abla_fn_526680780_930051525_direct:     # @abla_fn_526680780_930051525_direct
# %bb.0:                                # %entry
	entry	a1, 32
	or	a11, a4, a4
	l32i	a10, a2, 0
	l32i	a8, a10, 0
	l32i	a8, a8, 24
	callx8	a8
	or	a2, a10, a10
	retw.n
.Lfunc_end194:
	.size	abla_fn_526680780_930051525_direct, .Lfunc_end194-abla_fn_526680780_930051525_direct
                                        # -- End function
	.section	.text.abla_fn_179040964_268748625_direct,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_179040964_268748625_direct
	.type	abla_fn_179040964_268748625_direct,@function
abla_fn_179040964_268748625_direct:     # @abla_fn_179040964_268748625_direct
# %bb.0:                                # %entry
	entry	a1, 96
	addi	a9, a3, 1
	movi	a8, 1
	movi	a10, 0
	movi	a11, 1
	beq	a9, a10, .LBB195_2
# %bb.1:                                # %entry
	movi	a11, 0
.LBB195_2:                              # %entry
	bne	a11, a10, .LBB195_4
# %bb.3:                                # %entry
	or	a8, a9, a9
.LBB195_4:                              # %entry
	movi	a4, 17
	movi	a7, 0
	movi	a6, 0
	movi	a12, 0
	movi	a9, 17
.LBB195_5:                              # %source.label22
                                        # =>This Loop Header: Depth=1
                                        #     Child Loop BB195_8 Depth 2
                                        #       Child Loop BB195_9 Depth 3
	or	a5, a8, a8
	extui	a8, a9, 0, 5
	beq	a8, a4, .LBB195_6
	j	.LBB195_20
.LBB195_6:                              # %source.label23
                                        #   in Loop: Header=BB195_5 Depth=1
	movi	a9, 18
	movi	a8, 0
	beqz	a5, .LBB195_5
# %bb.7:                                # %source.label26.outer.preheader
                                        #   in Loop: Header=BB195_5 Depth=1
	s32i	a3, a1, 12                      # 4-byte Folded Spill
.LBB195_8:                              # %source.label26.outer
                                        #   Parent Loop BB195_5 Depth=1
                                        # =>  This Loop Header: Depth=2
                                        #       Child Loop BB195_9 Depth 3
	movi	a3, 1
.LBB195_9:                              # %source.label26
                                        #   Parent Loop BB195_5 Depth=1
                                        #     Parent Loop BB195_8 Depth=2
                                        # =>    This Inner Loop Header: Depth=3
	bbci	a3, 0, .LBB195_14
# %bb.10:                               # %source.label27
                                        #   in Loop: Header=BB195_9 Depth=3
	l32i	a10, a2, 0
	l32i	a8, a10, 0
	l32i	a8, a8, 56
	movi	a3, 0
	or	a11, a7, a7
	or	a12, a6, a6
	movi	a13, 0
	movi	a14, 0
	movi	a15, 0
	callx8	a8
	bnez	a10, .LBB195_9
# %bb.11:                               # %source.label29
                                        #   in Loop: Header=BB195_9 Depth=3
	beqz	a5, .LBB195_9
# %bb.12:                               # %source.label29
                                        #   in Loop: Header=BB195_9 Depth=3
	movi	a3, 1
	beqi	a5, 1, .LBB195_9
# %bb.13:                               # %source.label35
                                        #   in Loop: Header=BB195_8 Depth=2
	l32i	a10, a2, 12
	l32i	a8, a2, 8
	l32i	a8, a8, 12
	movi	a7, 1
	movi	a11, 1
	or	a12, a6, a6
	movi	a13, 0
	movi	a14, 0
	movi	a15, 0
	callx8	a8
	addi	a5, a5, -1
	j	.LBB195_8
.LBB195_14:                             # %source.label41
                                        #   in Loop: Header=BB195_5 Depth=1
	l32i	a8, a2, 4
	l32i	a3, a8, 100
	movi	a7, 1
	addi	a6, a1, 16
	or	a10, a2, a2
	movi	a11, 1
	or	a12, a6, a6
	movi	a13, 0
	movi	a14, 0
	movi	a15, 0
	callx8	a3
	or	a12, a3, a3
	movi	a9, 21
	or	a8, a5, a5
	l32i	a3, a1, 12                      # 4-byte Folded Reload
	movi	a11, 20
	bnez	a10, .LBB195_5
# %bb.15:                               # %source.label43
                                        #   in Loop: Header=BB195_5 Depth=1
	movi	a9, 10
	movi	a10, 0
	l32i	a12, a1, 16
	addi	a6, a1, 16
	or	a8, a5, a5
	bbsi	a12, 0, .LBB195_16
	j	.LBB195_5
.LBB195_16:                             # %source.label44
                                        #   in Loop: Header=BB195_5 Depth=1
	addi	a6, a1, 16
	movi	a8, 0
	movi	a9, 17
	beqz	a5, .LBB195_5
# %bb.17:                               # %source.label45
                                        #   in Loop: Header=BB195_5 Depth=1
	minu	a7, a5, a11
	l32i	a10, a2, 12
	l32i	a8, a2, 8
	l32i	a8, a8, 12
	addi	a6, a1, 16
	or	a11, a7, a7
	or	a12, a6, a6
	movi	a13, 0
	movi	a14, 0
	movi	a15, 0
	s32i	a8, a1, 8                       # 4-byte Folded Spill
	callx8	a8
	movi	a9, 0
	movi	a8, -1
	l32i	a3, a1, 12                      # 4-byte Folded Reload
	beq	a3, a8, .LBB195_19
# %bb.18:                               # %source.label45
                                        #   in Loop: Header=BB195_5 Depth=1
	or	a9, a7, a7
.LBB195_19:                             # %source.label45
                                        #   in Loop: Header=BB195_5 Depth=1
	sub	a8, a5, a9
	movi	a9, 17
	l32i	a12, a1, 8                      # 4-byte Folded Reload
	j	.LBB195_5
.LBB195_20:                             # %source.label22
	beqi	a8, 10, .LBB195_22
# %bb.21:                               # %source.label22
	movi	a9, 18
	beq	a8, a9, .LBB195_24
	j	.LBB195_26
.LBB195_22:                             # %source.label61
	extui	a9, a10, 0, 5
	l32i	a8, a2, 28
	ssr	a9
	srl	a9, a8
	bbci	a9, 0, .LBB195_24
# %bb.23:                               # %source.label66
	movi	a9, -2
	and	a8, a8, a9
	s32i	a8, a2, 28
	movi	a10, 262
	bbsi	a12, 1, .LBB195_26
.LBB195_24:                             # %source.label67
	movi	a10, 263
	movi	a8, 0
	beq	a5, a8, .LBB195_26
# %bb.25:                               # %source.label67
	movi	a10, 0
.LBB195_26:                             # %source.label81
	or	a2, a10, a10
	retw.n
.Lfunc_end195:
	.size	abla_fn_179040964_268748625_direct, .Lfunc_end195-abla_fn_179040964_268748625_direct
                                        # -- End function
	.literal_position
	.literal .LCPI196_0, 24579
	.literal .LCPI196_1, .Labla_string_abla_fn_627837887_633683867_3762.native.mutable.bytes
	.literal .LCPI196_2, .Labla_string_abla_fn_627837887_633683867_3769.native.mutable.bytes
	.literal .LCPI196_3, -2147483648
	.section	.text.abla_fn_179040964_268748625_direct,"ax",@progbits
	.section	.text.abla_fn_994348769_172344277_direct,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_994348769_172344277_direct
	.type	abla_fn_994348769_172344277_direct,@function
abla_fn_994348769_172344277_direct:     # @abla_fn_994348769_172344277_direct
# %bb.0:                                # %entry
	entry	a1, 32
	extui	a8, a3, 0, 1
	l32i	a14, a2, 16
	extui	a9, a14, 0, 16
	bnei	a9, 3, .LBB196_5
# %bb.1:                                # %source.label
	movi	a12, 24
	movi	a9, 0
	beq	a8, a9, .LBB196_3
# %bb.2:                                # %source.label
	movi	a12, 32
.LBB196_3:                              # %source.label
	movi	a10, 187
	add	a11, a8, a10
	l32r	a8, .LCPI196_3
	or	a14, a14, a8
	l32i	a8, a2, 28
	movi	a10, 2
	and	a8, a8, a10
	beq	a8, a9, .LBB196_12
# %bb.4:                                # %source.label
	l32r	a8, .LCPI196_1
	j	.LBB196_46
.LBB196_5:                              # %source.label25
	bltui	a9, 4, .LBB196_13
# %bb.6:                                # %source.label26
	beqi	a9, 5, .LBB196_23
# %bb.7:                                # %source.label26
	bnei	a9, 4, .LBB196_22
# %bb.8:                                # %source.label27
	movi	a12, 24
	movi	a9, 0
	beq	a8, a9, .LBB196_10
# %bb.9:                                # %source.label27
	movi	a12, 32
.LBB196_10:                             # %source.label27
	l32i	a10, a2, 28
	movi	a11, 2
	and	a10, a10, a11
	bne	a10, a9, .LBB196_11
	j	.LBB196_35
.LBB196_11:                             # %source.label27
	l32r	a9, .LCPI196_1
	j	.LBB196_36
.LBB196_12:
	l32r	a8, .LCPI196_2
	j	.LBB196_46
.LBB196_13:                             # %source.label51
	beqi	a9, 2, .LBB196_31
# %bb.14:                               # %source.label51
	beqi	a9, 1, .LBB196_27
# %bb.15:                               # %source.label51
	bnez.n	a9, .LBB196_22
# %bb.16:                               # %source.label54
	movi	a11, 3
	movi	a9, 0
	beq	a8, a9, .LBB196_18
# %bb.17:                               # %source.label54
	movi	a11, 19
.LBB196_18:                             # %source.label54
	movi	a12, 24
	beq	a8, a9, .LBB196_20
# %bb.19:                               # %source.label54
	movi	a12, 32
.LBB196_20:                             # %source.label54
	l32i	a8, a2, 28
	movi	a10, 2
	and	a8, a8, a10
	bne	a8, a9, .LBB196_21
	j	.LBB196_44
.LBB196_21:                             # %source.label54
	l32r	a8, .LCPI196_1
	j	.LBB196_45
.LBB196_22:
	l32r	a2, .LCPI196_0
	retw.n
.LBB196_23:                             # %source.label38
	movi	a12, 24
	movi	a9, 0
	beq	a8, a9, .LBB196_25
# %bb.24:                               # %source.label38
	movi	a12, 32
.LBB196_25:                             # %source.label38
	movi	a10, 235
	add	a11, a8, a10
	l32r	a8, .LCPI196_3
	or	a14, a14, a8
	l32i	a8, a2, 28
	movi	a10, 2
	and	a8, a8, a10
	beq	a8, a9, .LBB196_37
# %bb.26:                               # %source.label38
	l32r	a8, .LCPI196_1
	j	.LBB196_38
.LBB196_27:                             # %source.label77
	movi	a12, 24
	movi	a9, 0
	beq	a8, a9, .LBB196_29
# %bb.28:                               # %source.label77
	movi	a12, 32
.LBB196_29:                             # %source.label77
	l32i	a10, a2, 28
	movi	a11, 2
	and	a10, a10, a11
	beq	a10, a9, .LBB196_39
# %bb.30:                               # %source.label77
	l32r	a9, .LCPI196_1
	j	.LBB196_40
.LBB196_31:                             # %source.label66
	movi	a12, 24
	movi	a9, 0
	beq	a8, a9, .LBB196_33
# %bb.32:                               # %source.label66
	movi	a12, 32
.LBB196_33:                             # %source.label66
	l32i	a10, a2, 28
	movi	a11, 2
	and	a10, a10, a11
	beq	a10, a9, .LBB196_41
# %bb.34:                               # %source.label66
	l32r	a9, .LCPI196_1
	j	.LBB196_42
.LBB196_35:
	l32r	a9, .LCPI196_2
.LBB196_36:                             # %source.label27
	addi	a9, a9, 2
	l8ui	a13, a9, 0
	l32i	a10, a2, 0
	l32i	a9, a10, 0
	l32i	a9, a9, 60
	addi	a11, a8, 107
	j	.LBB196_43
.LBB196_37:
	l32r	a8, .LCPI196_2
.LBB196_38:                             # %source.label38
	addi	a8, a8, 1
	j	.LBB196_46
.LBB196_39:
	l32r	a9, .LCPI196_2
.LBB196_40:                             # %source.label77
	addi	a9, a9, 4
	l8ui	a13, a9, 0
	l32i	a10, a2, 0
	l32i	a9, a10, 0
	l32i	a9, a9, 60
	addi	a11, a8, 11
	j	.LBB196_43
.LBB196_41:
	l32r	a9, .LCPI196_2
.LBB196_42:                             # %source.label66
	addi	a9, a9, 3
	l8ui	a13, a9, 0
	l32i	a10, a2, 0
	l32i	a9, a10, 0
	l32i	a9, a9, 60
	addi	a11, a8, 59
.LBB196_43:                             # %source.label89
	movi	a15, 0
	callx8	a9
	j	.LBB196_47
.LBB196_44:
	l32r	a8, .LCPI196_2
.LBB196_45:                             # %source.label54
	addi	a8, a8, 5
.LBB196_46:                             # %source.label
	l8ui	a13, a8, 0
	l32i	a10, a2, 0
	l32i	a8, a10, 0
	l32i	a8, a8, 60
	movi	a15, 0
	callx8	a8
.LBB196_47:                             # %source.label89
	or	a2, a10, a10
	retw.n
.Lfunc_end196:
	.size	abla_fn_994348769_172344277_direct, .Lfunc_end196-abla_fn_994348769_172344277_direct
                                        # -- End function
	.literal_position
	.literal .LCPI197_0, abla_static_abla_fn_627837887_633683867_3703.0
	.literal .LCPI197_1, .Labla_string_abla_fn_627837887_633683867_3725.native.mutable.u32s
	.literal .LCPI197_2, .Labla_string_abla_fn_627837887_633683867_3838.native.mutable.u32s
	.section	.text.abla_fn_994348769_172344277_direct,"ax",@progbits
	.section	.text.abla_fn_500878493_387552107_direct,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_500878493_387552107_direct
	.type	abla_fn_500878493_387552107_direct,@function
abla_fn_500878493_387552107_direct:     # @abla_fn_500878493_387552107_direct
# %bb.0:                                # %entry
	entry	a1, 64
	or	a10, a4, a4
	or	a6, a2, a2
	l32r	a8, .LCPI197_0
	l8ui	a9, a8, 0
	movi	a8, 0
	beq	a9, a8, .LBB197_2
# %bb.1:
	l32r	a8, .LCPI197_1
.LBB197_2:                              # %entry
	movi	a2, 262
	beq	a8, a6, .LBB197_3
	j	.LBB197_21
.LBB197_3:                              # %source.label
	l32r	a7, .LCPI197_2
	l32i	a8, a7, 20
	movi	a4, 0
	s32i	a10, a1, 16                     # 4-byte Folded Spill
	or	a11, a5, a5
	movi	a12, 0
	movi	a13, 0
	movi	a14, 0
	movi	a15, 0
	callx8	a8
	beqz	a10, .LBB197_21
# %bb.4:                                # %source.label17
	s32i	a3, a1, 12                      # 4-byte Folded Spill
	l32i	a8, a7, 0
	or	a11, a5, a5
	movi	a12, 0
	movi	a13, 0
	movi	a14, 0
	movi	a15, 0
	callx8	a8
	movi	a13, 0
	or	a7, a5, a5
.LBB197_5:                              # %source.label19.outer.outer.outer
                                        # =>This Loop Header: Depth=1
                                        #     Child Loop BB197_6 Depth 2
                                        #       Child Loop BB197_7 Depth 3
	l32i	a14, a1, 16                     # 4-byte Folded Reload
	extui	a9, a14, 0, 5
	extui	a11, a14, 0, 6
	movi	a2, 0
	movi	a3, 0
	or	a12, a4, a4
.LBB197_6:                              # %source.label19.outer
                                        #   Parent Loop BB197_5 Depth=1
                                        # =>  This Loop Header: Depth=2
                                        #       Child Loop BB197_7 Depth 3
	or	a8, a7, a7
.LBB197_7:                              # %source.label19
                                        #   Parent Loop BB197_5 Depth=1
                                        #     Parent Loop BB197_6 Depth=2
                                        # =>    This Inner Loop Header: Depth=3
	or	a7, a8, a8
	extui	a8, a3, 0, 3
	bnez	a8, .LBB197_19
# %bb.8:                                # %source.label20
                                        #   in Loop: Header=BB197_7 Depth=3
	movi	a3, 1
	movi	a8, 0
	beqz	a7, .LBB197_7
# %bb.9:                                # %source.label21
                                        #   in Loop: Header=BB197_6 Depth=2
	beqz.n	a11, .LBB197_11
# %bb.10:                               # %source.label22
                                        #   in Loop: Header=BB197_6 Depth=2
	movi	a10, 16
	beqz.n	a9, .LBB197_13
	j	.LBB197_15
.LBB197_11:                             # %source.label29
                                        #   in Loop: Header=BB197_6 Depth=2
	movi	a10, 64
	movi	a8, 63
	bltu	a8, a7, .LBB197_15
# %bb.12:                               # %source.label33
                                        #   in Loop: Header=BB197_6 Depth=2
	movi	a10, 16
.LBB197_13:                             # %source.label33
                                        #   in Loop: Header=BB197_6 Depth=2
	movi	a8, 32
	bltu	a7, a8, .LBB197_15
# %bb.14:                               # %source.label33
                                        #   in Loop: Header=BB197_6 Depth=2
	movi	a10, 32
.LBB197_15:                             # %source.label39
                                        #   in Loop: Header=BB197_6 Depth=2
	s32i	a10, a1, 8                      # 4-byte Folded Spill
	l32r	a8, .LCPI197_2
	l32i	a8, a8, 8
	movi	a5, 0
	or	a10, a14, a14
	s32i	a11, a1, 0                      # 4-byte Folded Spill
	l32i	a11, a1, 12                     # 4-byte Folded Reload
	l32i	a12, a1, 8                      # 4-byte Folded Reload
	or	a3, a13, a13
	movi	a14, 0
	movi	a15, 0
	s32i	a9, a1, 4                       # 4-byte Folded Spill
	callx8	a8
	l32i	a8, a6, 4
	l32i	a8, a8, 44
	or	a10, a6, a6
	movi	a11, 0
	callx8	a8
	l32i	a14, a1, 16                     # 4-byte Folded Reload
	or	a13, a3, a3
	l32i	a12, a1, 8                      # 4-byte Folded Reload
	l32i	a11, a1, 0                      # 4-byte Folded Reload
	l32i	a9, a1, 4                       # 4-byte Folded Reload
	movi	a3, 4
	or	a2, a10, a10
	bnez	a10, .LBB197_6
# %bb.16:                               # %source.label41
                                        #   in Loop: Header=BB197_6 Depth=2
	l32r	a8, .LCPI197_2
	l32i	a8, a8, 12
	movi	a10, 0
	movi	a11, 0
	movi	a14, 0
	movi	a15, 0
	callx8	a8
	l32i	a8, a6, 4
	l32i	a8, a8, 68
	or	a10, a6, a6
	l32i	a5, a1, 12                      # 4-byte Folded Reload
	or	a11, a5, a5
	l32i	a12, a1, 16                     # 4-byte Folded Reload
	or	a13, a7, a7
	callx8	a8
	l32i	a14, a1, 16                     # 4-byte Folded Reload
	l32i	a11, a1, 0                      # 4-byte Folded Reload
	l32i	a9, a1, 4                       # 4-byte Folded Reload
	movi	a3, 4
	or	a12, a14, a14
	or	a13, a7, a7
	or	a2, a10, a10
	bnez	a10, .LBB197_6
# %bb.17:                               # %source.label43
                                        #   in Loop: Header=BB197_6 Depth=2
	l32i	a8, a6, 4
	l32i	a9, a8, 84
	l32i	a8, a8, 4
	l32i	a5, a8, 16
	or	a10, a6, a6
	or	a11, a5, a5
	or	a12, a14, a14
	or	a13, a7, a7
	movi	a14, 0
	movi	a15, 0
	callx8	a9
	l32i	a14, a1, 16                     # 4-byte Folded Reload
	l32i	a11, a1, 0                      # 4-byte Folded Reload
	l32i	a9, a1, 4                       # 4-byte Folded Reload
	or	a12, a14, a14
	or	a13, a7, a7
	or	a2, a10, a10
	bnez	a10, .LBB197_6
# %bb.18:                               # %source.label45
                                        #   in Loop: Header=BB197_5 Depth=1
	l32r	a8, .LCPI197_2
	l32i	a8, a8, 16
	movi	a10, 0
	or	a11, a5, a5
	or	a12, a14, a14
	or	a13, a7, a7
	or	a4, a14, a14
	movi	a14, 0
	movi	a15, 0
	callx8	a8
	l32i	a11, a1, 8                      # 4-byte Folded Reload
	add	a8, a11, a4
	l32i	a9, a1, 12                      # 4-byte Folded Reload
	add	a9, a11, a9
	s32i	a9, a1, 12                      # 4-byte Folded Spill
	sub	a9, a7, a11
	or	a13, a7, a7
	or	a7, a9, a9
	s32i	a8, a1, 16                      # 4-byte Folded Spill
	j	.LBB197_5
.LBB197_19:                             # %source.label19
	bnei	a8, 1, .LBB197_21
# %bb.20:                               # %source.label52
	l32r	a8, .LCPI197_2
	l32i	a8, a8, 4
	or	a11, a5, a5
	movi	a14, 0
	movi	a15, 0
	callx8	a8
.LBB197_21:                             # %source.label57
	retw.n
.Lfunc_end197:
	.size	abla_fn_500878493_387552107_direct, .Lfunc_end197-abla_fn_500878493_387552107_direct
                                        # -- End function
	.literal_position
	.literal .LCPI198_0, 65280
	.section	.text.abla_fn_500878493_387552107_direct,"ax",@progbits
	.section	.text.abla_fn_691100501_817565095_direct,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_691100501_817565095_direct
	.type	abla_fn_691100501_817565095_direct,@function
abla_fn_691100501_817565095_direct:     # @abla_fn_691100501_817565095_direct
# %bb.0:                                # %entry
	entry	a1, 80
	movi	a8, 4
	addi	a9, a1, 0
	or	a7, a9, a8
	or	a10, a2, a2
	movi	a11, 53
	or	a12, a7, a7
	call8	abla_fn_770005555_678222947_direct
	bnez.n	a10, .LBB198_3
# %bb.1:                                # %source.label
	addi	a12, a1, 0
	or	a10, a2, a2
	movi	a11, 5
	call8	abla_fn_770005555_678222947_direct
	bnez.n	a10, .LBB198_3
# %bb.2:                                # %source.label17
	l32i	a8, a7, 0
	slli	a8, a8, 8
	l32r	a9, .LCPI198_0
	and	a8, a8, a9
	l8ui	a9, a1, 0
	or	a8, a8, a9
	s32i	a8, a3, 0
	movi	a10, 0
.LBB198_3:                              # %source.label21
	or	a2, a10, a10
	retw.n
.Lfunc_end198:
	.size	abla_fn_691100501_817565095_direct, .Lfunc_end198-abla_fn_691100501_817565095_direct
                                        # -- End function
	.section	.text.abla_fn_342000349_189405272_direct,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_342000349_189405272_direct
	.type	abla_fn_342000349_189405272_direct,@function
abla_fn_342000349_189405272_direct:     # @abla_fn_342000349_189405272_direct
# %bb.0:                                # %entry
	entry	a1, 32
	or	a13, a3, a3
	or	a10, a2, a2
	movi	a11, 1
	movi	a12, 16
	call8	abla_fn_501841392_527998006_direct
	or	a2, a10, a10
	retw.n
.Lfunc_end199:
	.size	abla_fn_342000349_189405272_direct, .Lfunc_end199-abla_fn_342000349_189405272_direct
                                        # -- End function
	.section	.text.abla_fn_311395512_176419446_direct,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_311395512_176419446_direct
	.type	abla_fn_311395512_176419446_direct,@function
abla_fn_311395512_176419446_direct:     # @abla_fn_311395512_176419446_direct
# %bb.0:                                # %entry
	entry	a1, 176
	or	a7, a4, a4
	s32i	a3, a1, 96
	l32i	a8, a2, 4
	l32i	a8, a8, 76
	s32i	a8, a1, 100
	movi	a8, 4
	addi	a9, a1, 16
	or	a3, a9, a8
	movi	a10, 0
.LBB200_1:                              # %source.label.outer.outer.outer
                                        # =>This Loop Header: Depth=1
                                        #     Child Loop BB200_2 Depth 2
                                        #       Child Loop BB200_3 Depth 3
	add	a8, a7, a3
	s32i	a8, a1, 8                       # 4-byte Folded Spill
	movi	a8, 1
.LBB200_2:                              # %source.label.outer.outer
                                        #   Parent Loop BB200_1 Depth=1
                                        # =>  This Loop Header: Depth=2
                                        #       Child Loop BB200_3 Depth 3
	add	a9, a7, a5
	s32i	a9, a1, 12                      # 4-byte Folded Spill
.LBB200_3:                              # %source.label
                                        #   Parent Loop BB200_1 Depth=1
                                        #     Parent Loop BB200_2 Depth=2
                                        # =>    This Inner Loop Header: Depth=3
	bbsi	a8, 0, .LBB200_4
	j	.LBB200_9
.LBB200_4:                              # %source.label23
                                        #   in Loop: Header=BB200_3 Depth=3
	movi	a8, 0
	bnez	a10, .LBB200_3
# %bb.5:                                # %source.label28
                                        #   in Loop: Header=BB200_3 Depth=3
	beqz	a5, .LBB200_7
# %bb.6:                                # %source.label29
                                        #   in Loop: Header=BB200_3 Depth=3
	or	a10, a3, a3
	movi	a11, 255
	movi	a12, 64
	call8	abla_fn_853840267_528021067_direct
	l32i	a10, a2, 0
	l32i	a8, a10, 0
	l32i	a8, a8, 40
	l32i	a6, a1, 100
	addi	a13, a1, 16
	or	a11, a7, a7
	or	a12, a5, a5
	or	a14, a6, a6
	callx8	a8
	s32i	a10, a1, 104
	l32i	a8, a1, 16
	add	a9, a8, a10
	l32i	a10, a1, 12                     # 4-byte Folded Reload
	minu	a4, a10, a9
	sub	a12, a4, a7
	s32i	a12, a1, 108
	l32i	a9, a1, 8                       # 4-byte Folded Reload
	sub	a10, a9, a8
	l32i	a11, a1, 96
	call8	abla_fn_334943840_569200394_direct
	l32i	a8, a2, 4
	l32i	a8, a8, 44
	or	a10, a2, a2
	movi	a11, 0
	callx8	a8
	#APP
	nsau	a9, a10
	#NO_APP
	movi	a8, 1
	bbci	a9, 5, .LBB200_3
	j	.LBB200_8
.LBB200_7:                              #   in Loop: Header=BB200_2 Depth=2
	movi	a10, 0
	movi	a5, 0
	j	.LBB200_2
.LBB200_8:                              # %source.label34
                                        #   in Loop: Header=BB200_1 Depth=1
	l32i	a8, a2, 4
	l32i	a8, a8, 72
	l32i	a12, a1, 16
	l32i	a13, a1, 104
	or	a10, a2, a2
	or	a11, a3, a3
	or	a14, a6, a6
	movi	a15, 0
	callx8	a8
	l32i	a8, a1, 96
	l32i	a9, a1, 108
	add	a8, a9, a8
	s32i	a8, a1, 96
	l32i	a8, a1, 12                      # 4-byte Folded Reload
	sub	a5, a8, a4
	or	a7, a4, a4
	j	.LBB200_1
.LBB200_9:                              # %source.label40
	or	a2, a10, a10
	retw.n
.Lfunc_end200:
	.size	abla_fn_311395512_176419446_direct, .Lfunc_end200-abla_fn_311395512_176419446_direct
                                        # -- End function
	.literal_position
	.literal .LCPI201_0, .Labla_string_abla_fn_627837887_633683867_3776.native.bytes
	.literal .LCPI201_1, .Labla_string_abla_fn_627837887_633683867_3755.native.bytes
	.section	.text.abla_fn_311395512_176419446_direct,"ax",@progbits
	.section	.text.abla_fn_265241106_404917902_direct,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_265241106_404917902_direct
	.type	abla_fn_265241106_404917902_direct,@function
abla_fn_265241106_404917902_direct:     # @abla_fn_265241106_404917902_direct
# %bb.0:                                # %entry
	entry	a1, 80
	beqz.n	a3, .LBB201_4
# %bb.1:                                # %source.label18
	l32i	a8, a2, 4
	l32i	a8, a8, 100
	addi	a12, a1, 0
	or	a10, a2, a2
	movi	a11, 1
	movi	a13, 0
	movi	a14, 0
	movi	a15, 0
	callx8	a8
	bnez.n	a10, .LBB201_3
# %bb.2:                                # %source.label19
	movi	a8, -1
	l8ui	a9, a1, 0
	xor	a8, a9, a8
	extui	a8, a8, 1, 1
	s8i	a8, a3, 0
.LBB201_3:                              # %source.label21
	or	a2, a10, a10
	retw.n
.LBB201_4:                              # %source.label
	l32r	a13, .LCPI201_0
	addi	a10, a13, 51
	l32r	a12, .LCPI201_1
	movi	a11, 386
	call8	abla_fn_343754787_547301002_direct
.Lfunc_end201:
	.size	abla_fn_265241106_404917902_direct, .Lfunc_end201-abla_fn_265241106_404917902_direct
                                        # -- End function
	.section	.text.abla_fn_491534404_387327923_direct,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_491534404_387327923_direct
	.type	abla_fn_491534404_387327923_direct,@function
abla_fn_491534404_387327923_direct:     # @abla_fn_491534404_387327923_direct
# %bb.0:                                # %entry
	entry	a1, 80
	or	a7, a2, a2
	l32i	a8, a7, 8
	l32i	a8, a8, 24
	beqz.n	a8, .LBB202_6
# %bb.1:                                # %source.label20
	movi	a11, 1
	movi	a2, 0
	bne	a3, a2, .LBB202_3
# %bb.2:                                # %source.label20
	movi	a11, 0
.LBB202_3:                              # %source.label20
	movi	a9, 4
	addi	a10, a1, 0
	or	a6, a10, a9
	l32i	a10, a7, 12
	or	a12, a6, a6
	movi	a13, 0
	movi	a14, 0
	movi	a15, 0
	callx8	a8
	beqz.n	a10, .LBB202_7
# %bb.4:                                # %source.label20
	movi	a8, 263
	bne	a10, a8, .LBB202_9
.LBB202_5:                              # %source.label30
	retw.n
.LBB202_6:
	movi	a2, 0
	retw.n
.LBB202_7:                              # %source.label25
	l8ui	a8, a6, 0
	bbci	a8, 0, .LBB202_5
# %bb.8:                                # %source.label26
	l32i	a10, a7, 12
	l32i	a8, a7, 8
	l32i	a8, a8, 28
	addi	a11, a1, 0
	or	a12, a6, a6
	movi	a13, 0
	movi	a14, 0
	movi	a15, 0
	callx8	a8
	or	a2, a10, a10
	retw.n
.LBB202_9:                              # %source.label22
	ill.n
.Lfunc_end202:
	.size	abla_fn_491534404_387327923_direct, .Lfunc_end202-abla_fn_491534404_387327923_direct
                                        # -- End function
	.literal_position
	.literal .LCPI203_0, 65280
	.literal .LCPI203_1, .Labla_string_abla_fn_627837887_633683867_3783.native.bytes
	.literal .LCPI203_2, .Labla_string_abla_fn_627837887_633683867_3748.native.bytes
	.section	.text.abla_fn_491534404_387327923_direct,"ax",@progbits
	.section	.text.abla_fn_838066626_846918671_direct,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_838066626_846918671_direct
	.type	abla_fn_838066626_846918671_direct,@function
abla_fn_838066626_846918671_direct:     # @abla_fn_838066626_846918671_direct
# %bb.0:                                # %entry
	entry	a1, 144
	movi	a5, 0
	s32i	a5, a1, 36
	s32i	a5, a1, 32
	movi	a4, 8
	addi	a6, a1, 32
	or	a7, a6, a4
	or	a10, a7, a7
	movi	a11, 0
	movi	a12, 28
	call8	abla_fn_853840267_528021067_direct
	movi	a8, 32
	s8i	a8, a1, 62
	movi	a8, 75
	s16i	a8, a1, 60
	s32i	a6, a1, 52
	s8i	a4, a1, 42
	l32i	a10, a2, 0
	l32i	a8, a10, 0
	l32i	a8, a8, 4
	or	a11, a7, a7
	callx8	a8
	movi	a11, 1
	l32i	a9, a1, 32
	beq	a9, a5, .LBB203_2
# %bb.1:                                # %entry
	movi	a11, 0
.LBB203_2:                              # %entry
	l32i	a8, a1, 36
	sub	a11, a8, a11
	bnei	a11, -1, .LBB203_4
# %bb.3:                                # %source.label32
	addi	a11, a9, -1
	movi	a12, -3
	bltu	a12, a11, .LBB203_6
.LBB203_4:                              # %source.label30
	srli	a11, a9, 8
	l32r	a12, .LCPI203_0
	and	a11, a11, a12
	extui	a13, a9, 24, 8
	or	a11, a11, a13
	and	a13, a9, a12
	slli	a13, a13, 8
	slli	a9, a9, 24
	or	a9, a9, a13
	or	a9, a9, a11
	srli	a11, a8, 8
	and	a11, a11, a12
	extui	a13, a8, 24, 8
	or	a11, a11, a13
	and	a12, a8, a12
	slli	a12, a12, 8
	slli	a8, a8, 24
	or	a8, a8, a12
	or	a8, a8, a11
.LBB203_5:                              # %source.label40
	s32i	a9, a3, 4
	s32i	a8, a3, 0
	or	a2, a10, a10
	retw.n
.LBB203_6:                              # %source.label36
	movi	a8, 4
	or	a6, a6, a8
	call8	abla_fn_11786425_863113934_direct
	or	a11, a10, a10
	l32i	a14, a6, 0
	l32i	a15, a7, 0
	l32i	a13, a1, 32
	l32i	a8, a1, 44
	l32i	a9, a1, 48
	l32i	a10, a1, 52
	l32i	a12, a1, 56
	l32i	a7, a1, 60
	l32i	a5, a1, 64
	l32i	a4, a1, 68
	s32i	a4, a1, 24
	s32i	a5, a1, 20
	s32i	a7, a1, 16
	s32i	a12, a1, 12
	s32i	a10, a1, 8
	s32i	a9, a1, 4
	s32i	a8, a1, 0
	l32r	a10, .LCPI203_1
	l32r	a12, .LCPI203_2
	call8	abla_fn_248569758_289064282_direct
	l32i	a9, a6, 0
	movi	a10, 262
	l32i	a8, a1, 32
	j	.LBB203_5
.Lfunc_end203:
	.size	abla_fn_838066626_846918671_direct, .Lfunc_end203-abla_fn_838066626_846918671_direct
                                        # -- End function
	.section	.text.abla_fn_872780078_252961788_direct,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_872780078_252961788_direct
	.type	abla_fn_872780078_252961788_direct,@function
abla_fn_872780078_252961788_direct:     # @abla_fn_872780078_252961788_direct
# %bb.0:                                # %entry
	entry	a1, 32
	or	a12, a3, a3
	or	a10, a2, a2
	movi	a11, 53
	call8	abla_fn_770005555_678222947_direct
	or	a2, a10, a10
	retw.n
.Lfunc_end204:
	.size	abla_fn_872780078_252961788_direct, .Lfunc_end204-abla_fn_872780078_252961788_direct
                                        # -- End function
	.section	.text.abla_fn_920683364_581677190_direct,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_920683364_581677190_direct
	.type	abla_fn_920683364_581677190_direct,@function
abla_fn_920683364_581677190_direct:     # @abla_fn_920683364_581677190_direct
# %bb.0:                                # %entry
	entry	a1, 32
	or	a13, a3, a3
	or	a10, a2, a2
	movi	a11, 49
	movi	a12, 8
	call8	abla_fn_501841392_527998006_direct
	or	a2, a10, a10
	retw.n
.Lfunc_end205:
	.size	abla_fn_920683364_581677190_direct, .Lfunc_end205-abla_fn_920683364_581677190_direct
                                        # -- End function
	.literal_position
	.literal .LCPI206_0, abla_static_abla_fn_627837887_633683867_3703.0
	.literal .LCPI206_1, .Labla_string_abla_fn_627837887_633683867_3725.native.mutable.u32s
	.section	.text.abla_fn_920683364_581677190_direct,"ax",@progbits
	.section	.text.abla_fn_149950643_734865174_direct,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_149950643_734865174_direct
	.type	abla_fn_149950643_734865174_direct,@function
abla_fn_149950643_734865174_direct:     # @abla_fn_149950643_734865174_direct
# %bb.0:                                # %entry
	entry	a1, 80
	l32r	a8, .LCPI206_0
	l8ui	a8, a8, 0
	movi	a7, 0
	bne	a8, a7, .LBB206_2
# %bb.1:                                # %entry
	movi	a8, 0
	bne	a2, a7, .LBB206_3
	j	.LBB206_4
.LBB206_2:
	l32r	a8, .LCPI206_1
	beq	a2, a7, .LBB206_4
.LBB206_3:                              # %entry
	or	a8, a2, a2
.LBB206_4:                              # %entry
	l32i	a8, a8, 16
	movi	a9, -2
	and	a8, a8, a9
	bnei	a8, 4, .LBB206_10
# %bb.5:                                # %source.label17
	addi	a11, a1, 0
	or	a10, a2, a2
	movi	a12, 0
	movi	a13, 0
	movi	a14, 0
	movi	a15, 0
	callx8	a4
	beqz.n	a10, .LBB206_7
.LBB206_6:
	or	a7, a10, a10
	j	.LBB206_10
.LBB206_7:                              # %source.label18
	l32i	a8, a1, 0
	and	a9, a8, a5
	beq	a9, a5, .LBB206_10
# %bb.8:                                # %source.label19
	or	a6, a8, a5
	l32i	a8, a2, 4
	l32i	a8, a8, 44
	or	a10, a2, a2
	movi	a11, 0
	movi	a12, 0
	movi	a13, 0
	movi	a14, 0
	movi	a15, 0
	callx8	a8
	or	a10, a2, a2
	or	a11, a6, a6
	callx8	a3
	or	a7, a10, a10
	l32i	a8, a2, 4
	beqz.n	a7, .LBB206_11
# %bb.9:                                # %source.label39
	l32i	a8, a8, 44
	or	a10, a2, a2
	movi	a11, 1
	movi	a12, 0
	movi	a13, 0
	movi	a14, 0
	movi	a15, 0
	callx8	a8
.LBB206_10:                             # %source.label45
	or	a2, a7, a7
	retw.n
.LBB206_11:                             # %source.label20
	l32i	a9, a8, 84
	l32i	a8, a8, 4
	l32i	a11, a8, 0
	or	a10, a2, a2
	movi	a12, 0
	movi	a13, 0
	movi	a14, 0
	movi	a15, 0
	callx8	a9
	or	a7, a10, a10
	beqz.n	a7, .LBB206_14
# %bb.12:                               # %source.label20
	movi	a8, 262
	bne	a7, a8, .LBB206_10
# %bb.13:                               # %source.label21
	l32i	a8, a2, 4
	l32i	a8, a8, 44
	or	a10, a2, a2
	movi	a11, 1
	movi	a12, 0
	movi	a13, 0
	movi	a14, 0
	movi	a15, 0
	callx8	a8
.LBB206_14:                             # %source.label30
	addi	a11, a1, 0
	movi	a7, 0
	or	a10, a2, a2
	movi	a12, 0
	movi	a13, 0
	movi	a14, 0
	movi	a15, 0
	callx8	a4
	bnez	a10, .LBB206_6
# %bb.15:                               # %source.label31
	l32i	a8, a1, 0
	beq	a8, a6, .LBB206_10
# %bb.16:                               # %source.label31
	movi	a7, 264
	j	.LBB206_10
.Lfunc_end206:
	.size	abla_fn_149950643_734865174_direct, .Lfunc_end206-abla_fn_149950643_734865174_direct
                                        # -- End function
	.literal_position
	.literal .LCPI207_0, 16777216
	.section	.text.abla_fn_149950643_734865174_direct,"ax",@progbits
	.section	.text.abla_fn_317871032_550540883_direct,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_317871032_550540883_direct
	.type	abla_fn_317871032_550540883_direct,@function
abla_fn_317871032_550540883_direct:     # @abla_fn_317871032_550540883_direct
# %bb.0:                                # %entry
	entry	a1, 96
	l32i	a8, a2, 4
	l32i	a9, a8, 84
	l32i	a8, a8, 4
	l32i	a11, a8, 0
	or	a10, a2, a2
	movi	a12, 0
	movi	a13, 0
	movi	a14, 0
	movi	a15, 0
	callx8	a9
	#APP
	nsau	a8, a10
	#NO_APP
	movi	a9, -262
	add	a9, a10, a9
	#APP
	nsau	a9, a9
	#NO_APP
	or	a8, a9, a8
	bgeui	a8, 32, .LBB207_1
	j	.LBB207_8
.LBB207_1:                              # %source.label
	addi	a7, a1, 0
	or	a10, a7, a7
	movi	a11, 0
	movi	a12, 28
	call8	abla_fn_853840267_528021067_direct
	movi	a8, 8
	s32i	a8, a1, 16
	s32i	a3, a1, 8
	s8i	a5, a1, 1
	s32i	a4, a1, 4
	movi	a9, 2
	l32r	a8, .LCPI207_0
	bltu	a4, a8, .LBB207_3
# %bb.2:                                # %source.label
	movi	a9, 18
.LBB207_3:                              # %source.label
	s16i	a9, a1, 20
	movi	a9, 24
	bltu	a4, a8, .LBB207_5
# %bb.4:                                # %source.label
	movi	a9, 32
.LBB207_5:                              # %source.label
	s8i	a9, a1, 3
	l32i	a10, a2, 0
	l32i	a8, a10, 0
	l32i	a8, a8, 4
	or	a11, a7, a7
	movi	a12, 28
	movi	a13, 0
	movi	a14, 0
	movi	a15, 0
	callx8	a8
	bnez	a10, .LBB207_8
# %bb.6:                                # %source.label16
	l32i	a8, a2, 28
	movi	a9, 1
	or	a8, a8, a9
	s32i	a8, a2, 28
	l32i	a8, a2, 4
	l32i	a9, a8, 84
	l32i	a8, a8, 4
	l32i	a11, a8, 16
	or	a10, a2, a2
	or	a12, a4, a4
	or	a13, a5, a5
	movi	a14, 0
	movi	a15, 0
	callx8	a9
	movi	a8, 262
	bne	a10, a8, .LBB207_8
# %bb.7:                                # %source.label17
	l32i	a8, a2, 4
	l32i	a8, a8, 44
	or	a10, a2, a2
	movi	a11, 1
	or	a12, a4, a4
	or	a13, a5, a5
	movi	a14, 0
	movi	a15, 0
	callx8	a8
.LBB207_8:                              # %source.label23
	or	a2, a10, a10
	retw.n
.Lfunc_end207:
	.size	abla_fn_317871032_550540883_direct, .Lfunc_end207-abla_fn_317871032_550540883_direct
                                        # -- End function
	.literal_position
	.literal .LCPI208_0, 16777216
	.section	.text.abla_fn_317871032_550540883_direct,"ax",@progbits
	.section	.text.abla_fn_616072200_862438830_direct,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_616072200_862438830_direct
	.type	abla_fn_616072200_862438830_direct,@function
abla_fn_616072200_862438830_direct:     # @abla_fn_616072200_862438830_direct
# %bb.0:                                # %entry
	entry	a1, 96
	l32i	a8, a2, 4
	l32i	a8, a8, 44
	movi	a7, 0
	or	a10, a2, a2
	movi	a11, 0
	movi	a12, 0
	movi	a13, 0
	movi	a14, 0
	movi	a15, 0
	callx8	a8
	or	a6, a10, a10
	bnez.n	a6, .LBB208_2
# %bb.1:                                # %source.label
	l32i	a8, a2, 4
	l32i	a9, a8, 84
	l32i	a8, a8, 4
	l32i	a7, a8, 0
	or	a10, a2, a2
	or	a11, a7, a7
	movi	a12, 0
	movi	a13, 0
	movi	a14, 0
	movi	a15, 0
	callx8	a9
	or	a6, a10, a10
.LBB208_2:                              # %source.label17
	movi	a8, -262
	add	a8, a6, a8
	#APP
	nsau	a8, a8
	#NO_APP
	#APP
	nsau	a9, a6
	#NO_APP
	or	a8, a8, a9
	bltui	a8, 32, .LBB208_10
# %bb.3:                                # %source.label18
	l32i	a8, a2, 8
	l32i	a8, a8, 36
	beqz.n	a8, .LBB208_5
# %bb.4:                                # %source.label19
	movi	a10, 1
	or	a11, a7, a7
	movi	a12, 0
	movi	a13, 0
	movi	a14, 0
	movi	a15, 0
	callx8	a8
.LBB208_5:                              # %source.label21
	addi	a7, a1, 0
	or	a10, a7, a7
	movi	a11, 0
	movi	a12, 28
	call8	abla_fn_853840267_528021067_direct
	movi	a8, 8
	s32i	a8, a1, 16
	s32i	a3, a1, 4
	l32r	a8, .LCPI208_0
	movi	a9, 32
	bltu	a3, a8, .LBB208_7
# %bb.6:                                # %source.label21
	movi	a9, 33
.LBB208_7:                              # %source.label21
	s16i	a9, a1, 20
	movi	a9, 24
	bltu	a3, a8, .LBB208_9
# %bb.8:                                # %source.label21
	movi	a9, 32
.LBB208_9:                              # %source.label21
	s8i	a9, a1, 3
	l32i	a10, a2, 0
	l32i	a8, a10, 0
	l32i	a8, a8, 4
	or	a11, a7, a7
	movi	a12, 28
	movi	a13, 0
	movi	a14, 0
	movi	a15, 0
	callx8	a8
	or	a6, a10, a10
	beqz.n	a6, .LBB208_11
.LBB208_10:                             # %source.label44
	or	a2, a6, a6
	retw.n
.LBB208_11:                             # %source.label22
	l32i	a8, a2, 28
	movi	a9, 1
	or	a8, a8, a9
	s32i	a8, a2, 28
	l32i	a9, a2, 4
	l32i	a10, a2, 0
	l32i	a8, a10, 0
	l32i	a8, a8, 68
	beqz	a8, .LBB208_15
# %bb.12:                               # %source.label30
	l32i	a7, a9, 32
	or	a11, a3, a3
	or	a12, a7, a7
	movi	a13, 0
	movi	a14, 0
	movi	a15, 0
	callx8	a8
	or	a6, a10, a10
	bnez	a6, .LBB208_10
# %bb.13:                               # %source.label31
	l32i	a8, a2, 4
	l32i	a9, a8, 84
	l32i	a8, a8, 4
	l32i	a5, a8, 12
	or	a10, a2, a2
	or	a11, a5, a5
	or	a12, a7, a7
	movi	a13, 0
	movi	a14, 0
	movi	a15, 0
	callx8	a9
	or	a6, a10, a10
	l32i	a8, a2, 8
	l32i	a8, a8, 36
	beqz	a8, .LBB208_18
# %bb.14:                               # %source.label32
	movi	a10, 0
	or	a11, a5, a5
	or	a12, a7, a7
	j	.LBB208_17
.LBB208_15:                             # %source.label23
	l32i	a8, a9, 84
	l32i	a9, a9, 4
	l32i	a5, a9, 12
	movi	a7, 0
	or	a10, a2, a2
	or	a11, a5, a5
	movi	a12, 0
	movi	a13, 0
	movi	a14, 0
	movi	a15, 0
	callx8	a8
	or	a6, a10, a10
	l32i	a8, a2, 8
	l32i	a8, a8, 36
	beqz.n	a8, .LBB208_18
# %bb.16:                               # %source.label24
	movi	a10, 0
	or	a11, a5, a5
	movi	a12, 0
.LBB208_17:                             # %source.label34
	movi	a13, 0
	movi	a14, 0
	movi	a15, 0
	callx8	a8
.LBB208_18:                             # %source.label34
	movi	a8, 262
	beq	a6, a8, .LBB208_19
	j	.LBB208_10
.LBB208_19:                             # %source.label44.sink.split
	l32i	a8, a2, 4
	l32i	a8, a8, 44
	or	a10, a2, a2
	movi	a11, 1
	or	a12, a7, a7
	movi	a13, 0
	movi	a14, 0
	movi	a15, 0
	callx8	a8
	or	a6, a10, a10
	j	.LBB208_10
.Lfunc_end208:
	.size	abla_fn_616072200_862438830_direct, .Lfunc_end208-abla_fn_616072200_862438830_direct
                                        # -- End function
	.literal_position
	.literal .LCPI209_0, 16777216
	.section	.text.abla_fn_616072200_862438830_direct,"ax",@progbits
	.section	.text.abla_fn_407052752_528196726_direct,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_407052752_528196726_direct
	.type	abla_fn_407052752_528196726_direct,@function
abla_fn_407052752_528196726_direct:     # @abla_fn_407052752_528196726_direct
# %bb.0:                                # %entry
	entry	a1, 96
	l32i	a8, a2, 4
	l32i	a8, a8, 44
	movi	a7, 0
	or	a10, a2, a2
	movi	a11, 0
	movi	a12, 0
	movi	a13, 0
	movi	a14, 0
	movi	a15, 0
	callx8	a8
	or	a6, a10, a10
	bnez.n	a6, .LBB209_2
# %bb.1:                                # %source.label
	l32i	a8, a2, 4
	l32i	a9, a8, 84
	l32i	a8, a8, 4
	l32i	a7, a8, 0
	or	a10, a2, a2
	or	a11, a7, a7
	movi	a12, 0
	movi	a13, 0
	movi	a14, 0
	movi	a15, 0
	callx8	a9
	or	a6, a10, a10
.LBB209_2:                              # %source.label17
	movi	a8, -262
	add	a8, a6, a8
	#APP
	nsau	a8, a8
	#NO_APP
	#APP
	nsau	a9, a6
	#NO_APP
	or	a8, a8, a9
	bltui	a8, 32, .LBB209_10
# %bb.3:                                # %source.label18
	l32i	a8, a2, 8
	l32i	a8, a8, 36
	beqz.n	a8, .LBB209_5
# %bb.4:                                # %source.label19
	movi	a10, 1
	or	a11, a7, a7
	movi	a12, 0
	movi	a13, 0
	movi	a14, 0
	movi	a15, 0
	callx8	a8
.LBB209_5:                              # %source.label21
	addi	a7, a1, 0
	or	a10, a7, a7
	movi	a11, 0
	movi	a12, 28
	call8	abla_fn_853840267_528021067_direct
	movi	a8, 8
	s32i	a8, a1, 16
	s32i	a3, a1, 4
	movi	a9, 216
	l32r	a8, .LCPI209_0
	bltu	a3, a8, .LBB209_7
# %bb.6:                                # %source.label21
	movi	a9, 220
.LBB209_7:                              # %source.label21
	s16i	a9, a1, 20
	movi	a9, 24
	bltu	a3, a8, .LBB209_9
# %bb.8:                                # %source.label21
	movi	a9, 32
.LBB209_9:                              # %source.label21
	s8i	a9, a1, 3
	l32i	a10, a2, 0
	l32i	a8, a10, 0
	l32i	a8, a8, 4
	or	a11, a7, a7
	movi	a12, 28
	movi	a13, 0
	movi	a14, 0
	movi	a15, 0
	callx8	a8
	or	a6, a10, a10
	beqz.n	a6, .LBB209_11
.LBB209_10:                             # %source.label44
	or	a2, a6, a6
	retw.n
.LBB209_11:                             # %source.label22
	l32i	a8, a2, 28
	movi	a9, 1
	or	a8, a8, a9
	s32i	a8, a2, 28
	l32i	a9, a2, 4
	l32i	a10, a2, 0
	l32i	a8, a10, 0
	l32i	a8, a8, 68
	beqz	a8, .LBB209_15
# %bb.12:                               # %source.label30
	l32i	a7, a9, 36
	or	a11, a3, a3
	or	a12, a7, a7
	movi	a13, 0
	movi	a14, 0
	movi	a15, 0
	callx8	a8
	or	a6, a10, a10
	bnez	a6, .LBB209_10
# %bb.13:                               # %source.label31
	l32i	a8, a2, 4
	l32i	a9, a8, 84
	l32i	a8, a8, 4
	l32i	a5, a8, 8
	or	a10, a2, a2
	or	a11, a5, a5
	or	a12, a7, a7
	movi	a13, 0
	movi	a14, 0
	movi	a15, 0
	callx8	a9
	or	a6, a10, a10
	l32i	a8, a2, 8
	l32i	a8, a8, 36
	beqz	a8, .LBB209_18
# %bb.14:                               # %source.label32
	movi	a10, 0
	or	a11, a5, a5
	or	a12, a7, a7
	j	.LBB209_17
.LBB209_15:                             # %source.label23
	l32i	a8, a9, 84
	l32i	a9, a9, 4
	l32i	a5, a9, 8
	movi	a7, 0
	or	a10, a2, a2
	or	a11, a5, a5
	movi	a12, 0
	movi	a13, 0
	movi	a14, 0
	movi	a15, 0
	callx8	a8
	or	a6, a10, a10
	l32i	a8, a2, 8
	l32i	a8, a8, 36
	beqz.n	a8, .LBB209_18
# %bb.16:                               # %source.label24
	movi	a10, 0
	or	a11, a5, a5
	movi	a12, 0
.LBB209_17:                             # %source.label34
	movi	a13, 0
	movi	a14, 0
	movi	a15, 0
	callx8	a8
.LBB209_18:                             # %source.label34
	movi	a8, 262
	beq	a6, a8, .LBB209_19
	j	.LBB209_10
.LBB209_19:                             # %source.label44.sink.split
	l32i	a8, a2, 4
	l32i	a8, a8, 44
	or	a10, a2, a2
	movi	a11, 1
	or	a12, a7, a7
	movi	a13, 0
	movi	a14, 0
	movi	a15, 0
	callx8	a8
	or	a6, a10, a10
	j	.LBB209_10
.Lfunc_end209:
	.size	abla_fn_407052752_528196726_direct, .Lfunc_end209-abla_fn_407052752_528196726_direct
                                        # -- End function
	.literal_position
	.literal .LCPI210_0, 16777216
	.literal .LCPI210_1, .Labla_string_abla_fn_627837887_633683867_3858.native.bytes
	.literal .LCPI210_2, .Labla_string_abla_fn_627837887_633683867_3851.native.bytes
	.section	.text.abla_fn_407052752_528196726_direct,"ax",@progbits
	.section	.text.abla_fn_283351212_772728346_direct,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_283351212_772728346_direct
	.type	abla_fn_283351212_772728346_direct,@function
abla_fn_283351212_772728346_direct:     # @abla_fn_283351212_772728346_direct
# %bb.0:                                # %entry
	entry	a1, 160
	l32i	a8, a2, 4
	l32i	a9, a8, 76
	s32i	a9, a1, 92
	add	a9, a5, a4
	movi	a11, 1
	l32r	a10, .LCPI210_0
	bltu	a10, a9, .LBB210_2
# %bb.1:                                # %entry
	movi	a11, 0
.LBB210_2:                              # %entry
	l32i	a8, a8, 120
	or	a10, a2, a2
	movi	a12, 0
	movi	a13, 0
	movi	a14, 0
	movi	a15, 0
	callx8	a8
	s32i	a10, a1, 84
	movi	a8, 262
	bne	a10, a8, .LBB210_5
# %bb.3:                                # %source.label24
	call8	abla_fn_11786425_863113934_direct
	or	a12, a10, a10
	l32r	a11, .LCPI210_1
	l32r	a10, .LCPI210_2
	or	a13, a10, a10
	movi	a14, 0
	call8	abla_fn_992771427_703335695_direct
.LBB210_4:                              # %source.label43
	l32i	a2, a1, 84
	retw.n
.LBB210_5:                              # %source.label27.preheader
	movi	a8, 4
	addi	a9, a1, 0
	or	a7, a9, a8
.LBB210_6:                              # %source.label27.outer.outer
                                        # =>This Loop Header: Depth=1
                                        #     Child Loop BB210_7 Depth 2
                                        #       Child Loop BB210_8 Depth 3
	movi	a8, 1
.LBB210_7:                              # %source.label27.outer
                                        #   Parent Loop BB210_6 Depth=1
                                        # =>  This Loop Header: Depth=2
                                        #       Child Loop BB210_8 Depth 3
	or	a6, a5, a5
.LBB210_8:                              # %source.label27
                                        #   Parent Loop BB210_6 Depth=1
                                        #     Parent Loop BB210_7 Depth=2
                                        # =>    This Inner Loop Header: Depth=3
	bbci	a8, 0, .LBB210_4
# %bb.9:                                # %source.label28
                                        #   in Loop: Header=BB210_8 Depth=3
	movi	a8, 0
	l32i	a9, a1, 84
	bnez	a9, .LBB210_8
# %bb.10:                               # %source.label33
                                        #   in Loop: Header=BB210_7 Depth=2
	movi	a5, 0
	beqz	a6, .LBB210_7
# %bb.11:                               # %source.label34
                                        #   in Loop: Header=BB210_6 Depth=1
	or	a10, a7, a7
	movi	a11, 255
	movi	a12, 64
	call8	abla_fn_853840267_528021067_direct
	l32i	a10, a2, 0
	l32i	a8, a10, 0
	l32i	a8, a8, 52
	l32i	a14, a1, 92
	addi	a13, a1, 0
	or	a11, a4, a4
	or	a12, a6, a6
	callx8	a8
	or	a13, a10, a10
	l32i	a12, a1, 0
	sub	a8, a4, a12
	s32i	a8, a1, 88
	add	a8, a12, a13
	add	a5, a4, a6
	minu	a6, a5, a8
	sub	a8, a6, a4
	s32i	a8, a1, 80
	l32i	a10, a2, 0
	l32i	a8, a10, 0
	l32i	a8, a8, 44
	or	a11, a7, a7
	callx8	a8
	s32i	a10, a1, 84
	l32i	a8, a1, 88
	add	a11, a8, a7
	l32i	a12, a1, 80
	or	a10, a3, a3
	call8	abla_fn_334943840_569200394_direct
	sub	a5, a5, a6
	l32i	a8, a1, 80
	add	a3, a8, a3
	or	a4, a6, a6
	j	.LBB210_6
.Lfunc_end210:
	.size	abla_fn_283351212_772728346_direct, .Lfunc_end210-abla_fn_283351212_772728346_direct
                                        # -- End function
	.section	.text.abla_fn_61106253_836094646_direct,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_61106253_836094646_direct
	.type	abla_fn_61106253_836094646_direct,@function
abla_fn_61106253_836094646_direct:      # @abla_fn_61106253_836094646_direct
# %bb.0:                                # %entry
	entry	a1, 32
	l8ui	a8, a2, 24
	movi	a2, 4
	movi	a9, 24
	bgeu	a9, a8, .LBB211_2
# %bb.1:                                # %entry
	movi	a2, 6
.LBB211_2:                              # %entry
	retw.n
.Lfunc_end211:
	.size	abla_fn_61106253_836094646_direct, .Lfunc_end211-abla_fn_61106253_836094646_direct
                                        # -- End function
	.literal_position
	.literal .LCPI212_0, 65534
	.literal .LCPI212_1, 24581
	.section	.text.abla_fn_61106253_836094646_direct,"ax",@progbits
	.section	.text.abla_fn_290333585_319380335_direct,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_290333585_319380335_direct
	.type	abla_fn_290333585_319380335_direct,@function
abla_fn_290333585_319380335_direct:     # @abla_fn_290333585_319380335_direct
# %bb.0:                                # %entry
	entry	a1, 32
	l32i	a9, a2, 24
	extui	a10, a9, 0, 8
	movi	a8, 1
	ssl	a10
	sll	a8, a8
	movi	a2, 0
	movi	a11, 32
	bltu	a10, a11, .LBB212_2
# %bb.1:                                # %entry
	movi	a8, 0
.LBB212_2:                              # %entry
	extui	a9, a9, 0, 16
	addi	a9, a9, -1
	l32r	a10, .LCPI212_0
	bltu	a9, a10, .LBB212_4
# %bb.3:                                # %entry
	movi	a8, 0
.LBB212_4:                              # %entry
	s32i	a8, a3, 0
	bltu	a9, a10, .LBB212_6
# %bb.5:                                # %entry
	l32r	a2, .LCPI212_1
.LBB212_6:                              # %entry
	retw.n
.Lfunc_end212:
	.size	abla_fn_290333585_319380335_direct, .Lfunc_end212-abla_fn_290333585_319380335_direct
                                        # -- End function
	.literal_position
	.literal .LCPI213_0, -65536
	.literal .LCPI213_1, 13107200
	.literal .LCPI213_2, 65280
	.literal .LCPI213_3, 33536
	.literal .LCPI213_4, 57088
	.literal .LCPI213_5, 16384
	.literal .LCPI213_6, 17152
	.section	.text.abla_fn_290333585_319380335_direct,"ax",@progbits
	.section	.text.abla_fn_180484491_182634345_direct,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_180484491_182634345_direct
	.type	abla_fn_180484491_182634345_direct,@function
abla_fn_180484491_182634345_direct:     # @abla_fn_180484491_182634345_direct
# %bb.0:                                # %entry
	entry	a1, 32
	l32r	a8, .LCPI213_0
	and	a8, a3, a8
	movi	a2, 261
	l32r	a9, .LCPI213_1
	bne	a8, a9, .LBB213_7
# %bb.1:                                # %source.label2
	l32r	a8, .LCPI213_2
	and	a8, a3, a8
	l32r	a9, .LCPI213_3
	bne	a8, a9, .LBB213_3
# %bb.2:                                # %source.label2
	movi	a2, 0
.LBB213_3:                              # %source.label2
	l32r	a9, .LCPI213_4
	and	a9, a3, a9
	l32r	a10, .LCPI213_5
	bne	a9, a10, .LBB213_5
# %bb.4:                                # %source.label2
	movi	a2, 0
.LBB213_5:                              # %source.label2
	l32r	a9, .LCPI213_6
	bne	a8, a9, .LBB213_7
# %bb.6:                                # %source.label2
	movi	a2, 0
.LBB213_7:                              # %common.ret
	retw.n
.Lfunc_end213:
	.size	abla_fn_180484491_182634345_direct, .Lfunc_end213-abla_fn_180484491_182634345_direct
                                        # -- End function
	.literal_position
	.literal .LCPI214_0, 30005
	.section	.text.abla_fn_180484491_182634345_direct,"ax",@progbits
	.section	.text.abla_fn_789329514_748459409_direct,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_789329514_748459409_direct
	.type	abla_fn_789329514_748459409_direct,@function
abla_fn_789329514_748459409_direct:     # @abla_fn_789329514_748459409_direct
# %bb.0:                                # %entry
	entry	a1, 48
	addi	a7, a1, 0
	or	a10, a7, a7
	movi	a11, 0
	movi	a12, 8
	call8	abla_fn_853840267_528021067_direct
	movi	a8, 122
	s8i	a8, a1, 6
	l32r	a8, .LCPI214_0
	s16i	a8, a1, 4
	movi	a8, 132
	s32i	a8, a1, 0
	l32i	a10, a2, 0
	l32i	a8, a10, 0
	l32i	a8, a8, 84
	or	a11, a7, a7
	callx8	a8
	or	a2, a10, a10
	retw.n
.Lfunc_end214:
	.size	abla_fn_789329514_748459409_direct, .Lfunc_end214-abla_fn_789329514_748459409_direct
                                        # -- End function
	.literal_position
	.literal .LCPI215_0, 65280
	.literal .LCPI215_1, 24576
	.literal .LCPI215_2, abla_fn_920683364_581677190_direct
	.literal .LCPI215_3, abla_fn_872780078_252961788_direct
	.literal .LCPI215_4, abla_fn_342000349_189405272_direct
	.literal .LCPI215_5, abla_fn_691100501_817565095_direct
	.section	.text.abla_fn_789329514_748459409_direct,"ax",@progbits
	.section	.text.abla_fn_678785486_82486944_direct,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_678785486_82486944_direct
	.type	abla_fn_678785486_82486944_direct,@function
abla_fn_678785486_82486944_direct:      # @abla_fn_678785486_82486944_direct
# %bb.0:                                # %entry
	entry	a1, 32
	or	a10, a2, a2
	l32i	a8, a10, 24
	l32r	a9, .LCPI215_0
	and	a9, a8, a9
	l32r	a11, .LCPI215_1
	beq	a9, a11, .LBB215_3
# %bb.1:                                # %entry
	movi	a9, 254
	and	a8, a8, a9
	movi	a9, 22
	bltu	a8, a9, .LBB215_3
# %bb.2:                                # %source.label7
	l32r	a11, .LCPI215_2
	l32r	a12, .LCPI215_3
	movi	a13, 2
	j	.LBB215_4
.LBB215_3:                              # %source.label5
	l32r	a11, .LCPI215_4
	l32r	a12, .LCPI215_5
	movi	a13, 512
.LBB215_4:                              # %common.ret
	call8	abla_fn_149950643_734865174_direct
	or	a2, a10, a10
	retw.n
.Lfunc_end215:
	.size	abla_fn_678785486_82486944_direct, .Lfunc_end215-abla_fn_678785486_82486944_direct
                                        # -- End function
	.section	.text.abla_fn_40032114_308672228_direct,"ax",@progbits
	.p2align	2                               # -- Begin function abla_fn_40032114_308672228_direct
	.type	abla_fn_40032114_308672228_direct,@function
abla_fn_40032114_308672228_direct:      # @abla_fn_40032114_308672228_direct
# %bb.0:                                # %entry
	entry	a1, 48
	or	a10, a2, a2
	addi	a12, a1, 0
	movi	a11, 53
	call8	abla_fn_770005555_678222947_direct
	bnez.n	a10, .LBB216_2
# %bb.1:                                # %source.label
	l32i	a8, a1, 0
	slli	a8, a8, 1
	movi	a9, 4
	and	a8, a8, a9
	s32i	a8, a3, 0
.LBB216_2:                              # %source.label7
	or	a2, a10, a10
	retw.n
.Lfunc_end216:
	.size	abla_fn_40032114_308672228_direct, .Lfunc_end216-abla_fn_40032114_308672228_direct
                                        # -- End function
	.literal_position
	.literal .LCPI217_0, abla_global_186399490_945206650
	.literal .LCPI217_1, abla_global_462423855_903385096
	.literal .LCPI217_2, esp_ipc_isr_end_fl
	.literal .LCPI217_3, abla_global_61246377_765685754
	.literal .LCPI217_4, abla_global_447666338_361957421
	.literal .LCPI217_5, abla_static_abla_fn_627837887_633683867_4085.0
	.literal .LCPI217_6, abla_static_abla_fn_742253470_491478038_1
	.literal .LCPI217_7, 13398
	.section	.text.abla_fn_40032114_308672228_direct,"ax",@progbits
	.section	.text.main,"ax",@progbits
	.global	main                            # -- Begin function main
	.p2align	2
	.type	main,@function
main:                                   # @main
# %bb.0:                                # %entry
	entry	a1, 32
	l32r	a8, .LCPI217_0
	movi	a9, 0
	s32i	a9, a8, 0
	l32r	a8, .LCPI217_1
	s32i	a9, a8, 0
	l32r	a8, .LCPI217_2
	movi	a2, 1
	s32i	a2, a8, 0
	l32r	a8, .LCPI217_3
	s8i	a2, a8, 0
	l32r	a8, .LCPI217_4
	s8i	a2, a8, 0
	l32r	a8, .LCPI217_5
	s8i	a2, a8, 0
	l32r	a8, .LCPI217_6
	movi	a10, 18
	s8i	a10, a8, 4
	l32r	a10, .LCPI217_7
	s16i	a10, a8, 2
	movi	a10, 120
	s8i	a10, a8, 1
	bnez.n	a9, .LBB217_4
# %bb.1:                                # %entry
	l8ui	a9, a8, 0
	extui	a9, a9, 0, 8
	bnez.n	a9, .LBB217_4
# %bb.2:                                # %source.label19.i.i
	l8ui	a8, a8, 5
	movi	a2, 42
	movi	a9, 0
	beq	a8, a9, .LBB217_4
# %bb.3:                                # %source.label19.i.i
	movi	a2, 1
.LBB217_4:                              # %abla_fn_403736477_628984182.exit
	retw.n
.Lfunc_end217:
	.size	main, .Lfunc_end217-main
                                        # -- End function
	.type	.Labla_string_abla_fn_627837887_633683867_8.native.bytes,@object # @abla_string_abla_fn_627837887_633683867_8.native.bytes
	.section	.rodata.abla.abla_string_abla_fn_627837887_633683867_8.native.bytes,"a",@progbits
	.p2align	3, 0x0
.Labla_string_abla_fn_627837887_633683867_8.native.bytes:
	.ascii	"0123456789abcdefghijklmnopqrstuvwxyz"
	.size	.Labla_string_abla_fn_627837887_633683867_8.native.bytes, 36

	.type	abla_global_462423855_903385096,@object # @abla_global_462423855_903385096
	.section	.bss.abla_global_462423855_903385096,"aw",@nobits
	.p2align	2, 0x0
abla_global_462423855_903385096:
	.long	0                               # 0x0
	.size	abla_global_462423855_903385096, 4

	.type	abla_global_186399490_945206650,@object # @abla_global_186399490_945206650
	.section	.bss.abla_global_186399490_945206650,"aw",@nobits
	.p2align	2, 0x0
abla_global_186399490_945206650:
	.long	0                               # 0x0
	.size	abla_global_186399490_945206650, 4

	.type	esp_ipc_isr_finish_cmd,@object  # @esp_ipc_isr_finish_cmd
	.section	.bss.esp_ipc_isr_finish_cmd,"awR",@nobits
	.p2align	3, 0x0
esp_ipc_isr_finish_cmd:
	.space	4
	.size	esp_ipc_isr_finish_cmd, 4

	.type	esp_ipc_isr_end_fl,@object      # @esp_ipc_isr_end_fl
	.section	.bss.esp_ipc_isr_end_fl,"awR",@nobits
	.p2align	3, 0x0
esp_ipc_isr_end_fl:
	.space	4
	.size	esp_ipc_isr_end_fl, 4

	.type	abla_global_61246377_765685754,@object # @abla_global_61246377_765685754
	.section	.bss.abla_global_61246377_765685754,"aw",@nobits
	.p2align	2, 0x0
abla_global_61246377_765685754:
	.byte	0                               # 0x0
	.size	abla_global_61246377_765685754, 1

	.type	esp_ipc_func,@object            # @esp_ipc_func
	.section	.bss.esp_ipc_func,"awR",@nobits
	.p2align	3, 0x0
esp_ipc_func:
	.space	4
	.size	esp_ipc_func, 4

	.type	esp_ipc_func_arg,@object        # @esp_ipc_func_arg
	.section	.bss.esp_ipc_func_arg,"awR",@nobits
	.p2align	3, 0x0
esp_ipc_func_arg:
	.space	4
	.size	esp_ipc_func_arg, 4

	.type	esp_ipc_isr_start_fl,@object    # @esp_ipc_isr_start_fl
	.section	.bss.esp_ipc_isr_start_fl,"awR",@nobits
	.p2align	3, 0x0
esp_ipc_isr_start_fl:
	.space	4
	.size	esp_ipc_isr_start_fl, 4

	.type	abla_static_abla_fn_627837887_633683867_118.0,@object # @abla_static_abla_fn_627837887_633683867_118.0
	.section	.bss.abla_static_abla_fn_627837887_633683867_118.0,"aw",@nobits
	.p2align	3, 0x0
abla_static_abla_fn_627837887_633683867_118.0:
	.byte	0                               # 0x0
	.size	abla_static_abla_fn_627837887_633683867_118.0, 1

	.type	abla_static_abla_fn_627837887_633683867_124,@object # @abla_static_abla_fn_627837887_633683867_124
	.section	.bss.abla_static_abla_fn_627837887_633683867_124,"aw",@nobits
	.p2align	3, 0x0
abla_static_abla_fn_627837887_633683867_124:
	.space	84
	.size	abla_static_abla_fn_627837887_633683867_124, 84

	.type	.Labla_string_abla_fn_627837887_633683867_126.native.bytes,@object # @abla_string_abla_fn_627837887_633683867_126.native.bytes
	.section	.rodata.abla.abla_string_abla_fn_627837887_633683867_126.native.bytes,"a",@progbits
	.p2align	3, 0x0
.Labla_string_abla_fn_627837887_633683867_126.native.bytes:
	.asciz	"spi_flash_disable_interrupts_caches_and_other_cp\000"
	.size	.Labla_string_abla_fn_627837887_633683867_126.native.bytes, 50

	.type	.Labla_string_abla_fn_627837887_633683867_151.native.bytes,@object # @abla_string_abla_fn_627837887_633683867_151.native.bytes
	.section	.rodata.abla.abla_string_abla_fn_627837887_633683867_151.native.bytes,"aMS",@progbits,1,unique,2
	.p2align	3, 0x0
.Labla_string_abla_fn_627837887_633683867_151.native.bytes:
	.asciz	"spi_flash_enable_interrupts_caches_and_other_cpu"
	.size	.Labla_string_abla_fn_627837887_633683867_151.native.bytes, 49

	.type	.Labla_string_abla_fn_627837887_633683867_158.native.bytes,@object # @abla_string_abla_fn_627837887_633683867_158.native.bytes
	.section	.rodata.abla.abla_string_abla_fn_627837887_633683867_158.native.bytes,"a",@progbits
	.p2align	3, 0x0
.Labla_string_abla_fn_627837887_633683867_158.native.bytes:
	.asciz	"s_flash_op_mutex != NULL\000\000\000\000//IDF/components/spi_flash/cache_utils.c"
	.size	.Labla_string_abla_fn_627837887_633683867_158.native.bytes, 69

	.type	.Labla_string_abla_fn_627837887_633683867_165.native.bytes,@object # @abla_string_abla_fn_627837887_633683867_165.native.bytes
	.section	.rodata.abla.abla_string_abla_fn_627837887_633683867_165.native.bytes,"a",@progbits
	.p2align	3, 0x0
.Labla_string_abla_fn_627837887_633683867_165.native.bytes:
	.asciz	"esp_task_stack_is_sane_cache_disabled()\000s_flash_op_cpu == -1\000\000\000\000other_cpuid == 1\000\000\000\000cpuid == s_flash_op_cpu\000!(xTaskGetSchedulerState() == taskSCHEDULER_NOT_STARTED && cpuid != 0)\000\000cache_id <= CACHE_LL_ID_ALL\000/IDF/components/hal/esp32/include/hal/cache_ll.h"
	.size	.Labla_string_abla_fn_627837887_633683867_165.native.bytes, 257

	.type	abla_string_abla_fn_627837887_633683867_173.native.mutable.u32s.0,@object # @abla_string_abla_fn_627837887_633683867_173.native.mutable.u32s.0
	.section	.data.abla_string_abla_fn_627837887_633683867_173.native.mutable.u32s.0,"aw",@progbits
	.p2align	2, 0x0
abla_string_abla_fn_627837887_633683867_173.native.mutable.u32s.0:
	.long	4294967295                      # 0xffffffff
	.size	abla_string_abla_fn_627837887_633683867_173.native.mutable.u32s.0, 4

	.type	_xt_coproc_sa_offset,@object    # @_xt_coproc_sa_offset
	.section	.rodata.abla.xtensa.coprocessor_offsets,"aR",@progbits,unique,3
	.p2align	2, 0x0
_xt_coproc_sa_offset:
	.long	0                               # 0x0
	.long	72                              # 0x48
	.long	72                              # 0x48
	.long	72                              # 0x48
	.long	72                              # 0x48
	.long	72                              # 0x48
	.long	72                              # 0x48
	.long	72                              # 0x48
	.size	_xt_coproc_sa_offset, 32

	.type	.Labla_recovered_Esp32XtensaVectors_data__rodata__xt_coproc_mask,@object # @.Labla_recovered_Esp32XtensaVectors_data__rodata__xt_coproc_mask
	.section	.rodata.abla.xtensa.coprocessor_masks,"aR",@progbits,unique,4
	.p2align	2, 0x0
.Labla_recovered_Esp32XtensaVectors_data__rodata__xt_coproc_mask:
	.long	1                               # 0x1
	.long	65538                           # 0x10002
	.long	131076                          # 0x20004
	.long	196616                          # 0x30008
	.long	262160                          # 0x40010
	.long	327712                          # 0x50020
	.long	393280                          # 0x60040
	.long	458880                          # 0x70080
	.size	.Labla_recovered_Esp32XtensaVectors_data__rodata__xt_coproc_mask, 32

	.type	abla_static_abla_fn_627837887_633683867_235,@object # @abla_static_abla_fn_627837887_633683867_235
	.section	.bss.abla_static_abla_fn_627837887_633683867_235,"aw",@nobits
	.p2align	3, 0x0
abla_static_abla_fn_627837887_633683867_235:
	.space	248
	.size	abla_static_abla_fn_627837887_633683867_235, 248

	.type	abla_static_abla_fn_627837887_633683867_241.0,@object # @abla_static_abla_fn_627837887_633683867_241.0
	.section	.bss.abla_static_abla_fn_627837887_633683867_241.0,"aw",@nobits
	.p2align	3, 0x0
abla_static_abla_fn_627837887_633683867_241.0:
	.long	0                               # 0x0
	.size	abla_static_abla_fn_627837887_633683867_241.0, 4

	.type	abla_static_abla_fn_627837887_633683867_247.0,@object # @abla_static_abla_fn_627837887_633683867_247.0
	.section	.bss.abla_static_abla_fn_627837887_633683867_247.0,"aw",@nobits
	.p2align	3, 0x0
abla_static_abla_fn_627837887_633683867_247.0:
	.long	0                               # 0x0
	.size	abla_static_abla_fn_627837887_633683867_247.0, 4

	.type	.Labla_string_abla_fn_627837887_633683867_252.native.bytes,@object # @abla_string_abla_fn_627837887_633683867_252.native.bytes
	.section	.rodata.abla.abla_string_abla_fn_627837887_633683867_252.native.bytes,"aMS",@progbits,1,unique,5
	.p2align	3, 0x0
.Labla_string_abla_fn_627837887_633683867_252.native.bytes:
	.asciz	"esp_log_cache_get_level"
	.size	.Labla_string_abla_fn_627837887_633683867_252.native.bytes, 24

	.type	abla_static_abla_fn_627837887_633683867_260.0,@object # @abla_static_abla_fn_627837887_633683867_260.0
	.section	.bss.abla_static_abla_fn_627837887_633683867_260.0,"aw",@nobits
	.p2align	3, 0x0
abla_static_abla_fn_627837887_633683867_260.0:
	.long	0                               # 0x0
	.size	abla_static_abla_fn_627837887_633683867_260.0, 4

	.type	.Labla_string_abla_fn_627837887_633683867_265.native.bytes,@object # @abla_string_abla_fn_627837887_633683867_265.native.bytes
	.section	.rodata.abla.abla_string_abla_fn_627837887_633683867_265.native.bytes,"a",@progbits
	.p2align	3, 0x0
.Labla_string_abla_fn_627837887_633683867_265.native.bytes:
	.asciz	"i == 0 || s_log_cache[(i - 1) / 2].generation < s_log_cache[i].generation\000\000\000//IDF/components/log/src/log_level/tag_log_level/cache/log_binary_heap.c"
	.size	.Labla_string_abla_fn_627837887_633683867_265.native.bytes, 149

	.type	esp_app_desc,@object            # @esp_app_desc
	.section	.rodata_desc,"aR",@progbits,unique,6
	.p2align	4, 0x0
esp_app_desc:
	.asciz	"2T\315\253\000\000\000\000\000\000\000\000\000\000\000\0000a6906b-dirty\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000m5echo_firmware_abla\000\000\000\000\000\000\000\000\000\000\00000:00:00\000\000\000\000\000\000\000\000Jan  1 1980\000\000\000\000\000v6.0.2\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000c\000\020\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	.size	esp_app_desc, 255

	.type	abla_static_abla_fn_627837887_633683867_324,@object # @abla_static_abla_fn_627837887_633683867_324
	.section	.bss.abla_static_abla_fn_627837887_633683867_324,"aw",@nobits
	.p2align	3, 0x0
abla_static_abla_fn_627837887_633683867_324:
	.space	10
	.size	abla_static_abla_fn_627837887_633683867_324, 10

	.type	.Labla_string_abla_fn_627837887_633683867_329.native.bytes,@object # @abla_string_abla_fn_627837887_633683867_329.native.bytes
	.section	.rodata.abla.abla_string_abla_fn_627837887_633683867_329.native.bytes,"aMS",@progbits,1,unique,7
	.p2align	3, 0x0
.Labla_string_abla_fn_627837887_633683867_329.native.bytes:
	.asciz	"I app_init: Application information:\n"
	.size	.Labla_string_abla_fn_627837887_633683867_329.native.bytes, 38

	.type	.Labla_string_abla_fn_627837887_633683867_332.native.bytes,@object # @abla_string_abla_fn_627837887_633683867_332.native.bytes
	.section	.rodata.abla.abla_string_abla_fn_627837887_633683867_332.native.bytes,"aMS",@progbits,1,unique,8
	.p2align	3, 0x0
.Labla_string_abla_fn_627837887_633683867_332.native.bytes:
	.asciz	"I app_init: Project name:     "
	.size	.Labla_string_abla_fn_627837887_633683867_332.native.bytes, 31

	.type	.Labla_string_abla_fn_627837887_633683867_335.native.bytes,@object # @abla_string_abla_fn_627837887_633683867_335.native.bytes
	.section	.rodata.abla.abla_string_abla_fn_627837887_633683867_335.native.bytes,"aMS",@progbits,1,unique,9
	.p2align	3, 0x0
.Labla_string_abla_fn_627837887_633683867_335.native.bytes:
	.asciz	"I app_init: App version:      "
	.size	.Labla_string_abla_fn_627837887_633683867_335.native.bytes, 31

	.type	.Labla_string_abla_fn_627837887_633683867_338.native.bytes,@object # @abla_string_abla_fn_627837887_633683867_338.native.bytes
	.section	.rodata.abla.abla_string_abla_fn_627837887_633683867_338.native.bytes,"aMS",@progbits,1,unique,10
	.p2align	3, 0x0
.Labla_string_abla_fn_627837887_633683867_338.native.bytes:
	.asciz	"I app_init: Compile time:     "
	.size	.Labla_string_abla_fn_627837887_633683867_338.native.bytes, 31

	.type	.Labla_string_abla_fn_627837887_633683867_341.native.bytes,@object # @abla_string_abla_fn_627837887_633683867_341.native.bytes
	.section	.rodata.abla.abla_string_abla_fn_627837887_633683867_341.native.bytes,"aMS",@progbits,1,unique,11
	.p2align	3, 0x0
.Labla_string_abla_fn_627837887_633683867_341.native.bytes:
	.asciz	"I app_init: ELF file SHA256:  "
	.size	.Labla_string_abla_fn_627837887_633683867_341.native.bytes, 31

	.type	.Labla_string_abla_fn_627837887_633683867_344.native.bytes,@object # @abla_string_abla_fn_627837887_633683867_344.native.bytes
	.section	.rodata.abla.abla_string_abla_fn_627837887_633683867_344.native.bytes,"aMS",@progbits,1,unique,12
	.p2align	3, 0x0
.Labla_string_abla_fn_627837887_633683867_344.native.bytes:
	.asciz	"I app_init: ESP-IDF:          "
	.size	.Labla_string_abla_fn_627837887_633683867_344.native.bytes, 31

	.type	.Labla_string_abla_fn_627837887_633683867_347.native.bytes,@object # @abla_string_abla_fn_627837887_633683867_347.native.bytes
	.section	.rodata.abla.abla_string_abla_fn_627837887_633683867_347.native.bytes,"aMS",@progbits,1,unique,13
	.p2align	3, 0x0
.Labla_string_abla_fn_627837887_633683867_347.native.bytes:
	.asciz	"...\n"
	.size	.Labla_string_abla_fn_627837887_633683867_347.native.bytes, 5

	.type	abla_esp32_system_init_20_show_app_info,@object # @abla_esp32_system_init_20_show_app_info
	.section	.esp_system_init_fn.20,"aR",@progbits,unique,14
	.p2align	2, 0x0
abla_esp32_system_init_20_show_app_info:
	.long	abla_fn_350989413_350671624_direct
	.long	1                               # 0x1
	.size	abla_esp32_system_init_20_show_app_info, 8

	.type	abla_static_abla_fn_627837887_633683867_419,@object # @abla_static_abla_fn_627837887_633683867_419
	.section	.bss.abla_static_abla_fn_627837887_633683867_419,"aw",@nobits
	.p2align	3, 0x0
abla_static_abla_fn_627837887_633683867_419:
	.space	32
	.size	abla_static_abla_fn_627837887_633683867_419, 32

	.type	abla_static_abla_fn_627837887_633683867_425.0,@object # @abla_static_abla_fn_627837887_633683867_425.0
	.section	.bss.abla_static_abla_fn_627837887_633683867_425.0,"aw",@nobits
	.p2align	3, 0x0
abla_static_abla_fn_627837887_633683867_425.0:
	.long	0                               # 0x0
	.size	abla_static_abla_fn_627837887_633683867_425.0, 4

	.type	abla_static_abla_fn_627837887_633683867_431,@object # @abla_static_abla_fn_627837887_633683867_431
	.section	.bss.abla_static_abla_fn_627837887_633683867_431,"aw",@nobits
	.p2align	3, 0x0
abla_static_abla_fn_627837887_633683867_431:
	.space	4
	.size	abla_static_abla_fn_627837887_633683867_431, 4

	.type	.Labla_string_abla_fn_627837887_633683867_484.native.mutable.u32s,@object # @abla_string_abla_fn_627837887_633683867_484.native.mutable.u32s
	.section	.data..Labla_string_abla_fn_627837887_633683867_484.native.mutable.u32s,"aw",@progbits
	.p2align	2, 0x0
.Labla_string_abla_fn_627837887_633683867_484.native.mutable.u32s:
	.long	16776960                        # 0xffff00
	.long	4278255615                      # 0xff00ffff
	.long	4294902015                      # 0xffff00ff
	.long	16776960                        # 0xffff00
	.long	4278255615                      # 0xff00ffff
	.long	4294902015                      # 0xffff00ff
	.long	16776960                        # 0xffff00
	.long	4278255615                      # 0xff00ffff
	.long	4294902015                      # 0xffff00ff
	.long	16776960                        # 0xffff00
	.long	4278255615                      # 0xff00ffff
	.long	4294902015                      # 0xffff00ff
	.long	16776960                        # 0xffff00
	.long	4278255615                      # 0xff00ffff
	.long	4294902015                      # 0xffff00ff
	.long	16776960                        # 0xffff00
	.long	4278255615                      # 0xff00ffff
	.long	4294902015                      # 0xffff00ff
	.long	16776960                        # 0xffff00
	.long	4278255615                      # 0xff00ffff
	.long	4294902015                      # 0xffff00ff
	.long	16776960                        # 0xffff00
	.long	4278255615                      # 0xff00ffff
	.long	4294902015                      # 0xffff00ff
	.long	16776960                        # 0xffff00
	.long	4278255615                      # 0xff00ffff
	.long	4294902015                      # 0xffff00ff
	.long	16776960                        # 0xffff00
	.long	4278255615                      # 0xff00ffff
	.long	4294902015                      # 0xffff00ff
	.long	16776960                        # 0xffff00
	.long	4278255615                      # 0xff00ffff
	.long	4294902015                      # 0xffff00ff
	.long	16776960                        # 0xffff00
	.long	4278255615                      # 0xff00ffff
	.long	4294902015                      # 0xffff00ff
	.long	16776960                        # 0xffff00
	.long	4278255615                      # 0xff00ffff
	.long	4294902015                      # 0xffff00ff
	.long	16776960                        # 0xffff00
	.long	4278255615                      # 0xff00ffff
	.long	4294902015                      # 0xffff00ff
	.long	16776960                        # 0xffff00
	.long	4278255615                      # 0xff00ffff
	.long	4294902015                      # 0xffff00ff
	.long	16776960                        # 0xffff00
	.long	4278255615                      # 0xff00ffff
	.long	4294902015                      # 0xffff00ff
	.size	.Labla_string_abla_fn_627837887_633683867_484.native.mutable.u32s, 192

	.type	.Labla_string_abla_fn_627837887_633683867_489.native.bytes,@object # @abla_string_abla_fn_627837887_633683867_489.native.bytes
	.section	.rodata.abla.abla_string_abla_fn_627837887_633683867_489.native.bytes,"aMS",@progbits,1,unique,15
	.p2align	3, 0x0
.Labla_string_abla_fn_627837887_633683867_489.native.bytes:
	.asciz	"/"
	.size	.Labla_string_abla_fn_627837887_633683867_489.native.bytes, 2

	.type	.Labla_string_abla_fn_627837887_633683867_686.native.u32s,@object # @abla_string_abla_fn_627837887_633683867_686.native.u32s
	.section	.rodata..Labla_string_abla_fn_627837887_633683867_686.native.u32s,"a",@progbits
	.p2align	2, 0x0
.Labla_string_abla_fn_627837887_633683867_686.native.u32s:
	.long	3614090360                      # 0xd76aa478
	.long	3905402710                      # 0xe8c7b756
	.long	606105819                       # 0x242070db
	.long	3250441966                      # 0xc1bdceee
	.long	4118548399                      # 0xf57c0faf
	.long	1200080426                      # 0x4787c62a
	.long	2821735955                      # 0xa8304613
	.long	4249261313                      # 0xfd469501
	.long	1770035416                      # 0x698098d8
	.long	2336552879                      # 0x8b44f7af
	.long	4294925233                      # 0xffff5bb1
	.long	2304563134                      # 0x895cd7be
	.long	1804603682                      # 0x6b901122
	.long	4254626195                      # 0xfd987193
	.long	2792965006                      # 0xa679438e
	.long	1236535329                      # 0x49b40821
	.long	4129170786                      # 0xf61e2562
	.long	3225465664                      # 0xc040b340
	.long	643717713                       # 0x265e5a51
	.long	3921069994                      # 0xe9b6c7aa
	.long	3593408605                      # 0xd62f105d
	.long	38016083                        # 0x2441453
	.long	3634488961                      # 0xd8a1e681
	.long	3889429448                      # 0xe7d3fbc8
	.long	568446438                       # 0x21e1cde6
	.long	3275163606                      # 0xc33707d6
	.long	4107603335                      # 0xf4d50d87
	.long	1163531501                      # 0x455a14ed
	.long	2850285829                      # 0xa9e3e905
	.long	4243563512                      # 0xfcefa3f8
	.long	1735328473                      # 0x676f02d9
	.long	2368359562                      # 0x8d2a4c8a
	.long	4294588738                      # 0xfffa3942
	.long	2272392833                      # 0x8771f681
	.long	1839030562                      # 0x6d9d6122
	.long	4259657740                      # 0xfde5380c
	.long	2763975236                      # 0xa4beea44
	.long	1272893353                      # 0x4bdecfa9
	.long	4139469664                      # 0xf6bb4b60
	.long	3200236656                      # 0xbebfbc70
	.long	681279174                       # 0x289b7ec6
	.long	3936430074                      # 0xeaa127fa
	.long	3572445317                      # 0xd4ef3085
	.long	76029189                        # 0x4881d05
	.long	3654602809                      # 0xd9d4d039
	.long	3873151461                      # 0xe6db99e5
	.long	530742520                       # 0x1fa27cf8
	.long	3299628645                      # 0xc4ac5665
	.long	4096336452                      # 0xf4292244
	.long	1126891415                      # 0x432aff97
	.long	2878612391                      # 0xab9423a7
	.long	4237533241                      # 0xfc93a039
	.long	1700485571                      # 0x655b59c3
	.long	2399980690                      # 0x8f0ccc92
	.long	4293915773                      # 0xffeff47d
	.long	2240044497                      # 0x85845dd1
	.long	1873313359                      # 0x6fa87e4f
	.long	4264355552                      # 0xfe2ce6e0
	.long	2734768916                      # 0xa3014314
	.long	1309151649                      # 0x4e0811a1
	.long	4149444226                      # 0xf7537e82
	.long	3174756917                      # 0xbd3af235
	.long	718787259                       # 0x2ad7d2bb
	.long	3951481745                      # 0xeb86d391
	.size	.Labla_string_abla_fn_627837887_633683867_686.native.u32s, 256

	.type	.Labla_string_abla_fn_627837887_633683867_704.native.u32s,@object # @abla_string_abla_fn_627837887_633683867_704.native.u32s
	.section	.rodata..Labla_string_abla_fn_627837887_633683867_704.native.u32s,"a",@progbits
	.p2align	2, 0x0
.Labla_string_abla_fn_627837887_633683867_704.native.u32s:
	.long	7                               # 0x7
	.long	12                              # 0xc
	.long	17                              # 0x11
	.long	22                              # 0x16
	.long	5                               # 0x5
	.long	9                               # 0x9
	.long	14                              # 0xe
	.long	20                              # 0x14
	.long	4                               # 0x4
	.long	11                              # 0xb
	.long	16                              # 0x10
	.long	23                              # 0x17
	.long	6                               # 0x6
	.long	10                              # 0xa
	.long	15                              # 0xf
	.long	21                              # 0x15
	.size	.Labla_string_abla_fn_627837887_633683867_704.native.u32s, 64

	.type	abla_static_abla_fn_627837887_633683867_1325,@object # @abla_static_abla_fn_627837887_633683867_1325
	.section	.bss.abla_static_abla_fn_627837887_633683867_1325,"aw",@nobits
	.p2align	3, 0x0
abla_static_abla_fn_627837887_633683867_1325:
	.space	8
	.size	abla_static_abla_fn_627837887_633683867_1325, 8

	.type	.Labla_string_abla_fn_627837887_633683867_1332.native.mutable.u32s,@object # @abla_string_abla_fn_627837887_633683867_1332.native.mutable.u32s
	.section	.data..Labla_string_abla_fn_627837887_633683867_1332.native.mutable.u32s,"aw",@progbits
	.p2align	2, 0x0
.Labla_string_abla_fn_627837887_633683867_1332.native.mutable.u32s:
	.long	3007315967                      # 0xb33fffff
	.long	0                               # 0x0
	.size	.Labla_string_abla_fn_627837887_633683867_1332.native.mutable.u32s, 8

	.type	abla_static_abla_fn_627837887_633683867_1340,@object # @abla_static_abla_fn_627837887_633683867_1340
	.section	.bss.abla_static_abla_fn_627837887_633683867_1340,"aw",@nobits
	.p2align	3, 0x0
abla_static_abla_fn_627837887_633683867_1340:
	.space	8
	.size	abla_static_abla_fn_627837887_633683867_1340, 8

	.type	abla_static_abla_fn_627837887_633683867_1346,@object # @abla_static_abla_fn_627837887_633683867_1346
	.section	.bss.abla_static_abla_fn_627837887_633683867_1346,"aw",@nobits
	.p2align	3, 0x0
abla_static_abla_fn_627837887_633683867_1346:
	.space	4
	.size	abla_static_abla_fn_627837887_633683867_1346, 4

	.type	abla_static_abla_fn_627837887_633683867_1352,@object # @abla_static_abla_fn_627837887_633683867_1352
	.section	.bss.abla_static_abla_fn_627837887_633683867_1352,"aw",@nobits
	.p2align	3, 0x0
abla_static_abla_fn_627837887_633683867_1352:
	.space	4
	.size	abla_static_abla_fn_627837887_633683867_1352, 4

	.type	abla_static_abla_fn_627837887_633683867_1358,@object # @abla_static_abla_fn_627837887_633683867_1358
	.section	.bss.abla_static_abla_fn_627837887_633683867_1358,"aw",@nobits
	.p2align	3, 0x0
abla_static_abla_fn_627837887_633683867_1358:
	.space	20
	.size	abla_static_abla_fn_627837887_633683867_1358, 20

	.type	abla_static_abla_fn_627837887_633683867_1364,@object # @abla_static_abla_fn_627837887_633683867_1364
	.section	.bss.abla_static_abla_fn_627837887_633683867_1364,"aw",@nobits
	.p2align	3, 0x0
abla_static_abla_fn_627837887_633683867_1364:
	.space	40
	.size	abla_static_abla_fn_627837887_633683867_1364, 40

	.type	abla_static_abla_fn_627837887_633683867_1370,@object # @abla_static_abla_fn_627837887_633683867_1370
	.section	.bss.abla_static_abla_fn_627837887_633683867_1370,"aw",@nobits
	.p2align	3, 0x0
abla_static_abla_fn_627837887_633683867_1370:
	.space	4
	.size	abla_static_abla_fn_627837887_633683867_1370, 4

	.type	abla_static_abla_fn_627837887_633683867_1376,@object # @abla_static_abla_fn_627837887_633683867_1376
	.section	.bss.abla_static_abla_fn_627837887_633683867_1376,"aw",@nobits
	.p2align	3, 0x0
abla_static_abla_fn_627837887_633683867_1376:
	.space	500
	.size	abla_static_abla_fn_627837887_633683867_1376, 500

	.type	abla_static_abla_fn_627837887_633683867_1382,@object # @abla_static_abla_fn_627837887_633683867_1382
	.section	.bss.abla_static_abla_fn_627837887_633683867_1382,"aw",@nobits
	.p2align	3, 0x0
abla_static_abla_fn_627837887_633683867_1382:
	.space	20
	.size	abla_static_abla_fn_627837887_633683867_1382, 20

	.type	abla_static_abla_fn_627837887_633683867_1394,@object # @abla_static_abla_fn_627837887_633683867_1394
	.section	.bss.abla_static_abla_fn_627837887_633683867_1394,"aw",@nobits
	.p2align	3, 0x0
abla_static_abla_fn_627837887_633683867_1394:
	.space	4
	.size	abla_static_abla_fn_627837887_633683867_1394, 4

	.type	abla_static_abla_fn_627837887_633683867_1400,@object # @abla_static_abla_fn_627837887_633683867_1400
	.section	.bss.abla_static_abla_fn_627837887_633683867_1400,"aw",@nobits
	.p2align	3, 0x0
abla_static_abla_fn_627837887_633683867_1400:
	.space	4
	.size	abla_static_abla_fn_627837887_633683867_1400, 4

	.type	abla_static_abla_fn_627837887_633683867_1412,@object # @abla_static_abla_fn_627837887_633683867_1412
	.section	.bss.abla_static_abla_fn_627837887_633683867_1412,"aw",@nobits
	.p2align	3, 0x0
abla_static_abla_fn_627837887_633683867_1412:
	.space	8
	.size	abla_static_abla_fn_627837887_633683867_1412, 8

	.type	abla_static_abla_fn_627837887_633683867_1418,@object # @abla_static_abla_fn_627837887_633683867_1418
	.section	.bss.abla_static_abla_fn_627837887_633683867_1418,"aw",@nobits
	.p2align	3, 0x0
abla_static_abla_fn_627837887_633683867_1418:
	.space	4
	.size	abla_static_abla_fn_627837887_633683867_1418, 4

	.type	.Labla_string_abla_fn_627837887_633683867_1431.native.mutable.u32s,@object # @abla_string_abla_fn_627837887_633683867_1431.native.mutable.u32s
	.section	.data..Labla_string_abla_fn_627837887_633683867_1431.native.mutable.u32s,"aw",@progbits
	.p2align	2, 0x0
.Labla_string_abla_fn_627837887_633683867_1431.native.mutable.u32s:
	.long	3007315967                      # 0xb33fffff
	.long	0                               # 0x0
	.size	.Labla_string_abla_fn_627837887_633683867_1431.native.mutable.u32s, 8

	.type	.Labla_string_abla_fn_627837887_633683867_1441.native.bytes,@object # @abla_string_abla_fn_627837887_633683867_1441.native.bytes
	.section	.rodata.abla.abla_string_abla_fn_627837887_633683867_1441.native.bytes,"aMS",@progbits,1,unique,16
	.p2align	3, 0x0
.Labla_string_abla_fn_627837887_633683867_1441.native.bytes:
	.asciz	"<cached disabled>"
	.size	.Labla_string_abla_fn_627837887_633683867_1441.native.bytes, 18

	.type	.Labla_string_abla_fn_627837887_633683867_1444.native.bytes,@object # @abla_string_abla_fn_627837887_633683867_1444.native.bytes
	.section	.rodata.abla.abla_string_abla_fn_627837887_633683867_1444.native.bytes,"aMS",@progbits,1,unique,17
	.p2align	3, 0x0
.Labla_string_abla_fn_627837887_633683867_1444.native.bytes:
	.asciz	"assert failed: "
	.size	.Labla_string_abla_fn_627837887_633683867_1444.native.bytes, 16

	.type	.Labla_string_abla_fn_627837887_633683867_1447.native.bytes,@object # @abla_string_abla_fn_627837887_633683867_1447.native.bytes
	.section	.rodata.abla.abla_string_abla_fn_627837887_633683867_1447.native.bytes,"aMS",@progbits,1,unique,18
	.p2align	3, 0x0
.Labla_string_abla_fn_627837887_633683867_1447.native.bytes:
	.asciz	"\b"
	.size	.Labla_string_abla_fn_627837887_633683867_1447.native.bytes, 2

	.type	.Labla_string_abla_fn_627837887_633683867_1450.native.bytes,@object # @abla_string_abla_fn_627837887_633683867_1450.native.bytes
	.section	.rodata.abla.abla_string_abla_fn_627837887_633683867_1450.native.bytes,"aMS",@progbits,1,unique,19
	.p2align	3, 0x0
.Labla_string_abla_fn_627837887_633683867_1450.native.bytes:
	.asciz	" "
	.size	.Labla_string_abla_fn_627837887_633683867_1450.native.bytes, 2

	.type	.Labla_string_abla_fn_627837887_633683867_1453.native.bytes,@object # @abla_string_abla_fn_627837887_633683867_1453.native.bytes
	.section	.rodata.abla.abla_string_abla_fn_627837887_633683867_1453.native.bytes,"aMS",@progbits,1,unique,20
	.p2align	3, 0x0
.Labla_string_abla_fn_627837887_633683867_1453.native.bytes:
	.asciz	":"
	.size	.Labla_string_abla_fn_627837887_633683867_1453.native.bytes, 2

	.type	.Labla_string_abla_fn_627837887_633683867_1456.native.bytes,@object # @abla_string_abla_fn_627837887_633683867_1456.native.bytes
	.section	.rodata.abla.abla_string_abla_fn_627837887_633683867_1456.native.bytes,"aMS",@progbits,1,unique,21
	.p2align	3, 0x0
.Labla_string_abla_fn_627837887_633683867_1456.native.bytes:
	.asciz	" ("
	.size	.Labla_string_abla_fn_627837887_633683867_1456.native.bytes, 3

	.type	.Labla_string_abla_fn_627837887_633683867_1459.native.bytes,@object # @abla_string_abla_fn_627837887_633683867_1459.native.bytes
	.section	.rodata.abla.abla_string_abla_fn_627837887_633683867_1459.native.bytes,"aMS",@progbits,1,unique,22
	.p2align	3, 0x0
.Labla_string_abla_fn_627837887_633683867_1459.native.bytes:
	.asciz	")"
	.size	.Labla_string_abla_fn_627837887_633683867_1459.native.bytes, 2

	.type	abla_static_abla_fn_627837887_633683867_1495,@object # @abla_static_abla_fn_627837887_633683867_1495
	.section	.bss.abla_static_abla_fn_627837887_633683867_1495,"aw",@nobits
	.p2align	3, 0x0
abla_static_abla_fn_627837887_633683867_1495:
	.space	8
	.size	abla_static_abla_fn_627837887_633683867_1495, 8

	.type	abla_static_abla_fn_627837887_633683867_1501,@object # @abla_static_abla_fn_627837887_633683867_1501
	.section	.bss.abla_static_abla_fn_627837887_633683867_1501,"aw",@nobits
	.p2align	3, 0x0
abla_static_abla_fn_627837887_633683867_1501:
	.space	8
	.size	abla_static_abla_fn_627837887_633683867_1501, 8

	.type	.Labla_string_abla_fn_627837887_633683867_1506.native.bytes,@object # @abla_string_abla_fn_627837887_633683867_1506.native.bytes
	.section	.rodata.abla.abla_string_abla_fn_627837887_633683867_1506.native.bytes,"aMS",@progbits,1,unique,23
	.p2align	3, 0x0
.Labla_string_abla_fn_627837887_633683867_1506.native.bytes:
	.asciz	"spinlock_acquire"
	.size	.Labla_string_abla_fn_627837887_633683867_1506.native.bytes, 17

	.type	.Labla_string_abla_fn_627837887_633683867_1513.native.bytes,@object # @abla_string_abla_fn_627837887_633683867_1513.native.bytes
	.section	.rodata.abla.abla_string_abla_fn_627837887_633683867_1513.native.bytes,"aMS",@progbits,1,unique,24
	.p2align	3, 0x0
.Labla_string_abla_fn_627837887_633683867_1513.native.bytes:
	.asciz	"spinlock_release"
	.size	.Labla_string_abla_fn_627837887_633683867_1513.native.bytes, 17

	.type	.Labla_string_abla_fn_627837887_633683867_1520.native.bytes,@object # @abla_string_abla_fn_627837887_633683867_1520.native.bytes
	.section	.rodata.abla.abla_string_abla_fn_627837887_633683867_1520.native.bytes,"a",@progbits
	.p2align	3, 0x0
.Labla_string_abla_fn_627837887_633683867_1520.native.bytes:
	.asciz	"vPortExitCritica\000"
	.size	.Labla_string_abla_fn_627837887_633683867_1520.native.bytes, 18

	.type	.Labla_string_abla_fn_627837887_633683867_1527.native.bytes,@object # @abla_string_abla_fn_627837887_633683867_1527.native.bytes
	.section	.rodata.abla.abla_string_abla_fn_627837887_633683867_1527.native.bytes,"a",@progbits
	.p2align	3, 0x0
.Labla_string_abla_fn_627837887_633683867_1527.native.bytes:
	.asciz	"(uxStackPointer & ( 0x000f )) == 0\000\000//IDF/components/freertos/FreeRTOS-Kernel/portable/xtensa/port.c"
	.size	.Labla_string_abla_fn_627837887_633683867_1527.native.bytes, 101

	.type	.Labla_string_abla_fn_627837887_633683867_1534.native.bytes,@object # @abla_string_abla_fn_627837887_633683867_1534.native.bytes
	.section	.rodata.abla.abla_string_abla_fn_627837887_633683867_1534.native.bytes,"a",@progbits
	.p2align	3, 0x0
.Labla_string_abla_fn_627837887_633683867_1534.native.bytes:
	.asciz	"core_owner_id == lock->owner\000\000\000\000lock->count < 0x100\000nesting > 0"
	.size	.Labla_string_abla_fn_627837887_633683867_1534.native.bytes, 64

	.type	.Labla_string_abla_fn_627837887_633683867_1541.native.bytes,@object # @abla_string_abla_fn_627837887_633683867_1541.native.bytes
	.section	.rodata.abla.abla_string_abla_fn_627837887_633683867_1541.native.bytes,"a",@progbits
	.p2align	3, 0x0
.Labla_string_abla_fn_627837887_633683867_1541.native.bytes:
	.asciz	"lock\000\000\000\000//IDF/components/esp_hw_support/include/spinlock.h\000\000lock->count > 0 && lock->count < 0xFF\000\000\000lock->owner == core_owner_id\000\000\000\000lock->count == 0\000\000\000\000lock->owner == SPINLOCK_FREE || lock->owner == other_core_owner_id\000\000lock->count < 0x\000\000"
	.size	.Labla_string_abla_fn_627837887_633683867_1541.native.bytes, 239

	.type	.Labla_string_abla_fn_627837887_633683867_1597.native.bytes,@object # @abla_string_abla_fn_627837887_633683867_1597.native.bytes
	.section	.rodata.abla.abla_string_abla_fn_627837887_633683867_1597.native.bytes,"a",@progbits
	.p2align	3, 0x0
.Labla_string_abla_fn_627837887_633683867_1597.native.bytes:
	.asciz	"mems\000\000"
	.size	.Labla_string_abla_fn_627837887_633683867_1597.native.bytes, 7

	.type	.Labla_string_abla_fn_627837887_633683867_1604.native.bytes,@object # @abla_string_abla_fn_627837887_633683867_1604.native.bytes
	.section	.rodata.abla.abla_string_abla_fn_627837887_633683867_1604.native.bytes,"a",@progbits
	.p2align	3, 0x0
.Labla_string_abla_fn_627837887_633683867_1604.native.bytes:
	.asciz	"E (%lu) %s: no response\n\000"
	.size	.Labla_string_abla_fn_627837887_633683867_1604.native.bytes, 26

	.type	.Labla_string_abla_fn_627837887_633683867_1675.native.mutable.u32s,@object # @abla_string_abla_fn_627837887_633683867_1675.native.mutable.u32s
	.section	.data..Labla_string_abla_fn_627837887_633683867_1675.native.mutable.u32s,"aw",@progbits
	.p2align	2, 0x0
.Labla_string_abla_fn_627837887_633683867_1675.native.mutable.u32s:
	.long	abla_fn_356122711_422489762_direct
	.long	abla_fn_408654605_297463740_direct
	.long	abla_fn_657068560_251506979_direct
	.long	abla_fn_211640061_192638264_direct
	.long	abla_fn_388532938_210786097_direct
	.long	abla_fn_915500565_990736757_direct
	.long	abla_fn_841534189_540168598_direct
	.long	abla_fn_641427985_702920430_direct
	.long	abla_fn_320681036_795427026_direct
	.long	abla_fn_844637847_768207836_direct
	.long	abla_fn_548196426_722170064_direct
	.long	abla_fn_825130761_53798174_direct
	.long	abla_fn_215460651_430198619_direct
	.long	abla_fn_770566306_790016489_direct
	.long	abla_fn_962365924_831598467_direct
	.long	abla_fn_797348383_613908390_direct
	.long	abla_fn_204109230_234273409_direct
	.long	abla_fn_127496518_302417924_direct
	.long	0                               # 0x0
	.long	abla_fn_174183453_688535431_direct
	.long	abla_fn_597847875_749602468_direct
	.long	abla_fn_590569238_852306334_direct
	.size	.Labla_string_abla_fn_627837887_633683867_1675.native.mutable.u32s, 88

	.type	.Labla_string_abla_fn_627837887_633683867_1707.native.mutable.u32s,@object # @abla_string_abla_fn_627837887_633683867_1707.native.mutable.u32s
	.section	.data..Labla_string_abla_fn_627837887_633683867_1707.native.mutable.u32s,"aw",@progbits
	.p2align	2, 0x0
.Labla_string_abla_fn_627837887_633683867_1707.native.mutable.u32s:
	.long	abla_fn_673055136_650356638_direct
	.long	abla_fn_243591001_677668472_direct
	.long	0                               # 0x0
	.long	abla_fn_225896877_719081260_direct
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	0                               # 0x0
	.size	.Labla_string_abla_fn_627837887_633683867_1707.native.mutable.u32s, 40

	.type	.Labla_string_abla_fn_627837887_633683867_1722.native.bytes,@object # @abla_string_abla_fn_627837887_633683867_1722.native.bytes
	.section	.rodata.abla.abla_string_abla_fn_627837887_633683867_1722.native.bytes,"a",@progbits
	.p2align	3, 0x0
.Labla_string_abla_fn_627837887_633683867_1722.native.bytes:
	.asciz	"DRAM\000\000\000\000D/IRAM\000\000IRAM\000\000\000\000SPIRAM\000\000RTCR\000\000"
	.size	.Labla_string_abla_fn_627837887_633683867_1722.native.bytes, 39

	.type	.Labla_string_abla_fn_627837887_633683867_1952.native.mutable.u32s,@object # @abla_string_abla_fn_627837887_633683867_1952.native.mutable.u32s
	.section	.data..Labla_string_abla_fn_627837887_633683867_1952.native.mutable.u32s,"aw",@progbits
	.p2align	2, 0x0
.Labla_string_abla_fn_627837887_633683867_1952.native.mutable.u32s:
	.long	1073405952                      # 0x3ffae000
	.long	8192                            # 0x2000
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	1073414144                      # 0x3ffb0000
	.long	32768                           # 0x8000
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	1073446912                      # 0x3ffb8000
	.long	32768                           # 0x8000
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	1073479680                      # 0x3ffc0000
	.long	8192                            # 0x2000
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	1073487872                      # 0x3ffc2000
	.long	8192                            # 0x2000
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	1073496064                      # 0x3ffc4000
	.long	8192                            # 0x2000
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	1073504256                      # 0x3ffc6000
	.long	8192                            # 0x2000
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	1073512448                      # 0x3ffc8000
	.long	8192                            # 0x2000
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	1073520640                      # 0x3ffca000
	.long	8192                            # 0x2000
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	1073528832                      # 0x3ffcc000
	.long	8192                            # 0x2000
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	1073537024                      # 0x3ffce000
	.long	8192                            # 0x2000
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	1073545216                      # 0x3ffd0000
	.long	8192                            # 0x2000
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	1073553408                      # 0x3ffd2000
	.long	8192                            # 0x2000
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	1073561600                      # 0x3ffd4000
	.long	8192                            # 0x2000
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	1073569792                      # 0x3ffd6000
	.long	8192                            # 0x2000
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	1073577984                      # 0x3ffd8000
	.long	8192                            # 0x2000
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	1073586176                      # 0x3ffda000
	.long	8192                            # 0x2000
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	1073594368                      # 0x3ffdc000
	.long	8192                            # 0x2000
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	1073602560                      # 0x3ffde000
	.long	8192                            # 0x2000
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	1073610752                      # 0x3ffe0000
	.long	16384                           # 0x4000
	.long	1                               # 0x1
	.long	1074511872                      # 0x400bc000
	.long	1                               # 0x1
	.long	1073627136                      # 0x3ffe4000
	.long	16384                           # 0x4000
	.long	1                               # 0x1
	.long	1074495488                      # 0x400b8000
	.long	1                               # 0x1
	.long	1073643520                      # 0x3ffe8000
	.long	32768                           # 0x8000
	.long	1                               # 0x1
	.long	1074462720                      # 0x400b0000
	.long	1                               # 0x1
	.long	1073676288                      # 0x3fff0000
	.long	32768                           # 0x8000
	.long	1                               # 0x1
	.long	1074429952                      # 0x400a8000
	.long	1                               # 0x1
	.long	1073709056                      # 0x3fff8000
	.long	16384                           # 0x4000
	.long	1                               # 0x1
	.long	1074413568                      # 0x400a4000
	.long	1                               # 0x1
	.long	1073725440                      # 0x3fffc000
	.long	16384                           # 0x4000
	.long	1                               # 0x1
	.long	1074397184                      # 0x400a0000
	.long	1                               # 0x1
	.long	1074200576                      # 0x40070000
	.long	32768                           # 0x8000
	.long	2                               # 0x2
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	1074233344                      # 0x40078000
	.long	32768                           # 0x8000
	.long	2                               # 0x2
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	1074266112                      # 0x40080000
	.long	8192                            # 0x2000
	.long	2                               # 0x2
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	1074274304                      # 0x40082000
	.long	8192                            # 0x2000
	.long	2                               # 0x2
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	1074282496                      # 0x40084000
	.long	8192                            # 0x2000
	.long	2                               # 0x2
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	1074290688                      # 0x40086000
	.long	8192                            # 0x2000
	.long	2                               # 0x2
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	1074298880                      # 0x40088000
	.long	8192                            # 0x2000
	.long	2                               # 0x2
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	1074307072                      # 0x4008a000
	.long	8192                            # 0x2000
	.long	2                               # 0x2
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	1074315264                      # 0x4008c000
	.long	8192                            # 0x2000
	.long	2                               # 0x2
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	1074323456                      # 0x4008e000
	.long	8192                            # 0x2000
	.long	2                               # 0x2
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	1074331648                      # 0x40090000
	.long	8192                            # 0x2000
	.long	2                               # 0x2
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	1074339840                      # 0x40092000
	.long	8192                            # 0x2000
	.long	2                               # 0x2
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	1074348032                      # 0x40094000
	.long	8192                            # 0x2000
	.long	2                               # 0x2
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	1074356224                      # 0x40096000
	.long	8192                            # 0x2000
	.long	2                               # 0x2
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	1074364416                      # 0x40098000
	.long	8192                            # 0x2000
	.long	2                               # 0x2
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	1074372608                      # 0x4009a000
	.long	8192                            # 0x2000
	.long	2                               # 0x2
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	1074380800                      # 0x4009c000
	.long	8192                            # 0x2000
	.long	2                               # 0x2
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	1074388992                      # 0x4009e000
	.long	8192                            # 0x2000
	.long	2                               # 0x2
	.long	0                               # 0x0
	.long	0                               # 0x0
	.size	.Labla_string_abla_fn_627837887_633683867_1952.native.mutable.u32s, 860

	.type	.Labla_string_abla_fn_627837887_633683867_2000.native.mutable.u32s,@object # @abla_string_abla_fn_627837887_633683867_2000.native.mutable.u32s
	.section	.data..Labla_string_abla_fn_627837887_633683867_2000.native.mutable.u32s,"aw",@progbits
	.p2align	2, 0x0
.Labla_string_abla_fn_627837887_633683867_2000.native.mutable.u32s:
	.long	.Labla_string_abla_fn_627837887_633683867_1722.native.bytes
	.long	4100                            # 0x1004
	.long	2058                            # 0x80a
	.long	0                               # 0x0
	.long	.Labla_string_abla_fn_627837887_633683867_1722.native.bytes+8
	.long	0                               # 0x0
	.long	6156                            # 0x180c
	.long	3                               # 0x3
	.long	.Labla_string_abla_fn_627837887_633683867_1722.native.bytes+16
	.long	2051                            # 0x803
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	.Labla_string_abla_fn_627837887_633683867_1722.native.bytes+24
	.long	5120                            # 0x1400
	.long	0                               # 0x0
	.long	6                               # 0x6
	.long	.Labla_string_abla_fn_627837887_633683867_1722.native.bytes+32
	.long	32768                           # 0x8000
	.long	4100                            # 0x1004
	.long	2051                            # 0x803
	.size	.Labla_string_abla_fn_627837887_633683867_2000.native.mutable.u32s, 80

	.type	.Labla_string_abla_fn_627837887_633683867_2033.native.mutable.u32s,@object # @abla_string_abla_fn_627837887_633683867_2033.native.mutable.u32s
	.section	.data..Labla_string_abla_fn_627837887_633683867_2033.native.mutable.u32s,"aw",@progbits
	.p2align	2, 0x0
.Labla_string_abla_fn_627837887_633683867_2033.native.mutable.u32s:
	.long	_rtc_fast_reserved_start
	.long	_rtc_fast_reserved_end
	.long	1073405952                      # 0x3ffae000
	.long	1073407712                      # 0x3ffae6e0
	.long	_data_start
	.long	_heap_start
	.long	1073610752                      # 0x3ffe0000
	.long	1073611840                      # 0x3ffe0440
	.long	1073626912                      # 0x3ffe3f20
	.long	1073627984                      # 0x3ffe4350
	.long	1074200576                      # 0x40070000
	.long	1074233344                      # 0x40078000
	.long	1074233344                      # 0x40078000
	.long	1074266112                      # 0x40080000
	.long	_iram_start
	.long	_iram_end
	.long	_rtc_slow_reserved_start
	.long	_rtc_slow_reserved_end
	.size	.Labla_string_abla_fn_627837887_633683867_2033.native.mutable.u32s, 72

	.type	abla_static_abla_fn_627837887_633683867_2081,@object # @abla_static_abla_fn_627837887_633683867_2081
	.section	.bss.abla_static_abla_fn_627837887_633683867_2081,"aw",@nobits
	.p2align	3, 0x0
abla_static_abla_fn_627837887_633683867_2081:
	.space	1040
	.size	abla_static_abla_fn_627837887_633683867_2081, 1040

	.type	abla_static_abla_fn_627837887_633683867_2084,@object # @abla_static_abla_fn_627837887_633683867_2084
	.section	.bss.abla_static_abla_fn_627837887_633683867_2084,"aw",@nobits
	.p2align	3, 0x0
abla_static_abla_fn_627837887_633683867_2084:
	.space	576
	.size	abla_static_abla_fn_627837887_633683867_2084, 576

	.type	abla_esp32_system_init_100_init_heap,@object # @abla_esp32_system_init_100_init_heap
	.section	.esp_system_init_fn.100,"aR",@progbits,unique,25
	.p2align	2, 0x0
abla_esp32_system_init_100_init_heap:
	.long	abla_fn_338872068_789649821_direct
	.long	1                               # 0x1
	.size	abla_esp32_system_init_100_init_heap, 8

	.type	abla_static_abla_fn_627837887_633683867_2145,@object # @abla_static_abla_fn_627837887_633683867_2145
	.section	.bss.abla_static_abla_fn_627837887_633683867_2145,"aw",@nobits
	.p2align	3, 0x0
abla_static_abla_fn_627837887_633683867_2145:
	.space	8
	.size	abla_static_abla_fn_627837887_633683867_2145, 8

	.type	abla_static_abla_fn_627837887_633683867_2151,@object # @abla_static_abla_fn_627837887_633683867_2151
	.section	.bss.abla_static_abla_fn_627837887_633683867_2151,"aw",@nobits
	.p2align	3, 0x0
abla_static_abla_fn_627837887_633683867_2151:
	.space	2
	.size	abla_static_abla_fn_627837887_633683867_2151, 2

	.type	abla_static_abla_fn_627837887_633683867_2157,@object # @abla_static_abla_fn_627837887_633683867_2157
	.section	.bss.abla_static_abla_fn_627837887_633683867_2157,"aw",@nobits
	.p2align	3, 0x0
abla_static_abla_fn_627837887_633683867_2157:
	.space	8
	.size	abla_static_abla_fn_627837887_633683867_2157, 8

	.type	.Labla_string_abla_fn_627837887_633683867_2164.native.mutable.u32s,@object # @abla_string_abla_fn_627837887_633683867_2164.native.mutable.u32s
	.section	.data..Labla_string_abla_fn_627837887_633683867_2164.native.mutable.u32s,"aw",@progbits
	.p2align	2, 0x0
.Labla_string_abla_fn_627837887_633683867_2164.native.mutable.u32s:
	.long	3007315967                      # 0xb33fffff
	.long	0                               # 0x0
	.size	.Labla_string_abla_fn_627837887_633683867_2164.native.mutable.u32s, 8

	.type	.Labla_string_abla_fn_627837887_633683867_2208.native.mutable.u32s,@object # @abla_string_abla_fn_627837887_633683867_2208.native.mutable.u32s
	.section	.data..Labla_string_abla_fn_627837887_633683867_2208.native.mutable.u32s,"aw",@progbits
	.p2align	2, 0x0
.Labla_string_abla_fn_627837887_633683867_2208.native.mutable.u32s:
	.long	abla_fn_944518206_913693093_direct
	.long	0                               # 0x0
	.size	.Labla_string_abla_fn_627837887_633683867_2208.native.mutable.u32s, 8

	.type	.Labla_string_abla_fn_627837887_633683867_2241.native.bytes,@object # @abla_string_abla_fn_627837887_633683867_2241.native.bytes
	.section	.rodata.abla.abla_string_abla_fn_627837887_633683867_2241.native.bytes,"aMS",@progbits,1,unique,26
	.p2align	3, 0x0
.Labla_string_abla_fn_627837887_633683867_2241.native.bytes:
	.asciz	"cache_ll_l1_get_bus"
	.size	.Labla_string_abla_fn_627837887_633683867_2241.native.bytes, 20

	.type	abla_static_abla_fn_627837887_633683867_2249,@object # @abla_static_abla_fn_627837887_633683867_2249
	.section	.bss.abla_static_abla_fn_627837887_633683867_2249,"aw",@nobits
	.p2align	3, 0x0
abla_static_abla_fn_627837887_633683867_2249:
	.space	128
	.size	abla_static_abla_fn_627837887_633683867_2249, 128

	.type	.Labla_string_abla_fn_627837887_633683867_2260.native.bytes,@object # @abla_string_abla_fn_627837887_633683867_2260.native.bytes
	.section	.rodata.abla.abla_string_abla_fn_627837887_633683867_2260.native.bytes,"aMS",@progbits,1,unique,27
	.p2align	3, 0x0
.Labla_string_abla_fn_627837887_633683867_2260.native.bytes:
	.asciz	"esp_mmu_map"
	.size	.Labla_string_abla_fn_627837887_633683867_2260.native.bytes, 12

	.type	.Labla_string_abla_fn_627837887_633683867_2267.native.bytes,@object # @abla_string_abla_fn_627837887_633683867_2267.native.bytes
	.section	.rodata.abla.abla_string_abla_fn_627837887_633683867_2267.native.bytes,"aMS",@progbits,1,unique,28
	.p2align	3, 0x0
.Labla_string_abla_fn_627837887_633683867_2267.native.bytes:
	.asciz	"esp_mmu_map"
	.size	.Labla_string_abla_fn_627837887_633683867_2267.native.bytes, 12

	.type	.Labla_string_abla_fn_627837887_633683867_2274.native.bytes,@object # @abla_string_abla_fn_627837887_633683867_2274.native.bytes
	.section	.rodata.abla.abla_string_abla_fn_627837887_633683867_2274.native.bytes,"a",@progbits
	.p2align	3, 0x0
.Labla_string_abla_fn_627837887_633683867_2274.native.bytes:
	.asciz	"esp_mmu_unma\000"
	.size	.Labla_string_abla_fn_627837887_633683867_2274.native.bytes, 14

	.type	.Labla_string_abla_fn_627837887_633683867_2281.native.bytes,@object # @abla_string_abla_fn_627837887_633683867_2281.native.bytes
	.section	.rodata.abla.abla_string_abla_fn_627837887_633683867_2281.native.bytes,"a",@progbits
	.p2align	3, 0x0
.Labla_string_abla_fn_627837887_633683867_2281.native.bytes:
	.asciz	"esp_mmu_vaddr_to_pad\000\000"
	.size	.Labla_string_abla_fn_627837887_633683867_2281.native.bytes, 23

	.type	.Labla_string_abla_fn_627837887_633683867_2288.native.bytes,@object # @abla_string_abla_fn_627837887_633683867_2288.native.bytes
	.section	.rodata.abla.abla_string_abla_fn_627837887_633683867_2288.native.bytes,"a",@progbits
	.p2align	3, 0x0
.Labla_string_abla_fn_627837887_633683867_2288.native.bytes:
	.asciz	"E (%lu) %s: %s(%d): PSRAM is not supported\n\000E (%lu) %s: %s(%d): paddr must be rounded up to the nearest multiple of CONFIG_MMU_PAGE_SIZE\n\000\000\000E (%lu) %s: %s(%d): no such vaddr range\n\000\000\000\000E (%lu) %s: %s(%d): no mem\n\000E (%lu) %s: %s(%d): paddr block is overlapped with an already mapped paddr block\n\000\000\000foun\000"
	.size	.Labla_string_abla_fn_627837887_633683867_2288.native.bytes, 302

	.type	.Labla_string_abla_fn_627837887_633683867_2295.native.bytes,@object # @abla_string_abla_fn_627837887_633683867_2295.native.bytes
	.section	.rodata.abla.abla_string_abla_fn_627837887_633683867_2295.native.bytes,"a",@progbits
	.p2align	3, 0x0
.Labla_string_abla_fn_627837887_633683867_2295.native.bytes:
	.asciz	"E (%lu) %s: %s(%d): null pointer\n\000\000\000E (%lu) %s: %s(%d): invalid caps\000"
	.size	.Labla_string_abla_fn_627837887_633683867_2295.native.bytes, 70

	.type	.Labla_string_abla_fn_627837887_633683867_2302.native.bytes,@object # @abla_string_abla_fn_627837887_633683867_2302.native.bytes
	.section	.rodata.abla.abla_string_abla_fn_627837887_633683867_2302.native.bytes,"a",@progbits
	.p2align	3, 0x0
.Labla_string_abla_fn_627837887_633683867_2302.native.bytes:
	.asciz	"E (%lu) %s: %s(%d): munmap target pointer is outside external memory regions\n\000\000\000E (%lu) %s: %s(%d): munmap target pointer isn't mapped yet\n"
	.size	.Labla_string_abla_fn_627837887_633683867_2302.native.bytes, 140

	.type	.Labla_string_abla_fn_627837887_633683867_2309.native.bytes,@object # @abla_string_abla_fn_627837887_633683867_2309.native.bytes
	.section	.rodata.abla.abla_string_abla_fn_627837887_633683867_2309.native.bytes,"a",@progbits
	.p2align	3, 0x0
.Labla_string_abla_fn_627837887_633683867_2309.native.bytes:
	.asciz	"E (%lu) %s: %s(%d): not a valid external virtual address\n\000\000\000E (%lu) %s: %s(%d): vaddr isn't mapped\n"
	.size	.Labla_string_abla_fn_627837887_633683867_2309.native.bytes, 100

	.type	.Labla_string_abla_fn_627837887_633683867_2316.native.bytes,@object # @abla_string_abla_fn_627837887_633683867_2316.native.bytes
	.section	.rodata.abla.abla_string_abla_fn_627837887_633683867_2316.native.bytes,"a",@progbits
	.p2align	3, 0x0
.Labla_string_abla_fn_627837887_633683867_2316.native.bytes:
	.asciz	"false\000\000\000/IDF/components/hal/esp32/include/hal/cache_ll.h\000\000\000\000vaddr_end < SOC_DRAM1_CACHE_ADDRESS_HIGH\000\000\000\000vaddr_end < SOC_DROM0_CACHE_ADDRESS_HIGH"
	.size	.Labla_string_abla_fn_627837887_633683867_2316.native.bytes, 145

	.type	.Labla_string_abla_fn_627837887_633683867_2323.native.bytes,@object # @abla_string_abla_fn_627837887_633683867_2323.native.bytes
	.section	.rodata.abla.abla_string_abla_fn_627837887_633683867_2323.native.bytes,"a",@progbits
	.p2align	3, 0x0
.Labla_string_abla_fn_627837887_633683867_2323.native.bytes:
	.asciz	"(mmu_ll_vaddr_to_laddr((uint32_t)&_instruction_reserved_end) - mmu_ll_vaddr_to_laddr((uint32_t)&_instruction_reserved_start)) == irom_len_to_reserve\000\000\000\000//IDF/components/esp_mm/esp_mmu_map.\000"
	.size	.Labla_string_abla_fn_627837887_633683867_2323.native.bytes, 190

	.type	.Labla_string_abla_fn_627837887_633683867_2330.native.bytes,@object # @abla_string_abla_fn_627837887_633683867_2330.native.bytes
	.section	.rodata.abla.abla_string_abla_fn_627837887_633683867_2330.native.bytes,"aMS",@progbits,1,unique,29
	.p2align	3, 0x0
.Labla_string_abla_fn_627837887_633683867_2330.native.bytes:
	.asciz	"mmap"
	.size	.Labla_string_abla_fn_627837887_633683867_2330.native.bytes, 5

	.type	abla_global_447666338_361957421,@object # @abla_global_447666338_361957421
	.section	.bss.abla_global_447666338_361957421,"aw",@nobits
	.p2align	2, 0x0
abla_global_447666338_361957421:
	.byte	0                               # 0x0
	.size	abla_global_447666338_361957421, 1

	.type	.Labla_string_abla_fn_627837887_633683867_2468.native.mutable.u32s,@object # @abla_string_abla_fn_627837887_633683867_2468.native.mutable.u32s
	.section	.data..Labla_string_abla_fn_627837887_633683867_2468.native.mutable.u32s,"aw",@progbits
	.p2align	2, 0x0
.Labla_string_abla_fn_627837887_633683867_2468.native.mutable.u32s:
	.long	1072955392                      # 0x3ff40000
	.long	1073020928                      # 0x3ff50000
	.long	1073143808                      # 0x3ff6e000
	.size	.Labla_string_abla_fn_627837887_633683867_2468.native.mutable.u32s, 12

	.type	.Labla_string_abla_fn_627837887_633683867_2569.native.mutable.u32s,@object # @abla_string_abla_fn_627837887_633683867_2569.native.mutable.u32s
	.section	.data..Labla_string_abla_fn_627837887_633683867_2569.native.mutable.u32s,"aw",@progbits
	.p2align	2, 0x0
.Labla_string_abla_fn_627837887_633683867_2569.native.mutable.u32s:
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	4294967295                      # 0xffffffff
	.long	4294967295                      # 0xffffffff
	.long	4294967295                      # 0xffffffff
	.long	4294967295                      # 0xffffffff
	.long	4294967295                      # 0xffffffff
	.long	4294967295                      # 0xffffffff
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	4294967295                      # 0xffffffff
	.long	4294967295                      # 0xffffffff
	.long	4294967295                      # 0xffffffff
	.long	4294967295                      # 0xffffffff
	.long	4294967295                      # 0xffffffff
	.long	4294967295                      # 0xffffffff
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	4294967295                      # 0xffffffff
	.long	4294967295                      # 0xffffffff
	.long	4294967295                      # 0xffffffff
	.long	4294967295                      # 0xffffffff
	.long	4294967295                      # 0xffffffff
	.long	4294967295                      # 0xffffffff
	.long	0                               # 0x0
	.size	.Labla_string_abla_fn_627837887_633683867_2569.native.mutable.u32s, 384

	.type	.Labla_string_abla_fn_627837887_633683867_2576.native.mutable.u32s,@object # @abla_string_abla_fn_627837887_633683867_2576.native.mutable.u32s
	.section	.data..Labla_string_abla_fn_627837887_633683867_2576.native.mutable.u32s,"aw",@progbits
	.p2align	2, 0x0
.Labla_string_abla_fn_627837887_633683867_2576.native.mutable.u32s:
	.long	3007315967                      # 0xb33fffff
	.long	0                               # 0x0
	.size	.Labla_string_abla_fn_627837887_633683867_2576.native.mutable.u32s, 8

	.type	.Labla_string_abla_fn_627837887_633683867_2605.native.mutable.u32s,@object # @abla_string_abla_fn_627837887_633683867_2605.native.mutable.u32s
	.section	.data..Labla_string_abla_fn_627837887_633683867_2605.native.mutable.u32s,"aw",@progbits
	.p2align	2, 0x0
.Labla_string_abla_fn_627837887_633683867_2605.native.mutable.u32s:
	.long	1072955392                      # 0x3ff40000
	.long	1073020928                      # 0x3ff50000
	.long	1073143808                      # 0x3ff6e000
	.size	.Labla_string_abla_fn_627837887_633683867_2605.native.mutable.u32s, 12

	.type	.Labla_string_abla_fn_627837887_633683867_2613.native.mutable.u32s,@object # @abla_string_abla_fn_627837887_633683867_2613.native.mutable.u32s
	.section	.data..Labla_string_abla_fn_627837887_633683867_2613.native.mutable.u32s,"aw",@progbits
	.p2align	2, 0x0
.Labla_string_abla_fn_627837887_633683867_2613.native.mutable.u32s:
	.space	12,255
	.size	.Labla_string_abla_fn_627837887_633683867_2613.native.mutable.u32s, 12

	.type	abla_static_abla_fn_627837887_633683867_2619,@object # @abla_static_abla_fn_627837887_633683867_2619
	.section	.bss.abla_static_abla_fn_627837887_633683867_2619,"aw",@nobits
	.p2align	3, 0x0
abla_static_abla_fn_627837887_633683867_2619:
	.space	12
	.size	abla_static_abla_fn_627837887_633683867_2619, 12

	.type	abla_static_abla_fn_627837887_633683867_2625,@object # @abla_static_abla_fn_627837887_633683867_2625
	.section	.bss.abla_static_abla_fn_627837887_633683867_2625,"aw",@nobits
	.p2align	3, 0x0
abla_static_abla_fn_627837887_633683867_2625:
	.space	12
	.size	abla_static_abla_fn_627837887_633683867_2625, 12

	.type	.Labla_string_abla_fn_627837887_633683867_2633.native.mutable.u32s,@object # @abla_string_abla_fn_627837887_633683867_2633.native.mutable.u32s
	.section	.data..Labla_string_abla_fn_627837887_633683867_2633.native.mutable.u32s,"aw",@progbits
	.p2align	2, 0x0
.Labla_string_abla_fn_627837887_633683867_2633.native.mutable.u32s:
	.long	1                               # 0x1
	.long	1                               # 0x1
	.long	1                               # 0x1
	.size	.Labla_string_abla_fn_627837887_633683867_2633.native.mutable.u32s, 12

	.type	abla_static_abla_fn_627837887_633683867_2639,@object # @abla_static_abla_fn_627837887_633683867_2639
	.section	.bss.abla_static_abla_fn_627837887_633683867_2639,"aw",@nobits
	.p2align	3, 0x0
abla_static_abla_fn_627837887_633683867_2639:
	.space	12
	.size	abla_static_abla_fn_627837887_633683867_2639, 12

	.type	abla_static_abla_fn_627837887_633683867_2645,@object # @abla_static_abla_fn_627837887_633683867_2645
	.section	.bss.abla_static_abla_fn_627837887_633683867_2645,"aw",@nobits
	.p2align	3, 0x0
abla_static_abla_fn_627837887_633683867_2645:
	.space	24
	.size	abla_static_abla_fn_627837887_633683867_2645, 24

	.type	abla_static_abla_fn_627837887_633683867_2651.0,@object # @abla_static_abla_fn_627837887_633683867_2651.0
	.section	.bss.abla_static_abla_fn_627837887_633683867_2651.0,"aw",@nobits
	.p2align	3, 0x0
abla_static_abla_fn_627837887_633683867_2651.0:
	.long	0                               # 0x0
	.size	abla_static_abla_fn_627837887_633683867_2651.0, 4

	.type	abla_static_abla_fn_627837887_633683867_2657.0,@object # @abla_static_abla_fn_627837887_633683867_2657.0
	.section	.bss.abla_static_abla_fn_627837887_633683867_2657.0,"aw",@nobits
	.p2align	3, 0x0
abla_static_abla_fn_627837887_633683867_2657.0:
	.long	0                               # 0x0
	.size	abla_static_abla_fn_627837887_633683867_2657.0, 4

	.type	abla_static_abla_fn_627837887_633683867_2663,@object # @abla_static_abla_fn_627837887_633683867_2663
	.section	.bss.abla_static_abla_fn_627837887_633683867_2663,"aw",@nobits
	.p2align	3, 0x0
abla_static_abla_fn_627837887_633683867_2663:
	.space	12
	.size	abla_static_abla_fn_627837887_633683867_2663, 12

	.type	.Labla_string_abla_fn_627837887_633683867_2670.native.mutable.u32s,@object # @abla_string_abla_fn_627837887_633683867_2670.native.mutable.u32s
	.section	.data..Labla_string_abla_fn_627837887_633683867_2670.native.mutable.u32s,"aw",@progbits
	.p2align	2, 0x0
.Labla_string_abla_fn_627837887_633683867_2670.native.mutable.u32s:
	.long	3007315967                      # 0xb33fffff
	.long	0                               # 0x0
	.size	.Labla_string_abla_fn_627837887_633683867_2670.native.mutable.u32s, 8

	.type	.Labla_string_abla_fn_627837887_633683867_2675.native.bytes,@object # @abla_string_abla_fn_627837887_633683867_2675.native.bytes
	.section	.rodata.abla.abla_string_abla_fn_627837887_633683867_2675.native.bytes,"aMS",@progbits,1,unique,30
	.p2align	3, 0x0
.Labla_string_abla_fn_627837887_633683867_2675.native.bytes:
	.asciz	"/dev/uart"
	.size	.Labla_string_abla_fn_627837887_633683867_2675.native.bytes, 10

	.type	.Labla_string_abla_fn_627837887_633683867_2698.native.u32s,@object # @abla_string_abla_fn_627837887_633683867_2698.native.u32s
	.section	.rodata..Labla_string_abla_fn_627837887_633683867_2698.native.u32s,"a",@progbits
	.p2align	2, 0x0
.Labla_string_abla_fn_627837887_633683867_2698.native.u32s:
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	abla_fn_748403643_303058322_direct
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	0                               # 0x0
	.size	.Labla_string_abla_fn_627837887_633683867_2698.native.u32s, 64

	.type	.Labla_string_abla_fn_627837887_633683867_2713.native.u32s,@object # @abla_string_abla_fn_627837887_633683867_2713.native.u32s
	.section	.rodata..Labla_string_abla_fn_627837887_633683867_2713.native.u32s,"a",@progbits
	.p2align	2, 0x0
.Labla_string_abla_fn_627837887_633683867_2713.native.u32s:
	.long	abla_fn_369693268_153718691_direct
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	abla_fn_870340349_402015619_direct
	.size	.Labla_string_abla_fn_627837887_633683867_2713.native.u32s, 24

	.type	.Labla_string_abla_fn_627837887_633683867_2747.native.u32s,@object # @abla_string_abla_fn_627837887_633683867_2747.native.u32s
	.section	.rodata..Labla_string_abla_fn_627837887_633683867_2747.native.u32s,"a",@progbits
	.p2align	2, 0x0
.Labla_string_abla_fn_627837887_633683867_2747.native.u32s:
	.long	abla_fn_315095783_945796533_direct
	.long	0                               # 0x0
	.long	abla_fn_422061067_936412767_direct
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	abla_fn_322401140_130420176_direct
	.long	abla_fn_546143059_927569099_direct
	.long	abla_fn_500858384_48428969_direct
	.long	abla_fn_925668403_79311636_direct
	.long	0                               # 0x0
	.long	abla_fn_64859000_962709316_direct
	.long	.Labla_string_abla_fn_627837887_633683867_2698.native.u32s
	.long	.Labla_string_abla_fn_627837887_633683867_2713.native.u32s
	.size	.Labla_string_abla_fn_627837887_633683867_2747.native.u32s, 52

	.type	abla_esp32_system_init_110_vfs_uart,@object # @abla_esp32_system_init_110_vfs_uart
	.section	.esp_system_init_fn.110,"aR",@progbits,unique,31
	.p2align	2, 0x0
abla_esp32_system_init_110_vfs_uart:
	.long	abla_fn_337303989_705926631_direct
	.long	1                               # 0x1
	.size	abla_esp32_system_init_110_vfs_uart, 8

	.type	abla_static_abla_fn_627837887_633683867_2759.0,@object # @abla_static_abla_fn_627837887_633683867_2759.0
	.section	.bss.abla_static_abla_fn_627837887_633683867_2759.0,"aw",@nobits
	.p2align	3, 0x0
abla_static_abla_fn_627837887_633683867_2759.0:
	.byte	0                               # 0x0
	.size	abla_static_abla_fn_627837887_633683867_2759.0, 1

	.type	abla_static_abla_fn_627837887_633683867_2765.0,@object # @abla_static_abla_fn_627837887_633683867_2765.0
	.section	.bss.abla_static_abla_fn_627837887_633683867_2765.0,"aw",@nobits
	.p2align	3, 0x0
abla_static_abla_fn_627837887_633683867_2765.0:
	.long	0                               # 0x0
	.size	abla_static_abla_fn_627837887_633683867_2765.0, 4

	.type	abla_static_abla_fn_627837887_633683867_2771.0,@object # @abla_static_abla_fn_627837887_633683867_2771.0
	.section	.bss.abla_static_abla_fn_627837887_633683867_2771.0,"aw",@nobits
	.p2align	3, 0x0
abla_static_abla_fn_627837887_633683867_2771.0:
	.long	0                               # 0x0
	.size	abla_static_abla_fn_627837887_633683867_2771.0, 4

	.type	.Labla_string_abla_fn_627837887_633683867_2776.native.mutable.bytes,@object # @abla_string_abla_fn_627837887_633683867_2776.native.mutable.bytes
	.section	.data..Labla_string_abla_fn_627837887_633683867_2776.native.mutable.bytes,"aw",@progbits
	.p2align	3, 0x0
.Labla_string_abla_fn_627837887_633683867_2776.native.mutable.bytes:
	.asciz	"/dev/uart/0\000/dev/console"
	.size	.Labla_string_abla_fn_627837887_633683867_2776.native.mutable.bytes, 25

	.type	.Labla_string_abla_fn_627837887_633683867_2806.native.mutable.u32s,@object # @abla_string_abla_fn_627837887_633683867_2806.native.mutable.u32s
	.section	.data..Labla_string_abla_fn_627837887_633683867_2806.native.mutable.u32s,"aw",@progbits
	.p2align	2, 0x0
.Labla_string_abla_fn_627837887_633683867_2806.native.mutable.u32s:
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	abla_fn_115387104_275846057_direct
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	0                               # 0x0
	.size	.Labla_string_abla_fn_627837887_633683867_2806.native.mutable.u32s, 64

	.type	.Labla_string_abla_fn_627837887_633683867_2823.native.mutable.u32s,@object # @abla_string_abla_fn_627837887_633683867_2823.native.mutable.u32s
	.section	.data..Labla_string_abla_fn_627837887_633683867_2823.native.mutable.u32s,"aw",@progbits
	.p2align	2, 0x0
.Labla_string_abla_fn_627837887_633683867_2823.native.mutable.u32s:
	.long	abla_fn_156319067_875660471_direct
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	abla_fn_891148129_194415638_direct
	.size	.Labla_string_abla_fn_627837887_633683867_2823.native.mutable.u32s, 24

	.type	.Labla_string_abla_fn_627837887_633683867_2859.native.mutable.u32s,@object # @abla_string_abla_fn_627837887_633683867_2859.native.mutable.u32s
	.section	.data..Labla_string_abla_fn_627837887_633683867_2859.native.mutable.u32s,"aw",@progbits
	.p2align	2, 0x0
.Labla_string_abla_fn_627837887_633683867_2859.native.mutable.u32s:
	.long	abla_fn_902582166_734695485_direct
	.long	0                               # 0x0
	.long	abla_fn_972528636_40049108_direct
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	abla_fn_51800387_177339318_direct
	.long	abla_fn_332235414_655482945_direct
	.long	abla_fn_276581088_959060495_direct
	.long	abla_fn_722127480_787560196_direct
	.long	0                               # 0x0
	.long	abla_fn_71339790_974836269_direct
	.long	.Labla_string_abla_fn_627837887_633683867_2806.native.mutable.u32s
	.long	.Labla_string_abla_fn_627837887_633683867_2823.native.mutable.u32s
	.size	.Labla_string_abla_fn_627837887_633683867_2859.native.mutable.u32s, 52

	.type	abla_esp32_system_init_119_vfs_console,@object # @abla_esp32_system_init_119_vfs_console
	.section	.esp_system_init_fn.119,"aR",@progbits,unique,32
	.p2align	2, 0x0
abla_esp32_system_init_119_vfs_console:
	.long	abla_fn_368411890_169521707_direct
	.long	1                               # 0x1
	.size	abla_esp32_system_init_119_vfs_console, 8

	.type	abla_static_abla_fn_627837887_633683867_3205.0,@object # @abla_static_abla_fn_627837887_633683867_3205.0
	.section	.bss.abla_static_abla_fn_627837887_633683867_3205.0,"aw",@nobits
	.p2align	3, 0x0
abla_static_abla_fn_627837887_633683867_3205.0:
	.long	0                               # 0x0
	.size	abla_static_abla_fn_627837887_633683867_3205.0, 4

	.type	abla_static_abla_fn_627837887_633683867_3211,@object # @abla_static_abla_fn_627837887_633683867_3211
	.section	.bss.abla_static_abla_fn_627837887_633683867_3211,"aw",@nobits
	.p2align	3, 0x0
abla_static_abla_fn_627837887_633683867_3211:
	.space	4
	.size	abla_static_abla_fn_627837887_633683867_3211, 4

	.type	.Labla_string_abla_fn_627837887_633683867_3230.native.bytes,@object # @abla_string_abla_fn_627837887_633683867_3230.native.bytes
	.section	.rodata.abla.abla_string_abla_fn_627837887_633683867_3230.native.bytes,"a",@progbits
	.p2align	3, 0x0
.Labla_string_abla_fn_627837887_633683867_3230.native.bytes:
	.asciz	"E (%lu) %s: load_partitions returned 0x%\000\000"
	.size	.Labla_string_abla_fn_627837887_633683867_3230.native.bytes, 43

	.type	.Labla_string_abla_fn_627837887_633683867_3256.native.bytes,@object # @abla_string_abla_fn_627837887_633683867_3256.native.bytes
	.section	.rodata.abla.abla_string_abla_fn_627837887_633683867_3256.native.bytes,"a",@progbits
	.p2align	3, 0x0
.Labla_string_abla_fn_627837887_633683867_3256.native.bytes:
	.asciz	"partition\000\000\000E (%lu) %s: No MD5 found in partition table\n\000\000\000\000E (%lu) %s: Partition table MD5 mismatch\000"
	.size	.Labla_string_abla_fn_627837887_633683867_3256.native.bytes, 102

	.type	.Labla_string_abla_fn_627837887_633683867_3487.native.bytes,@object # @abla_string_abla_fn_627837887_633683867_3487.native.bytes
	.section	.rodata.abla.abla_string_abla_fn_627837887_633683867_3487.native.bytes,"aMS",@progbits,1,unique,33
	.p2align	3, 0x0
.Labla_string_abla_fn_627837887_633683867_3487.native.bytes:
	.asciz	"spi_flash_munmap"
	.size	.Labla_string_abla_fn_627837887_633683867_3487.native.bytes, 17

	.type	.Labla_string_abla_fn_627837887_633683867_3494.native.bytes,@object # @abla_string_abla_fn_627837887_633683867_3494.native.bytes
	.section	.rodata.abla.abla_string_abla_fn_627837887_633683867_3494.native.bytes,"a",@progbits
	.p2align	3, 0x0
.Labla_string_abla_fn_627837887_633683867_3494.native.bytes:
	.asciz	"new_array_id < block_nums\000\000\000//IDF/components/spi_flash/flash_mmap.c"
	.size	.Labla_string_abla_fn_627837887_633683867_3494.native.bytes, 68

	.type	.Labla_string_abla_fn_627837887_633683867_3501.native.bytes,@object # @abla_string_abla_fn_627837887_633683867_3501.native.bytes
	.section	.rodata.abla.abla_string_abla_fn_627837887_633683867_3501.native.bytes,"a",@progbits
	.p2align	3, 0x0
.Labla_string_abla_fn_627837887_633683867_3501.native.bytes:
	.asciz	"0 && \"invalid handle, or handle already unmapped\000"
	.size	.Labla_string_abla_fn_627837887_633683867_3501.native.bytes, 50

	.type	abla_static_abla_fn_627837887_633683867_3539.0,@object # @abla_static_abla_fn_627837887_633683867_3539.0
	.section	.bss.abla_static_abla_fn_627837887_633683867_3539.0,"aw",@nobits
	.p2align	3, 0x0
abla_static_abla_fn_627837887_633683867_3539.0:
	.long	0                               # 0x0
	.size	abla_static_abla_fn_627837887_633683867_3539.0, 4

	.type	.Labla_string_abla_fn_627837887_633683867_3544.native.bytes,@object # @abla_string_abla_fn_627837887_633683867_3544.native.bytes
	.section	.rodata.abla.abla_string_abla_fn_627837887_633683867_3544.native.bytes,"a",@progbits
	.p2align	3, 0x0
.Labla_string_abla_fn_627837887_633683867_3544.native.bytes:
	.asciz	"esp_ota_get_running_partitio\000"
	.size	.Labla_string_abla_fn_627837887_633683867_3544.native.bytes, 30

	.type	.Labla_string_abla_fn_627837887_633683867_3551.native.bytes,@object # @abla_string_abla_fn_627837887_633683867_3551.native.bytes
	.section	.rodata.abla.abla_string_abla_fn_627837887_633683867_3551.native.bytes,"a",@progbits
	.p2align	3, 0x0
.Labla_string_abla_fn_627837887_633683867_3551.native.bytes:
	.asciz	"phys_offs != SPI_FLASH_CACHE2PHYS_FAIL\000\000//IDF/components/app_update/esp_ota_ops.c\000\000\000it != NU\000\000"
	.size	.Labla_string_abla_fn_627837887_633683867_3551.native.bytes, 95

	.type	.Labla_string_abla_fn_627837887_633683867_3561.native.u32s,@object # @abla_string_abla_fn_627837887_633683867_3561.native.u32s
	.section	.rodata..Labla_string_abla_fn_627837887_633683867_3561.native.u32s,"a",@progbits
	.p2align	2, 0x0
.Labla_string_abla_fn_627837887_633683867_3561.native.u32s:
	.long	abla_fn_945139464_207419804_direct
	.size	.Labla_string_abla_fn_627837887_633683867_3561.native.u32s, 4

	.type	.Labla_string_abla_fn_627837887_633683867_3621.native.bytes,@object # @abla_string_abla_fn_627837887_633683867_3621.native.bytes
	.section	.rodata.abla.abla_string_abla_fn_627837887_633683867_3621.native.bytes,"aMS",@progbits,1,unique,34
	.p2align	3, 0x0
.Labla_string_abla_fn_627837887_633683867_3621.native.bytes:
	.asciz	"spi_flash_os_check_yield"
	.size	.Labla_string_abla_fn_627837887_633683867_3621.native.bytes, 25

	.type	abla_static_abla_fn_627837887_633683867_3629,@object # @abla_static_abla_fn_627837887_633683867_3629
	.section	.bss.abla_static_abla_fn_627837887_633683867_3629,"aw",@nobits
	.p2align	3, 0x0
abla_static_abla_fn_627837887_633683867_3629:
	.space	20
	.size	abla_static_abla_fn_627837887_633683867_3629, 20

	.type	.Labla_string_abla_fn_627837887_633683867_3634.native.bytes,@object # @abla_string_abla_fn_627837887_633683867_3634.native.bytes
	.section	.rodata.abla.abla_string_abla_fn_627837887_633683867_3634.native.bytes,"a",@progbits
	.p2align	3, 0x0
.Labla_string_abla_fn_627837887_633683867_3634.native.bytes:
	.asciz	"chip_status == 0\000\000\000\000//IDF/components/spi_flash/spi_flash_os_func_app\000\000"
	.size	.Labla_string_abla_fn_627837887_633683867_3634.native.bytes, 71

	.type	.Labla_string_abla_fn_627837887_633683867_3669.native.mutable.u32s,@object # @abla_string_abla_fn_627837887_633683867_3669.native.mutable.u32s
	.section	.data..Labla_string_abla_fn_627837887_633683867_3669.native.mutable.u32s,"aw",@progbits
	.p2align	2, 0x0
.Labla_string_abla_fn_627837887_633683867_3669.native.mutable.u32s:
	.long	abla_fn_986977340_555538594_direct
	.long	abla_fn_526172849_945061129_direct
	.long	abla_fn_563991449_691852434_direct
	.long	abla_fn_384677981_576167795_direct
	.long	abla_fn_367195186_502328401_direct
	.long	abla_fn_518574188_300923136_direct
	.long	abla_fn_792983549_415993329_direct
	.long	abla_fn_689607981_668554081_direct
	.long	0                               # 0x0
	.long	abla_fn_453137308_422103327_direct
	.size	.Labla_string_abla_fn_627837887_633683867_3669.native.mutable.u32s, 40

	.type	abla_static_abla_fn_627837887_633683867_3703.0,@object # @abla_static_abla_fn_627837887_633683867_3703.0
	.section	.bss.abla_static_abla_fn_627837887_633683867_3703.0,"aw",@nobits
	.p2align	3, 0x0
abla_static_abla_fn_627837887_633683867_3703.0:
	.byte	0                               # 0x0
	.size	abla_static_abla_fn_627837887_633683867_3703.0, 1

	.type	abla_static_abla_fn_627837887_633683867_3709,@object # @abla_static_abla_fn_627837887_633683867_3709
	.section	.bss.abla_static_abla_fn_627837887_633683867_3709,"aw",@nobits
	.p2align	3, 0x0
abla_static_abla_fn_627837887_633683867_3709:
	.space	48
	.size	abla_static_abla_fn_627837887_633683867_3709, 48

	.type	.Labla_string_abla_fn_627837887_633683867_3725.native.mutable.u32s,@object # @abla_string_abla_fn_627837887_633683867_3725.native.mutable.u32s
	.section	.data..Labla_string_abla_fn_627837887_633683867_3725.native.mutable.u32s,"aw",@progbits
	.p2align	2, 0x0
.Labla_string_abla_fn_627837887_633683867_3725.native.mutable.u32s:
	.long	abla_static_abla_fn_627837887_633683867_3709
	.long	0                               # 0x0
	.long	.Labla_string_abla_fn_627837887_633683867_1707.native.mutable.u32s
	.long	0                               # 0x0
	.long	3                               # 0x3
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	0                               # 0x0
	.size	.Labla_string_abla_fn_627837887_633683867_3725.native.mutable.u32s, 36

	.type	abla_esp32_system_init_130_init_flash,@object # @abla_esp32_system_init_130_init_flash
	.section	.esp_system_init_fn.130,"aR",@progbits,unique,35
	.p2align	2, 0x0
abla_esp32_system_init_130_init_flash:
	.long	abla_fn_300212323_608936396_direct
	.long	1                               # 0x1
	.size	abla_esp32_system_init_130_init_flash, 8

	.type	.Labla_string_abla_fn_627837887_633683867_3748.native.bytes,@object # @abla_string_abla_fn_627837887_633683867_3748.native.bytes
	.section	.rodata.abla.abla_string_abla_fn_627837887_633683867_3748.native.bytes,"aMS",@progbits,1,unique,36
	.p2align	3, 0x0
.Labla_string_abla_fn_627837887_633683867_3748.native.bytes:
	.asciz	"chip_generic"
	.size	.Labla_string_abla_fn_627837887_633683867_3748.native.bytes, 13

	.type	.Labla_string_abla_fn_627837887_633683867_3755.native.bytes,@object # @abla_string_abla_fn_627837887_633683867_3755.native.bytes
	.section	.rodata.abla.abla_string_abla_fn_627837887_633683867_3755.native.bytes,"aMS",@progbits,1,unique,37
	.p2align	3, 0x0
.Labla_string_abla_fn_627837887_633683867_3755.native.bytes:
	.asciz	"spi_flash_chip_generic_get_write_protect"
	.size	.Labla_string_abla_fn_627837887_633683867_3755.native.bytes, 41

	.type	.Labla_string_abla_fn_627837887_633683867_3762.native.mutable.bytes,@object # @abla_string_abla_fn_627837887_633683867_3762.native.mutable.bytes
	.section	.data..Labla_string_abla_fn_627837887_633683867_3762.native.mutable.bytes,"aw",@progbits
	.p2align	3, 0x0
.Labla_string_abla_fn_627837887_633683867_3762.native.mutable.bytes:
	.asciz	"\b\n\b\b\000"
	.size	.Labla_string_abla_fn_627837887_633683867_3762.native.mutable.bytes, 6

	.type	.Labla_string_abla_fn_627837887_633683867_3769.native.mutable.bytes,@object # @abla_string_abla_fn_627837887_633683867_3769.native.mutable.bytes
	.section	.data..Labla_string_abla_fn_627837887_633683867_3769.native.mutable.bytes,"aw",@progbits
	.p2align	3, 0x0
.Labla_string_abla_fn_627837887_633683867_3769.native.mutable.bytes:
	.asciz	"\004\006\b\b\000"
	.size	.Labla_string_abla_fn_627837887_633683867_3769.native.mutable.bytes, 6

	.type	.Labla_string_abla_fn_627837887_633683867_3776.native.bytes,@object # @abla_string_abla_fn_627837887_633683867_3776.native.bytes
	.section	.rodata.abla.abla_string_abla_fn_627837887_633683867_3776.native.bytes,"a",@progbits
	.p2align	3, 0x0
.Labla_string_abla_fn_627837887_633683867_3776.native.bytes:
	.asciz	"out_write_protect!=NULL\000//IDF/components/spi_flash/spi_flash_chip_generic.c"
	.size	.Labla_string_abla_fn_627837887_633683867_3776.native.bytes, 76

	.type	.Labla_string_abla_fn_627837887_633683867_3783.native.bytes,@object # @abla_string_abla_fn_627837887_633683867_3783.native.bytes
	.section	.rodata.abla.abla_string_abla_fn_627837887_633683867_3783.native.bytes,"aMS",@progbits,1,unique,38
	.p2align	3, 0x0
.Labla_string_abla_fn_627837887_633683867_3783.native.bytes:
	.asciz	"E (%lu) %s: No response from device when trying to retrieve Unique ID\n\n"
	.size	.Labla_string_abla_fn_627837887_633683867_3783.native.bytes, 72

	.type	.Labla_string_abla_fn_627837887_633683867_3813.native.mutable.u32s,@object # @abla_string_abla_fn_627837887_633683867_3813.native.mutable.u32s
	.section	.data..Labla_string_abla_fn_627837887_633683867_3813.native.mutable.u32s,"aw",@progbits
	.p2align	2, 0x0
.Labla_string_abla_fn_627837887_633683867_3813.native.mutable.u32s:
	.long	200000                          # 0x30d40
	.long	4000000                         # 0x3d0900
	.long	4100000                         # 0x3e8fa0
	.long	600000                          # 0x927c0
	.long	500000                          # 0x7a120
	.size	.Labla_string_abla_fn_627837887_633683867_3813.native.mutable.u32s, 20

	.type	.Labla_string_abla_fn_627837887_633683867_3838.native.mutable.u32s,@object # @abla_string_abla_fn_627837887_633683867_3838.native.mutable.u32s
	.section	.data..Labla_string_abla_fn_627837887_633683867_3838.native.mutable.u32s,"aw",@progbits
	.p2align	2, 0x0
.Labla_string_abla_fn_627837887_633683867_3838.native.mutable.u32s:
	.long	abla_fn_954586519_862037725_direct
	.long	abla_fn_471788702_517623392_direct
	.long	abla_fn_16377822_540100096_direct
	.long	abla_fn_931545567_835396853_direct
	.long	abla_fn_103051375_4624815_direct
	.long	abla_fn_15173205_827940961_direct
	.size	.Labla_string_abla_fn_627837887_633683867_3838.native.mutable.u32s, 24

	.type	.Labla_string_abla_fn_627837887_633683867_3851.native.bytes,@object # @abla_string_abla_fn_627837887_633683867_3851.native.bytes
	.section	.rodata.abla.abla_string_abla_fn_627837887_633683867_3851.native.bytes,"aMS",@progbits,1,unique,39
	.p2align	3, 0x0
.Labla_string_abla_fn_627837887_633683867_3851.native.bytes:
	.asciz	"chip_wb"
	.size	.Labla_string_abla_fn_627837887_633683867_3851.native.bytes, 8

	.type	.Labla_string_abla_fn_627837887_633683867_3858.native.bytes,@object # @abla_string_abla_fn_627837887_633683867_3858.native.bytes
	.section	.rodata.abla.abla_string_abla_fn_627837887_633683867_3858.native.bytes,"aMS",@progbits,1,unique,40
	.p2align	3, 0x0
.Labla_string_abla_fn_627837887_633683867_3858.native.bytes:
	.asciz	"E (%lu) %s: configure host io mode failed - unsupported\n"
	.size	.Labla_string_abla_fn_627837887_633683867_3858.native.bytes, 57

	.type	.Labla_string_abla_fn_627837887_633683867_3865.native.bytes,@object # @abla_string_abla_fn_627837887_633683867_3865.native.bytes
	.section	.rodata.abla.abla_string_abla_fn_627837887_633683867_3865.native.bytes,"aMS",@progbits,1,unique,41
	.p2align	3, 0x0
.Labla_string_abla_fn_627837887_633683867_3865.native.bytes:
	.asciz	"gd"
	.size	.Labla_string_abla_fn_627837887_633683867_3865.native.bytes, 3

	.type	.Labla_string_abla_fn_627837887_633683867_3951.native.mutable.u32s,@object # @abla_string_abla_fn_627837887_633683867_3951.native.mutable.u32s
	.section	.data..Labla_string_abla_fn_627837887_633683867_3951.native.mutable.u32s,"aw",@progbits
	.p2align	2, 0x0
.Labla_string_abla_fn_627837887_633683867_3951.native.mutable.u32s:
	.long	.Labla_string_abla_fn_627837887_633683867_3865.native.bytes
	.long	.Labla_string_abla_fn_627837887_633683867_3813.native.mutable.u32s
	.long	abla_fn_180484491_182634345_direct
	.long	abla_fn_415918908_162849687_direct
	.long	abla_fn_290333585_319380335_direct
	.long	abla_fn_746975339_875058026_direct
	.long	abla_fn_616072200_862438830_direct
	.long	abla_fn_407052752_528196726_direct
	.long	4096                            # 0x1000
	.long	65536                           # 0x10000
	.long	abla_fn_265241106_404917902_direct
	.long	abla_fn_87105386_416578553_direct
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	abla_fn_283351212_772728346_direct
	.long	abla_fn_311395512_176419446_direct
	.long	abla_fn_317871032_550540883_direct
	.long	256                             # 0x100
	.long	abla_fn_500878493_387552107_direct
	.long	abla_fn_179040964_268748625_direct
	.long	abla_fn_678785486_82486944_direct
	.long	abla_fn_40032114_308672228_direct
	.long	0                               # 0x0
	.long	abla_fn_526680780_930051525_direct
	.long	abla_fn_491534404_387327923_direct
	.long	abla_fn_789329514_748459409_direct
	.long	abla_fn_838066626_846918671_direct
	.long	abla_fn_61106253_836094646_direct
	.long	abla_fn_994348769_172344277_direct
	.size	.Labla_string_abla_fn_627837887_633683867_3951.native.mutable.u32s, 124

	.type	port_xSchedulerRunning,@object  # @port_xSchedulerRunning
	.section	.bss.port_xSchedulerRunning,"awR",@nobits
	.p2align	3, 0x0
port_xSchedulerRunning:
	.space	8
	.size	port_xSchedulerRunning, 8

	.type	abla_static_abla_fn_627837887_633683867_4085.0,@object # @abla_static_abla_fn_627837887_633683867_4085.0
	.section	.bss.abla_static_abla_fn_627837887_633683867_4085.0,"aw",@nobits
	.p2align	3, 0x0
abla_static_abla_fn_627837887_633683867_4085.0:
	.byte	0                               # 0x0
	.size	abla_static_abla_fn_627837887_633683867_4085.0, 1

	.type	port_interruptNesting,@object   # @port_interruptNesting
	.section	.bss.port_interruptNesting,"awR",@nobits
	.p2align	3, 0x0
port_interruptNesting:
	.space	8
	.size	port_interruptNesting, 8

	.type	port_switch_flag,@object        # @port_switch_flag
	.section	.bss.port_switch_flag,"awR",@nobits
	.p2align	3, 0x0
port_switch_flag:
	.space	8
	.size	port_switch_flag, 8

	.type	pxCurrentTCBs,@object           # @pxCurrentTCBs
	.section	.bss.pxCurrentTCBs,"awR",@nobits
	.p2align	3, 0x0
pxCurrentTCBs:
	.space	8
	.size	pxCurrentTCBs, 8

	.type	abla_static_abla_fn_627837887_633683867_4112,@object # @abla_static_abla_fn_627837887_633683867_4112
	.section	.bss.abla_static_abla_fn_627837887_633683867_4112,"aw",@nobits
	.p2align	3, 0x0
abla_static_abla_fn_627837887_633683867_4112:
	.space	4
	.size	abla_static_abla_fn_627837887_633683867_4112, 4

	.type	_xt_coproc_owner_sa,@object     # @_xt_coproc_owner_sa
	.section	.bss._xt_coproc_owner_sa,"awR",@nobits
	.p2align	3, 0x0
_xt_coproc_owner_sa:
	.space	8
	.size	_xt_coproc_owner_sa, 8

	.type	_xt_coproc_owner_sa_lock,@object # @_xt_coproc_owner_sa_lock
	.section	.bss._xt_coproc_owner_sa_lock,"awR",@nobits
	.p2align	3, 0x0
_xt_coproc_owner_sa_lock:
	.space	4
	.size	_xt_coproc_owner_sa_lock, 4

	.type	port_IntStack,@object           # @port_IntStack
	.section	.bss.port_IntStack,"awR",@nobits
	.p2align	3, 0x0
port_IntStack:
	.space	3088
	.size	port_IntStack, 3088

	.type	port_uxCoreStartupDone,@object  # @port_uxCoreStartupDone
	.section	.bss.port_uxCoreStartupDone,"awR",@nobits
	.p2align	3, 0x0
port_uxCoreStartupDone:
	.space	8
	.size	port_uxCoreStartupDone, 8

	.type	abla_xtensa_window_spill_required,@object # @abla_xtensa_window_spill_required
	.section	.rodata.abla.xtensa.window_spill_required,"aR",@progbits,unique,42
	.p2align	2, 0x0
abla_xtensa_window_spill_required:
	.asciz	"\001\000\000\000\001\000\000"
	.size	abla_xtensa_window_spill_required, 8

	.type	errno,@object                   # @errno
	.section	.tdata.abla_errno,"awTR",@progbits,unique,43
	.p2align	2, 0x0
errno:
	.space	4
	.size	errno, 4

	.type	abla_static_abla_fn_742253470_491478038_1,@object # @abla_static_abla_fn_742253470_491478038_1
	.section	.bss.abla_static_abla_fn_742253470_491478038_1,"aw",@nobits
	.p2align	3, 0x0
abla_static_abla_fn_742253470_491478038_1:
	.space	8
	.size	abla_static_abla_fn_742253470_491478038_1, 8

	.type	.Lswitch.table.abla_fn_765949846_578441510_direct,@object # @switch.table.abla_fn_765949846_578441510_direct
	.section	.rodata..Lswitch.table.abla_fn_765949846_578441510_direct,"a",@progbits
	.p2align	2, 0x0
.Lswitch.table.abla_fn_765949846_578441510_direct:
	.ascii	"(null"
	.size	.Lswitch.table.abla_fn_765949846_578441510_direct, 5

	.section	".note.GNU-stack","",@progbits
